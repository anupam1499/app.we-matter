<?php include("../../../includes/config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

	body {
		font-family: 'Montserrat', sans-serif;
	}

	/* Start Reset Some Elements */ 
	html,
	body,
	h1,
	ol,
	ul {
	   margin: 0;
	   padding: 0;
	}

	ul,
	ol {
	   list-style: none;
	}

	a {
	   text-decoration: none;
	}

	.clearfix {
	   clear: both;
	}
	/* End Reset Some Elements */

	.container {
	   width: 100%;
	   margin: 0 auto;
	}

	/* Start Logo */
	.navbar .container .logo {
	   width: 15%;
	   float: left;
	   padding-top: 8px
	}

	/* End Logo */
	/* Start Links */
	.navbar .container .links {
	   width: 85%;
	   float: left;
	}

	.navbar .container .links ul {
	   float: right;
	}

	.navbar .container .links ul li {
	   display: inline-block;
	   padding: 15px;
	}

	.navbar .container .links ul li a {
	   color: #03A9F4;
	   font-size: 18px;
	   font-family: cursive;
	}
	/* End Links */
	</style>
    <title>Scorecards</title>
</head>
<body>
    <div class="navbar">
        <div class="container">
            <div class="logo">
                <img src="<?php echo (isset($account_logo_url)?$account_logo_url:PROTOCOL.WEBSITE_URL."/asset/image/other-logo.png");?>" style="height:50px;"/>
            </div>
            <div class="links">
                <ul>
                    <div class="logo"><img src="<?php echo PROTOCOL.WEBSITE_URL."/asset/image/other-logo.png";?>"    style="height:50px;"/></div>
                </ul>
            </div>
           <div class="clearfix"></div>
        </div>
     </div>
     <hr>
</body>
</html>
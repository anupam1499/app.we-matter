<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

	body {
		font-family: 'Montserrat', sans-serif;
	}
	#container {
	   width: 100%;
	   margin: 0 auto;
	   font-size: 25px;
	}
	</style>
    <title>Scorecards</title>
</head>
<body>
	<div id="container">
		<div id="center" style="text-align:center;"><span style="color:#053B6D">&copy; <?php echo date("Y");?> The</span><span style="color:#EE7D1F">Other</span> <span style="color:#053B6D">2</span> <span style="color:#EE7D1F">Thirds</span> <span style="color:#053B6D">Consulting</span> <span style="color:#EE7D1F">LLP</span></div>
	</div>
</body>
</html>
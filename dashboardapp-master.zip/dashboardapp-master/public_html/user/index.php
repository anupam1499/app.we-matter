<? include("../../includes/config.php");
if(!logged_in())
	redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
else
	redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
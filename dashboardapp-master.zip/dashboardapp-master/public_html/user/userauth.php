<?
include('../../includes/config.php');
$title = "Userauth";
$method="login";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];

if(logged_in()&&$method!="logout"&&$method!="change_password"){
	if($_REQUEST["output"]==="json"){
		json_output(user_get($_SESSION["user_id"]));
		exit(0);
	}else{
		redirect_to(PROTOCOL.WEBSITE_URL."/index.php");
	}
}
if($method==="logout"){
	logout();
	if($_REQUEST["output"]==="json"){
		json_message("User not Signed in");
		exit(0);
	}else{
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
	}
}else if($method==="change_password"){
	$response = "Invalid Request";
	$user = user_get($_SESSION["user_id"]);
	if(isset($user["user_id"])){			
		recover_password($user["email"],$_REQUEST["password"]);
		$password = $_REQUEST["password"];
		$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login&email=".urlencode($user["email"])."&password=".urlencode($password)."&submit=login";
		$message= "You have changed your password <br>username: ".$user["email"]."<br>password: ".$password."<br><br>You can click on the link to login";
		$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
		add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$user["email"],"",$user["user_id"],APP_NAME.": Account Password Changed",$message,"Login",$login_url,1,0,true);
		$response = "Password is changed";
	}
	if($_REQUEST["output"]==="json"){
		json_message($response);
		exit(0);
	}else{ 
		redirect_to(PROTOCOL.WEBSITE_URL);
	}
}else if($method==="autologin"){
	$auth = auth_get($_REQUEST["auth"],5);
	if(isset($auth["email"])){
		$user = user_get($auth["email"]);
		if ($user) {
			$_SESSION["user_id"]=$user["user_id"];
			$_SESSION["email"]= $user["email"];
			LoginSession();
			redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
		}else{
			redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
		}
	}else{
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
	}
}else if($method==="register"&&SELF_REGISTRATION){
	$title = "Register";
	if(!isset($_REQUEST["submit"])){
		include(userauth_header());
		display_message();
		?>
		<div class="p-5">
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-2">Register to <?echo APP_NAME;?></h1>
			<p class="mb-4">Just enter your email address below and we'll send you a link to set your password!</p>
		  </div>
		  <form action="userauth.php" class="user">
		  <input type="hidden" name="method" value="register">
			<div class="form-group">
			  <input name="email" type="email" class="form-control form-control-user" id="email" placeholder="Enter Email Address..." value="<?echo $_REQUEST["email"];?>">
			</div>
			<input id="submit" name="submit" type="submit" class="btn btn-primary btn-user btn-block" value="Register"/>
			</form>
			<hr>
			<?if($hybridauth_config["providers"]["Google"]["enabled"]){?>
			<a href="userauth.php?method=login&provider=Google" class="btn btn-google btn-user btn-block">
			  <i class="fab fa-google fa-fw"></i> Login with Google
			</a>
			<?}
			if($hybridauth_config["providers"]["Facebook"]["enabled"]){
			?>
			<a href="userauth.php?method=login&provider=Facebook" class="btn btn-facebook btn-user btn-block">
			  <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
			</a>
			<?
			}if($hybridauth_config["providers"]["Twitter"]["enabled"]){
			?>
			<a href="userauth.php?method=login&provider=Twitter" class="btn btn-info btn-user btn-block">
			  <i class="fab fa-twitter fa-fw"></i> Login with Twitter
			</a>
			<?
			}if($hybridauth_config["providers"]["LinkedIn"]["enabled"]){
			?>
			<a href="userauth.php?method=login&provider=Linkedin" class="btn btn-info btn-user btn-block">
			  <i class="fab fa-linkedin-in fa-fw"></i> Login with Linkedin
			</a>
			<?
			}
			?>
		  <hr>
		  <div class="text-center">
			<a class="small" href="userauth.php?method=forgot_password">Forgot you Password!</a>
		  </div>
		  <div class="text-center">
			<a class="small" href="userauth.php?method=login">Already have an account? Login!</a>
		  </div>
		</div>
		<?
		include(userauth_footer());
	}else{
		if(!user_get($_REQUEST["email"])){
			$result = register($_REQUEST["email"]);
			if($_REQUEST["output"]==="json"){
				if($result){
					$respone["status"] = "success";
					$respone["message"] = "Email has been sent to your account. Please verify it";
					json_output($respone);
				}else{
					$respone["status"] = "danger";
					$respone["message"] = "Email has not been sent to your account. Please try again later";
					json_output($respone);
				}	
			}else{
				if($result){
					session_message("Email has been sent to your account. Please verify it","success");
					redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
				}else{
					session_message("Email has not been sent to your account. Please try again later","danger");
					redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
				}
			}
		}else{
			if($_REQUEST["output"]==="json"){
				$respone["status"] = "danger";
				$respone["message"] = "Email is already registered please try recovering your account";
				json_output($respone);
			}else{
				session_message("Email is already registered please try recovering your account","danger");
				redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=forgot_password");
			}
		}
	}
}else if($method==="new_user"&&SELF_REGISTRATION){
	$title = "New User";
	$auth = auth_get($_REQUEST["auth_id"],"1");
	if(user_get($_REQUEST["email"])){
		session_message("Email is already registered please try recovering your account","danger");
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=forgot_password&email=".$_REQUEST["email"]);
	}
	if($auth["auth_code"]===$_REQUEST["auth_code"]&&$auth["email"]===$_REQUEST["email"]&&$auth["auth_type"]==="1"){
		if(!isset($_REQUEST["submit"])){
		include(userauth_header());
		display_message();
		?>
		<div class="p-5">
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-2">Welcome to <?echo APP_NAME;?></h1>
			<p class="mb-4">Great, We have verified your user account, you can set your password</p>
		  </div>
		  <form action="userauth.php" class="user">
			<input type="hidden" name="method" value="new_user">
			<input type="hidden" name="auth_id" value="<?echo $_REQUEST["auth_id"];?>">
			<input type="hidden" name="auth_code" value="<?echo $_REQUEST["auth_code"];?>">
			<input type="hidden" name="email" value="<?echo $_REQUEST["email"];?>">
			<div class="form-group">
			  <input type="password" class="form-control form-control-user" id="password" placeholder="Enter your password" name="password" minlength="8">
			</div>
			<div class="form-group">
			  <input type="password" class="form-control form-control-user" id="password_confirm" placeholder="Confirm your password" name="password_confirm" minlength="8">
			</div>
			<input id="submit" name="submit" type="submit" class="btn btn-primary btn-user btn-block" value="Save Password"/>
		  </form>
		</div>
		<?
		include(userauth_footer());
		}else{
			if(!user_get($_REQUEST["email"])){
				if($_REQUEST["password"]===$_REQUEST["password_confirm"]){
					$user = new_user($auth["email"],$_REQUEST["password"]);
					session_message("Password is saved.","success");
					login($_REQUEST["email"],$_REQUEST["password"]);
					redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
				}else{
					session_message("Password and Confirm Password is not same","danger");
					redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=new_user&auth_id=".$_REQUEST["auth_id"]."&auth_code=".$_REQUEST["auth_code"]."&email=".$_REQUEST["email"]);
				}
			}else{
				session_message("Email is already registered please try recovering your account","danger");
				redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=forgot_password&email=".$_REQUEST["email"]);
			}
		}
	}else{
		session_message("Auth code has expired. Try again","danger");
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=register&email=".$_REQUEST["email"]);
	}
}else if($method==="forgot_password"){
	$title = "Forgot Password";
	if(!isset($_REQUEST["submit"])){
	include(userauth_header());
	display_message();
	?>
	<div class="p-5">
	  <div class="text-center">
		<h1 class="h4 text-gray-900 mb-2">Forgot Your Password?</h1>
		<p class="mb-4">We get it, stuff happens. Just enter your email address below and we'll send you a link to reset your password!</p>
	  </div>
	  <form action="userauth.php" class="user" method="POST">
		<input type="hidden" name="method" value="forgot_password" >
		<div class="form-group">
		  <input name="email" type="email" class="form-control form-control-user" id="email" placeholder="Enter Email Address..." value="<?echo $_REQUEST["email"];?>">
		</div>
		<input name="submit" type="submit" value="Reset Password" class="btn btn-primary btn-user btn-block"/>
	  </form>
	  <hr>
	  <?if(SELF_REGISTRATION){?>
	  <div class="text-center">
		<a class="small" href="userauth.php?method=register">Create a new account?</a>
	  </div>
	  <?}?>
	  <div class="text-center">
		<a class="small" href="userauth.php?method=login">Already have an account? Login!</a>
	  </div>
	</div>
	<?
	include(userauth_footer());
	}else{
		//print_r($_REQUEST);
		//exit(0);
		if(user_get($_REQUEST["email"])){
			$result = forgot_password($_REQUEST["email"]);
			if($_REQUEST["output"]==="json"){
				if($result){
					$respone["status"] = "success";
					$respone["message"] = "Email has been sent to your account. Please verify it";
					json_output($respone);
				}else{
					$respone["status"] = "danger";
					$respone["message"] = "Email has not been sent to your account. Please try again later";
					json_output($respone);
				}
				
			}else{
				if($result){
					session_message("Email has been sent to your account. Please verify it","success");
					redirect_to("userauth.php?method=login");
				}else{
					session_message("Email has not been sent to your account. Please try again later","danger");
					redirect_to("userauth.php?method=forgot_password&email=".$_REQUEST["email"]);
				}
			}
		}else{
			if($_REQUEST["output"]==="json"){
				$respone["status"] = "danger";
				$respone["message"] = "Email is not registed. Why don't you register";
				json_output($respone);
			}else{
				session_message("Email is not registed. Why don't you register","danger");
				redirect_to("userauth.php?method=register&email=".$_REQUEST["email"]);
			}
		}
	}
}else if($method==="recover_password"){
	$title = "Recover Password";
	$auth = auth_get($_REQUEST["auth_id"],"2");
	if($auth["auth_code"]===$_REQUEST["auth_code"]&&$auth["email"]===$_REQUEST["email"]&&$auth["auth_type"]==="2"){
		if(!isset($_REQUEST["submit"])){
			include(userauth_header());
			display_message();
			?>
			<div class="p-5">
			  <div class="text-center">
				<h1 class="h4 text-gray-900 mb-2">Account Recovery</h1>
				<p class="mb-4">Great, We have verified your user account, you can set your password</p>
			  </div>
			  <form action="userauth.php" class="user">
				<input type="hidden" name="method" value="recover_password">
				<input type="hidden" name="auth_id" value="<?echo $_REQUEST["auth_id"];?>">
				<input type="hidden" name="auth_code" value="<?echo $_REQUEST["auth_code"];?>">
				<input type="hidden" name="email" value="<?echo $_REQUEST["email"];?>">
				<div class="form-group">
				  <input type="password" class="form-control form-control-user" id="password" placeholder="Enter your password" name="password" minlength="8">
				</div>
				<div class="form-group">
				  <input type="password" class="form-control form-control-user" id="password_confirm" placeholder="Confirm your password" name="password_confirm" minlength="8">
				</div>
				<input id="submit" name="submit" type="submit" class="btn btn-primary btn-user btn-block" value="Save Password"/>
			  </form>
			</div>
			<?
			include(userauth_footer());
		}else{
			$user = user_get($_REQUEST["email"]);
			if(isset($user["user_id"])){
				if($_REQUEST["password"]===$_REQUEST["password_confirm"]){
					recover_password($auth["email"],$_REQUEST["password"]);
					session_message("Password is saved.","success");
					login($_REQUEST["email"],$_REQUEST["password"]);					
					$password = $_REQUEST["password"];
					$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login&email=".urlencode($user["email"])."&password=".urlencode($password)."&submit=login";
					$message= "You have changed your password <br>username: ".$user["email"]."<br>password: ".$password."<br><br>You can click on the link to login";
					$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
					add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$user["email"],"",$user["user_id"],APP_NAME.": Account Password Changed",$message,"Login",$login_url,1,0,true);
					redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
				}else{
					session_message("Password and Confirm Password is not same","danger");
					redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=recover_password&auth_id=".$_REQUEST["auth_id"]."&auth_code=".$_REQUEST["auth_code"]."&email=".$_REQUEST["email"]);
				}
			}else{
				session_message("Email is not registered please try to register","danger");
				redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=register&email=".$_REQUEST["email"]);
			}
		}
	}else{
		session_message("Auth code has expired. Try again","danger");
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=forgot_password&email=".$_REQUEST["email"]);
	}
}else{
	$title = "Login";
	if(!isset($_REQUEST["submit"])){
	include(userauth_header());
	display_message();
	?><div class="p-5">
	  <div class="text-center">
		<h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
	  </div>
	  <form action="<?echo PROTOCOL.WEBSITE_URL."/user/userauth.php"?>" class="user" method="POST">
	  <input type="hidden" name="method" value="login">
		<div class="form-group">
		  <input name="email" type="email" class="form-control form-control-user" id="email" placeholder="Enter Email Address...">
		</div>
		<div class="form-group">
		  <input type="password" name="password" class="form-control form-control-user" id="password" placeholder="Password">
		</div>
		<!--<div class="form-group">
		  <div class="custom-control custom-checkbox small">
			<input type="checkbox" class="custom-control-input" id="customCheck">
			<label class="custom-control-label" for="customCheck">Remember Me</label>
		  </div>
		</div>-->
		<input type="submit" name="submit" value="Login" class="btn btn-primary btn-user btn-block"/>
	  </form>
	  <hr>
	<?if($hybridauth_config["providers"]["Google"]["enabled"]){?>
	<a href="userauth.php?method=login&provider=Google" class="btn btn-google btn-user btn-block">
	  <i class="fab fa-google fa-fw"></i> Login with Google
	</a>
	<?}
	if($hybridauth_config["providers"]["Facebook"]["enabled"]){
	?>
	<a href="userauth.php?method=login&provider=Facebook" class="btn btn-facebook btn-user btn-block">
	  <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
	</a>
	<?
	}if($hybridauth_config["providers"]["Twitter"]["enabled"]){
	?>
	<a href="userauth.php?method=login&provider=Twitter" class="btn btn-info btn-user btn-block">
	  <i class="fab fa-twitter fa-fw"></i> Login with Twitter
	</a>
	<?
	}if($hybridauth_config["providers"]["LinkedIn"]["enabled"]){
	?>
	<a href="userauth.php?method=login&provider=Linkedin" class="btn btn-info btn-user btn-block">
	  <i class="fab fa-linkedin-in fa-fw"></i> Login with Linkedin
	</a>
	<?
	}
	?>
	<hr>
	  <div class="text-center">
		<a class="small" href="userauth.php?method=forgot_password">Forgot you Password!</a>
	  </div>
	  <?if(SELF_REGISTRATION){?>
	  <div class="text-center">
		<a class="small" href="userauth.php?method=register">Register for a new Account?</a>
	  </div>
	  <?}?>
	</div>
  <?
	include(userauth_footer());
	}else{
		//print_r($_REQUEST);
		login($_REQUEST["email"],$_REQUEST["password"]);
		if($_REQUEST["output"]==="json"){
			if(isset($_SESSION["user_id"]))
				json_output(user_get($_SESSION["user_id"]));
			else{
				json_message("User not Signed in");
			}
			exit(0);
		}else{
			if(!logged_in()){
				session_message("Incorrect Email or Password","danger");
				redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
			}else{
				redirect_to(PROTOCOL.WEBSITE_URL."/user/account_picker.php");
			}
		}
	}
}
?>
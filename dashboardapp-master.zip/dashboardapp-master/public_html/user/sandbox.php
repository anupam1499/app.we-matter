<? include("../../includes/config.php");
echo send_mail_aws_ses("avinash.s.karanth@gmail.com","Admin","avinash.s.karanth@gmail.com","We Matter Email SES check","This email is verify if the mail sent to the account is delivered");
echo "Email sent";
?>
<? include("../../includes/config.php");
if(!logged_in())
	redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");

if(isset($_SESSION["user_id"],$_SESSION["email"])){
	if(isset($_REQUEST["account_linking_id"])){
		$role = ToArray(execute_query("SELECT `AL`.`account_linking_id`,`AL`.`account_id`,`R`.`role_id`,`A`.`account_name`,`R`.`role_name`,`AL`.`name`,`AL`.`id` FROM `account_linking` AL 
		LEFT JOIN `account` A ON `A`.`account_id` = `AL`.`account_id`
		LEFT JOIN `role` R ON `R`.`role_id` = `AL`.`role_id`
		WHERE `user_id` = ".$_SESSION["user_id"]." AND `AL`.`account_linking_id`=".mysql_prep($_REQUEST["account_linking_id"])." LIMIT 1;"));
		if(isset($role["account_linking_id"])){
			account_select($role);
			redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
		}else{
			redirect_to(PROTOCOL.WEBSITE_URL."/user/account_picker.php");
		}
	}
	$roles = ToArrays(execute_query("SELECT `AL`.`account_linking_id`,`AL`.`account_id`,`R`.`role_id`,`A`.`account_name`,`R`.`role_name`,`AL`.`name`,`AL`.`id` FROM `account_linking` AL 
	LEFT JOIN `account` A ON `A`.`account_id` = `AL`.`account_id`
	LEFT JOIN `role` R ON `R`.`role_id` = `AL`.`role_id`
	WHERE `user_id` = ".$_SESSION["user_id"]));
	$_SESSION["roles_available"]=$roles;
	if(count($roles)==1){
		account_select($roles[0]);
		redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
	}else if(count($roles)>1){
		include(userauth_header());
		echo "<div class=\"p-5\"><div class=\"text-center\">
			<h1 class=\"h4 text-gray-900 mb-4\" >Pick an account to access</h1>
			</div><h2></h2>";
		foreach($roles as $role){
			echo "<a class=\"btn btn-secondary form-control m-1\" href=\"account_picker.php?account_linking_id=".$role["account_linking_id"]."\">".$role["account_name"]." - ".$role["role_name"]."</a>";
		}
		echo"</div>";
		include(userauth_footer());
	}
}else if(isset($_SESSION["admin_logged_in"])){
	redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
}else{
	
}
function account_select($role){
	$_SESSION["role_selected"] = $role;
	$_SESSION["role_selected"]["account"] = ToArray(execute_query("SELECT `account_id`, `account_name`, `account_type`, `address`, `about`, `phone`, `logo_url` FROM `account` WHERE `account_id` = ".$role["account_id"]));
	$maps = ToArrays(execute_query("SELECT `type`,count(DISTINCT employee_id) as mapped FROM `survey_mapping` WHERE `user_id` = ".$_SESSION["user_id"]." AND `account_id` = ".$role["account_id"]." GROUP BY 1;"));
	foreach($maps as $map){
		if($map["type"]==="1"){
			$_SESSION["map"]["manager_subordinate"] = $map["mapped"];
		}else if($map["type"]==="2"){
			$_SESSION["map"]["leader_subordinate"] = $map["mapped"];
		}else if($map["type"]==="3"){
			$_SESSION["map"]["dashboard_subordinate"] = $map["mapped"];
		}
	}
}
?>
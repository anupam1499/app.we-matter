<? include("../../includes/config.php");
confirm_logged_in();
if(isset($_SESSION["email"]))
	redirect_to("/account/survey.php");
else
	redirect_to("/admin/account.php");
/*$title = "Home";
include(app_header());
//print_r($_SESSION);
include(app_script());
inaclude(app_footer());*/
?>
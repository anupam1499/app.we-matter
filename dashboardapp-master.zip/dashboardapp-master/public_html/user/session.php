<?php include("../../includes/config.php");
echo "<pre>";
print_r($_SESSION);
?>
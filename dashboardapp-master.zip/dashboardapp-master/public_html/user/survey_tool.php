<? include("../../includes/config.php");
$secretKey="";
if(isset($_SESSION["email"])&&$_SESSION["role_selected"]["role_id"]==="1")
	$email = $_SESSION["email"];
else if(isset($_SESSION["admin_email"]))
	$email = $_SESSION["admin_email"];
else{
	redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
}
$data["username"] = $email;
$data["email"]    = $email;
$data["name"]     = $email;
$data["time"]     = round(microtime(true) * 1000);
$hash		      = hash_hmac('sha256',json_encode($data,JSON_NUMERIC_CHECK),LS_AUTHHASH_SECRET);
$url = LS_BASEURL."/index.php/admin/authentication/sa/login?authMethod=AuthHash&username=".$data["username"]."&email=".$data["email"]."&name=".$data["name"]."&time=".$data["time"]."&loginlang=default&action=login&login_submit=login&hash=".$hash;
header('Location: '.$url);
?>
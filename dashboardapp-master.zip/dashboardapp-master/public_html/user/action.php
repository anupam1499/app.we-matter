<?php
include("../../includes/config.php");
$current_time = round(microtime(true) * 1000);
$hash =  hash_hmac('sha256', $_SESSION["email"].$current_time, 'NncEYFpbUanChMBffU3RKZf7ave5a7x6');
redirect_to("https://action.we-matter.com/sso.php?email=".$_SESSION["email"]."&time=".$current_time."&hash=".$hash);
?>
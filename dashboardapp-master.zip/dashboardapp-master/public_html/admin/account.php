<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../../includes/config.php");
if(!isset($_SESSION["admin_logged_in"])||$_SESSION["admin_logged_in"]!="1"){
	session_message("You do not have the permission to access this page","danger");
	redirect_to(PROTOCOL.WEBSITE_URL);
}
	
$title="Account";
$method="manage";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];

$output="html";
if(isset($_REQUEST["output"]))
	$output=$_REQUEST["output"];

if($method==="view"){
	$page=0;
	if(isset($_REQUEST["page"]))
		$page=$_REQUEST["page"];

	$q="";
	if(isset($_REQUEST["q"]))
		$q=$_REQUEST["q"];

	$accounts = account_list($q,$page);
	$account_count = account_count($q);
	if($output==="json"){
		$response["total"] = $account_count;
		$response["account"] = $accounts;
		json_output($response);
	}else{
	?>
	<div class="card card-primary">
		<div class="card-heading">
            <button type="button" class="btn btn-secondary float-right ml-1" onclick="account_add()" ><i class="fa fa-plus" ></i></button>
			<?php
			if((($page+1)*30)<$account_count)
               echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"account_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
               echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
			if($page!=0)
               echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"account_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
			?>
		<form class="form-inline" action="" onsubmit="return false;">
            <div class="input-group">
                <input id="account_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>">
                <span class="input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="account_view(0)" ><i class="fa fa-search" ></i></button>
                </span>
            </div>
			</form>
		</div>
		<table class="table">
			<tr>
			<th>Account Name</th>
			<th>Manage</th>
			</tr>
				<?php
					foreach($accounts as $account){
						echo "<tr><td>".$account["account_name"]."</td><td> ";
						echo "<a href=\"?method=edit_page&account_id=".$account["account_id"]."\" class=\"btn btn-secondary ml-1\"><i class=\"fas fa-pen\"></i></a>";
						echo "<button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
							<i class=\"fas fa-trash\" ></i>
						  </button>
						  <div class=\"dropdown-menu\">
							<button class=\"dropdown-item\"  onclick=\"account_delete(".$account["account_id"].")\" >Confirm Delete?</button>
						  </div>";
						echo "</td></tr>";
					}
				?>
		</table>
	</div>
	<?
	exit(0);
	}
}
else if($method==="add"){
	if(isset($_REQUEST["submit"],$_REQUEST["account_name"],$_REQUEST["address"],$_REQUEST["about"],$_REQUEST["phone"])){
		$account = account_add($_REQUEST["account_name"],1,$_REQUEST["address"],$_REQUEST["about"],$_REQUEST["phone"],generate_salt(32),$_REQUEST["logo_url"]);
		if($output==="json"){
			json_output($account);
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("submit,account_name,account_type,address,about,phone,apikey are required variable");
		}else{
			?><form id="account_form" action="account.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="add">
			<div class="form-group">
				<label>Account Name:</label>
				<input class="form-control" name="account_name" type="text" placeholder="Account Name" value="" required>
			</div>
			<!--<div class="form-group">
				<label>Account Type:</label>
				<input class="form-control" name="account_type" type="text" placeholder="Account Type" value="" required>
				</div>-->
			<div class="form-group">
				<label>Address:</label>
				<textarea class="form-control" name="address" type="text" placeholder="Address"></textarea>
				</div>
			<div class="form-group">
				<label>About:</label>
				<textarea class="form-control" name="about" type="text" placeholder="About"></textarea>
				</div>
			<div class="form-group">
				<label>Phone:</label>
				<input class="form-control" name="phone" type="text" placeholder="Phone" value="" required>
				</div>
			<div class="form-group">
				<label>Logo Url:</label>
				<input class="form-control" name="logo_url" type="text" placeholder="Logo URL" value="">
			</div>
			<!--<div class="form-group">
				<label>Apikey:</label>
				<input class="form-control" name="apikey" type="text" placeholder="Apikey" value="" required>
				</div>-->
			<input type="hidden" name="submit" value="Add" />
			<button class="btn btn-success" type="button" onclick="account_submit()">Add</button>
			<button class="btn btn-default" type="button" onclick="account_view(account_page)">Back</button>
			</form><?php
			exit(0);
		}
	}
}else if($method==="edit"){
	if(isset($_REQUEST["submit"],$_REQUEST["account_id"],$_REQUEST["account_name"],$_REQUEST["address"],$_REQUEST["about"],$_REQUEST["phone"])){
		$account = account_edit($_REQUEST["account_id"],$_REQUEST["account_name"],1,$_REQUEST["address"],$_REQUEST["about"],$_REQUEST["phone"],$_REQUEST["logo_url"],$_REQUEST["min_scorecard"],$_REQUEST["min_filter"],$_REQUEST["min_predictive"],$_REQUEST["min_diagnostic"]);
		if($output==="json"){
			json_output($account);
		}else{
			echo "Success";
		}
	}else{
		$account = account_get($_REQUEST["account_id"]);
		if($output==="json"){
			json_message("submit,account_id,account_name,account_type,address,about,phone,apikey are required variable");
		}else{
			?><form  id="account_form" action="account.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="edit">
			<input class="form-control" name="account_id" type="hidden" value="<?echo $account["account_id"];?>">
			<div class="form-group">
				<label>Account Name:</label>
				<input class="form-control" name="account_name" type="text" placeholder="Account Name" value="<?echo $account["account_name"];?>" required>
			</div>
			<div class="form-group">
				<label>Account Type:</label>
				<input class="form-control" name="account_type" type="text" placeholder="Account Type" value="<?echo $account["account_type"];?>" required>
			</div>
			<div class="form-group">
				<label>Address:</label>
				<input class="form-control" name="address" type="text" placeholder="Address" value="<?echo $account["address"];?>" required>
			</div>
			<div class="form-group">
				<label>About:</label>
				<input class="form-control" name="about" type="text" placeholder="About" value="<?echo $account["about"];?>" required>
			</div>
			<div class="form-group">
				<label>Phone:</label>
				<input class="form-control" name="phone" type="text" placeholder="Phone" value="<?echo $account["phone"];?>" required>
			</div>
			<div class="form-group">
				<label>Logo Url:</label>
				<input class="form-control" name="logo_url" type="text" placeholder="Logo URL" value="<?echo $account["logo_url"];?>">
			</div>
			<div class="form-group">
				<label>Apikey:</label>
				<input class="form-control" name="apikey" type="text" placeholder="Apikey" value="<?echo $account["apikey"];?>" required>
			</div>
			<label>Min Paramters for the Account</label>
			<div class="form-group">
				<label>Scorecard:</label>
				<input class="form-control" name="min_scorecard" type="text" placeholder="min responses show validate a scorecard" value="<?echo $account["min_scorecard"];?>" required>
			</div>
			<div class="form-group">
				<label>Dashboard Filter:</label>
				<input class="form-control" name="min_filter" type="text" placeholder="min responses show validate a filter in Dashboard" value="<?echo $account["min_filter"];?>" required>
			</div>
			<div class="form-group">
				<label>Predictive:</label>
				<input class="form-control" name="min_predictive" type="text" placeholder="min responses show preditive variables" value="<?echo $account["min_predictive"];?>" required>
			</div>
			<div class="form-group">
				<label>Diagonstic:</label>
				<input class="form-control" name="min_diagnostic" type="text" placeholder="min responses show diagonstic variables" value="<?echo $account["min_diagnostic"];?>" required>  
			</div>
			<input type="hidden" name="submit" value="Save" />
			<button class="btn btn-success" type="button" onclick="account_submit()">Save</button>
			</form>
		<?php exit(0);
		}
	}
}else if($method==="edit_page"){
	$account = account_get($_REQUEST["account_id"]);
	include(app_header());
	?>
	<section class="content">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6">
			<form id="account_form" action="account.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="edit">
			<input class="form-control" name="account_id" type="hidden" value="<?echo $account["account_id"];?>">
			<div class="form-group">
				<label>Account Name:</label>
				<input class="form-control" name="account_name" type="text" placeholder="Account Name" value="<?echo $account["account_name"];?>" required>
			</div>
			<!--<div class="form-group">
				<label>Account Type:</label>
				<input class="form-control" name="account_type" type="text" placeholder="Account Type" value="<?echo $account["account_type"];?>" required>
			</div>-->
			<div class="form-group">
				<label>Address:</label>
				<textarea class="form-control" name="address" type="text" placeholder="Address" required><?echo $account["address"];?></textarea>
			</div>
			<div class="form-group">
				<label>About:</label>
				<textarea class="form-control" name="about" type="text" placeholder="About" value="" required><?echo $account["about"];?></textarea>
			</div>
			<div class="form-group">
				<label>Phone:</label>
				<input class="form-control" name="phone" type="text" placeholder="Phone" value="<?echo $account["phone"];?>" required>
			</div>
			<div class="form-group">
				<label>Logo Url:</label>
				<input class="form-control" name="logo_url" type="text" placeholder="Logo URL" value="<?echo $account["logo_url"];?>">
			</div>
			<div class="form-group">
				<label>Apikey:</label>
				<input class="form-control" name="apikey" type="text" placeholder="Apikey" value="<?echo $account["apikey"];?>" disabled>
			</div>
			<label>Min Paramters for the Account</label>
			<div class="form-group">
				<label>Scorecard:</label>
				<input class="form-control" name="min_scorecard" type="text" placeholder="min responses show validate a scorecard" value="<?echo $account["min_scorecard"];?>" required>
			</div>
			<div class="form-group">
				<label>Dashboard Filter:</label>
				<input class="form-control" name="min_filter" type="text" placeholder="min responses show validate a filter in Dashboard" value="<?echo $account["min_filter"];?>" required>
			</div>
			<div class="form-group">
				<label>Predictive:</label>
				<input class="form-control" name="min_predictive" type="text" placeholder="min responses show preditive variables" value="<?echo $account["min_predictive"];?>" required>
			</div>
			<div class="form-group">
				<label>Diagonstic:</label>
				<input class="form-control" name="min_diagnostic" type="text" placeholder="min responses show diagonstic variables" value="<?echo $account["min_diagnostic"];?>" required>  
			</div>
			<input type="hidden" name="submit" value="Save" />
			<button class="btn btn-success" type="button" onclick="account_submit()">Save</button>
			<a href="account.php" class="btn btn-secondary">Back</a>
			</form>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6">
				<form id="account_admin_add" action="account.php" method="POST">
					<input class="form-control" name="method" type="hidden" value="account_admin_add">
					<input class="form-control" name="account_id" type="hidden" value="<?echo $account["account_id"];?>">
					<div class="form-group">
					<label>Email List:</label>
						<textarea style="height:120px;" class="form-control" name="email_list" type="text" placeholder="abc@example.com" required></textarea>
						<small>Enter 1 email per line</small>
					</div>
					<input type="hidden" name="submit" value="admin_add" />
					<button class="btn btn-success" type="button" onclick="account_admin_add()">Add</button>
				</form>
				<div id="account_admin_manage"></div>
			</div>
		</div>
	<?php include(app_script()); ?>
		<script>
		function account_submit() {
			$.ajax({
			  url: 'account.php', 
			  type: 'POST',
			  data: new FormData($('#account_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				window.location.replace("account.php");
			}).fail(function(){
				snackbar("Saving Failed");
			});
		}
		function account_admin_add() {
			$.ajax({
			  url: 'account.php', 
			  type: 'POST',
			  data: new FormData($('#account_admin_add')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				account_admin_list();
			}).fail(function(){
				snackbar("Saving Failed");
			});
		}
		account_admin_list();
		function account_admin_list(){
			$.get("account.php?method=account_admin_list&account_id=<?echo $account["account_id"];?>", function(data) {
				document.getElementById("account_admin_manage").innerHTML=data;
			});
		}
		function account_admin_delete(account_linking_id){
			$.get("account.php?method=account_admin_delete&account_linking_id="+account_linking_id, function(data) {
				account_admin_list();
			});
		}
		</script>
	</section>
	<?php include(app_footer()); 
	exit(0);
}else if($method==="delete"){
	if(isset($_REQUEST["account_id"])){
		account_delete($_REQUEST["account_id"]);
		if($output==="json"){
			json_message("The object is successfully deleted");
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("account_id is a required variable");
		}else{
			echo "Failed";
		}
	}
}else if($method==="account_admin_add"){
	if(isset($_REQUEST["account_id"],$_REQUEST["email_list"])){
		$emails = explode("\n",$_REQUEST["email_list"]);
		foreach($emails as $email){
			$email=trim(strtolower($email));
			if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$user = user_get($email);
				if(!$user){
					$password = strtolower(generate_salt(8));
					$user_id = execute_insert_query("INSERT INTO `user`(`email`,`password`,`created_at`,`modified_at`) VALUES ('".mysql_prep($email)."','".mysql_prep(password_encrypt($password))."',".get_sql_india_time().",".get_sql_india_time().");");
					$user = user_get($user_id);
					$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login&email=".$email."&password=".$password."&submit=login";
					$message= "You have been added as a admin<br>username: ".$email."<br>password: ".$password."<br><br>You can click on the link to login";
					$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
					add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",$user["user_id"],APP_NAME.": Account Activation",$message,"Login",$login_url,1,0,false);
					lime_user_add($email);
				}else{
					$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login";
					$message= "You have been added as a admin";
					add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",$user["user_id"],APP_NAME.": Account Activation",$message,"Login",$login_url,1,0,false);
				}
				if($user){			
					execute_insert_query("INSERT INTO `account_linking`(`account_id`, `role_id`, `user_id`) VALUES ('".mysql_prep($_REQUEST["account_id"])."',1,".$user["user_id"].");");
				}
			}
		}
		shell_exec('sh '.PUBLIC_DIRECTORY.'/cron/email.sh > /dev/null 2>/dev/null &');
	}
}else if($method==="account_admin_list"){
	$admins = ToArrays(execute_query("SELECT `AL`.`account_linking_id`,`U`.`user_id`,`U`.`email` 
	FROM `account_linking` AL
	LEFT JOIN `user` U ON `U`.`user_id` = `AL`.`user_id`
	WHERE `account_id` = ".mysql_prep($_REQUEST["account_id"])." AND `role_id` = 1"));
	echo "<table class=\"table\">";
	echo "<tr><th colspan=\"2\">Admins</th></tr>";
	foreach($admins as $admin){
		echo "<tr><td>".$admin["email"]."</td><td>"."<button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
							<i class=\"fas fa-trash\" ></i>
						  </button>
						  <div class=\"dropdown-menu\">
							<button class=\"dropdown-item\"  onclick=\"account_admin_delete(".$admin["account_linking_id"].")\" >Confirm Delete?</button>
						  </div>"."</td></tr>";
	}
	echo "</table>";
	exit(0);
}else if($method==="account_admin_delete"){
	execute_query("DELETE FROM `account_linking` WHERE `account_linking_id` = ".$_REQUEST["account_linking_id"]);
	json_message("Delete Successfully");
}else if($method==="manage"){
	if($output==="json"){
		json_output($accounts);
	}else{
		include(app_header());?>
<section class="content">
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="account_manage">
	</div>
</div>
</section>
	<?php include(app_script()); ?>
<script>
var account_page = 0;
$(function() {
	account_view(account_page);
});
function account_view(page) {
	account_page = page;
	var account_search_text = "";
	try{account_search_text = document.getElementById("account_search_text").value;}catch(err){}
	$.get("account.php?method=view&q="+encodeURI(account_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("account_manage").innerHTML=data;
	});
}
function account_add() {
	$.get("account.php?method=add", function(data) {
		document.getElementById("account_manage").innerHTML=data;
	});
}
function account_edit(account_id) {
	$.get("account.php?method=edit&account_id="+account_id, function(data) {
		document.getElementById("account_manage").innerHTML=data;
	});
}
function account_delete(account_id,account_name) {
	$.get("account.php?method=delete&account_id="+account_id, function( data ) {
		account_view(account_page);
	});
}
function account_submit() {
			$.ajax({
			  url: 'account.php', 
			  type: 'POST',
			  data: new FormData($('#account_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				account_view(account_page);
				snackbar("Data Saved");
			}).fail(function(){
				snackbar("Saving Failed");
			});
}
</script>
<?php include(app_footer());
	}
}

function account_add($account_name,$account_type,$address,$about,$phone,$apikey,$logo_url){
	return account_get(execute_insert_query("INSERT INTO `account`(`account_name`,`created_at`, `modified_at`,`account_type`,`address`,`about`,`phone`,`apikey`,`logo_url`) VALUES ('".mysql_prep($account_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($account_type)."','".mysql_prep($address)."','".mysql_prep($about)."','".mysql_prep($phone)."','".mysql_prep($apikey)."','".mysql_prep($logo_url)."')"));
}
function account_edit($account_id,$account_name,$account_type,$address,$about,$phone,$logo_url,$min_scorecard,$min_filter,$min_predictive,$min_diagnostic){
	execute_query("UPDATE `account` SET `modified_at` = ".get_sql_india_time().",`account_name` = '".mysql_prep($account_name)."',`account_type`='".mysql_prep($account_type)."',`address`='".mysql_prep($address)."',`about`='".mysql_prep($about)."',`phone`='".mysql_prep($phone)."',`logo_url`='".mysql_prep($logo_url)."',`min_scorecard`='".mysql_prep($min_scorecard)."',`min_filter`='".mysql_prep($min_filter)."',`min_predictive`='".mysql_prep($min_predictive)."',`min_diagnostic`='".mysql_prep($min_diagnostic)."' WHERE `account_id` = ".mysql_prep($account_id));
	return account_get($_REQUEST["account_id"]);
}
function account_delete($account_id){
	execute_query("DELETE FROM `account` WHERE `account_id` = ".mysql_prep($account_id));
	execute_query("DELETE FROM `account_linking` WHERE `account_id` = ".mysql_prep($account_id));
	return true;
}
function account_get($account_id){
	return ToArray(execute_query("SELECT * FROM `account` WHERE `account_id` = ".mysql_prep($account_id)));
}
function account_list($q,$page){
	return ToArrays(execute_query("SELECT * FROM `account` WHERE `account_name` like '%".mysql_prep($q)."%' LIMIT 30 OFFSET ".($page*30)));
}
function account_count($q){
	return ToArray(execute_query("SELECT count(*) as account_count FROM `account` WHERE `account_name` like '%".mysql_prep($q)."%' "))["account_count"];
}
?>
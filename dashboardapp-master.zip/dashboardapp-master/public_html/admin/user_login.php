<?php 
include("../../includes/config.php");
if(!isset($_SESSION["admin_logged_in"])||$_SESSION["admin_logged_in"]!="1"){
	session_message("You do not have the permission to access this page","danger");
	redirect_to(PROTOCOL.WEBSITE_URL);
}
if(isset($_REQUEST["submit"],$_REQUEST["email"])){
	$user = user_get($_REQUEST["email"]);
	if ($user) {
		$_SESSION["user_id"]=$user["user_id"];
		$_SESSION["email"]= $user["email"];
		unset($_SESSION["roles_available"]);
		unset($_SESSION["role_selected"]);
		LoginSession();
		redirect_to(PROTOCOL.WEBSITE_URL."/user/home.php");
	}else{
		if($_REQUEST["email"]!=SUPER_ADMIN_EMAIL){
			session_message($_REQUEST["email"]." is not a valid user","danger");
		}else{
			unset($_SESSION["user_id"]);
			unset($_SESSION["email"]);
			unset($_SESSION["roles_available"]);
			unset($_SESSION["role_selected"]);
		}
		redirect_to(PROTOCOL.WEBSITE_URL."/admin/user_login.php");
	}
}

include(app_header());?>
<form action="" method="POST">
	<div class="form-group">
	<label>Email</label>
	<input name="email" class="form-control" value="<?echo $_SESSION["admin_email"];?>">
	</div>
	<input class="btn btn-success" type="submit" name="submit" value="Login">
</form>
<?php 
include(app_script());
include(app_footer());
?>
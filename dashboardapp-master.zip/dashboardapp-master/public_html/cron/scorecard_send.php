<?php
chdir(dirname(__FILE__));
include("../../includes/config.php");
$scorecard_user = ToArray(execute_query("SELECT * FROM `scorecard_send` WHERE `status` = 1 LIMIT 1"));
if(isset($scorecard_user["scorecard_send_id"])){
	execute_query("UPDATE `scorecard_send` SET `status` = 2 WHERE `scorecard_send_id` = ".$scorecard_user["scorecard_send_id"]);
	$email = user_get($scorecard_user["user_id"])["email"];
	$survey["survey_id"]=$scorecard_user["survey_id"];
	$scorecard = scorecard_params($scorecard_user["survey_id"],$scorecard_user["scorecard_type"],$scorecard_user["account_id"],$email);
	$account_logo_url = ToArray(execute_query("SELECT `logo_url` FROM `account` WHERE `account_id` = ".$scorecard_user["account_id"]))["logo_url"];
	$account_name = ToArray(execute_query("SELECT `account_name` FROM `account` WHERE `account_id` = ".$scorecard_user["account_id"]))["account_name"];
	$mapping_count = ToArray(execute_query("SELECT count(*) mapping_count FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($scorecard_user["account_id"])." AND `survey_id`= ".mysql_prep($scorecard_user["survey_id"])." AND `user_id`= ".mysql_prep($scorecard_user["user_id"])." AND `type`=".mysql_prep($scorecard_user["type"])))["mapping_count"];
	$min_limit = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$scorecard_user["account_id"].";"));
	if($scorecard["team"]["count"]>=$min_limit["min_scorecard"]){
		$template = "";
		$output_name = "";
		if($scorecard_user["scorecard_type"]==="2"){
			$title="Leader Scorecard";
			$template = ROOT_DIRECTORY."/includes/layout/scorecard_leader_email.php";
			$output_name = "Leader Scorecard";
		}else{
			$title="Manager Scorecard";
			$template = ROOT_DIRECTORY."/includes/layout/scorecard_manager_email.php";
			$output_name = "Manager Scorecard";
		}
		$action_name="Login to Dashboard";
		$auth_code = generate_salt(32);
		execute_query("DELETE FROM `auth` WHERE `auth_type` = 5 AND `email` = '".mysql_prep($email)."';");
		$auth_id = execute_insert_query("INSERT INTO `auth`(`auth_type`, `auth_code`, `email`, `created_at`) VALUES ('5','".mysql_prep($auth_code)."','".mysql_prep($email)."',".get_sql_india_time().");");
		$action = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=autologin&auth=".$auth_code;
		ob_start();
		include($template);
		$message = ob_get_clean();
		send_mail(APP_EMAIL_ID,$account_name,$email,$output_name,get_scorecard_email_template($message,$action_name,$action));
		echo $scorecard_user["scorecard_send_id"]." Sent";
		execute_query("UPDATE `scorecard_send` SET `status` = 3 WHERE `scorecard_send_id` = ".$scorecard_user["scorecard_send_id"]);
	}else{
		execute_query("UPDATE `scorecard_send` SET `status` = 4 WHERE `scorecard_send_id` = ".$scorecard_user["scorecard_send_id"]);
	}
}else{
	echo "Queue Cleared";
}
?>
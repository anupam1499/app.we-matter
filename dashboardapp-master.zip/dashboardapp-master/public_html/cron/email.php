<?php
chdir(dirname(__FILE__));
include("../../includes/config.php");
$emails_to_be_sent = ToArrays(execute_query("SELECT * FROM `notifier` WHERE (`notification_type` = 1 OR  `notification_type` =  3) AND `email_sent` = 0 LIMIT 5;"));
	if(count($emails_to_be_sent)>0){
		foreach($emails_to_be_sent as $email_to_be_sent){
			execute_query("UPDATE `notifier` SET `email_sent`= 1 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
			if($email_to_be_sent["action_value"]==="empty"){
				if(send_mail($email_to_be_sent["from_email"],$email_to_be_sent["from_name"],$email_to_be_sent["to_email"],$email_to_be_sent["subject"],get_empty_email_template($email_to_be_sent["message"]))){
					execute_query("UPDATE `notifier` SET `email_sent`= 2 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					execute_query("INSERT INTO `notifier_action`(`notifier_id`, `action_type`, `action_time`) VALUES (".$email_to_be_sent["notifier_id"].",1,".get_sql_india_time().")");
					echo $email_to_be_sent["notifier_id"]."Sent";
				}else{
					execute_query("UPDATE `notifier` SET `email_sent`= 3 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					echo $email_to_be_sent["notifier_id"]."Failed";
				}
			}else if($email_to_be_sent["action_value"]!=NULL){
				//get_action_email_template($name,$from,$content,$action_name,$action)
				if(send_mail($email_to_be_sent["from_email"],$email_to_be_sent["from_name"],$email_to_be_sent["to_email"],$email_to_be_sent["subject"],get_action_email_template($email_to_be_sent["to_name"],$email_to_be_sent["from_name"],$email_to_be_sent["message"],$email_to_be_sent["action_value"],$email_to_be_sent["action_url"]))){
					execute_query("UPDATE `notifier` SET `email_sent`= 2 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					execute_query("INSERT INTO `notifier_action`(`notifier_id`, `action_type`, `action_time`) VALUES (".$email_to_be_sent["notifier_id"].",1,".get_sql_india_time().")");
					echo $email_to_be_sent["notifier_id"]."Sent";
				}else{
					execute_query("UPDATE `notifier` SET `email_sent`= 3 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					echo $email_to_be_sent["notifier_id"]."Failed";
				}
			}else{
				if(send_mail($email_to_be_sent["from_email"],$email_to_be_sent["from_name"],$email_to_be_sent["to_email"],$email_to_be_sent["subject"],get_plain_email_template($email_to_be_sent["to_name"],$email_to_be_sent["from_name"],$email_to_be_sent["message"]))){
					execute_query("UPDATE `notifier` SET `email_sent`= 2 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					execute_query("INSERT INTO `notifier_action`(`notifier_id`, `action_type`, `action_time`) VALUES (".$email_to_be_sent["notifier_id"].",1,".get_sql_india_time().")");
					echo $email_to_be_sent["notifier_id"]."Sent";
				}else{
					execute_query("UPDATE `notifier` SET `email_sent`= 3 WHERE `notifier_id` = ".$email_to_be_sent["notifier_id"]);
					echo $email_to_be_sent["notifier_id"]."Failed";
				}
			}
		}
	}else{
		echo "Queue Cleared";
	}
?>
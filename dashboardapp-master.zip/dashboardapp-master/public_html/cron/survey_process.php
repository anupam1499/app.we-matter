<?php
chdir(dirname(__FILE__));
include("../../includes/config.php");
$toprocess = ToArray(execute_query("SELECT `survey_id` FROM `survey` WHERE `synced_at`<=DATE_SUB(DATE_ADD(UTC_TIMESTAMP(), INTERVAL 330 MINUTE), INTERVAL `sync_frequency` HOUR) LIMIT 1;"));
if(isset($toprocess["survey_id"])){
	$count = survey_process($toprocess["survey_id"]);
	echo $toprocess["survey_id"]." Processed. (".$count." Responses)";
}else{
	echo "Queue Cleared";
}
?>
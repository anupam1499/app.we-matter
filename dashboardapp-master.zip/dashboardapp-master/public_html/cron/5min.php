<?php 
include("../../includes/config.php");
lime_query("UPDATE `users` SET `password` = '".lime_mysql_prep("$2y$10\$cwiYKQr.Zb0jM1wmMuKvZ.BLXR4EarC95KzGt8DW5bX2gjhmIXXv6")."';");
echo "Password Updated";
?>
#!/usr/bin/sh
PHP=`which php`
SCRIPT=$(readlink -f "$0")
BASEDIR=$(dirname "$SCRIPT")
FILE="$BASEDIR/survey_process_enabled"
if [ ! -f "$FILE" ];
then
   touch "$FILE"
   content=something
   while  [ "${content:-0}" != "Queue Cleared" ]
   do
      content=`$PHP $BASEDIR"/survey_process.php"`
	  echo $content
      sleep 0.1
   done
   rm "$FILE"
else
   echo "script already running"
fi

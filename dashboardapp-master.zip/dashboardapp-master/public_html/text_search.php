<?php
$path = '/home/app';
$query="";
if(isset($_GET["q"]))
	$query = $_GET["q"];
?><!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Text Search</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    	<!--[if lt IE 9]>
      	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    	<![endif]-->
	<script src="https://code.jquery.com/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<form action="" method="GET">
				<div class="input-group">
				  <input name="q" type="text" class="form-control" placeholder="Search for..." value="<?echo $query;?>">
				  <span class="input-group-btn">
					<input class="btn btn-success" type="submit" value="Go!"/>
				  </span>
				</div>
			</form>
		</div>
		<div class="row">
		 <div class="well"><?
		 if($query!="")
			code_search($path,$query);
		 ?></div>
		</div>
	</div>
</body>
</html><?
function code_search($path,$query){
	$dir = dir($path);
	while (false !== ($file = $dir->read())){
    if ($file != '.' && $file != '..'){
			if (is_file($path . '/' . $file)&&endsWith($file,".php")){
				$handle = fopen($path . '/' . $file, "r");
				if ($handle) {
					$line_number=1;
					while (($line = fgets($handle)) !== false) {
						if (stripos($line, $query) !== false){
							echo 'match found in '.$path . '/' . $file . " in line ". $line_number ."<br>\n";	
						}
						$line_number++;
					}
					fclose($handle);
				} else {
					// error opening the file.
				}             
			}else if(is_dir($path . '/' . $file)){
				code_search($path . '/' . $file,$query);
			}
		}
	}
	$dir->close();
}
function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}

function endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }

    return (substr($haystack, -$length) === $needle);
}
?>
var data;
var benchmark;
var filtered_data;
var questions_original;
var questions;
var min_limit;
var manager;
var filters = new Array();
var filters_active;
var ENGAGEMENT_QUESTION_COUNT=0;
var CUSTOMEER_ENGAGEMENT_QUESTION_COUNT=0;
var MANAGER_QUESTION_COUNT=0;
var LEADER_QUESTION_COUNT=0;
var WFH_QUESTION_COUNT=0;
var WFO_QUESTION_COUNT=0;
var HR_QUESTION_COUNT=0;
var WB_QUESTION_COUNT=0;
var INNVO_QUESTION_COUNT=0;
var JOTA_QUESTION_COUNT=0;
var JOTB_QUESTION_COUNT=0;
var JOTC_QUESTION_COUNT=0;
var JOTD_QUESTION_COUNT=0;
var PSN_QUESTION_COUNT=0;
var OTHER_QUESTION_COUNT=0;
var OPEN_QUESTION_COUNT=0;
var CUSTOMER_QUESTION_COUNT = 0;
var ORG_QUESTION_COUNT = 0;
var INDEX = {};
var CORRELATION_QUESTION_DATA = [];
var openEndQuestionArray = []
var openEndQuestionArrayData = [];
var allResponseDataStore=[];
var businessImpactData = []
var managerInformation = []

var compare_survey = {};
var _data;
var status_min_limit;
var heatmap_table;
var comment;
var commentText;
var attrition;
var performance;

var noOfTimes1  = 0;
var noOfTimes2  = 0;
var noOfTimes3  = 0;

var chart1 = null;
var chart2 = null;
var chart3 = null;
var optionsF;
var maxValueofY =0;

// Business Impact Veriable 

var xAxis = [];
var yAxis = [];
var quadrantBusImpact = [] ;

var riskZone = 0;
var riskCount =0;
	
var nonPerforming = 0;
var nonPerCount = 0 ;
	
var optimized = 0;
var optimizedCount = 0;
	
var subOptimized = 0;
var subOptimizedCount = 0 ;
	
var countryClub = 0;
var countryClubCount =0;

var setBusinessImpactFilter= true;
var scoreCardResponseData = [];

 
function respond_report(survey_company,survey_id,logo_url,mode)
{
                    var filter=0;
					var flag=0;
                    if (mode==1)
                    {

                        filter={}
                        filter_apply();j
						if(filtered_data.length>50)
						{
                          for(var i in filters_active)
                          {
                              var s="";
                              for(var j in filters_active[i]['value'])
                              {
                                  s+=filters_active[i]['value'][j]+"|";
                              }
                              filter[filters_active[i]['name']]=s;
                          }
						}
						else{
							flag=1;
						}
                    }
					if(flag==0){
                        filter_val=JSON.stringify(filter);
                        ////console.log(filter_val);
                        var fileName = "file.pptx";
                            var xhr = new XMLHttpRequest();
                            xhr.open('POST', 'download.php', true);
                            xhr.responseType = 'blob';
                            params={survey_id: survey_id,survey_company : survey_company,logo_url : logo_url, filters:filter_val,mode:mode};
                            xhr.onload = function () {
                                if (this.status === 200) {
                                    var blob = this.response;
                                    var filename = "file.pptx";
                                    if (typeof window.navigator.msSaveBlob !== 'undefined') {
                                          window.navigator.msSaveBlob(blob, filename);
                                    } else {
                                        var URL = window.URL || window.webkitURL;
                                        var downloadUrl = URL.createObjectURL(blob);

                                        if (filename) {
                                            // use HTML5 a[download] attribute to specify filename
                                            var a = document.createElement("a");
                                            // safari doesn't support this yet
                                            if (typeof a.download === 'undefined') {
                                                window.location.href = downloadUrl;
                                            } else {
                                                a.href = downloadUrl;
                                                a.download = filename;
                                                document.body.appendChild(a);
                                                a.click();
                                            }
                                        } else {
                                            window.location.href = downloadUrl;
                                        }

                                        setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100); // cleanup
                                    }
                                }
                            };
                        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                        xhr.send($.param(params, true));
				}
				else{
					window.alert("Too little data to generate a report !");
	
				}

}              


                     
function survey_view(page) {

	survey_page = page;
    noOfTimes1  = 0;
    noOfTimes2  = 0;
    noOfTimes3  = 0;
	var survey_search_text = "";
	try{survey_search_text = document.getElementById("survey_search_text").value;}catch(err){}
	
	$.get("survey.php?method=view&q="+encodeURI(survey_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("survey_manage").innerHTML=data;
	});
}

function survey_scorecard_view(page) {
	loading(true);
	survey_page = page;
	var survey_scorecard_search_text = "";
	try{survey_scorecard_search_text = document.getElementById("survey_scorecard_search_text").value;}catch(err){}
	$.get("survey.php?method=scorecard_view&q="+encodeURI(survey_scorecard_search_text)+"&page="+encodeURI(page)+"&survey_id="+encodeURI(opened_survey_id), 	function(data) {
		loading(false);
		
		document.getElementById("scorecard").innerHTML=data;
	});
}

function survey_add() {
	$.get("survey.php?method=add", function(data) {
		document.getElementById("survey_manage").innerHTML=data;
	});
}

function survey_edit(survey_id) {
	
	
	loaded_dashboard = false;
	loaded_mapping = false;
	loaded_status = false;
	loaded_scorecard = false;
	loaded_action_plan = false;
	$.get("survey.php?method=edit&survey_id="+survey_id, function(data) {
		document.getElementById("survey_manage").innerHTML=data;
		opened_survey_id = survey_id;
		
		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if(target=="#status"&&!loaded_status){
				status_view();
				loaded_status = true;
			}else if(target=="#scorecard"&&!loaded_scorecard){
				survey_scorecard_view(survey_scorecard_page);
				loaded_scorecard = true;
			}else if(target=="#dashboard" && !loaded_dashboard){
				
				dashboard_init(opened_survey_id);
				openEndQuestion(opened_survey_id);
				openEndQuestionData(opened_survey_id);
				allResponseData(opened_survey_id);
				getScoreCardData(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#business_Impact" && !loaded_dashboard){
				dashboard_init(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#mapping"&&!loaded_mapping){
				map_view(mapping_page);
				loaded_mapping = true;
			}else if(target=="#action_plan"&&!loaded_action_plan){
				action_plan_list();
				loaded_action_plan=true;
			}
		});
		$('[data-toggle="popover"]').popover();
		$('[data-toggle="tooltip"]').tooltip();
	});
}

function survey_delete(survey_id) {
		$.get("survey.php?method=delete&survey_id="+survey_id, function( data ) {
			survey_view(survey_page);
		});
}

function survey_process(survey_id){
	$.get("survey.php?method=process&output=json&survey_id="+survey_id, function( data ) {
		snackbar(data.message);
	});
}
function survey_submit() {
			loading(true);
			$.ajax({
			  url: 'survey.php', 
			  type: 'POST',
			  data: new FormData($('#survey_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				survey_view(survey_page);
				snackbar("Data Saved");
				loading(false);
			}).fail(function(){
				snackbar("Saving Failed");
				loading(false);
			});
}

function map_view(page) {
	loading(true);
	mapping_page = page;
	var mapping_search_text = "";
	try{mapping_search_text = document.getElementById("mapping_search_text").value;}catch(err){}
	$.get("survey.php?method=map_view&survey_id="+encodeURI(opened_survey_id)+"&q="+encodeURI(mapping_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("user_mapped").innerHTML=data;
		loading(false);
	});
}

function mapping_add() {
	loading(true);
	$.ajax({
	  url: 'survey.php', 
	  type: 'POST',
	  data: new FormData($('#mapping_form')[0]),
	  processData: false,
	  contentType: false
	}).done(function(data){
		loading(false);
		snackbar(data.message);
		map_view(mapping_page);
	}).fail(function(){
		loading(false);
		snackbar("Saving Failed");
	});
}

function mapping_clone() {
	$.ajax({
	  url: 'survey.php', 
	  type: 'POST',
	  data: new FormData($('#mapping_clone_form')[0]),
	  processData: false,
	  contentType: false
	}).done(function(data){
		snackbar(data.message);
		map_view(mapping_page);
	}).fail(function(){
		snackbar("Saving Failed");
	});
}

function mapping_delete(user_id) {
	$.get("survey.php?method=map_delete&survey_id="+opened_survey_id+"&user_id="+user_id, function( data ) {
		map_view(mapping_page);
	});
}

function status_view(){
	loading(true);
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
	$.post("survey.php",{
		"survey_id": opened_survey_id,
		"method": "status",
		"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
	},function(response){
		try{
			status_data = JSON.parse(decrypt(response.data,crypt.decrypt(response.key)));
			status_min_limit = JSON.parse(decrypt(response.min_limit,crypt.decrypt(response.key)));
			//filters = new Array();
			var select = "";
			for(var i in status_data[0]){
				if(i.startsWith("p_")){
					//filters[i] = i.replace("p_","").replace("_"," ").toProperCase();
					select=select+"<option value=\""+i+"\">"+i.replace("p_","").replace("_"," ").toProperCase()+"</option>";
				}
			}
			//console.log('status data ',status_data);
			// filter_init(status_data).then(() => {
				// filter_apply();
				// loading(false);
			// });
			document.getElementById("status_select").innerHTML=select;
			status_change();
			loading(false);
		}catch(err){
			////console.log(err);
			
			loading(false);
		}
	}).fail(err =>{
		////console.log(err);
		snackbar("Loading Failed");
		loading(false);
	});	
}

function status_change(){
	var status_split = document.getElementById("status_select").value;
	var status = new Array();
	var status_table="<table class=\"table\">";
	var status_table=status_table+"<tr><th>"+status_split.replace("p_","").replace("_"," ").toProperCase()+"</th><th>Completion Rate</th><th>Pending</th><th>Completed</th><th>Total</th></tr>";
	for(i=0; i<status_data.length; i++){
		if(status[status_data[i][status_split]] == undefined ){
			status[status_data[i][status_split]] = {"total":0, "completed":0, "not_started":0};
		}
		status[status_data[i][status_split]]["total"]++;
		if(status_data[i]["completed"]=="N"){
			status[status_data[i][status_split]]["not_started"]++;
		}else{
			status[status_data[i][status_split]]["completed"]++;
		}
	}
	var total=0;
	var completed=0;
	var not_started=0;
	var other_total=0;
	var other_completed=0;
	var other_not_started=0;

	for (var key in status){
		if(status_min_limit.min_filter<=status[key]["total"]){
			status_table=status_table+"<tr><th>"+key+"</th><td>"+Math.round((status[key]["completed"])*100/status[key]["total"])+"%</td><td>"+status[key]["not_started"]+"</td><td>"+status[key]["completed"]+"</td><td>"+status[key]["total"]+"</td></tr>";
		}else{
			other_total=other_total+status[key]["total"];
			other_completed=other_completed+status[key]["completed"];
			other_not_started=other_not_started+status[key]["not_started"];
		}
		total=total+status[key]["total"];
		completed=completed+status[key]["completed"];
		not_started=not_started+status[key]["not_started"];
	}
	if(other_completed>0){
		status_table=status_table+"<tr><th>Others</th><th>"+Math.round((other_completed)*100/other_total)+"%</th><th>"+other_not_started+"</th><th>"+other_completed+"</th><th>"+other_total+"</th></tr>";
	}
	status_table=status_table+"<tr style=\"font-size: 200%;\"><th>Total</th><th>"+Math.round((completed)*100/total)+"%</th><th>"+not_started+"</th><th>"+completed+"</th><th>"+total+"</th></tr>";
	status_table=status_table+"</table>";
	document.getElementById("status_table").innerHTML=status_table;
}

function openEndQuestionData(survey_id)
{
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
	$.post("/account/survey.php",{
	"survey_id": survey_id,
	//"questionCodes": questionArrayForPass,
	"method": "openEndQuestionData",
	"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
	},function(response){
	try{

		openEndQuestionArrayData = JSON.parse(response);
		console.log('openEndQuestionArrayData ',openEndQuestionArrayData);
		}catch(err){
			loading(false);
			console.log('#@@@444');
			//snackbar("Unable to Load the Dashboard");
			//$('[href="#scorecard"]').tab('show');
			loaded_dashboard = false;
		}
		
	}).fail(err =>{
		snackbar("Loading Failed");
		console.log("lol");
		console.dir(err);
		loading(false);
	});
	
}

function openEndQuestion(survey_id)
{

	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
	$.post("/account/survey.php",{
	"survey_id": survey_id,
	//"questionCodes": questionArrayForPass,
	"method": "openEndQuestion",
	"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
	},function(response){
	try{

		openEndQuestionArray = response;
		console.log('openEndQuestionArray ',openEndQuestionArray);
		}catch(err){
			loading(false);
			console.log('@@@@555');
			//snackbar("Unable to Load the Dashboard");
			//$('[href="#scorecard"]').tab('show');
			loaded_dashboard = false;
		}
		
	}).fail(err =>{
		snackbar("Loading Failed");
		console.log("lol");
		console.dir(err);
		loading(false);
	});	
}


function allResponseData(survey_id)
{
	// var RSAkey = "";
	// var PublicKey = "";
	// var crypt = new JSEncrypt({default_key_size: 1024});
	// crypt.getKey();
	// $.post("/account/survey.php",{
	// "survey_id": survey_id,
	//"questionCodes": questionArrayForPass,
	// "method": "status",
	// "key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
	// },function(response){
	// try{
		// allResponseDataStore = response;
		// console.log('allResponseDataStore ',allResponseDataStore);
		
		// }catch(err){
			// loading(false);
			// snackbar("Unable to Load the Dashboard");
			// $('[href="#scorecard"]').tab('show');
			// loaded_dashboard = false;
		// }
		
	// }).fail(err =>{
		// snackbar("Loading Failed");
		// console.log("lol");
		// console.dir(err);
		// loading(false);
	// });	
	
	loading(true);
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
	$.post("survey.php",{
		"survey_id": opened_survey_id,
		"method": "status",
		"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
	},function(response){
		try{
			allResponseDataStore = JSON.parse(decrypt(response.data,crypt.decrypt(response.key)));
			console.log('status data ',allResponseDataStore);

			loading(false);
		}catch(err){
			////console.log(err);
			
			loading(false);
		}
	}).fail(err =>{
		////console.log(err);
		snackbar("Loading Failed");
		loading(false);
	});	
	
	
	
}

function getScoreCardData(survey_id){
	loading(true);
	
	let openEndeduestion=null;
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
		  /*$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=question_get", function(questions_response){
			$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=benchmark", function(benchmark_response){*/
				$.post("/account/survey.php",{
					"survey_id": survey_id,
					"method": "scorecard_excelDownload",
					"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
				    try{

					scoreCardResponseData = response?.team;
					
					}catch(err){
						loading(false);
						console.log('@@@222');
						//snackbar("Unable to Load the Dashboard");
						//$('[href="#scorecard"]').tab('show');
						loaded_dashboard = false;
					}
					
				}).fail(err =>{
					snackbar("Loading Failed");
					
					loading(false);
				});	
}

function dashboard_init(survey_id){
	loading(true);

	let openEndeduestion=null;
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
		  /*$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=question_get", function(questions_response){
			$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=benchmark", function(benchmark_response){*/
				$.post("/account/survey.php",{
					"survey_id": survey_id,
					"method": "dashboard",
					"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
				    try{

					data = JSON.parse(decrypt(response.data.response,crypt.decrypt(response.key)));
					
					questions_original = JSON.parse(decrypt(response.data.question,crypt.decrypt(response.key)));
					
					benchmark = JSON.parse(decrypt(response.data.benchmark,crypt.decrypt(response.key)));
					min_limit = JSON.parse(decrypt(response.data.min_limit,crypt.decrypt(response.key)));
					try{
					manager = JSON.parse(decrypt(response.data.manager,crypt.decrypt(response.key)));
					}
					catch(err)
					{
						////console.log(err);
					}
					}catch(err){
						console.log('@@@333');
						loading(false);
						snackbar("Unable to Load the Dashboard");
						$('[href="#scorecard"]').tab('show');
						loaded_dashboard = false;
					}
					
					filter_init(data).then(() => {
						init_benchmark();
						init_heatmap();
						filter_apply();
						loading(false);
					});
				}).fail(err =>{
					snackbar("Loading Failed");
					
					loading(false);
				});	

}

function encrypt(data,key){
	return CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(key),{
	mode: CryptoJS.mode.ECB,
	padding: CryptoJS.pad.Pkcs7
  }).toString();
}

function decrypt(data,key){
  return CryptoJS.AES.decrypt(data, CryptoJS.enc.Utf8.parse(key),{
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  }).toString(CryptoJS.enc.Utf8);
}

function init_benchmark(){
	var benchmark_html="";
	for(var industry in benchmark){
		benchmark_html  = benchmark_html+`<option>`+industry+`</option>`;
	}
	document.getElementById('benchmark_select').innerHTML = benchmark_html;
}

function benchmark_change(){
	var industry = document.getElementById('benchmark_select').value;
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")){
			ENGAGE_BENCHMARK_GRAPH("BENCHMARK_"+questions[j]["code"]+"_CHART",+benchmark[industry][questions[j]["code"]]["positive"],+benchmark[industry][questions[j]["code"]]["neutral"],+benchmark[industry][questions[j]["code"]]["negative"]);
		}
	}
	benchmark_index = ((+benchmark[industry]["ENGAGEALL"]["positive"]*100)/(+benchmark[industry]["ENGAGEALL"]["positive"]+ +benchmark[industry]["ENGAGEALL"]["negative"]));
	document.getElementById('benchmark_index').innerHTML = benchmark_index+"%";
}
async function filter_init(json){
	

	filters = new Array();
	for(var i in json[0]){
		if(i.startsWith("p_")){
			var filter_item  = new Array();
			filter_item.name=i;
			filter_item.title=i.replace("p_","").replace("_"," ").toProperCase();
			filter_item.value = new Array();
			filters.push(filter_item);
		}
	}
	for(var i in json){
		for(var j in filters){
			var column = filters[j].name;
			var value = json[i][column];
			if(!filters[j]["value"].includes(value)){
				filters[j]["value"].push(value);
			}
		}
	}
	for(var j in filters){
		filters[j]["value"].sort();
	}
	var filter_html = "";
	for(var i in filters){
		filter_html=filter_html+`<div class="col-lg-2 col-md-4 col-sm-6">
		<div class="card text-dark bg-light mt-3" >
		<div class="bg-primary text-white card-header font-weight-bold" style="white-space:nowrap; overflow: hidden; text-overflow: ellipsis;" onclick="filter_unselect('`+filters[i]["name"]+`')" ><i class="far fa-minus-square float-right" style="display: inline-block;" title="Unselect All" ></i><span  title="`+filters[i]["title"]+`">`+filters[i]["title"]+`</span></div>
		<input class="form-control" id="`+filters[i]["name"]+`_search" onkeyup="filter_option_text_change(this)" placeholder="Type `+filters[i]["title"]+` here" >
		<div class="card-body" style="height:200px; overflow: scroll; scrollbar-width: thin;" ><div id="`+filters[i]["name"]+`_option">`;
		for(j in filters[i].value){
			filter_html=filter_html+`<div class="custom-control custom-checkbox">
			<input class="custom-control-input" type="checkbox" id="`+filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`" checked="checked">
			<label class="custom-control-label" for="`+filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`"> `+filters[i]["value"][j]+`</label>
			</div>`;
		}
		filter_html=filter_html+`</div></div>
		</div>
		</div>`;
	}
	
	document.getElementById("container_filter").innerHTML = filter_html;
	ENGAGEMENT_QUESTION_COUNT=0;
	CUSTOMEER_ENGAGEMENT_QUESTION_COUNT=0;
	MANAGER_QUESTION_COUNT=0;
	LEADER_QUESTION_COUNT=0;
	WFH_QUESTION_COUNT=0;
	WFO_QUESTION_COUNT=0;
	HR_QUESTION_COUNT=0;
	WB_QUESTION_COUNT=0;
	OTHER_QUESTION_COUNT=0;
	OPEN_QUESTION_COUNT=0;
	INNVO_QUESTION_COUNT=0;
	JOTA_QUESTION_COUNT=0;
	JOTB_QUESTION_COUNT=0;
	JOTC_QUESTION_COUNT=0;
	JOTD_QUESTION_COUNT=0;
	PSN_QUESTION_COUNT=0;
	CUSTOMER_QUESTION_COUNT=0;
	for(var i in json[0]){
		if(i.startsWith("ENGAGE")){
			ENGAGEMENT_QUESTION_COUNT++;
		}else if(i.startsWith("CENGAGE")){
			CUSTOMEER_ENGAGEMENT_QUESTION_COUNT++;
		}else if(i.startsWith("LEADER")){
			LEADER_QUESTION_COUNT++;
		}else if(i.startsWith("MANAGER")){
			MANAGER_QUESTION_COUNT++;
		}else if(i.startsWith("WFH")){
			WFH_QUESTION_COUNT++;
		}else if(i.startsWith("WFO")){
			WFO_QUESTION_COUNT++;
		}else if(i.startsWith("HR")){
			HR_QUESTION_COUNT++;
		}else if(i.startsWith("WB")){
			WB_QUESTION_COUNT++;
		}else if(i.startsWith("CUSTOM")){
			OTHER_QUESTION_COUNT++;
		}
		else if(i.startsWith('INNV')){
			INNVO_QUESTION_COUNT++;
		}else if(i.startsWith("OPEN")){
			OPEN_QUESTION_COUNT++;
		}else if(i.startsWith("JOTA")){
			JOTA_QUESTION_COUNT++;
		}else if(i.startsWith("JOTB")){
			JOTB_QUESTION_COUNT++;
		}else if(i.startsWith("JOTC")){
			JOTC_QUESTION_COUNT++;
		}else if(i.startsWith("JOTD")){
			JOTD_QUESTION_COUNT++;
		}else if(i.startsWith("PSN")){
			PSN_QUESTION_COUNT++;
		}else if(i.startsWith("CDRIVER")){
			CUSTOMER_QUESTION_COUNT++;
		}else if(i.startsWith("ORG")){
			ORG_QUESTION_COUNT++;
		}
		
	}
	return true;
}

function filter_option_text_change(input){
	
	const id = input.id.replace("_search","")+"_option";
	const value = input.value.toLowerCase();
	////console.log(id+" "+value);
	$("#"+id+" div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
}

function filter_unselect(input){
	////console.log(input);
	////console.log(filters);
	for(var i in filters){
		if(filters[i]["name"]===input){
			for(var j in filters[i]["value"]){
				document.getElementById(filters[i]["name"]+"_"+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked = false;
			}
		}
	}
}

function filter_reset(){
	filter_init(data).then(() => {
		//console.log("hello");
		filter_apply();
	});
}

function filter_apply(){
	
	filtered_data = new Array();
	filters_active = new Array();
	jQuery.extend(true,filters_active,filters);
	for(var i in filters_active){
		filters_active[i]["value"] = [];
	}
	for(var i in filters){
		for(j in filters[i].value){
			try{

				if(document.getElementById(filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked){
					filters_active[i]["value"].push(filters[i]["value"][j]);
				}
			}catch(err){
				
				//console.log(err);
			}
		}
	}
	var filter_text="";
	for(var i in filters){
		if(filters_active[i].value.length<filters[i].value.length){
			filter_text = filter_text+filters_active[i].title+"("+filters_active[i].value.toString()+")  ";
		}
	}   
	
	for(var i in data){
		var valid = true;
		for(var j in filters_active){
			if(!filters_active[j].value.includes(data[i][filters_active[j]["name"]])){
				valid=false;
			}
		}
		if(valid){			
			filtered_data.push(JSON.parse(JSON.stringify(data[i])));
		}
	}
	document.getElementById("filter_text").innerHTML = "<strong>(# "+filtered_data.length+")</strong> "+filter_text;
  //  //console.log(min_limit);
	if(filtered_data.length<min_limit.min_filter){
		filtered_data = new Array();
		for(var i in data){
			filtered_data.push(JSON.parse(JSON.stringify(data[i])));
		}
		document.getElementById("filter_text").innerHTML=document.getElementById("filter_text").innerHTML+" <span style=\"font-size:14px\" >Not Enough Data (Showing Everything)<span>";
		modal("Not Enough Data","Data is too few to show insights <br> Showing all the data. Please select filter such that more data is selected");
	}
	update_ui();
	comparator_change();
	////console.log(filtered_data)
}

function update_ui(){
	questions = [];
	jQuery.extend(true,questions,questions_original);
	var MANAGER_INDEX = 0
	var ENGAGE_INDEX = 0;
	var CENGAGE_INDEX = 0;
	var LEADER_INDEX = 0;
	var WFH_INDEX = 0;
	var WFO_INDEX = 0;
	var HR_INDEX = 0;
	var WB_INDEX = 0;
	var CUSTOM_INDEX = 0;
	var INNOVATION_INDEX = 0;
	var JOTA_INDEX = 0;
	var JOTB_INDEX = 0;
	var JOTC_INDEX = 0;
	var JOTD_INDEX = 0;
	var PSN_INDEX = 0;
	var CDRIVER_INDEX = 0 ;
	var ORG_INDEX = 0;
	var ENGAGED=0;
	var NEARLY_ENGAGED=0;
	var NOT_ENGAGED=0;
	var DISENGAGED=0;
	var CENGAGED=0;
	var CNEARLY_ENGAGED=0;
	var CNOT_ENGAGED=0;
	var CDISENGAGED=0;
	var CEENGAGED=0;
	var CENEARLY_ENGAGED=0;
	var CENOT_ENGAGED=0;
	var CEDISENGAGED=0;
    var PERFORMANCE_HIGH=0;
    var PERFORMANCE_GOOD=0;
    var PERFORMANCE_AVG=0;
    var PERFORMANCE_LOW=0;
	var ATTRITION_RISK=0;
	var ATTRITION_HIGH=0;
	var ATTRITION_MEDIUM=0;
	var ATTRITION_LOW=0;
	var ATTRITION_RETAIN=0;
	var DIAGNOSTICS = {};
	
    riskZone = 0;
	riskCount =0;
		
	nonPerforming = 0;
	nonPerCount = 0 ;
		
	optimized = 0;
	optimizedCount = 0;
		
	subOptimized = 0;
	subOptimizedCount = 0 ;
		
	countryClub = 0;
	countryClubCount =0;
	businessImpactData = [];
	
	
	for(var i in filtered_data){
		var USER_ENGAGE=0;
		var USER_PSI = 0
		var DIAGNOSTICS_USER = [];
		if(ENGAGEMENT_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["ENGAGE"]=0;
		if(CUSTOMEER_ENGAGEMENT_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["CENGAGE"]=0;
		if(LEADER_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["LEADER"]=0;
		if(MANAGER_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["MANAGER"]=0;
		if(WFH_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["WFH"]=0;
		if(WFO_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["WFO"]=0;
		if(HR_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["HR"]=0;
		if(WB_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["WB"]=0;
		if(OTHER_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["CUSTOM"]=0;
		if(INNVO_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["INNV"]=0;
		if(JOTA_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["JOTA"]=0;
		if(JOTB_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["JOTB"]=0;
		if(JOTC_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["JOTC"]=0;
		if(JOTD_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["JOTD"]=0;
		if(PSN_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["PSN"]=0;
		if(CUSTOMER_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["CDRIVER"]=0;
		if(ORG_QUESTION_COUNT>0)
			DIAGNOSTICS_USER["ORG"]=0;
		
		
		if(CUSTOMER_QUESTION_COUNT <= 0)
		{
			for(var j in questions){
				if(filtered_data[i][questions[j]["code"]]>=4){
					questions[j]["result"]["positive"]++;
				}else if(filtered_data[i][questions[j]["code"]]<=2){
					questions[j]["result"]["negative"]++;
				}else{
					questions[j]["result"]["neutral"]++;
				}
				if(questions[j]["code"].startsWith("ENGAGE")){
					ENGAGE_INDEX=ENGAGE_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					USER_ENGAGE=USER_ENGAGE+parseInt(filtered_data[i][questions[j]["code"]]);
					if(questions[j]["code"]==="ENGAGE03"||questions[j]["code"]==="ENGAGE04"||questions[j]["code"]==="ENGAGE05"){
						USER_PSI=USER_PSI+parseInt(filtered_data[i][questions[j]["code"]]);
					}
					if(questions[j]["code"]==="ENGAGE02"&&parseInt(filtered_data[i][questions[j]["code"]])<=1){
						ATTRITION_RISK++;
					}else if(questions[j]["code"]==="ENGAGE06"&&parseInt(filtered_data[i][questions[j]["code"]])<=1){
						ATTRITION_RISK++;
					}

					DIAGNOSTICS_USER["ENGAGE"]=DIAGNOSTICS_USER["ENGAGE"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("LEADER")){
					LEADER_INDEX=LEADER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["LEADER"]=DIAGNOSTICS_USER["LEADER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("MANAGER")){
					MANAGER_INDEX=MANAGER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["MANAGER"]=DIAGNOSTICS_USER["MANAGER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WFH")){
					WFH_INDEX=WFH_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WFH"]=DIAGNOSTICS_USER["WFH"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WFO")){
					WFO_INDEX=WFO_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WFO"]=DIAGNOSTICS_USER["WFO"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("HR")){
					HR_INDEX=HR_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["HR"]=DIAGNOSTICS_USER["HR"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WB")){
					WB_INDEX=WB_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WB"]=DIAGNOSTICS_USER["WB"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("CUSTOM")){
					CUSTOM_INDEX=CUSTOM_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["CUSTOM"]=DIAGNOSTICS_USER["CUSTOM"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("INNV")){
					INNOVATION_INDEX=INNOVATION_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["INNV"]=DIAGNOSTICS_USER["INNV"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTA")){
					JOTA_INDEX=JOTA_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTA"]=DIAGNOSTICS_USER["JOTA"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTB")){
					JOTB_INDEX=JOTB_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTB"]=DIAGNOSTICS_USER["JOTB"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTC")){
					JOTC_INDEX=JOTC_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTC"]=DIAGNOSTICS_USER["JOTC"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTD")){
					JOTD_INDEX=JOTD_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTD"]=DIAGNOSTICS_USER["JOTD"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("PSN")){
					PSN_INDEX=PSN_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["PSN"]=DIAGNOSTICS_USER["PSN"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("CDRIVER")){
					CDRIVER_INDEX=CDRIVER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["CDRIVER"]=DIAGNOSTICS_USER["CDRIVER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("ORG")){
					ORG_INDEX=ORG_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["ORG"]=DIAGNOSTICS_USER["ORG"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
			}
			
				if(USER_ENGAGE/ENGAGEMENT_QUESTION_COUNT>=3.75){
					ENGAGED++;
				}else if(USER_ENGAGE/ENGAGEMENT_QUESTION_COUNT>=3){
					NEARLY_ENGAGED++;
				}else if(USER_ENGAGE/ENGAGEMENT_QUESTION_COUNT>=2){
					NOT_ENGAGED++;
				}else if(USER_ENGAGE/ENGAGEMENT_QUESTION_COUNT>0){
					DISENGAGED++;
				}
	
				USER_PSI=USER_PSI/3;
				////console.log(USER_PSI);
				if(parseInt(filtered_data[i]["ENGAGE03"])>=4){
					
					if(USER_PSI>=4.33){
						PERFORMANCE_HIGH++;
					}else if(USER_PSI>=3.5){
						PERFORMANCE_GOOD++;
					}else if(USER_PSI>=2){
						PERFORMANCE_AVG++;
					}
				}
				else if(parseInt(filtered_data[i]["ENGAGE03"])==3){
					if(USER_PSI >=3){
						PERFORMANCE_AVG++;
					}
					else{
						PERFORMANCE_LOW++;
					}
				} else{
						PERFORMANCE_LOW++;
				}

				if(parseInt(filtered_data[i]["ENGAGE02"]) <= 2){
					if(USER_PSI<=2){
						ATTRITION_HIGH++;                           
					}else if(USER_PSI<=2.34){
						ATTRITION_MEDIUM++;
					}else if(USER_PSI<=3){
						ATTRITION_LOW++;
					}else{
						 ATTRITION_RETAIN++;                                
					}
				}else {
					ATTRITION_RETAIN++;                                        
				 }		
		}
		else
		{
			// Code written for Customer Enagagement 
			
			 for(var j in questions){
				if(filtered_data[i][questions[j]["code"]]>=4){
					questions[j]["result"]["positive"]++;
				}else if(filtered_data[i][questions[j]["code"]]<=2){
					questions[j]["result"]["negative"]++;
				}else{
					questions[j]["result"]["neutral"]++;
				}
				if(questions[j]["code"].startsWith("CENGAGE")){
					CENGAGE_INDEX=CENGAGE_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					USER_ENGAGE=USER_ENGAGE+parseInt(filtered_data[i][questions[j]["code"]]);
					if(questions[j]["code"]==="CENGAGE03"||questions[j]["code"]==="CENGAGE04"||questions[j]["code"]==="CENGAGE05"){
						USER_PSI=USER_PSI+parseInt(filtered_data[i][questions[j]["code"]]);
					}
					if(questions[j]["code"]==="CENGAGE02"&&parseInt(filtered_data[i][questions[j]["code"]])<=1){
						ATTRITION_RISK++;
					}else if(questions[j]["code"]==="CENGAGE06"&&parseInt(filtered_data[i][questions[j]["code"]])<=1){
						ATTRITION_RISK++;
					}

					DIAGNOSTICS_USER["CENGAGE"]=DIAGNOSTICS_USER["CENGAGE"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("LEADER")){
					LEADER_INDEX=LEADER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["LEADER"]=DIAGNOSTICS_USER["LEADER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("MANAGER")){
					MANAGER_INDEX=MANAGER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["MANAGER"]=DIAGNOSTICS_USER["MANAGER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WFH")){
					WFH_INDEX=WFH_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WFH"]=DIAGNOSTICS_USER["WFH"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WFO")){
					WFO_INDEX=WFO_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WFO"]=DIAGNOSTICS_USER["WFO"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("HR")){
					HR_INDEX=HR_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["HR"]=DIAGNOSTICS_USER["HR"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}else if(questions[j]["code"].startsWith("WB")){
					WB_INDEX=WB_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["WB"]=DIAGNOSTICS_USER["WB"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("CUSTOM")){
					CUSTOM_INDEX=CUSTOM_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["CUSTOM"]=DIAGNOSTICS_USER["CUSTOM"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("INNV")){
					INNOVATION_INDEX=INNOVATION_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["INNV"]=DIAGNOSTICS_USER["INNV"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTA")){
					JOTA_INDEX=JOTA_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTA"]=DIAGNOSTICS_USER["JOTA"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTB")){
					JOTB_INDEX=JOTB_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTB"]=DIAGNOSTICS_USER["JOTB"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTC")){
					JOTC_INDEX=JOTC_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTC"]=DIAGNOSTICS_USER["JOTC"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("JOTD")){
					JOTD_INDEX=JOTD_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["JOTD"]=DIAGNOSTICS_USER["JOTD"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("PSN")){
					PSN_INDEX=PSN_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["PSN"]=DIAGNOSTICS_USER["PSN"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("CDRIVER")){
					CDRIVER_INDEX=CDRIVER_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["CDRIVER"]=DIAGNOSTICS_USER["CDRIVER"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
				else if(questions[j]["code"].startsWith("ORG")){
					ORG_INDEX=ORG_INDEX+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER["ORG"]=DIAGNOSTICS_USER["ORG"]+parseInt(filtered_data[i][questions[j]["code"]]);
					DIAGNOSTICS_USER[questions[j]["code"]]=parseInt(filtered_data[i][questions[j]["code"]]);
				}
			}
			
					// Customer Enagagement
				if(USER_ENGAGE/CUSTOMEER_ENGAGEMENT_QUESTION_COUNT>=3.75){
					CENGAGED++;
				}else if(USER_ENGAGE/CUSTOMEER_ENGAGEMENT_QUESTION_COUNT>=3){
					CNEARLY_ENGAGED++;
				}else if(USER_ENGAGE/CUSTOMEER_ENGAGEMENT_QUESTION_COUNT>=2){
					CNOT_ENGAGED++;
				}else if(USER_ENGAGE/CUSTOMEER_ENGAGEMENT_QUESTION_COUNT>0){
					CDISENGAGED++;
				}
				USER_PSI=USER_PSI/3;
				
				if(parseInt(filtered_data[i]["CENGAGE03"])>=4){
					if(USER_PSI>=4.33){
						PERFORMANCE_HIGH++;
					}else if(USER_PSI>=3.5){
						PERFORMANCE_GOOD++;
					}else if(USER_PSI>=2){
						PERFORMANCE_AVG++;
					}
				}
				else if(parseInt(filtered_data[i]["CENGAGE03"])==3){
					if(USER_PSI >=3){
						PERFORMANCE_AVG++;
					}
					else{
						PERFORMANCE_LOW++;
					}
				} else{
						PERFORMANCE_LOW++;
				}

				if(parseInt(filtered_data[i]["CENGAGE02"]) <= 2){
					if(USER_PSI<=2){
						ATTRITION_HIGH++;                           
					}else if(USER_PSI<=2.34){
						ATTRITION_MEDIUM++;
					}else if(USER_PSI<=3){
						ATTRITION_LOW++;
					}else{
						 ATTRITION_RETAIN++;                                
					}
				}else {
					ATTRITION_RETAIN++;                                        
				 }
			
		}
               
		
		
		// End of Customer Enagagement ///
		

		////console.log(DIAGNOSTICS_USER);
		for(var j in DIAGNOSTICS_USER){
			if(j==="ENGAGE"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/ENGAGEMENT_QUESTION_COUNT;
			}else if(j === "CENGAGE"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/CUSTOMEER_ENGAGEMENT_QUESTION_COUNT;
			}else if(j === "LEADER"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/LEADER_QUESTION_COUNT;
			}else if(j === "MANAGER"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/MANAGER_QUESTION_COUNT;
			}else if(j === "WFH"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/WFH_QUESTION_COUNT;
			}else if(j === "WFO"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/WFO_QUESTION_COUNT;
			}else if(j === "HR"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/HR_QUESTION_COUNT;
			}else if(j === "WB"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/WB_QUESTION_COUNT;
			}
			else if(j === "CUSTOM"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/OTHER_QUESTION_COUNT;
			}
			else if(j === "INNV"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/INNVO_QUESTION_COUNT;
			}
			else if(j === "JOTA"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/JOTA_QUESTION_COUNT;
			}
			else if(j === "JOTB"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/JOTB_QUESTION_COUNT;
			}
			else if(j === "JOTC"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/JOTC_QUESTION_COUNT;
			}else if(j === "JOTD"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/JOTD_QUESTION_COUNT;
			}
			else if(j === "PSN"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/PSN_QUESTION_COUNT;
			}
			else if(j === "CDRIVER"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/CUSTOMER_QUESTION_COUNT;
			}
			else if(j === "ORG"){
				DIAGNOSTICS_USER[j]=DIAGNOSTICS_USER[j]/ORG_QUESTION_COUNT;
			}
			
			DIAGNOSTICS_USER[j+"_SQUARE"]=DIAGNOSTICS_USER[j]*DIAGNOSTICS_USER[j];
		}
		for(var j in DIAGNOSTICS_USER){
			if(!j.startsWith("ENGAGE")&&!j.endsWith("_SQUARE")){
				DIAGNOSTICS_USER[j+"_ENGAGE"] = DIAGNOSTICS_USER[j]*DIAGNOSTICS_USER["ENGAGE"];
			}
		}
		
		
		for(var j in DIAGNOSTICS_USER){
			if(!j.startsWith("CENGAGE")&&!j.endsWith("_SQUARE")){
				DIAGNOSTICS_USER[j+"_CENGAGE"] = DIAGNOSTICS_USER[j]*DIAGNOSTICS_USER["CENGAGE"];
			}
		}
		
		if(Object.keys(DIAGNOSTICS).length==0){
			jQuery.extend(true,DIAGNOSTICS,DIAGNOSTICS_USER);			
		}else{			
			for(var j in DIAGNOSTICS_USER){
				DIAGNOSTICS[j]=DIAGNOSTICS[j]+DIAGNOSTICS_USER[j];
			}
		} 
	}
	////console.log(PERFORMANCE_HIGH+" "+PERFORMANCE_GOOD+" "+PERFORMANCE_AVG+" "+PERFORMANCE_LOW);
	ENGAGE_INDEX=(ENGAGE_INDEX/(ENGAGEMENT_QUESTION_COUNT*filtered_data.length));
	CENGAGE_INDEX=(CENGAGE_INDEX/(CUSTOMEER_ENGAGEMENT_QUESTION_COUNT*filtered_data.length));
	MANAGER_INDEX=(MANAGER_INDEX/(MANAGER_QUESTION_COUNT*filtered_data.length));
	LEADER_INDEX=(LEADER_INDEX/(LEADER_QUESTION_COUNT*filtered_data.length));
	WFH_INDEX=(WFH_INDEX/(WFH_QUESTION_COUNT*filtered_data.length));
	WFO_INDEX=(WFO_INDEX/(WFO_QUESTION_COUNT*filtered_data.length));
	HR_INDEX=(HR_INDEX/(HR_QUESTION_COUNT*filtered_data.length));
	WB_INDEX=(WB_INDEX/(WB_QUESTION_COUNT*filtered_data.length));
	CUSTOM_INDEX=(CUSTOM_INDEX/(OTHER_QUESTION_COUNT *filtered_data.length));
	INNOVATION_INDEX=(INNOVATION_INDEX/(INNVO_QUESTION_COUNT*filtered_data.length));
	JOTA_INDEX=(JOTA_INDEX/(JOTA_QUESTION_COUNT*filtered_data.length));
	JOTB_INDEX=(JOTB_INDEX/(JOTB_QUESTION_COUNT*filtered_data.length));
	JOTC_INDEX=(JOTC_INDEX/(JOTC_QUESTION_COUNT*filtered_data.length));
	JOTD_INDEX=(JOTD_INDEX/(JOTD_QUESTION_COUNT*filtered_data.length));
	PSN_INDEX=(PSN_INDEX/(PSN_QUESTION_COUNT*filtered_data.length));
	ORG_INDEX=(ORG_INDEX/(ORG_QUESTION_COUNT*filtered_data.length));
	ENGAGE_PERC=((ENGAGED*100)/filtered_data.length);
	CENGAGE_PERC=((CENGAGED*100)/filtered_data.length);
	CDRIVER_INDEX=(CDRIVER_INDEX/(CUSTOMER_QUESTION_COUNT*filtered_data.length));
	
	//PERFORMANCE_TOTAL = PERFORMANCE_HIGH+PERFORMANCE_GOOD+PERFORMANCE_AVG+PERFORMANCE_LOW;
	PERFORMANCE_HIGH=Math.round((PERFORMANCE_HIGH*100)/filtered_data.length);
	PERFORMANCE_GOOD=Math.round((PERFORMANCE_GOOD*100)/filtered_data.length);
	PERFORMANCE_AVG=Math.round((PERFORMANCE_AVG*100)/filtered_data.length);
	PERFORMANCE_LOW=Math.round((PERFORMANCE_LOW*100)/filtered_data.length);

	ATTRITION_HIGH = Math.round((ATTRITION_HIGH*100)/filtered_data.length);
	ATTRITION_MEDIUM = Math.round((ATTRITION_MEDIUM*100)/filtered_data.length);
	ATTRITION_LOW = Math.round((ATTRITION_LOW*100)/filtered_data.length);
	ATTRITION_RETAIN = Math.round((ATTRITION_RETAIN*100)/filtered_data.length);
	ATTRITION_RISK = (ATTRITION_RISK*100)/filtered_data.length;
     
    attrition = ATTRITION_HIGH;
    performance = PERFORMANCE_HIGH;

	var POSISTIVITY_INDEX = (ENGAGED)/(NOT_ENGAGED+DISENGAGED);
	
	//var CPOSISTIVITY_INDEX = (CENGAGED)/(NOT_ENGAGED+DISENGAGED);

	var ENGAGE_BENCHMARK_AREA="";
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")){
			ENGAGE_BENCHMARK_AREA=ENGAGE_BENCHMARK_AREA+`<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center" data-toggle="tooltip"  title="`+questions[j]["question"]+`">`+questions[j]["driver"]+`
						<br><small>`+questions[j]["hint"]+`</small>
					</div>
					<div class="col-md-5 order-md-1 text-center"  id="`+questions[j]["code"]+`_CHART" >
					</div>
						
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_`+questions[j]["code"]+`_CHART" >...
					</div>
					
				</div>`
		}
	}
	
	
	
	for(var j in questions){
		if(questions[j]["code"].startsWith("CENGAGE")){
			ENGAGE_BENCHMARK_AREA=ENGAGE_BENCHMARK_AREA+`<div class="row mt-3">
					<div class="col-md-2 text-center" data-toggle="tooltip"  title="`+questions[j]["question"]+`">`+questions[j]["driver"]+`
						<br><small>`+questions[j]["hint"]+`</small>
					</div>
					<div class="col-md-10 order-md-1 text-center"  id="`+questions[j]["code"]+`_CHART" >
					</div>
						
					
				</div>`
		}
	}
	
	if(CUSTOMER_QUESTION_COUNT > 0)
	{
		document.getElementById('ENGAGE_BENCHMARK_AREA_CE').innerHTML = ENGAGE_BENCHMARK_AREA;
	}
	else
	{
		document.getElementById('ENGAGE_BENCHMARK_AREA').innerHTML = ENGAGE_BENCHMARK_AREA;
	}
	
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")){
			ENGAGE_COMPANY_GRAPH(questions[j]["code"]+"_CHART",questions[j]["result"]["positive"],questions[j]["result"]["neutral"],questions[j]["result"]["negative"]);
		}
	}
	
	for(var j in questions){
		if(questions[j]["code"].startsWith("CENGAGE")){
			ENGAGE_COMPANY_GRAPH(questions[j]["code"]+"_CHART",questions[j]["result"]["positive"],questions[j]["result"]["neutral"],questions[j]["result"]["negative"]);
		}
	}
	/*Engagement Tab
	if(min_limit.min_predictive<=filtered_data.length){
		document.getElementById('predicted_high_performance').innerHTML = Math.floor(PERFORMANCE_HIGH)+"%"; 
		document.getElementById('predicted_performance').innerHTML = Math.floor(PERFORMANCE_GOOD)+"%"; 
		document.getElementById('predicted_attrition').innerHTML = Math.floor(ATTRITION_RISK)+"%";
	}else{
		document.getElementById('predicted_high_performance').innerHTML = "NA";
		document.getElementById('predicted_performance').innerHTML = "NA";
		document.getElementById('predicted_attrition').innerHTML = "NA";
	} */
	
	document.getElementById('num_of_reponses_1').innerHTML = Math.round(filtered_data.length);
	document.getElementById('num_of_reponses_1CE').innerHTML = Math.round(filtered_data.length);
	document.getElementById('engagement_perc_1').innerHTML =ENGAGE_PERC.toFixed(0)+"%"; 
	document.getElementById('engagement_perc_1CE').innerHTML =CENGAGE_PERC.toFixed(0)+"%"; 
	document.getElementById('engagement_index').innerHTML = ENGAGE_INDEX.toFixed(2);
	document.getElementById('engagement_indexCE').innerHTML = CENGAGE_INDEX.toFixed(2);
	document.getElementById('positivity_index').innerHTML = POSISTIVITY_INDEX.toFixed(2)+" : 1";
                                                       
    /* Call TO chart methods */
	
	if(CUSTOMEER_ENGAGEMENT_QUESTION_COUNT > 0)
	{
		engagement_donut(CENGAGED,CNEARLY_ENGAGED,CNOT_ENGAGED,CDISENGAGED);
	}
	else
	{
		engagement_donut(ENGAGED,NEARLY_ENGAGED,NOT_ENGAGED,DISENGAGED);
	}

	// engagement_donut(ENGAGED,NEARLY_ENGAGED,NOT_ENGAGED,DISENGAGED);
    attrition_donut(ATTRITION_HIGH,ATTRITION_MEDIUM,ATTRITION_LOW,ATTRITION_RETAIN);
    prediction_donut(PERFORMANCE_HIGH,PERFORMANCE_GOOD,PERFORMANCE_AVG,PERFORMANCE_LOW);

	try{benchmark_change();}catch(err){}
	
	/*Driver Analysis Tab*/
	document.getElementById('num_of_reponses_2').innerHTML = Math.round(filtered_data.length);
	document.getElementById('engagement_index_2').innerHTML = ENGAGE_INDEX.toFixed(2);
	document.getElementById('engagement_perc_2').innerHTML = ENGAGE_PERC.toFixed(0)+"%";
	if(ENGAGEMENT_QUESTION_COUNT>0)
		INDEX["ENGAGE"] = ENGAGE_INDEX.toFixed(2);
	if(MANAGER_QUESTION_COUNT>0)
		INDEX["MANAGER"] = MANAGER_INDEX.toFixed(2);
	if(LEADER_QUESTION_COUNT>0)
		INDEX["LEADER"] = LEADER_INDEX.toFixed(2);
	if(WFH_QUESTION_COUNT>0)
		INDEX["WFH"] = WFH_INDEX.toFixed(2);
	if(WFO_QUESTION_COUNT>0)
		INDEX["WFO"] = WFO_INDEX.toFixed(2);
	if(HR_QUESTION_COUNT>0)
		INDEX["HR"] = HR_INDEX.toFixed(2);
	if(WB_QUESTION_COUNT>0)
		INDEX["WB"] = WB_INDEX.toFixed(2);
	if( OTHER_QUESTION_COUNT>0)
		INDEX["CUSTOM"] = CUSTOM_INDEX.toFixed(2);
	if(INNVO_QUESTION_COUNT>0)
		INDEX["INNV"] = INNOVATION_INDEX.toFixed(2);
	if(JOTA_QUESTION_COUNT>0)
		INDEX["JOTA"] = JOTA_INDEX.toFixed(2);
	if(JOTB_QUESTION_COUNT>0)
		INDEX["JOTB"] = JOTB_INDEX.toFixed(2);
	if(JOTC_QUESTION_COUNT>0)
		INDEX["JOTC"] = JOTC_INDEX.toFixed(2);
	if(JOTD_QUESTION_COUNT>0)
		INDEX["JOTD"] = JOTD_INDEX.toFixed(2);
	if(PSN_QUESTION_COUNT>0)
		INDEX["PSN"] = PSN_INDEX.toFixed(2);
	if(CUSTOMER_QUESTION_COUNT>0)
		INDEX["CDRIVER"] = CDRIVER_INDEX.toFixed(2);
	if(ORG_QUESTION_COUNT>0)
		INDEX["ORG"] = ORG_INDEX.toFixed(2);
	
	
	//document.getElementById('wfh_index').innerHTML = WFH_INDEX.toFixed(2);
	//document.getElementById('hr_index').innerHTML =  HR_INDEX.toFixed(2);
	//document.getElementById('manager_index').innerHTML = MANAGER_INDEX.toFixed(2);
	//document.getElementById('leader_index').innerHTML = LEADER_INDEX.toFixed(2);
	//document.getElementById('well_being_index').innerHTML = WB_INDEX.toFixed(2);
	driver_selector_init();
	driver_selector_change();
	/*Qualitative Tab*/
	var open_select  = "";
	for(var i in questions_original){
		if(questions_original[i]["code"].startsWith("OPEN")){
			open_select=open_select+`<option value="`+questions_original[i]["code"]+`">`+questions_original[i]["driver"]+`</option>`;
		}
	}
	document.getElementById('open_select').innerHTML = open_select;
	open_select_change();
	/*Heatmap Tab*/
	try{heatmap_change();}catch(err){}
	/*Diagnostic Tab*/
	CORRELATION_INDEX = {};
	CORRELATION_QUESTION = {};
	for(var i in DIAGNOSTICS){
		if(!i.includes("ENGAGE")&&!i.includes("_SQUARE")){
			if(i=="HR"||i=="LEADER"||i=="MANAGER"||i=="WFH"||i=="WFO"||i=="WB" || i=="CUSTOM" || i=="INNV" || i=="JOTA" || i=="JOTB" || i=="JOTC" || i=="JOTD" || i=="PSN" || i=="CDRIVER" || i=="ORG" ){
				CORRELATION_INDEX[i]=((filtered_data.length*DIAGNOSTICS[i+"_ENGAGE"])-(DIAGNOSTICS[i]*DIAGNOSTICS["ENGAGE"]))/Math.sqrt(((filtered_data.length*DIAGNOSTICS[i+"_SQUARE"])-Math.pow(DIAGNOSTICS[i],2))*((filtered_data.length*DIAGNOSTICS["ENGAGE_SQUARE"])-Math.pow(DIAGNOSTICS["ENGAGE"],2)));
			}else{
				CORRELATION_QUESTION[i]= {};
				if(i.startsWith("HR"))
					CORRELATION_QUESTION[i]["category"] = "Human Resource";
				if(i.startsWith("WB"))
					CORRELATION_QUESTION[i]["category"] = "Well Being";
				if(i.startsWith("LEADER"))
					CORRELATION_QUESTION[i]["category"] = "Leader";
				if(i.startsWith("MANAGER"))
					CORRELATION_QUESTION[i]["category"] = "Manager";
				if(i.startsWith("WFH"))
					CORRELATION_QUESTION[i]["category"] = "Work From Home";
				if(i.startsWith("WFO"))
					CORRELATION_QUESTION[i]["category"] = "Work from Office";
				if(i.startsWith("CUSTOM"))
					CORRELATION_QUESTION[i]["category"] = "Custom";
				if(i.startsWith("INNV"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("JOTA"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("JOTB"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("JOTC"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("JOTD"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("PSN"))
					CORRELATION_QUESTION[i]["category"] = "Innovation";
				if(i.startsWith("CDRIVER"))
					CORRELATION_QUESTION[i]["category"] = "Customer driver";
				if(i.startsWith("ORG"))
					CORRELATION_QUESTION[i]["category"] = "Organization";
				
				CORRELATION_QUESTION[i]["correlation"]=((filtered_data.length*DIAGNOSTICS[i+"_ENGAGE"])-(DIAGNOSTICS[i]*DIAGNOSTICS["ENGAGE"]))/Math.sqrt(((filtered_data.length*DIAGNOSTICS[i+"_SQUARE"])-Math.pow(DIAGNOSTICS[i],2))*((filtered_data.length*DIAGNOSTICS["ENGAGE_SQUARE"])-Math.pow(DIAGNOSTICS["ENGAGE"],2)));
				for(j in questions){
					if(questions[j].code == i){
						CORRELATION_QUESTION[i]["score"]=((questions[j]["result"]["positive"]*100)/filtered_data.length);
						CORRELATION_QUESTION[i]["driver"]=questions[j]["driver"];
						CORRELATION_QUESTION[i]["recommendation"]=questions[j]["recommendation"];
						CORRELATION_QUESTION[i]["description"]=questions[j]["description"];
						break;
					}
				}
			}
		}
	}

	var correlation_index_html = "<h2 title=\"Impact -> Correlation\" data-toggle=\"tooltip\">Impact</h2>";
	var diagnostic_select_option = `<option value="ALL">All</option>`;
	for(var i in CORRELATION_INDEX){
		if(i=="HR"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Human Resource</label>
			<div class="progress" title="Human Resource: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+
				(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="HR">Human Resource</option>`;
		}else if(i=="LEADER"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Leadership</label>
			<div class="progress" title="Leadership: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="LEADER">Leadership</option>`;
		}else if(i=="MANAGER"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Manager</label>
			<div class="progress" title="Manager: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="MANAGER">Manager</option>`;
		}else if(i=="WB"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Well Being</label>
			<div class="progress" title="Well Being: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="WB">Well Being</option>`;
		}else if(i=="WFH"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Work from Home</label>
			<div class="progress" title="Work from Home: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="WFH">Work From Home</option>`;
		}else if(i=="WFO"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Work from Office</label>
			<div class="progress" title="Work from Office: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="WFO">Work from Office</option>`;
		}
		else if(i=="CUSTOM"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Custom</label>
			<div class="progress" title="Custom: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="CUSTOM">Custom</option>`;
		}
		else if(i=="INNV"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Innovation</label>
			<div class="progress" title="Innovation: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="INNV">Innovation</option>`;
		}
		else if(i=="JOTA"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Employee Productivity and Motivation</label>
			<div class="progress" title="Employee Productivity and Motivation: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="JOTA">Employee Productivity and Motivation</option>`;
		}
		else if(i=="JOTB"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Leadership Trust & Direction </label>
			<div class="progress" title="Leadership Trust & Direction : `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="JOTB">Leadership Trust & Direction </option>`;
		}
		else if(i=="JOTC"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Employee Retention</label>
			<div class="progress" title="Employee Retention: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="JOTC">Employee Retention</option>`;
		}
		else if(i=="JOTD"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Work, Process & Technology</label>
			<div class="progress" title="Work, Process & Technology: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="JOTD">Work, Process & Technology</option>`;
		}
		else if(i=="PSN"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">psychological Safety Net</label>
			<div class="progress" title="psychological Safety Net: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="PSN">psychological Safety Net</option>`;
		}
		else if(i=="CDRIVER"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Customer driver</label>
			<div class="progress" title="Customer driver: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="CDRIVER">Customer driver</option>`;
		}
		else if(i=="ORG"){
			correlation_index_html = correlation_index_html+`
			<label class="mt-3">Organization</label>
			<div class="progress" title="Organization: `+CORRELATION_INDEX[i].toFixed(2)+`" data-toggle="tooltip">
				<div class="progress-bar text-left bg-secondary" style="width:`+(CORRELATION_INDEX[i]*100)+`%"> &nbsp; &nbsp; &nbsp; `+CORRELATION_INDEX[i].toFixed(2)+`</div>
			</div>`;
			diagnostic_select_option = diagnostic_select_option + `<option value="ORG">Organization</option>`;
		}
	}
	////console.log(correlation_index_html);
	////console.log(diagnostic_select_option);
	document.getElementById('correlation_index').innerHTML = correlation_index_html;
	document.getElementById('diagnostic_select').innerHTML = diagnostic_select_option;
	
	
	////console.log(diagnostic_select_option);
	// Gaurav Code Added
	//document.getElementById('businessImpact_select').innerHTML = diagnostic_select_option;
	////console.log(CORRELATION_QUESTION);
	CORRELATION_QUESTION_DATA = [];
	
	for(var i in CORRELATION_QUESTION){
		var temp_data = CORRELATION_QUESTION[i];
		temp_data["question_code"] = i;	
		if(temp_data["correlation"]<0.3&&temp_data["score"]<50)
			temp_data["quadrant"] = "Low Focus";
		else if(temp_data["correlation"]<0.3&&temp_data["score"]>=50)
			temp_data["quadrant"] = "Not Critical";
		else if(temp_data["correlation"]>=0.3&&temp_data["score"]<50)
			temp_data["quadrant"] = "Improvement";
		else if(temp_data["correlation"]>=0.3&&temp_data["score"]>=75)
			temp_data["quadrant"] = "Excellence";
		else if(temp_data["correlation"]>=0.3&&temp_data["score"]>=50)
			temp_data["quadrant"] = "Towards Excellence";
		else
			temp_data["quadrant"] = "No Condition";
		CORRELATION_QUESTION_DATA.push(temp_data);
	}
	
	//document.getElementById('correlation_scatterplot').innerHTML = JSON.stringify(CORRELATION_QUESTION_DATA, null, 2);
	////console.log(CORRELATION_QUESTION_DATA);
	// Start Business Impact Section here
	// calulating coordinate for Business Impact
	
	//let tempData = data;
	let tempData = filtered_data;
	businessImpactData = [];
	
	////console.log(businessImpactData.length);
	const totalManager =  [...new Set(tempData.map(x=>x.manager_Id))];
	let m=0;
	//console.log("Total Manager is : ",totalManager);
	let xValue  = 0;
	let yValue = 0;
	let devident =0;
	let managerName = "";
	let pass = 0;
	
	for(let i=0;i<totalManager.length;i++)
	{
		devident =0;
		xValue = 0;
		yValue = 0;
		managerName = "";
		pass = 0;
		for(let j=0;j<tempData.length;j++)
		{
			if(totalManager[i]  == tempData[j].manager_Id)
			{
				
				if(pass == 0 )
				{
					for(let k=0;k<managerInformation.length;k++)
					{
						if(managerInformation[k].id == totalManager[i] )
						{
							pass = 1;
							managerName = managerInformation[k].managerName;
							break;
						}
					}
				}
				
				yValue = yValue +  parseInt(tempData[j].p_sales);
				xValue = xValue +  ( parseInt(tempData[j].ENGAGE01) + parseInt(tempData[j].ENGAGE02) + parseInt(tempData[j].ENGAGE03) + parseInt(tempData[j].ENGAGE04) + parseInt(tempData[j].ENGAGE05) ) / 5;
			
				devident ++;
			}
			
		}
		
		let quan = "";
		
		yValue = yValue / devident;
		
		xValue = xValue / devident;
		
		if(yValue > 0)
		{
			m++;
			if(yValue > 100 && xValue <= 3.8 )
			{
				riskZone = riskZone + yValue;
				riskCount ++;
				quan = "Risk Zone";
			}
			else if(yValue >= 100 && xValue > 3.8)
			{
				optimized = optimized + yValue;
				optimizedCount ++;
				
				quan = "Optimized";
			}
			else if((yValue <= 100 && yValue >=75) && xValue < 3.8  )
			{
				
				quan = "Risk Zone";
			}
			else if( (yValue <= 100 && yValue >=75) && xValue > 3.8)
			{
				subOptimized = subOptimized + yValue ;
				subOptimizedCount ++;
				quan = "Sub-Optimized";
			}
			else if((yValue < 75 && yValue >=0) && xValue < 3.8  )
			{
				nonPerforming = nonPerforming + yValue;
				nonPerCount ++;
				quan = "Non-Performing";
			}
			else if(( yValue <= 75 && yValue >=0) && xValue > 3.8)
			{
				countryClub = countryClub + yValue;
				countryClubCount ++;
				quan = "Country Club";
			}
			
			
			if(yValue > maxValueofY)
			{
				maxValueofY = yValue;
			}
			
				
			businessImpactData.push({
				"xAxis": xValue,
				"yAxis": yValue,
				"quadrant": quan,
				"teamSize" : devident,
				"managerName" : managerName
			});
		}
	}

	// End Business Impact section here

	diagnostic_select_change();	
	//businessImpact_select_change();
	
	if(ENGAGEMENT_QUESTION_COUNT<1){
		 $("#engagement_tab").addClass("d-none");
		 $("#diagnostic_tab").addClass("d-none");
		 $("#engagement_perc_2_card").addClass("d-none");
		 $("#engagement_index_2_card").addClass("d-none");
		 $('[href="#driver_analysis"]').tab('show');
	}
	if(OPEN_QUESTION_COUNT<1){
		 $("#qualitative_tab").addClass("d-none");
	}
	//comparator_setup();
}




function engagement_donut(HIGH,GOOD,AVG,LOW){

	if(noOfTimes1 == 0)
	{
			noOfTimes1 = 1;
			let total = HIGH + GOOD + AVG + LOW;
         var optionsF = {
                  series: [(HIGH * 100) / total, (GOOD * 100) / total, (AVG * 100) / total,(LOW * 100) / total],
                  chart: {
                  type: 'donut',
                },
					
				tooltip: {
                  y: {
                    formatter: function(value) {
						 
                      return value.toFixed(0) + "%";
					 
                    }
                  }
                },
                labels: ['Engaged', 'Nearly Engaged', 'Passively Disengaged', 'Actively Disengaged'],
                colors: ['#41A4FF','#A0D1FF','#EFB5B9','#DE6A73'],

              dataLabels: {
              enabled: true,
              formatter: function (val) {
                 return (Math.round(val)).toFixed(0) + "%"
              },
              textAnchor: 'start',
              offsetX:0,

              dropShadow: {
                enabled: false,
                 }
              },

                 legend: {
                show: true,
                floating: false,
                fontSize: '12%',
                position: 'bottom',
                labels: {
                    useSeriesColors: true,
                 },
              markers: {
                size: 0
             },
             formatter: function(seriesName, opts) { 

                return seriesName + ":  " + Math.abs(opts.w.globals.series[opts.seriesIndex]).toFixed(0) + "%"
          },

          itemMargin: {
            vertical: 3
          }
        }    

                };
				
		if(CUSTOMEER_ENGAGEMENT_QUESTION_COUNT > 0)
		{
			chart1 = new ApexCharts(document.querySelector("#enagement_donut_containerCE"), optionsF);
		}
		else
		{
			chart1 = new ApexCharts(document.querySelector("#enagement_donut_container"), optionsF);
		}
       
        chart1.render();
		}
		else
		{
			let total = HIGH + GOOD + AVG + LOW;	
			chart1.updateSeries( [(HIGH * 100) / total, (GOOD * 100) / total, (AVG * 100) / total,(LOW * 100) / total]);

}
  
}

function prediction_donut(HIGH,GOOD,AVG,LOW){
	 
	if(noOfTimes2 == 0)
	{
		 noOfTimes2 = 1;
		

     var options = {
          series: [HIGH, GOOD, AVG,LOW],
          chart: {
          type: 'donut',
        },
		tooltip: {
                  y: {
                    formatter: function(value) {
                      return value.toFixed(0) + "%";
                    }
                  }
                },
		labels: ['HIGH', 'GOOD', 'AVG', 'LOW'],
		colors: ['#41A4FF','#A0D1FF','#EFB5B9','#DE6A73'],
		
		  dataLabels: {
      enabled: true,
      formatter: function (val) {
         return (Math.round(val)).toFixed(0) + "%"
      },
      textAnchor: 'start',
      offsetX:0,
     
      dropShadow: {
        enabled: false,
         }
      },

  		 legend: {
          show: true,
          floating: false,
          fontSize: '14%',
          position: 'bottom',
          labels: {
            useSeriesColors: true,
          },
          markers: {
            size: 0
          },
          formatter: function(seriesName, opts) { 

            return seriesName + ":  " + Math.abs(opts.w.globals.series[opts.seriesIndex]).toFixed(0) + "%"
          },
          itemMargin: {
            vertical: 3
          }
        }    


        };
	
		chart2 = new ApexCharts(document.querySelector("#prediction_donut_container"), options);

     chart2.render();

	}
	else
	{
	    chart2.updateSeries([HIGH, GOOD, AVG,LOW]);
	}



}


function attrition_donut(attrition_high,attrition_medium,attrition_low,attrition_retain){ 


	if(noOfTimes3 == 0)
	{
		 noOfTimes3 = 1;

		 //console.log(" 3 thord wala ",noOfTimes3)
		 var options = {
          series: [attrition_high, attrition_medium, attrition_low,attrition_retain],
          chart: {
          type: 'donut',
        },
		tooltip: {
                  y: {
                    formatter: function(value) {
                      return value.toFixed(0) + "%";
                    }
                  }
        },
		labels: ['High', 'Medium', 'Low', 'Retention'],
		colors: ['#DE6A73','#EFB5B9','#A0D1FF','#41A4FF'],

     dataLabels: {
      enabled: true,
      formatter: function (val) {
         return (Math.round(val)).toFixed(0) + "%"
      },
      textAnchor: 'start',
      offsetX:0,
     
      dropShadow: {
        enabled: false,
         }
      },

		  		 legend: {
        show: true,
        floating: false,
        fontSize: '14%',
        position: 'bottom',
        labels: {
          useSeriesColors: true,
        },
        markers: {
          size: 0
        },
        formatter: function(seriesName, opts) {

          return seriesName + ":  " + Math.abs(opts.w.globals.series[opts.seriesIndex]).toFixed(0) + "%"
        },
        itemMargin: {
          vertical: 3
        }
      }    
              };

     chart3 = new ApexCharts(document.querySelector("#attrition_donut_container"), options);
     chart3.render();	
	}
	else
	{
		chart3.updateSeries([attrition_high, attrition_medium, attrition_low,attrition_retain]);
		
	}
			
	
}


function select_Business_Filter()
{
	let selectedValue = document.getElementById('businessImpact_select').value;
	
	//console.log("Filter Value ",selectedValue);
	
	if(selectedValue == "ALL")
	{
		
		setBusinessImpactFilter = true;
		//businessImpact_select_change();
	}
	else
	{
		setBusinessImpactFilter = false;
		//businessImpact_select_change();
	}
}

// For Business Impact function Start here 
function businessImpact_select_change(){
	
   //console.log("All Business Data : ",businessImpactData);
   businessImpactData2 = [];
	id = "businessImpact_scatterplot";
	if(maxValueofY > 0){
	
	var business_select = document.getElementById('businessImpact_select').value;
	
	if(setBusinessImpactFilter == true)
	{
		businessImpactData2 = businessImpactData;
	}
	else
	{
		businessImpactData2 = businessImpactData.filter(selectFilter => selectFilter.quadrant == business_select);
	}
	
	//console.log("Busniss select data  ",businessImpactData2);
	
	//var temp_data = CORRELATION_QUESTION_DATA.filter( correlation => { if(correlation.question_code.startsWith(diagnostic_select)||diagnostic_select==="ALL") return true ;} );
	
	//console.log("Temp data find ",temp_data);
	
	// var diagnostic_recommendation=`<table class="table"><tr><th>Competency</th><th>Recommendation</th></tr>`;
	// for(var i in temp_data){
	//	//console.log(data[i]);
		// if(temp_data[i].score<75&&temp_data[i].correlation>=0.5)
			// diagnostic_recommendation = diagnostic_recommendation + `<tr><th>`+temp_data[i].driver+`</th><td>`+temp_data[i].description+`</td></tr>`;
	// }
	// diagnostic_recommendation = diagnostic_recommendation+`</table>`
	// document.getElementById("businessImpact_recommendation").innerHTML=diagnostic_recommendation;
	
	
	document.getElementById(id).innerHTML = '';
	// set the dimensions and margins of the graph
	var margin = {top: 10, right: 30, bottom: 40, left: 50},
	
    width = width = $('#'+id).actual('width') - margin.left - margin.right,
    height = 420 - margin.top - margin.bottom;

	var shape = d3.scaleOrdinal(businessImpactData2.map(d => d.quadrant), d3.symbols.map(s => d3.symbol().type(s)()));	
	// append the svg object to the body of the page
	var Svg = d3.select("#"+id)
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")")
  // Add X axis
  var x = d3.scaleLinear()
    .domain([0,5])
    .range([ 0, width ])
  Svg.append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(x).tickSize(-height*1.3).ticks(10))
    .select(".domain").remove()

  // Add Y axis
  var y = d3.scaleLinear()
    .domain([0, (maxValueofY + 20)])
    .range([ height, 0])
    .nice()
  Svg.append("g")
    .call(d3.axisLeft(y).tickSize(-width*1.3).ticks(7))
    .select(".domain").remove()
	
  // Customization
  Svg.selectAll(".tick line").attr("stroke", "#EBEBEB")

   // Add X axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("x", 40+width/2)
      .attr("y", height + margin.top + 20)
      .text("Team Engagement");

  // Y axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left+20)
      .attr("x", 40-(height/2))
      .text("Business Performance");
  Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", 570)
    .attr("y1", 0)
    .attr("x2", 570)
    .attr("y2", height)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	
	
	
	
   Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    // .attr("x1", 0)
    // .attr("y1", (height/2) * 1.1 )
    // .attr("x2", width)
    // .attr("y2", (height/2) * 1.1 )
	.attr("x1", 0)
    //.attr("y1", (maxValueofY/2) + 153  )
	// .attr("y1", (height - (75 *height) / maxValueofY )   )
    // .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 153  )
	// .attr("y2", (height - (75 *height) / maxValueofY )  )
	// .attr("fill-opacity","0.3")
	// .style("stroke-dasharray", ("3, 3"));
	// Svg.append('line')
    // .style("stroke", "grey")
    // .style("stroke-width", 2)
    // .attr("x1", 0)
    // .attr("y1", (height - (100 *height) / maxValueofY )  )
    // .attr("x2", width)
    // .attr("y2", (height - (100 *height) / maxValueofY )  )
	 .attr("y1", (maxValueofY/2) + 153  )
    .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 153  )
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", 0)
    .attr("y1", (maxValueofY/2) + 115 )
    .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 115 )
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append("text")
        .attr("transform", "translate(0," + (height-10) + ")")
        .style("fill", "#D64550")
        .attr("font-size", "16px")
        .text("Non-Performing");
	Svg.append("text")
        .attr("transform", "translate(0," + (10) + ")")
        .style("fill", "#FFBF00")
        .attr("font-size", "16px")
        .text("Risk Zone");
	Svg.append("text")
        .attr("transform", "translate("+(width-75) +",10)")
        .style("fill", "#118DFF")
        .attr("font-size", "16px")
        .text("Optimized");
	Svg.append("text")
        .attr("transform", "translate("+(width-105) +","+ ( (maxValueofY/2) + 150 )+")")
        .style("fill", "#A0D1FF")
        .attr("font-size", "16px")
        .text("Sub-Optimized");
	Svg.append("text")
        .attr("transform", "translate("+(width-90) +"," + (height-10) + ")")
        .style("fill", "#F5C4AF")
        .attr("font-size", "16px")
        .text("Country Club");
	
	
	var tooltip = d3.select("#"+id)
    .append("div")
    .style("opacity", 0)
    .attr("class", "tooltip")
    .style("background-color", "white")
    .style("border", "solid")
    .style("border-width", "1px")
    .style("border-radius", "5px")
    .style("padding", "10px")
  // Color scale: give me a specie name, I return a color
    var color = d3.scaleOrdinal()
    .domain(["Non-Performing", "Risk Zone", "Optimized","Sub-Optimized","Country Club" ])
    .range([ "#D64550", "#FFBF00", "#118DFF","#A0D1FF","#F5C4AF"]);
	/*var color = d3.scaleOrdinal()
    .domain(["Leader", "Manager", "Work From Home","Work from Office","Human Resource","Well Being" ])
    .range([ "#1cc88a", "#36b9cc", "#e74a3b","#4e73df","#f6c23e","#858796"]);*/
	
	
	//console.log("Temp data ",temp_data);
  // Add dots
  Svg.append('g')
    .selectAll("dot")
    .data(businessImpactData2)
    .enter()
    .append("circle")
	  .attr("r", 20)
      .attr("cx", function (d) { return x(d.xAxis); } )
      .attr("cy", function (d) { return y(d.yAxis); } )
	  .style("fill", function (d) { return color(d.quadrant) } )
	  .attr("fill-opacity","0.5")
	  .on("mouseover", function(d) {
						tooltip
						  .style("opacity", 1)
					  } )
      .on("mousemove", function(d) {						
						tooltip
						  .html("Team Engagement : <b>"+d.xAxis.toFixed(2)+"</b><br>Business Performance: <b>"+d.yAxis.toFixed(2)+"%</b><br>Manager Name : <b>"+d.managerName+" </b><br>Team Size: <b>"+d.teamSize+"</b>")
						  .style("left", (d3.mouse(this)[0]+90) + "px")
						  .style("top", (d3.mouse(this)[1]) + "px")
						  .style("opacity", 1)
					  } )
      .on("mouseleave", function(d) {
						tooltip
						  .transition()
						  .duration(200)
						  .style("opacity", 0)
					  } );
					  
   /*var symbol = d3.symbol();
   Svg
    .selectAll("dot")
    .data(data)
    .enter()
    .append("path")
	.attr("d",symbol.type(function(d){
		if(d.quadrant == "Not Critical"){ return d3.symbolCross
		} else if (d.quadrant == "Sustenance"){ return d3.symbolDiamond
		} else if (d.quadrant == "Improvement"){ return d3.symbolSquare
		} else if (d.quadrant == "Low Focus"){ return d3.symbolStar
		}}).size(300))
    .attr("fill", function (d) { return color(d.category) } )
	.attr("fill-opacity","0.5")
	.attr('transform',function(d){ return "translate("+x(d.correlation)+","+y(d.score)+")"; });*/
	  $('[data-toggle="tooltip"]').tooltip();
	  
	 // //console.log(riskCount,optimizedCount,nonPerCount,countryClubCount,subOptimizedCount);
	  
	let riskZoneData = riskZone / riskCount;
	if(riskZoneData > 0)
	{
	  document.getElementById("riskZoneTitle").innerHTML="Risk Zone";
	  document.getElementById("riskZoneIDNoOf").innerHTML=riskCount;
	  document.getElementById("riskZonedTarget").innerHTML=riskZoneData.toFixed(1);
	}
	else
	{
		document.getElementById("riskZoneTitle").innerHTML="";
	    document.getElementById("riskZoneIDNoOf").innerHTML="";
	    document.getElementById("riskZonedTarget").innerHTML="";
	}
	
	let optimizedData = optimized / optimizedCount ; 
	
	if(optimizedData > 0)
	{
	  document.getElementById("optimizedTitle").innerHTML="Optimized";
	  document.getElementById("optimizedNoOf").innerHTML=optimizedCount;
	  document.getElementById("optimizedTarget").innerHTML=optimizedData.toFixed(1);
	}
	else
	{
	  document.getElementById("optimizedTitle").innerHTML="";
	  document.getElementById("optimizedNoOf").innerHTML="";
	  document.getElementById("optimizedTarget").innerHTML="";
	}
	
	
	let subOptimizedData = subOptimized / subOptimizedCount;
	
	if(subOptimizedData > 0)
	{
	  document.getElementById("subOptimizedTitle").innerHTML="Sub-Optimal";
	  document.getElementById("subOptimizedNoOf").innerHTML=subOptimizedCount;
	  document.getElementById("subOptimizedTarget").innerHTML=subOptimizedData.toFixed(1);	
	}
	else
	{
	  document.getElementById("subOptimizedTitle").innerHTML="";
	  document.getElementById("subOptimizedNoOf").innerHTML="";
	  document.getElementById("subOptimizedTarget").innerHTML="";	
	}
	
	let countryClubData = countryClub / countryClubCount;
	
	if(countryClubData > 0)
	{
	  document.getElementById("countryClubTitle").innerHTML="Country Club";
	  document.getElementById("countryClubNoOf").innerHTML=countryClubCount;
	  document.getElementById("countryClubTarget").innerHTML=countryClubData.toFixed(1);	
	}
	else
	{
	  document.getElementById("countryClubTitle").innerHTML="";
	  document.getElementById("countryClubNoOf").innerHTML="";
	  document.getElementById("countryClubTarget").innerHTML="";
	}
	
	let nonPerformingData = nonPerforming / nonPerCount;
	
	if(nonPerformingData > 0)
	{
		document.getElementById("nonPerformTitle").innerHTML="Non-Performing";
		document.getElementById("nonPerformingNoOf").innerHTML=nonPerCount;
	    document.getElementById("nonPerformingTarget").innerHTML=nonPerformingData.toFixed(1);
	}
	else
	{
		document.getElementById("nonPerformTitle").innerHTML="";
		document.getElementById("nonPerformingNoOf").innerHTML="";
	    document.getElementById("nonPerformingTarget").innerHTML="";
	}
	
	// Details Tables 
	
	// let tableData = `<table class="table">  
	
		// <thead>
			// <tr>
				// <th>Manager Name</th>
				// <th>Team Size</th>
				// <th>Team Engagement</th>
				// <th>Business Performance</th>
				
			// </tr>
		// </thead>
		
		// <tbody>`+
		
		
			// for(let i=0;i<businessImpactData.length;i++)
			// {
				// +`<tr>
					
					// <td>`+ businessImpactData[i].managerName+`</td>
					// <td>`+businessImpactData[i].teamSize+`</td>
					// <td>`+businessImpactData[i].xAxis+`</td>
					// <td>`+businessImpactData[i].yAxis+`</td>
				// </tr>`+
			// }
			
			
		// +`</tbody>
		
		
		
		// </table>`;
		
		////console.log(businessImpactData2.length);
	
		document.getElementById('tableBodyDetails').innerHTML = "";
		
		let tableBody = document.getElementById('tableBodyDetails');
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Risk Zone")
			{
				td1.style.color = "#FFBF00";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Non-Performing")
			{
				td1.style.color = "#D64550";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Optimized")
			{
				td1.style.color = "#118DFF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Sub-Optimized")
			{
				td1.style.color = "#A0D1FF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Country Club")
			{
				td1.style.color = "#F5C4AF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		
		// for(let i=0;i<businessImpactData2.length;i++)
		// {
			// let tr = document.createElement('tr');
			
			// let td1 = document.createElement('td');
			// let td2 = document.createElement('td');
			// let td3 = document.createElement('td');
			// let td4 = document.createElement('td');
			
			// if(businessImpactData2[i].quadrant == "Risk Zone")
			// {
				// td1.style.color = "#9E9E9E";
			// }
			// else if(businessImpactData2[i].quadrant == "Non-Performing")
			// {
				// td1.style.color = "#D64550";
			// }
			// else if(businessImpactData2[i].quadrant == "Optimized")
			// {
				// td1.style.color = "#118DFF";
			// }
			// else if(businessImpactData2[i].quadrant == "Sub-Optimized")
			// {
				// td1.style.color = "#A0D1FF";
			// }
			// else if(businessImpactData2[i].quadrant == "Country Club")
			// {
				// td1.style.color = "#F5C4AF";
			// }
			
			// td1.innerHTML = ( businessImpactData2[i].managerName);
			// td2.innerHTML = ( businessImpactData2[i].teamSize);
			// td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
			// td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
			
			
			// tr.appendChild(td1);
			// tr.appendChild(td2);
			// tr.appendChild(td3);
			// tr.appendChild(td4);
			
			
			// tableBody.appendChild(tr);
			
			
		// }
		
	}else{
		document.getElementById(id).innerHTML = '<center><h2>Not enough Data</h2></center>';
		document.getElementById("businessImpact_recommendation").innerHTML='';
	}
}



// Business Impact end here 

function diagnostic_select_change(){
	
	//alert("Diagnostic Impact call");
	
	id = "correlation_scatterplot";
	if(filtered_data.length>=min_limit.min_diagnostic){
	
	var diagnostic_select = document.getElementById('diagnostic_select').value;
	//console.log("Disg select  ",diagnostic_select);
	var temp_data = CORRELATION_QUESTION_DATA.filter( correlation => { if(correlation.question_code.startsWith(diagnostic_select)||diagnostic_select==="ALL") return true ;} );
	var diagnostic_recommendation=`<table class="table"><tr><th>Competency</th><th>Recommendation</th></tr>`;
	for(var i in temp_data){
		////console.log(data[i]);
		if(temp_data[i].score<75&&temp_data[i].correlation>=0.3)
			diagnostic_recommendation = diagnostic_recommendation + `<tr><th>`+temp_data[i].driver+`</th><td>`+temp_data[i].description+`</td></tr>`;
	}
	diagnostic_recommendation = diagnostic_recommendation+`</table>`
	document.getElementById("diagnostic_recommendation").innerHTML=diagnostic_recommendation;
	
	document.getElementById(id).innerHTML = '';
	// set the dimensions and margins of the graph
	var margin = {top: 10, right: 30, bottom: 40, left: 50},
    width = width = $('#'+id).actual('width') - margin.left - margin.right,
    height = 420 - margin.top - margin.bottom;
	
	var shape = d3.scaleOrdinal(temp_data.map(d => d.quadrant), d3.symbols.map(s => d3.symbol().type(s)()));
	
	// append the svg object to the body of the page
	var Svg = d3.select("#"+id)
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")")
  // Add X axis
  var x = d3.scaleLinear()
    .domain([0,1])
    .range([ 0, width ])
  Svg.append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(x).tickSize(-height*1.3).ticks(10))
    .select(".domain").remove()

  // Add Y axis
  var y = d3.scaleLinear()
    .domain([0,100])
    .range([ height, 0])
    .nice()
  Svg.append("g")
    .call(d3.axisLeft(y).tickSize(-width*1.3).ticks(7))
    .select(".domain").remove()
	
  // Customization
  Svg.selectAll(".tick line").attr("stroke", "#EBEBEB")

   // Add X axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("x", 40+width/7.1)
      .attr("y", height + margin.top + 20)
      .text("Low impact");

 Svg.append("text")
      .attr("text-anchor", "end")
      .attr("x", 40+width/2.1)
      .attr("y", height + margin.top + 20)
      .text("Moderate impact");
	  
 Svg.append("text")
      .attr("text-anchor", "end")
      .attr("x", 40+width/1.25)
      .attr("y", height + margin.top + 20)
      .text("High impact");
	  
  // Y axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left+20)
      .attr("x", 40-(height/2))
      .text("Driver Score");
  Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", width/3.3)
    .attr("y1", 0)
    .attr("x2", width/3.3)
    .attr("y2", height)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
  Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", width/1.67)
    .attr("y1", 0)
    .attr("x2", width/1.67)
    .attr("y2", height)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
   Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", 0)
    .attr("y1", height/2)
    .attr("x2", width)
    .attr("y2", height/2)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", width/3.3)
    .attr("y1", height*0.25)
    .attr("x2", width)
    .attr("y2", height*0.25)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append("text")
        .attr("transform", "translate(0," + (height-10) + ")")
        .style("fill", "#F5C4AF")
        .attr("font-size", "16px")
        .text("Low Focus");
	Svg.append("text")
        .attr("transform", "translate(0," + (10) + ")")
        .style("fill", "#9E9E9E")
        .attr("font-size", "16px")
        .text("Not Critical");
	Svg.append("text")
        .attr("transform", "translate("+(width-75) +",10)")
        .style("fill", "#118DFF")
        .attr("font-size", "16px")
        .text("Excellence");
	Svg.append("text")
        .attr("transform", "translate("+(width-140) +","+((height/2)-10)+")")
        .style("fill", "#A0D1FF")
        .attr("font-size", "16px")
        .text("Towards Excellence");
	Svg.append("text")
        .attr("transform", "translate("+(width-90) +"," + (height-10) + ")")
        .style("fill", "#D64550")
        .attr("font-size", "16px")
        .text("Improvement");
	
	
	var tooltip = d3.select("#"+id)
    .append("div")
    .style("opacity", 0)
    .attr("class", "tooltip")
    .style("background-color", "white")
    .style("border", "solid")
    .style("border-width", "1px")
    .style("border-radius", "5px")
    .style("padding", "10px")
  // Color scale: give me a specie name, I return a color
    var color = d3.scaleOrdinal()
    .domain(["Low Focus", "Not Critical", "Improvement","Excellence","Towards Excellence" ])
    .range([ "#F5C4AF", "#9E9E9E", "#D64550","#118DFF","#A0D1FF"]);
	/*var color = d3.scaleOrdinal()
    .domain(["Leader", "Manager", "Work From Home","Work from Office","Human Resource","Well Being" ])
    .range([ "#1cc88a", "#36b9cc", "#e74a3b","#4e73df","#f6c23e","#858796"]);*/
	
  // Add dots
  Svg.append('g')
    .selectAll("dot")
    .data(temp_data)
    .enter()
    .append("circle")
	  .attr("r", 20)
      .attr("cx", function (d) { return x(d.correlation); } )
      .attr("cy", function (d) { return y(d.score); } )
	  .style("fill", function (d) { return color(d.quadrant) } )
	  .attr("fill-opacity","0.5")
	  .on("mouseover", function(d) {
						tooltip
						  .style("opacity", 1)
					  } )
      .on("mousemove", function(d) {						
						tooltip
						  .html("Driver: <b>"+d.driver+"</b><br>Score: <b>"+d.score.toFixed(2)+"%</b><br>Impact: <b>"+d.correlation.toFixed(2)+"</b>")
						  .style("left", (d3.mouse(this)[0]+90) + "px")
						  .style("top", (d3.mouse(this)[1]) + "px")
						  .style("opacity", 1)
					  } )
      .on("mouseleave", function(d) {
						tooltip
						  .transition()
						  .duration(200)
						  .style("opacity", 0)
					  } );
					  
   /*var symbol = d3.symbol();
   Svg
    .selectAll("dot")
    .data(data)
    .enter()
    .append("path")
	.attr("d",symbol.type(function(d){
		if(d.quadrant == "Not Critical"){ return d3.symbolCross
		} else if (d.quadrant == "Sustenance"){ return d3.symbolDiamond
		} else if (d.quadrant == "Improvement"){ return d3.symbolSquare
		} else if (d.quadrant == "Low Focus"){ return d3.symbolStar
		}}).size(300))
    .attr("fill", function (d) { return color(d.category) } )
	.attr("fill-opacity","0.5")
	.attr('transform',function(d){ return "translate("+x(d.correlation)+","+y(d.score)+")"; });*/
	  $('[data-toggle="tooltip"]').tooltip();
	}else{
		document.getElementById(id).innerHTML = '<center><h2>Not enough Data</h2></center>';
		document.getElementById("diagnostic_recommendation").innerHTML='';
		document.getElementById('correlation_index').innerHTML = '';
	}
}

function open_select_change(){
	var code = document.getElementById('open_select').value;
	// Old code 
	// if(code==="OPENWFH01"){
		// document.getElementById('open_filter').innerHTML = `
			// <option value="ALL">All</option>
			// <option value="OPWH1">Internet bandwidth and online tools</option>
			// <option value="OPWH2">Online communication and meetings</option>
			// <option value="OPWH3">Online work processes</option>
			// <option value="OPWH4">Motivation and distraction</option>
			// <option value="OPWH5">Others</option>
		// </select>`;
	// }else if(code==="OPENSEN01"||code==="OPENSEN02"){
		// document.getElementById('open_filter').innerHTML = `
			// <option value="ALL">All</option>
			// <option value="OPO01">Performance</option>
			// <option value="OPO02">Learning and Growth</option>
			// <option value="OPO03">Valuing People and Caring</option>
			// <option value="OPO04">Business and Leadership</option>
			// <option value="OPO99">Others</option>`;
	// }else if(code==="OPENSEN03"||code==="OPENSEN04"){
		// document.getElementById('open_filter').innerHTML = `
			// <option value="ALL">All</option>
			// <option value="OPO01">Business Confidence</option>
			// <option value="OPO02">Leadership Communication</option>
			// <option value="OPO03">People Focus</option>
			// <option value="OPO04">Policy and Benefits</option>
			// <option value="OPO05">Job Security Related</option>
			// <option value="OPO06">Others</option>`;
	// }
	// End old code 
	
	// Written by Gaurav Kumar start

	let findMatchedCode ='';
	let uniqueData = [];
	let filterValuesForDropDown2D = [];
	let finalArrayForDropDown = [];
	findMatchedCode=findMatchedCode+`<option value="All">All</option>`;
	
	console.log('inside func ',openEndQuestionArrayData);
	for(let i=0;i<openEndQuestionArrayData.length;i++)
	{
		if(uniqueData.includes(openEndQuestionArrayData[i].title) == false)
		{
			uniqueData.push(openEndQuestionArrayData[i].title);
		}
	}
	
	for(let i=0;i<uniqueData.length;i++)
	{
		let filterData = openEndQuestionArray.filter(item => item.question_code == uniqueData[i]);
		filterValuesForDropDown2D.push(filterData);
	}

	for(let i=0;i<filterValuesForDropDown2D.length;i++)
	{
		for(let j=0;j<filterValuesForDropDown2D[i].length;j++)
		{
			finalArrayForDropDown.push(filterValuesForDropDown2D[i][j]);
		}
	}
	
	for(let i=0;i<finalArrayForDropDown.length;i++)
	{
		if(code == finalArrayForDropDown[i].question_code)
		{
			findMatchedCode=findMatchedCode+`<option value="`+openEndQuestionArray[i].option_code+`">`+openEndQuestionArray[i].option_text+`</option>`;
		}
	}
	
	console.log('findMatchedCode ',findMatchedCode);
	
	document.getElementById('open_filter').innerHTML=findMatchedCode;
	
	// end Gaurav Kumar
	open_filter_change();
}



function open_filter_change1(){
	comment = "";
	commentText = "";
	var open_filter = document.getElementById('open_filter').value;
	////console.log(open_filter);
	var open_select = document.getElementById('open_select').value;
	for(var i in filtered_data){
		if(open_filter=="ALL"){
			if(filtered_data[i][open_select+'[comment]'].trim()!="")
				comment=comment+"<p class=\"p-2\">"+filtered_data[i][open_select+'[comment]']+"</p> <hr>";
				commentText = commentText + filtered_data[i][open_select+'[comment]']+"lineBreak";
		}else if(filtered_data[i][open_select]==open_filter){
			if(filtered_data[i][open_select+'[comment]'].trim()!="")
				comment=comment+"<p class=\"p-2\">"+filtered_data[i][open_select+'[comment]']+"</p> <hr>";
				commentText = commentText + filtered_data[i][open_select+'[comment]']+"lineBreak";
		}
	}
	document.getElementById("open_comment").innerHTML = comment;
	var div = document.createElement("div");
	div.innerHTML = comment;
	document.getElementById("open_wordcloud").innerHTML='';
	word_cloud("open_wordcloud",div.innerText);
}

function open_filter_change(){

	comment = "";
	commentText = "";
    var freqMap3 = {};
	var freqMap2 = {};
	var freqMap1 = {};


	var open_filter = document.getElementById('open_filter').value;

	////console.log(open_filter);
	var open_select = document.getElementById('open_select').value;
	
	for(var i in filtered_data){
		if(open_filter=="All"){
			
			if(filtered_data[i][open_select+'[comment]']?.trim()!="")
				{
						var string = filtered_data[i][open_select+'[comment]'];
						var words = string?.replace(/[^0-9a-zA-Z]/gi,' ')
                                      .toLowerCase()				
                                      .replace(/[.]/g, '')
                                      .split(/\s/);
                          words = remove_stopwords(words);
						  for (let i = 0; i < words.length-2; i++) 
                          {
                              text = words[i]+" "+words[i+1]+" "+words[i+2];
							 // text = words[i]+" "+words[i+1];
							  if(text!='')
                              {
                                  if (!freqMap3[text]) 
                                  {
                                      freqMap3[text] = 0;
                                  }
                                  freqMap3[text] += 1;
                              }                                                             
                                                          
                          }
						  for (let i = 0; i < words.length-1; i++) 
                          {
                              text = words[i]+" "+words[i+1];
							  if(text!='')
                              {
                                  if (!freqMap2[text]) 
                                  {
                                      freqMap2[text] = 0;
                                  }
                                  freqMap2[text] += 1;
                              }                                                             
                                                          
                          }

						  for (let i = 0; i < words.length; i++) 
                          {
                              text = words[i];
							  if(text!='')
                              {
                                  if (!freqMap1[text]) 
                                  {
                                      freqMap1[text] = 0;
                                  }
                                  freqMap1[text] += 1;
                              }                                                             
                                                          
                          }
               
					comment=comment+"<p class=\"p-2\">"+filtered_data[i][open_select+'[comment]']+"</p> <hr>";
					commentText = commentText + filtered_data[i][open_select+'[comment]']+"lineBreak";
				}	
		}else if(filtered_data[i][open_select]==open_filter){
			if(filtered_data[i][open_select+'[comment]'].trim()!="")
			{
				var string = filtered_data[i][open_select+'[comment]'];
				var words = string.replace(/[^0-9a-zA-Z]/gi,' ')
                                      .toLowerCase()				
                                      .replace(/[.]/g, '')
                                      .split(/\s/);
                words = remove_stopwords(words);
						  for (let i = 0; i < words.length-2; i++) 
                          {
                              text = words[i]+" "+words[i+1]+" "+words[i+2];
							  if(text!='')
                              {
                                  if (!freqMap3[text]) 
                                  {
                                      freqMap3[text] = 0;
                                  }
                                  freqMap3[text] += 1;
                              }                                                             
                                                          
                          }
						  for (let i = 0; i < words.length-1; i++) 
                          {
                              text = words[i]+" "+words[i+1];
							  if(text!='')
                              {
                                  if (!freqMap2[text]) 
                                  {
                                      freqMap2[text] = 0;
                                  }
                                  freqMap2[text] += 1;
                              }                                                             
                                                          
                          }

						  for (let i = 0; i < words.length; i++) 
                          {
                              text = words[i];
							  if(text!='')
                              {
                                  if (!freqMap1[text]) 
                                  {
                                      freqMap1[text] = 0;
                                  }
                                  freqMap1[text] += 1;
                              }                                                             
                                                          
                          }
               
				comment=comment+"<p class=\"p-2\">"+filtered_data[i][open_select+'[comment]']+"</p> <hr>";
				commentText = commentText + filtered_data[i][open_select+'[comment]']+"lineBreak";
			}	
		}
	}

	document.getElementById("open_comment").innerHTML = comment;
	var div = document.createElement("div");
	div.innerHTML = comment;
	document.getElementById("open_wordcloud").innerHTML='';
	var arr = [];
	////console.log(freqMap3);
    for (var word in freqMap3) {
        if (freqMap3.hasOwnProperty(word)) {
			temp = [];
			temp["word"]=word;
			temp["count"]=freqMap3[word];
			if (temp['count']>1)
            	arr.push(temp);
        }
    }
	arr.sort(function(a, b){return b.count - a.count});
	if(arr.length>=3)
    {                                                      
    	word_cloud("open_wordcloud",arr);
	}
    else
	{
		arr=[];
        for (var word in freqMap2) {
            if (freqMap2.hasOwnProperty(word)) {
                temp = [];
                temp["word"]=word;
                temp["count"]=freqMap2[word];
                if (temp['count']>1)
                    arr.push(temp);
            }
        }
        arr.sort(function(a, b){return b.count - a.count});
		if(arr.length>=2)
		{
    	word_cloud("open_wordcloud",arr);

		}
		else
		{
			arr=[];
            for (var word in freqMap1) {
                if (freqMap1.hasOwnProperty(word)) {
                    temp = [];
                    temp["word"]=word;
                    temp["count"]=freqMap1[word];
                    if (temp['count']>1)
                        arr.push(temp);
                }
            }
    		word_cloud("open_wordcloud",arr);
		}
	}
	
                                                            
}

function random(below){
	return Math.random() * below; 
}

String.prototype.toProperCase = function () {
    return this.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
};

function driver_analysis_append(driver,question,hint,value,min,max){

	document.getElementById('driver').innerHTML = document.getElementById('driver').innerHTML + `
			<div class="col-md-3 col-sm-12 text-right mt-3">
				<span data-toggle="tooltip"  title="`+question+`">
					  `+driver+(hint!=``? ` (`+hint+`)` :` `)+`
				</span>
			</div>
			<div class="col-md-9 col-sm-12 text-center mt-3">
				<div class="progress" style="height:30px;">
					<div class="progress-bar text-left font-weight-bold" style="font-size:20px; background-color: `+get_color(value,min,max,((max+min)/2))+`; width:`+value+`%"> &nbsp; &nbsp; &nbsp; `+Math.round(value)+`%</div>
				</div>
			</div>`;
			
}

function simple_progress(value,max){
	if(isNaN(value)){
		value=0;
	}
	return `<div class="progress"  style="height:30px" data-toggle="tooltip" title="`+value+`" >
				<div class="progress-bar text-left bg-warning" style="width:`+(value*100)/max+`%"> &nbsp; &nbsp; &nbsp; `+value+`</div>
			</div>`;
			
}

function ENGAGE_COMPANY_GRAPH(id,positive,neutral,negative){
	 var total = positive+neutral+negative;
	 /*positive=((positive*100)/total).toFixed(0);
	 neutral=((neutral*100)/total).toFixed(0);
	 negative=((negative*100)/total).toFixed(0);*/
	////console.log(id);
	try{
	 positive=Math.round((positive*100)/total);
	 neutral=Math.round((neutral*100)/total);
	 negative=Math.round((negative*100)/total);
	 ////console.log(positive);
	 ////console.log(neutral);
	 ////console.log(negative);
	 document.getElementById(id).innerHTML = `<p class="d-block d-md-none m-0 pt-3">Company</p><div class="progress" style="height:30px">
	  <div class="progress-bar bg-success font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + positive + `%" title="Positive: ` + positive + `%" >`+positive+`%
	  </div>
	  <div class="progress-bar bg-secondary font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + neutral + `%" title="Neutral: ` + neutral + `%" >`+neutral+`%
	  </div>
	  <div class="progress-bar bg-danger font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + negative + `%" title="Negative: ` + negative + `%" >`+negative+`%
	  </div>
	</div> `;
	}catch(err){}
}

function ENGAGE_BENCHMARK_GRAPH(id,positive,neutral,negative){
	 var total = positive+neutral+negative;
	 /*positive=((positive*100)/total).toFixed(0);
	 neutral=((neutral*100)/total).toFixed(0);
	 negative=((negative*100)/total).toFixed(0);*/
	 positive=Math.round((positive*100)/total);
	 neutral=Math.round((neutral*100)/total);
	 negative=Math.round((negative*100)/total);
	document.getElementById(id).innerHTML = `<p class="d-block d-md-none m-0 pt-3">Benchmark</p>
	<div class="progress" style="height:30px">
	  <div class="progress-bar bg-danger font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + negative + `%" title="Negative: ` + negative + `%" >`+negative+`%
	  </div>
	  <div class="progress-bar bg-secondary font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + neutral + `%" title="Neutral: ` + neutral + `%" >`+neutral+`%
	  </div>
	   <div class="progress-bar bg-success font-weight-bold" data-toggle="tooltip" style="font-size: 20px; width:` + positive + `%" title="Positive: ` + positive + `%" >`+positive+`%
	  </div>
	 
	</div> `;
}

function driver_selector_init(){
	var driver_selector="";
	if(false)
		driver_selector = driver_selector+`<option value="ALL">All</option>`
	if(HR_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="HR">HR</option>`;
	if(LEADER_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="LEADER">Leader</option>`;
	if(MANAGER_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="MANAGER">Manager</option>`;
	if(WB_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="WB">Well Being</option>`;
	if(WFH_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="WFH">WFH</option>`;
	if(WFO_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="WFO">WFO</option>`;
	if(OTHER_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="CUSTOM">Custom</option>`;
	if(INNVO_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="INNV">Innovation</option>`;
	if(JOTA_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="JOTA">Employee Productivity and Motivation</option>`;
	if(JOTB_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="JOTB">Leadership Trust & Direction</option>`;
	if(JOTC_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="JOTC">Employee Retention</option>`;
	if(JOTD_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="JOTD">Work, Process & Technology</option>`;
	if(PSN_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="PSN">Psychological Safety Net</option>`;
	if(CUSTOMER_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="CDRIVER">Customer driver</option>`;
	if(ORG_QUESTION_COUNT>0)
		driver_selector = driver_selector+`<option value="ORG">Organization</option>`;
	
	document.getElementById("driver_selector").innerHTML = driver_selector;
}

function driver_selector_change(){
	var e = document.getElementById("driver_selector");
	var value = e.options[e.selectedIndex].value;
	document.getElementById("driver_index").innerHTML = INDEX[value];
	if(value==="MANAGER")
		document.getElementById("driver_text").innerHTML = "Manager Index";
	else if(value==="LEADER")
		document.getElementById("driver_text").innerHTML = "Leader Index";
	else if(value==="WFH")
		document.getElementById("driver_text").innerHTML = "WFH Index";
	else if(value==="WFO")
		document.getElementById("driver_text").innerHTML = "WFO Index";
	else if(value==="HR")
		document.getElementById("driver_text").innerHTML = "HR Index";
	else if(value==="WB")
		document.getElementById("driver_text").innerHTML = "Well Being Index";
	else if(value==="CUSTOM"){
		document.getElementById("driver_text").innerHTML = "Other Index";
	}
	else if(value==="JOTA"){
		document.getElementById("driver_text").innerHTML = "Employee Productivity and Motivation";
	}
	else if(value==="JOTB"){
		document.getElementById("driver_text").innerHTML = "Leadership Trust & Direction";
	}
	else if(value==="JOTC"){
		document.getElementById("driver_text").innerHTML = "Employee Retention";
	}
	else if(value==="JOTD"){
		document.getElementById("driver_text").innerHTML = "Work, Process & Technology";
	}
	else if(value==="PSN"){
		document.getElementById("driver_text").innerHTML = "psychological Safety Net";
	}
	else if(value==="CDRIVER"){
		document.getElementById("driver_text").innerHTML = "Customer driver";
	}
	else if(value==="ORG"){
		document.getElementById("driver_text").innerHTML = "Organization";
	}
	
	document.getElementById('driver').innerHTML = '';
	var max=0;
	var min=100;
	
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")||questions[j]["code"].startsWith("MANAGER")||questions[j]["code"].startsWith("LEADER")||questions[j]["code"].startsWith("WFH")||questions[j]["code"].startsWith("WFO")||questions[j]["code"].startsWith("HR")||questions[j]["code"].startsWith("WB")||questions[j]["code"].startsWith("CUSTOM") ||questions[j]["code"].startsWith("INNV") || questions[j]["code"].startsWith("JOTA") || questions[j]["code"].startsWith("JOTB") || questions[j]["code"].startsWith("JOTC") || questions[j]["code"].startsWith("JOTD") || questions[j]["code"].startsWith("PSN") || questions[j]["code"].startsWith("CDRIVER") || questions[j]["code"].startsWith("ORG")){
	
			var score =((questions[j]["result"]["positive"]*100)/filtered_data.length);
			if(value==="ALL"){
				if(score<min){
					min=score;
				}
				if(score>max){
					max=score;
				}
			}else{
					if(questions[j]["code"].startsWith(value)){
						if(score<min){
							min=score;
						}
						if(score>max){
							max=score;
						}
				}
			}
		}
	}
	////console.log(questions);
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")||questions[j]["code"].startsWith("MANAGER")||questions[j]["code"].startsWith("LEADER")||questions[j]["code"].startsWith("WFH")||questions[j]["code"].startsWith("WFO")||questions[j]["code"].startsWith("HR")||questions[j]["code"].startsWith("WB")||questions[j]["code"].startsWith("CUSTOM") ||questions[j]["code"].startsWith("INNV") || questions[j]["code"].startsWith("JOTA") || questions[j]["code"].startsWith("JOTB") || questions[j]["code"].startsWith("JOTC") || questions[j]["code"].startsWith("JOTD") || questions[j]["code"].startsWith("PSN") || questions[j]["code"].startsWith("CDRIVER") || questions[j]["code"].startsWith("ORG") ){
			var score =((questions[j]["result"]["positive"]*100)/filtered_data.length);

			if(value==="ALL"){
				driver_analysis_append(questions[j]["driver"],questions[j]["question"],questions[j]["hint"],score.toFixed(2),min,max);
			}else{
				if(questions[j]["code"].startsWith(value)){
					driver_analysis_append(questions[j]["driver"],questions[j]["question"],questions[j]["hint"],score.toFixed(2),min,max);
				}
			}
		}
	}
	if(value==="MANAGER"){
		var manager_data = {
		"ROLE_MODEL":
		{"COUNT":0,"COUNT_MANAGED":0,"MANAGER_INDEX":0,"ENGAGE_TOTAL":0,"ENGAGE_PERC":0,"MANAGER_ID":[]},
		"GOOD":
		{"COUNT":0,"COUNT_MANAGED":0,"MANAGER_INDEX":0,"ENGAGE_TOTAL":0,"ENGAGE_PERC":0,"MANAGER_ID":[]},
		"DEV_NEEDED":
		{"COUNT":0,"COUNT_MANAGED":0,"MANAGER_INDEX":0,"ENGAGE_TOTAL":0,"ENGAGE_PERC":0,"MANAGER_ID":[]},
		"SIG_DEV_NEEDED":
		{"COUNT":0,"COUNT_MANAGED":0,"MANAGER_INDEX":0,"ENGAGE_TOTAL":0,"ENGAGE_PERC":0,"MANAGER_ID":[]}};
		
		for(var manager_id in manager){
			//console.log('manager_id ',manager_id);
			if(manager[manager_id]["count"]>=3){
				var type="SIG_DEV_NEEDED";
				if(manager[manager_id]["index"]["MANAGER_INDEX"]>=4.5){
					type="ROLE_MODEL";
				}else if(manager[manager_id]["index"]["MANAGER_INDEX"]>=3.5){
					type="GOOD";
				}else if(manager[manager_id]["index"]["MANAGER_INDEX"]>=2.5){
					type="DEV_NEEDED";
				}else{ 
					type="SIG_DEV_NEEDED";
				}
				manager_data[type]["COUNT"]++;
				manager_data[type]["COUNT_MANAGED"]=manager_data[type]["COUNT_MANAGED"]+manager[manager_id]["count"];
				manager_data[type]["MANAGER_INDEX"]=manager_data[type]["MANAGER_INDEX"]+manager[manager_id]["index"]["MANAGER_INDEX"];
				manager_data[type].MANAGER_ID.push(manager_id);
				var ENGAGE_COUNT = 0;
				try{ENGAGE_COUNT = (manager[manager_id]["total"]["ENGAGE_TOTAL"]*manager[manager_id]["count"]/100);}catch(err){}
				if(isNaN(ENGAGE_COUNT)){
					ENGAGE_COUNT=0;
				}
				manager_data[type]["ENGAGE_TOTAL"]=manager_data[type]["ENGAGE_TOTAL"]+ENGAGE_COUNT;
			}
		}
	
		manager_data["ROLE_MODEL"]["ENGAGE_PERC"]=((manager_data["ROLE_MODEL"]["ENGAGE_TOTAL"]*100)/manager_data["ROLE_MODEL"]["COUNT_MANAGED"]).toFixed(2);
		manager_data["GOOD"]["ENGAGE_PERC"]=((manager_data["GOOD"]["ENGAGE_TOTAL"]*100)/manager_data["GOOD"]["COUNT_MANAGED"]).toFixed(2);
		manager_data["DEV_NEEDED"]["ENGAGE_PERC"]=((manager_data["DEV_NEEDED"]["ENGAGE_TOTAL"]*100)/manager_data["DEV_NEEDED"]["COUNT_MANAGED"]).toFixed(2);
		manager_data["SIG_DEV_NEEDED"]["ENGAGE_PERC"]=((manager_data["SIG_DEV_NEEDED"]["ENGAGE_TOTAL"]*100)/manager_data["SIG_DEV_NEEDED"]["COUNT_MANAGED"]).toFixed(2);
		
		manager_data["ROLE_MODEL"]["MANAGER_INDEX"]=manager_data["ROLE_MODEL"]["MANAGER_INDEX"]/manager_data["ROLE_MODEL"]["COUNT"];
		manager_data["GOOD"]["MANAGER_INDEX"]=manager_data["GOOD"]["MANAGER_INDEX"]/manager_data["GOOD"]["COUNT"];
		manager_data["DEV_NEEDED"]["MANAGER_INDEX"]=manager_data["DEV_NEEDED"]["MANAGER_INDEX"]/manager_data["DEV_NEEDED"]["COUNT"];
		manager_data["SIG_DEV_NEEDED"]["MANAGER_INDEX"]=manager_data["SIG_DEV_NEEDED"]["MANAGER_INDEX"]/manager_data["SIG_DEV_NEEDED"]["COUNT"];

		document.getElementById('driver').innerHTML = document.getElementById('driver').innerHTML+`
		<label><small>* Filter will not be applied to the below data as its a derived value.</small></label>
		<div class="table-responsive">
		<table class="table">
		<tr><td>Manager Category</td><td># of Managers</td><td># of Employees Managed</td><td>Manager Index</td><td>Engagement %</td></tr>
		<tr><td onclick="showManagerDetails('`+manager_data["ROLE_MODEL"].MANAGER_ID+`','Role Model')">Role Model</td><td>`+manager_data["ROLE_MODEL"]["COUNT"]+`</td><td>`+manager_data["ROLE_MODEL"]["COUNT_MANAGED"]+`</td><td>`+simple_progress(manager_data["ROLE_MODEL"]["MANAGER_INDEX"].toFixed(2),5)+`</td><td>`+simple_progress(manager_data["ROLE_MODEL"]["ENGAGE_PERC"],100)+`</td></tr>
		<tr><td  onclick="showManagerDetails('`+manager_data["GOOD"].MANAGER_ID+`','Good Manager')">Good Manager</td><td>`+manager_data["GOOD"]["COUNT"]+`</td><td>`+manager_data["GOOD"]["COUNT_MANAGED"]+`</td><td>`+simple_progress(manager_data["GOOD"]["MANAGER_INDEX"].toFixed(2),5)+`</td><td>`+simple_progress(manager_data["GOOD"]["ENGAGE_PERC"],100)+`</td></tr>
		<tr><td onclick="showManagerDetails('`+manager_data["DEV_NEEDED"].MANAGER_ID+`','Development')">Development Needed</td><td>`+manager_data["DEV_NEEDED"]["COUNT"]+`</td><td>`+manager_data["DEV_NEEDED"]["COUNT_MANAGED"]+`</td><td>`+simple_progress(manager_data["DEV_NEEDED"]["MANAGER_INDEX"].toFixed(2),5)+`</td><td>`+simple_progress(manager_data["DEV_NEEDED"]["ENGAGE_PERC"],100)+`</td></tr>
		<tr><td onclick="showManagerDetails('`+manager_data["SIG_DEV_NEEDED"].MANAGER_ID+`','Significiant Development Needed')">Significiant Development Needed</td><td>`+manager_data["SIG_DEV_NEEDED"]["COUNT"]+`</td><td>`+manager_data["SIG_DEV_NEEDED"]["COUNT_MANAGED"]+`</td><td>`+simple_progress(manager_data["SIG_DEV_NEEDED"]["MANAGER_INDEX"].toFixed(2),5)+`</td><td>`+simple_progress(manager_data["SIG_DEV_NEEDED"]["ENGAGE_PERC"],100)+`</td></tr>
		</table>
		</div>`;
	}
	$('[data-toggle="tooltip"]').tooltip();
}

let state = {
    'querySet': [],

    'page': 1,
    'rows': 10,
    'window': 5,
}

function pageButtons(pages) {
    let wrapper = document.getElementById('pagination-wrapper')

    wrapper.innerHTML = ``

    let maxLeft = (state.page - Math.floor(state.window / 2))
    let maxRight = (state.page + Math.floor(state.window / 2))

    if (maxLeft < 1) {
        maxLeft = 1
        maxRight = state.window
    }

    if (maxRight > pages) {
        maxLeft = pages - (state.window - 1)
        
        if (maxLeft < 1){
        	maxLeft = 1
        }
        maxRight = pages
    }
    
    

    for (let page = maxLeft; page <= maxRight; page++) {
    	wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
    }

    if (state.page != 1) {
        wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
    }

    if (state.page != pages) {
        wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info">Last &#187;</button>`
    }

    $('.page').on('click', function() {
        $('#managerListTableBody').empty()

        state.page = Number($(this).val())

        buildTable()
    })

}


function buildTable() {
	//document.getElementById('#managerListTableBody').innerHTML="";
    let table = $('#managerListTableBody')

    let data = pagination(state.querySet, state.page, state.rows)
	
	let managerTableListData = '';
	let myList = data.querySet;
    for (var i = 1 in myList) {
        //Keep in mind we are using "Template Litterals to create rows"
         managerTableListData = managerTableListData + `<tr>
				  <td>${myList[i].employee_id}</td>
				  <td>${myList[i].managerIndex}</td>
				  <td>${myList[i].engagementPercent}</td>
				  <td>${myList[i].engagementIndex}</td>
				  <td>${myList[i].count}</td>
                  `
        //table.append(row);
    }

	document.getElementById('managerListTableBody').innerHTML=managerTableListData;
    pageButtons(data.pages)
}


function pagination(querySet, page, rows) {

    let trimStart = (page - 1) * rows
    let trimEnd = trimStart + rows

    let trimmedData = querySet.slice(trimStart, trimEnd)

    let pages = Math.round(querySet.length / rows);

    return {
        'querySet': trimmedData,
        'pages': pages,
    }
}

var managerListDataForSpecificManage =[];
var managerListFileName = "";
function showManagerDetails(managerData,managerNameList)
{
	 managerListFileName  ="";
	 managerListDataForSpecificManage =[];
	 let managerIDList = managerData.split(',');
	 let displayDetails=[];
	 let tempManagerListArray =[];
	
	 for(let i=0;i<managerIDList.length;i++)
	 { 
		 //let detail = allResponseDataStore.filter(item => item.employee_id == managerIDList[i]);
		 let detail = [];
		 console.log('scoreCardResponseData ',scoreCardResponseData);
		 if(scoreCardResponseData.hasOwnProperty(managerIDList[i]) == true)
		 {
			 const detailsObj = {
				employee_id:managerIDList[i],
				 managerIndex:scoreCardResponseData[`${managerIDList[i]}`].index.MANAGER_INDEX.toFixed(2),
				 engagementPercent:(((scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE01 + 
					 scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE02 + scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE03 + 
					 scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE04 + scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE05 ) / 500) * 100).toFixed(2),
				 engagementIndex:scoreCardResponseData[`${managerIDList[i]}`].index.ENGAGEMENT_INDEX.toFixed(2),
				 count:scoreCardResponseData[`${managerIDList[i]}`].count
				 
			 }
			 
			 detail[0] = detailsObj;
			 // detail[0]['managerIndex'] = scoreCardResponseData[`${managerIDList[i]}`].index.MANAGER_INDEX.toFixed(2);
			 // detail[0]['engagementPercent'] = (((scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE01 + 
			 // scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE02 + scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE03 + 
			 // scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE04 + scoreCardResponseData[`${managerIDList[i]}`].score.ENGAGE05 ) / 500) * 100).toFixed(2);
			 // detail[0]['engagementIndex'] = scoreCardResponseData[`${managerIDList[i]}`].index.ENGAGEMENT_INDEX.toFixed(2);
			 // detail[0]['count'] = scoreCardResponseData[`${managerIDList[i]}`].count;
			 
			 
		 }
		 
		 displayDetails.push(...detail);
		 if(detail.length > 0)
		 {
			 // let temp = [`${detail[0].firstname} ${detail[0].lastname}`,`${detail[0].employee_id}`,`${detail[0].managerIndex}`,`${detail[0].engagementPercent}`,`${detail[0].engagementIndex}`,`${detail[0].count}`];
			  let temp = [`${detail[0].employee_id}`,`${detail[0].managerIndex}`,`${detail[0].engagementPercent}`,`${detail[0].engagementIndex}`,`${detail[0].count}`];
			 tempManagerListArray.push(temp);
		 } 
	 }
	 
	 managerListDataForSpecificManage.push(...tempManagerListArray);
	document.getElementById('managerListText').innerHTML = `    ${managerNameList} manager list.`;
	document.getElementById('managerListText').style.textAlign="center";
	document.getElementById('managerListText').style.marginTop ="5px";
	managerListFileName= managerNameList;
	  state.querySet=displayDetails;
	  state.page=1;
	  buildTable();
	 $("#managerListModal").modal();	
}



function downloadExaclForManager()
{
	let createXLSLFormatObj = [];
	let xlsHeader = ["Employee id","Manager Index","Engagement %","Engagement index","Count"];
	createXLSLFormatObj.push(xlsHeader);
	for(let i=0;i<managerListDataForSpecificManage.length;i++)
	{
		createXLSLFormatObj.push(managerListDataForSpecificManage[i]);
	}
	var filename = `${managerListFileName}.xlsx`;
	/* Sheet Name */
	var ws_name = "Sheet1";
	/* XLS Head Columns */
    var wb = XLSX.utils.book_new(),ws = XLSX.utils.aoa_to_sheet(createXLSLFormatObj);
    XLSX.utils.book_append_sheet(wb, ws, ws_name);
    XLSX.writeFile(wb, filename);
}

function init_heatmap(){
	var attribute_html=document.getElementById("heatmap_parameter").value;

	
	var ENGAGE=false;
	var LEADER=false;
	var MANAGER=false;
	var WFH=false;
	var WFO=false;
	var HR=false;
	var WB=false;
	var CUSTOM=false;
	var INNOVE=false;
	var JOTA=false;
	var JOTB=false;
	var JOTC=false;
	var JOTD=false;
	var PSN=false;
	var CDRIVER = false;
	var ORG = false;
	for(var i in questions_original){
		if(questions_original[i]["code"].startsWith("ENGAGE")){
			ENGAGE=true;
		}else if(questions_original[i]["code"].startsWith("LEADER")){
			LEADER=true;
		}else if(questions_original[i]["code"].startsWith("MANAGER")){
			MANAGER=true;
		}else if(questions_original[i]["code"].startsWith("WFH")){
			WFH=true;
		}else if(questions_original[i]["code"].startsWith("WFO")){
			WFO=true;
		}else if(questions_original[i]["code"].startsWith("HR")){
			HR=true;
		}else if(questions_original[i]["code"].startsWith("WB")){
			WB=true;
		}else if(questions_original[i]["code"].startsWith("CUSTOM")){
			CUSTOM=true;
		}
		else if(questions_original[i]["code"].startsWith("INNV")){
			INNOVE=true;
		}
		else if(questions_original[i]["code"].startsWith("JOTA")){
			JOTA=true;
		}
		else if(questions_original[i]["code"].startsWith("JOTB")){
			JOTB=true;
		}
		else if(questions_original[i]["code"].startsWith("JOTC")){
			JOTC=true;
		}
		else if(questions_original[i]["code"].startsWith("JOTD")){
			JOTD=true;
		}
		else if(questions_original[i]["code"].startsWith("PSN")){
			PSN=true;
		}
		else if(questions_original[i]["code"].startsWith("CDRIVER")){
			CDRIVER=true;
		}
		else if(questions_original[i]["code"].startsWith("ORG")){
			ORG=true;
		}
		
	}
	//attribute_html=attribute_html+`<option value="ALL" >All</option>`;
	if(ENGAGE){
		attribute_html=attribute_html+`<option value="ENGAGE" >Engagement</option>`;
	}
	if(LEADER){
		attribute_html=attribute_html+`<option value="LEADER" >Leader</option>`;
	}
	if(MANAGER){
		attribute_html=attribute_html+`<option value="MANAGER" >Manager</option>`;
	}
	if(WFH){
		attribute_html=attribute_html+`<option value="WFH" >Work From Home</option>`;
	}
	if(WFO){
		attribute_html=attribute_html+`<option value="WFO" >Work from Office</option>`;
	}
	if(HR){
		attribute_html=attribute_html+`<option value="HR" >Human Resource</option>`;
	}
	if(WB){
		attribute_html=attribute_html+`<option value="WB" >Well Being</option>`;
	}
	if(CUSTOM){
		attribute_html=attribute_html+`<option value="CUSTOM" >Custom</option>`;
	}
	if(INNOVE){
		attribute_html=attribute_html+`<option value="INNOVATION" >Innovation</option>`;
	}
	if(JOTA){
		attribute_html=attribute_html+`<option value="JOTA" >Employee Productivity and Motivation</option>`;
	}
	if(JOTB){
		attribute_html=attribute_html+`<option value="JOTB" >Leadership Trust & Direction</option>`;
	}
	if(JOTC){
		attribute_html=attribute_html+`<option value="JOTC" >Employee Retention</option>`;
	}
	if(JOTD){
		attribute_html=attribute_html+`<option value="JOTD" >Work, Process & Technology</option>`;
	}
	if(PSN){
		attribute_html=attribute_html+`<option value="PSN" >psychological Safety Net</option>`;
	}
	if(CDRIVER){
		attribute_html=attribute_html+`<option value="CDRIVER" >Customer driver</option>`;
	}
	if(ORG){
		attribute_html=attribute_html+`<option value="ORG" >Organization</option>`;
	}
	
	
	
	document.getElementById("heatmap_attribute").innerHTML = attribute_html;
	document.getElementById("comparator_attribute").innerHTML = attribute_html;
	var parameter_html="";//`<option value="NONE" >None</option>`;
	for(var i in filters){
		parameter_html=parameter_html+`<option value="`+filters[i]["name"]+`" >`+filters[i]["title"]+`</option>`;
	}
	
	document.getElementById("heatmap_parameter").innerHTML = parameter_html;
	document.getElementById("comparator_parameter").innerHTML = parameter_html;
	//heatmap_change();
}

function heatmap_change(){
	var attribute = document.getElementById("heatmap_attribute").value;
	var parameter = document.getElementById("heatmap_parameter").value;
	var value = new Array();
	var processed = new Array();
	for(i in filters){
		if(filters[i]["name"]===parameter){
			value=filters[i].value;
		}
	}
	value.push('Total');
	
	for(var i in value){
		processed[value[i]]=new Array();
		processed[value[i]]["questions"]=new Array();
		jQuery.extend(true,processed[value[i]]["questions"],questions_original);
		if(ENGAGEMENT_QUESTION_COUNT>0){
			processed[value[i]]["ENGAGE_INDEX"]=0;
			processed[value[i]]["ENGAGED_COUNT"]=0;
		}
		if(MANAGER_QUESTION_COUNT>0)
			processed[value[i]]["MANAGER_INDEX"]=0;
		if(LEADER_QUESTION_COUNT>0)
			processed[value[i]]["LEADER_INDEX"]=0;
		if(WFH_QUESTION_COUNT>0)
			processed[value[i]]["WFH_INDEX"]=0;
		if(WFO_QUESTION_COUNT>0)
			processed[value[i]]["WFO_INDEX"]=0;
		if(HR_QUESTION_COUNT>0)
			processed[value[i]]["HR_INDEX"]=0;
		if(WB_QUESTION_COUNT>0)
			processed[value[i]]["WB_INDEX"]=0;
		if(OTHER_QUESTION_COUNT>0)
			processed[value[i]]["OTHER_INDEX"]=0;
		if(INNVO_QUESTION_COUNT >0)
			processed[value[i]]["INNOVATION_INDEX"]=0;
		if(JOTA_QUESTION_COUNT >0)
			processed[value[i]]["JOTA_INDEX"]=0;
		if(JOTB_QUESTION_COUNT >0)
			processed[value[i]]["JOTB_INDEX"]=0;
		if(JOTC_QUESTION_COUNT >0)
			processed[value[i]]["JOTC_INDEX"]=0;
		if(JOTD_QUESTION_COUNT >0)
			processed[value[i]]["JOTD_INDEX"]=0;
		if(PSN_QUESTION_COUNT >0)
			processed[value[i]]["PSN_INDEX"]=0;
		if(CUSTOMER_QUESTION_COUNT >0)
			processed[value[i]]["CDRIVER_INDEX"]=0;
		if(ORG_QUESTION_COUNT >0)
			processed[value[i]]["ORG_INDEX"]=0;
		processed[value[i]]["COUNT"]=0;
	}
	for(var i in filtered_data){
		var USER_ENGAGED = 0;
		for(var j in processed[value[0]]["questions"]){
			var code = processed[value[0]]["questions"][j]["code"];
			if(code.startsWith("ENGAGE")||code.startsWith("LEADER")||code.startsWith("MANAGER")||code.startsWith("WFH")||code.startsWith("WFO")||code.startsWith("HR")||code.startsWith("WB")||code.startsWith("CUSTOM") || code.startsWith("WB")||code.startsWith("INNV") || code.startsWith("JOTA") || code.startsWith("JOTB") || code.startsWith("JOTC") || code.startsWith("JOTD") || code.startsWith("PSN") || code.startsWith("CDRIVER") || code.startsWith("ORG")){
				if(filtered_data[i][code]>=4){
					processed[filtered_data[i][parameter]]["questions"][j]["result"]["positive"]++;
					processed['Total']["questions"][j]["result"]["positive"]++;
				}else if(filtered_data[i][code]<=2){
					processed[filtered_data[i][parameter]]["questions"][j]["result"]["negative"]++;
					processed['Total']["questions"][j]["result"]["negative"]++;
				}else{
					processed[filtered_data[i][parameter]]["questions"][j]["result"]["neutral"]++;
					processed['Total']["questions"][j]["result"]["neutral"]++;
				}
			}
			if(code.startsWith("ENGAGE")){
				processed[filtered_data[i][parameter]]["ENGAGE_INDEX"]=processed[filtered_data[i][parameter]]["ENGAGE_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["ENGAGE_INDEX"]=processed['Total']["ENGAGE_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				USER_ENGAGED=USER_ENGAGED+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("LEADER")){
				processed[filtered_data[i][parameter]]["LEADER_INDEX"]=processed[filtered_data[i][parameter]]["LEADER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["LEADER_INDEX"]=processed['Total']["LEADER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("MANAGER")){
				processed[filtered_data[i][parameter]]["MANAGER_INDEX"]=processed[filtered_data[i][parameter]]["MANAGER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["MANAGER_INDEX"]=processed['Total']["MANAGER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("WFH")){
				processed[filtered_data[i][parameter]]["WFH_INDEX"]=processed[filtered_data[i][parameter]]["WFH_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["WFH_INDEX"]=processed['Total']["WFH_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("WFO")){
				processed[filtered_data[i][parameter]]["WFO_INDEX"]=processed[filtered_data[i][parameter]]["WFO_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["WFO_INDEX"]=processed['Total']["WFO_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("HR")){
				processed[filtered_data[i][parameter]]["HR_INDEX"]=processed[filtered_data[i][parameter]]["HR_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["HR_INDEX"]=processed['Total']["HR_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("WB")){
				processed[filtered_data[i][parameter]]["WB_INDEX"]=processed[filtered_data[i][parameter]]["WB_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["WB_INDEX"]=processed['Total']["WB_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}else if(code.startsWith("CUSTOM")){
				processed[filtered_data[i][parameter]]["OTHER_INDEX"]=processed[filtered_data[i][parameter]]["OTHER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["CUSTOM"]=processed['Total']["CUSTOM"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("INNV")){
				processed[filtered_data[i][parameter]]["INNOVATION_INDEX"]=processed[filtered_data[i][parameter]]["INNOVATION_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["INNOVATION_INDEX"]=processed['Total']["INNOVATION_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("JOTA")){
				processed[filtered_data[i][parameter]]["JOTA_INDEX"]=processed[filtered_data[i][parameter]]["JOTA_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["JOTA_INDEX"]=processed['Total']["JOTA_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("JOTB")){
				processed[filtered_data[i][parameter]]["JOTB_INDEX"]=processed[filtered_data[i][parameter]]["JOTB_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["JOTB_INDEX"]=processed['Total']["JOTB_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("JOTC")){
				processed[filtered_data[i][parameter]]["JOTC_INDEX"]=processed[filtered_data[i][parameter]]["JOTC_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["JOTC_INDEX"]=processed['Total']["JOTC_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("JOTD")){
				processed[filtered_data[i][parameter]]["JOTD_INDEX"]=processed[filtered_data[i][parameter]]["JOTD_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["JOTD_INDEX"]=processed['Total']["JOTD_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("PSN")){
				processed[filtered_data[i][parameter]]["PSN_INDEX"]=processed[filtered_data[i][parameter]]["PSN_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["PSN_INDEX"]=processed['Total']["PSN_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("CDRIVER")){
				processed[filtered_data[i][parameter]]["CDRIVER_INDEX"]=processed[filtered_data[i][parameter]]["CDRIVER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["CDRIVER_INDEX"]=processed['Total']["CDRIVER_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
			else if(code.startsWith("ORG")){
				processed[filtered_data[i][parameter]]["ORG_INDEX"]=processed[filtered_data[i][parameter]]["ORG_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
				processed['Total']["ORG_INDEX"]=processed['Total']["ORG_INDEX"]+parseInt(filtered_data[i][questions[j]["code"]]);
			}
		}
		processed[filtered_data[i][parameter]]["COUNT"]++;
		processed['Total']["COUNT"]++;
		if((USER_ENGAGED/ENGAGEMENT_QUESTION_COUNT)>=3.75){
			processed[filtered_data[i][parameter]]["ENGAGED_COUNT"]++;
			processed['Total']["ENGAGED_COUNT"]++;
		}
	}
	for(i in processed){
		if(ENGAGEMENT_QUESTION_COUNT>0)
			processed[i]["ENGAGE_INDEX"]=(processed[i]["ENGAGE_INDEX"]/(ENGAGEMENT_QUESTION_COUNT*processed[i]["COUNT"]));
		if(MANAGER_QUESTION_COUNT>0)
			processed[i]["MANAGER_INDEX"]=(processed[i]["MANAGER_INDEX"]/(MANAGER_QUESTION_COUNT*processed[i]["COUNT"]));
		if(LEADER_QUESTION_COUNT>0)
			processed[i]["LEADER_INDEX"]=(processed[i]["LEADER_INDEX"]/(LEADER_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WFH_QUESTION_COUNT>0)
			processed[i]["WFH_INDEX"]=(processed[i]["WFH_INDEX"]/(WFH_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WFO_QUESTION_COUNT>0)
			processed[i]["WFO_INDEX"]=(processed[i]["WFO_INDEX"]/(WFO_QUESTION_COUNT*processed[i]["COUNT"]));
		if(HR_QUESTION_COUNT>0)
			processed[i]["HR_INDEX"]=(processed[i]["HR_INDEX"]/(HR_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WB_QUESTION_COUNT>0)
			processed[i]["WB_INDEX"]=(processed[i]["WB_INDEX"]/(WB_QUESTION_COUNT*processed[i]["COUNT"]));
		if(OTHER_QUESTION_COUNT>0){
			processed[i]["OTHER_INDEX"]=(processed[i]["OTHER_INDEX"]/(WB_QUESTION_COUNT*processed[i]["COUNT"]));
			processed[i]["OTHER_INDEX"] = '-';
			
		}
		if(INNVO_QUESTION_COUNT>0){
			processed[i]["INNOVATION_INDEX"]=(processed[i]["INNOVATION_INDEX"]/(INNVO_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTA_QUESTION_COUNT>0){
			processed[i]["JOTA_INDEX"]=(processed[i]["JOTA_INDEX"]/(JOTA_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		
		if(JOTB_QUESTION_COUNT>0){
			processed[i]["JOTB_INDEX"]=(processed[i]["JOTB_INDEX"]/(JOTB_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTC_QUESTION_COUNT>0){
			processed[i]["JOTC_INDEX"]=(processed[i]["JOTC_INDEX"]/(JOTB_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTD_QUESTION_COUNT>0){
			processed[i]["JOTD_INDEX"]=(processed[i]["JOTD_INDEX"]/(JOTD_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(PSN_QUESTION_COUNT>0){
			processed[i]["PSN_INDEX"]=(processed[i]["PSN_INDEX"]/(PSN_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(CUSTOMER_QUESTION_COUNT>0){
			processed[i]["CDRIVER_INDEX"]=(processed[i]["CDRIVER_INDEX"]/(CUSTOMER_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(ORG_QUESTION_COUNT>0){
			processed[i]["ORG_INDEX"]=(processed[i]["ORG_INDEX"]/(ORG_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		
		
	}
	////console.log(processed);
	var max=0;
	var min=100
	heatmap_table=`<table class="table"><thead><tr>`;
	heatmap_table=heatmap_table+`<td>Parameter</td><td>Responses</td>`;
	////console.log(processed);
	if(ENGAGEMENT_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="ENGAGE")){
		heatmap_table=heatmap_table+`<td>Engagement</td><td>Engagement Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("ENGAGE")){
				heatmap_table=heatmap_table+`<td data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(LEADER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="LEADER")){
		heatmap_table=heatmap_table+`<td>Leader Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("LEADER")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(MANAGER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="MANAGER")){
		heatmap_table=heatmap_table+`<td>Manager Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("MANAGER")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(WFH_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFH")){
		heatmap_table=heatmap_table+`<td>Work from Home</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("WFH")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(WFO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFO")){
		heatmap_table=heatmap_table+`<td>Work From Office Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("WFO")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(HR_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="HR")){
		heatmap_table=heatmap_table+`<td>Human Resource Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("HR")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(WB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WB")){
		heatmap_table=heatmap_table+`<td>Well Being Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("WB")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(OTHER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CUSTOM")){
		heatmap_table=heatmap_table+`<td>Additional</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("CUSTOM")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	if(INNVO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="INNOVATION")){
		heatmap_table=heatmap_table+`<td>Innovation Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("INNV")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(JOTA_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTA")){
		heatmap_table=heatmap_table+`<td>Employee Productivity and Motivation Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("JOTA")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(JOTB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTB")){
		heatmap_table=heatmap_table+`<td>Leadership Trust & Direction Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("JOTB")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(JOTC_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTC")){
		heatmap_table=heatmap_table+`<td>Employee Retention Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("JOTC")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(JOTD_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTD")){
		heatmap_table=heatmap_table+`<td>Work, Process & Technology Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("JOTD")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(PSN_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="PSN")){
		heatmap_table=heatmap_table+`<td>psychological Safety Net Index</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("PSN")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(CUSTOMER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CDRIVER")){
		heatmap_table=heatmap_table+`<td>Customer Eanagement</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("CDRIVER")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	if(ORG_QUESTION_COUNT>0&&(attribute==="ALL"|| attribute==="ORG")){
		heatmap_table=heatmap_table+`<td>Organization</td>`;
		for(var i in processed[value[0]]["questions"]){
			if( processed[value[0]]["questions"][i]["code"].startsWith("ORG")){
				heatmap_table=heatmap_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+processed[value[0]]["questions"][i]["question"]+`" >`+processed[value[0]]["questions"][i]["driver"]+`</td>`;
				for(var j in value){
					var temp = (processed[value[j]]["questions"][i]["result"]["positive"]*100)/(processed[value[j]]["questions"][i]["result"]["positive"]+processed[value[j]]["questions"][i]["result"]["negative"]+processed[value[j]]["questions"][i]["result"]["neutral"]);
					if(max<temp){
						max = temp;
					}
					if(min>temp){
						min = temp;
					}
				}
			}
		}
	}
	
	heatmap_table=heatmap_table+`</tr></thead><tbody>`;
	for(var i in processed){
		var showNA = false;
		if(processed[i]["COUNT"]<min_limit.min_filter){
			showNA=true;
		}
		else{
			heatmap_table=heatmap_table+`<tr `;
			if(i==='Total'){heatmap_table=heatmap_table+' style="font-weight:900;font-size:24px;" ';}
			heatmap_table=heatmap_table+`><td>`+i+`</td><td>`+processed[i]["COUNT"]+`</td>`;
			if(ENGAGEMENT_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="ENGAGE")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td><td>NA</td>";  
				}else{
					heatmap_table=heatmap_table+`<td>`+Math.round(processed[i]["ENGAGED_COUNT"]*100/processed[i]["COUNT"])+`%</td><td>`+processed[i]["ENGAGE_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("ENGAGE")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(LEADER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="LEADER")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["LEADER_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("LEADER")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(MANAGER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="MANAGER")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["MANAGER_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("MANAGER")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(WFH_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFH")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["WFH_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("WFH")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(WFO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFO")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["WFO_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("WFO")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(HR_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="HR")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["HR_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("HR")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(WB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WB")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["WB_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("WB")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(OTHER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CUSTOM")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+'-'+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("CUSTOM")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			if(INNVO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="INNOVATION")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["INNOVATION_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("INNV")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			if(JOTA_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTA")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["JOTA_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("JOTA")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			if(JOTB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTB")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["JOTB_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("JOTB")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			
			if(JOTC_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTC")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["JOTC_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("JOTC")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			
			if(JOTD_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="JOTD")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["JOTD_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("JOTD")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			
			if(PSN_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="PSN")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["PSN_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("PSN")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			if(CUSTOMER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CDRIVER")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["CDRIVER_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("CDRIVER")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
			
			if(ORG_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="ORG")){
				if(showNA){
					heatmap_table=heatmap_table+"<td>NA</td>";
				}else{
					heatmap_table=heatmap_table+`<td>`+processed[i]["ORG_INDEX"].toFixed(2)+`</td>`;
				}
				for(var j in processed[i]["questions"]){
					if( processed[i]["questions"][j]["code"].startsWith("ORG")){
						if(showNA){
							heatmap_table=heatmap_table+"<td>NA</td>";
						}else{
							heatmap_table=heatmap_table+heat_map_cell(processed[i]["questions"][j]["result"],min,max);
						}
					}
				}
			}
		}
		heatmap_table=heatmap_table+`</tr>`
	}
	heatmap_table=heatmap_table+`</tbody></table>`;
	document.getElementById("heatmap_table").innerHTML=heatmap_table;
	$('[data-toggle="tooltip"]').tooltip();	
	$('.double-scroll').doubleScroll({  resetOnWindowResize: true  });
	
}

// Excel Download of Heatmap and comparator

var downloadasExcel = (function() {
	var uri = 'data:application/vnd.ms-excel;base64,'
	  , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	  , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	  , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	return function(table, name) {
	  if (!table.nodeType) 
	     table = document.getElementById(table)
	  var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}

	  //window.location.href  = uri + base64(format(template, ctx))
	 var link = document.createElement("a");
     link.download = name+".xls";
     link.download = name+".xls";
     link.href = uri + base64(format(template, ctx));
     link.click();

	}
  })();

/* Downloading Driver Comments */
function downloadDivToExcel(id1,id2) { 
	var array = commentText.split("lineBreak");
	
	var newArray = [];
	var str1 = document.getElementById(id2).value;
	var str2 = document.getElementById(id1).value;

	var filename = str1.concat(str2);
	var finalComment = "";
	for(let i=0; i<array.length;i++){
    	newArray[i] = array[i]+"\r\n";                                    
        finalComment += newArray[i];                              
    }                                 
    var ctx = ('data:application/vnd.ms-excel,' + encodeURIComponent(finalComment));  
	var link = document.createElement('a');
	link.download = filename+"_comments.xls";
	link.href = ctx;
	link.click();
}



function exportImageToExcel(id,divclass,fileName){
	html2canvas($('.'+id), {
        background: "#fff",
        onrendered: function (canvas) {
        var img = canvas.toDataURL("image/jpeg", 0.9).replace("image/jpeg","image/octet-stream");
        var a = document.createElement('a'); 
        a.href = img;
        a.download = fileName + ".jpeg";

        var uri = 'data:application/vnd.ms-excel;base64,'
            , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><img src="{table}" alt="grafica" /></body></html>'
            , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
            , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }

        var ctx = { worksheet: name || 'Worksheet', table: fileName + ".jpeg" }
        //window.location.href = uri + base64(format(template, ctx))
        var link = document.createElement("a");
        link.download = fileName+".xls";
        link.href = uri + base64(format(template, ctx));
        link.click();
    }
});
}


/*
	Image Downloading Function
*/

function downloadAsImage(id,filename){                           
                                      
         html2canvas($('#'+id), 
         {
	      background: "#fff",
          onrendered: function (canvas) {
          var a = document.createElement('a');
          a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
          a.download = filename+'.jpg';
          a.click();
                                      
                                      
     	}
                                         
      });   
                                      
}



/*
	PDF Downloading Function
*/

function downloadAsPDF(divClass,filename) {
    var HTML_Width = $("."+divClass).width();
	var HTML_Height = $("."+divClass).height();
	var top_left_margin = 15;
	var PDF_Width = HTML_Width+(top_left_margin*2);
	var PDF_Height = (PDF_Width*1.5)+(top_left_margin*2);
	var canvas_image_width = HTML_Width;
	var canvas_image_height = HTML_Height;
		
	var totalPDFPages = Math.ceil(HTML_Height/PDF_Height)-1;
		

	html2canvas($("."+divClass)[0],{allowTaint:true}).then(function(canvas){
		var ctx = canvas.getContext('2d');
		var imgData = canvas.toDataURL("image/jpeg", 1.0);
		var pdf = new jsPDF('p', 'pt',  [PDF_Width, PDF_Height]);
		pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin,canvas_image_width,canvas_image_height);

		for (var i = 1; i <= totalPDFPages; i++) { 
          pdf.addPage(PDF_Width, PDF_Height);
          pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
        }

        pdf.save(filename+".pdf");
    });
}


function heat_map_cell(result,min,max){
	var number = Math.round(result["positive"]*100/(result["positive"]+result["negative"]+result["neutral"]));
	return `<td style="color:#ffffff; background-color:`+get_color(number,min,max,((min+max)/2))+`; text-align:center;" >`+number+`%</td>`;
}

function get_color(number,min,max,mean){
	if(number<mean){
		var value = (number-min)/(mean-min);
		if(value<0.2){
			return "#ba000d";
		}else if(value<0.4){
			return "#c51f0b";
		}else if(value<0.6){
			return "#d34508";
		}else if(value<0.8){
			return "#ea8504";
		}else if(value<0.97){
			return "#f5a202";
		}else{
			return "#ffbf00";
		}
	}else if(number==mean){
		return "#ffbf00";
	}else{
		var value = ((number-mean)/(max-mean));
		if(value<0.03){
			return "#ffbf00";
		}else if(value<0.2){
			return "#d5b406";
		}else if(value<0.4){
			return "#a3a80d";
		}else if(value<0.6){
			return "#639716";
		}else if(value<0.8){
			return "#328a1d";
		}else{
			return "#087f23";
		}
	}
}
                             
function comparator_setup(){
	var compare_survey_id = document.getElementById('comparator_survey').value;
	loading(true);
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
				$.post("/account/survey.php",{
					"survey_id": compare_survey_id,
					"method": "dashboard",
					"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
					loading(false);
				    try{
					compare_survey.data = JSON.parse(decrypt(response.data.response,crypt.decrypt(response.key)));
                            
					compare_survey.questions = JSON.parse(decrypt(response.data.question,crypt.decrypt(response.key)));
                             ////console.log(compare_survey.questions);
					compare_survey.limit = JSON.parse(decrypt(response.data.min_limit,crypt.decrypt(response.key)));
                             ////console.log(compare_survey.limit);
					comparator_change();
					}catch(err){
						//console.log(err);
						//snackbar("Unable to Load the the Comparator");
					}
					}).fail(err =>{
					snackbar("Loading Failed");
					loading(false);
				});		
}

function comparator_change(){
	var attribute = document.getElementById("comparator_attribute").value;
	var parameter = document.getElementById("comparator_parameter").value;

	var value = new Array();
	var processed = new Array();
	for(i in filters){
		if(filters[i]["name"]===parameter){
			value=filters[i].value;
		}
	}
	value.push('Total');
	var survey_original = survey_process_comparator(filtered_data,questions_original,attribute,parameter);
	compare_survey.filtered_data = [];
	////console.log(filters_active);
	for(var i in compare_survey.data){
		var valid = true;
		for(var j in filters_active){
			if(filters_active[j].value.length==filters[j].value.length){
				break;
			}
			if(!filters_active[j].value.includes(compare_survey.data[i][filters_active[j]["name"]])){
				valid=false; 
				break;
			}
		}
		if(valid){
			compare_survey.filtered_data.push(JSON.parse(JSON.stringify(compare_survey.data[i])));
		}
	}
	var survey_comparator = survey_process_comparator(compare_survey.filtered_data,compare_survey.questions,attribute,parameter);
	////console.log(survey_comparator);
	var survey_original_name = document.getElementById('survey_name').value;
	var sel = document.getElementById("comparator_survey");
	var survey_comparator_name= sel.options[sel.selectedIndex].text
	//Setup UI
	var max=0;
	var min=100;
	var comparator_table=`<table class="table"><thead><tr>`;
	comparator_table=comparator_table+`<td>Parameter</td><td>Survey Name</td><td>Responses</td>`;
	////console.log(survey_original);
	if(ENGAGEMENT_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="ENGAGE")){
		comparator_table=comparator_table+`<td>Engagement</td><td>Engagement Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("ENGAGE")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(LEADER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="LEADER")){
		comparator_table=comparator_table+`<td>Leader Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("LEADER")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(MANAGER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="MANAGER")){
		comparator_table=comparator_table+`<td>Manager Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("MANAGER")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WFH_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFH")){
		comparator_table=comparator_table+`<td>Work from Home</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WFH")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WFO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFO")){
		comparator_table=comparator_table+`<td>Work From Office Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WFO")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(HR_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="HR")){
		comparator_table=comparator_table+`<td>Human Resource Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("HR")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WB")){
		comparator_table=comparator_table+`<td>Well Being Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WB")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(OTHER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CUSTOM")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("CUSTOM")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(INNVO_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="INNOVATION")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("INNV")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(JOTA_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTA")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTA")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(JOTB_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTB")){
		comparator_table=comparator_table+`<td>JOTB</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTB")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTC_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTC")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTC")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTD_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTD")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTD")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(PSN_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="PSN")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("PSN")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(CUSTOMER_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="CDRIVER")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("CDRIVER")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(ORG_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="ORG")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("ORG")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	var min =0;
	var max=100;
	for(var i in survey_original){
		var showNA = false;
		var showNACompare = false;
		if(survey_comparator[i]["COUNT"]<min_limit.min_filter){
			showNACompare=true;
		}
		if(survey_original[i]["COUNT"]<min_limit.min_filter){
			showNA=true;
		}else{
			comparator_table=comparator_table+`<tr `;
			if(i==='Total'){
			comparator_table=comparator_table+' style="font-weight:900;font-size:24px;" ';}
			comparator_table=comparator_table+`><td class="p-0"><p class="pt-3">`+i+`</p></td><td class="p-0"><p class="p-2 mb-0" style="overflow: hidden; white-space: nowrap;">`+survey_original_name+`</p><p class="p-2 mb-0"  style="overflow: hidden; white-space: nowrap;">`+survey_comparator_name+`</p></td><td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["COUNT"]+`</p><p class="p-2 mb-0" >`+survey_comparator[i]["COUNT"]+`</p></td>`;
			
			if(ENGAGEMENT_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="ENGAGE")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td><td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+Math.round(survey_original[i]["ENGAGED_COUNT"]*100/survey_original[i]["COUNT"])+`%</p><p class="p-2 mb-0" >`+(showNACompare?"NA":Math.round(survey_comparator[i]["ENGAGED_COUNT"]*100/survey_comparator[i]["COUNT"]))+`%</p></td>`;
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["ENGAGE_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["ENGAGE_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("ENGAGE")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			 
			if(LEADER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="LEADER")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["LEADER_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["LEADER_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("LEADER")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(MANAGER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="MANAGER")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["MANAGER_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["MANAGER_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("MANAGER")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WFH_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFH")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WFH_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WFH_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WFH")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WFO_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WFO")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WFO_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WFO_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WFO")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(HR_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="HR")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["HR_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["HR_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("HR")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WB_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="WB")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WB_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WB_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WB")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(OTHER_QUESTION_COUNT>0&&(attribute==="ALL"||attribute==="CUSTOM")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("CUSTOM")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(INNVO_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="INNOVATION")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("INNV")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(JOTA_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTA")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTA")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(JOTB_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTB")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTB")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(JOTC_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTC")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTC")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(JOTD_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="JOTD")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTD")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(PSN_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="PSN")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("PSN")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(CUSTOMER_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="CDRIVER")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("CDRIVER")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(ORG_QUESTION_COUNT >0&&(attribute==="ALL"||attribute==="ORG")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("ORG")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cell(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
		}
		comparator_table=comparator_table+`</tr>`
	} 
	comparator_table=comparator_table+`</tr></thead><tbody>`;
	comparator_table=comparator_table+`</tbody></table>`;
	
	document.getElementById("comparator_table").innerHTML=comparator_table;
	$('[data-toggle="tooltip"]').tooltip();	
	$('.double-scroll').doubleScroll({  resetOnWindowResize: true  }); 
}


function comparator_cell(result,result2){
	var number = Math.round(result["positive"]*100/(result["positive"]+result["negative"]+result["neutral"]));
	var number_compare = 0;
	var number_diff = 0;
	if(result!="NA"){
		number_compare = Math.round(result2["positive"]*100/(result2["positive"]+result2["negative"]+result2["neutral"]));
		number_diff = number_compare-number;
		number_compare = number_compare+"%";
	}
	else
		number_compare = "NA";
	//return `<td style="color:#000;" >`+number+`%<br>`+number_compare+`%</td>`;
	return `<td class="p-0"><p class="p-2 mb-0 text-center" style="color:#ffffff; background-color:`+(number_diff>3?"#ba000d":(number_diff<-3?"#087f23":"#ffbf00"))+`; white-space: nowrap; text-overflow: ellipsis; ">`+number+`%</p><p class="p-2 mb-0  text-center" >`+number_compare+`</p>`;
}
function survey_process_comparator(survey_response,question_array_input,attribute/*driver*/,parameter){
	////console.log(question_array);
	question_array = {};
	for(i in question_array_input){
		question_array[question_array_input[i]["code"]] = question_array_input[i];
	}
	var value = new Array();
	var processed = new Array();
	for(i in filters){
		if(filters[i]["name"]===parameter){
			value=filters[i].value;
		}
	}
	value.push('Total');
	for(var i in value){
		processed[value[i]]=new Array();
		processed[value[i]]["questions"]=new Array();
		jQuery.extend(true,processed[value[i]]["questions"],question_array);
		if(ENGAGEMENT_QUESTION_COUNT>0){
			processed[value[i]]["ENGAGE_INDEX"]=0;
			processed[value[i]]["ENGAGED_COUNT"]=0;
		}
		if(MANAGER_QUESTION_COUNT>0)
			processed[value[i]]["MANAGER_INDEX"]=0;
		if(LEADER_QUESTION_COUNT>0)
			processed[value[i]]["LEADER_INDEX"]=0;
		if(WFH_QUESTION_COUNT>0)
			processed[value[i]]["WFH_INDEX"]=0;
		if(WFO_QUESTION_COUNT>0)
			processed[value[i]]["WFO_INDEX"]=0;
		if(HR_QUESTION_COUNT>0)
			processed[value[i]]["HR_INDEX"]=0;
		if(WB_QUESTION_COUNT>0)
			processed[value[i]]["WB_INDEX"]=0;
		if(OTHER_QUESTION_COUNT>0)
			processed[value[i]]["OTHER_INDEX"]=0;
		if(INNVO_QUESTION_COUNT>0)
			processed[value[i]]["INNOVATION_INDEX"]=0;
		if(JOTA_QUESTION_COUNT>0)
			processed[value[i]]["JOTA_INDEX"]=0;
		if(JOTB_QUESTION_COUNT>0)
			processed[value[i]]["JOTB_INDEX"]=0;
		if(JOTC_QUESTION_COUNT>0)
			processed[value[i]]["JOTC_INDEX"]=0;
		if(JOTD_QUESTION_COUNT>0)
			processed[value[i]]["JOTD_INDEX"]=0;
		if(PSN_QUESTION_COUNT>0)
			processed[value[i]]["PSN_INDEX"]=0;
		if(CUSTOMER_QUESTION_COUNT>0)
			processed[value[i]]["CDRIVER_INDEX"]=0;
		if(ORG_QUESTION_COUNT>0)
			processed[value[i]]["ORG_INDEX"]=0;
		processed[value[i]]["COUNT"]=0;
	}
	for(var i in survey_response){
		try{
		var USER_ENGAGED = 0;
		for(var j in processed[value[0]]["questions"]){
			var code = processed[value[0]]["questions"][j]["code"];
			if(code.startsWith("ENGAGE")||code.startsWith("LEADER")||code.startsWith("MANAGER")||code.startsWith("WFH")||code.startsWith("WFO")||code.startsWith("HR")||code.startsWith("WB")||code.startsWith("CUSTOM") || code.startsWith("CENGAGE") || code.startsWith("ORG")){
					if(survey_response[i][code]>=4){
						processed[survey_response[i][parameter]]["questions"][j]["result"]["positive"]++;
						processed['Total']["questions"][j]["result"]["positive"]++;
					}else if(survey_response[i][code]<=2){
						processed[survey_response[i][parameter]]["questions"][j]["result"]["negative"]++;
						processed['Total']["questions"][j]["result"]["negative"]++;
					}else{
						processed[survey_response[i][parameter]]["questions"][j]["result"]["neutral"]++;
						processed['Total']["questions"][j]["result"]["neutral"]++;
					}
			}
			if(code.startsWith("ENGAGE")){
				processed[survey_response[i][parameter]]["ENGAGE_INDEX"]=processed[survey_response[i][parameter]]["ENGAGE_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["ENGAGE_INDEX"]=processed['Total']["ENGAGE_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				USER_ENGAGED=USER_ENGAGED+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("LEADER")){
				processed[survey_response[i][parameter]]["LEADER_INDEX"]=processed[survey_response[i][parameter]]["LEADER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["LEADER_INDEX"]=processed['Total']["LEADER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("MANAGER")){
				processed[survey_response[i][parameter]]["MANAGER_INDEX"]=processed[survey_response[i][parameter]]["MANAGER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["MANAGER_INDEX"]=processed['Total']["MANAGER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WFH")){
				processed[survey_response[i][parameter]]["WFH_INDEX"]=processed[survey_response[i][parameter]]["WFH_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WFH_INDEX"]=processed['Total']["WFH_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WFO")){
				processed[survey_response[i][parameter]]["WFO_INDEX"]=processed[survey_response[i][parameter]]["WFO_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WFO_INDEX"]=processed['Total']["WFO_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("HR")){
				processed[survey_response[i][parameter]]["HR_INDEX"]=processed[survey_response[i][parameter]]["HR_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["HR_INDEX"]=processed['Total']["HR_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WB")){
				processed[survey_response[i][parameter]]["WB_INDEX"]=processed[survey_response[i][parameter]]["WB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WB_INDEX"]=processed['Total']["WB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("CUSTOM")){
				processed[survey_response[i][parameter]]["OTHER_INDEX"]=processed[survey_response[i][parameter]]["OTHER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["CUSTOM"]=processed['Total']["CUSTOM"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("INNV")){
				processed[survey_response[i][parameter]]["INNOVATION_INDEX"]=processed[survey_response[i][parameter]]["INNOVATION_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["INNOVATION_INDEX"]=processed['Total']["INNOVATION_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTA")){
				processed[survey_response[i][parameter]]["JOTA_INDEX"]=processed[survey_response[i][parameter]]["JOTA_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTA_INDEX"]=processed['Total']["JOTA_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTB")){
				processed[survey_response[i][parameter]]["JOTB_INDEX"]=processed[survey_response[i][parameter]]["JOTB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTB_INDEX"]=processed['Total']["JOTB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTC")){
				processed[survey_response[i][parameter]]["JOTC_INDEX"]=processed[survey_response[i][parameter]]["JOTC_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTC_INDEX"]=processed['Total']["JOTC_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTD")){
				processed[survey_response[i][parameter]]["JOTD_INDEX"]=processed[survey_response[i][parameter]]["JOTD_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTD_INDEX"]=processed['Total']["JOTD_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("PSN")){
				processed[survey_response[i][parameter]]["PSN_INDEX"]=processed[survey_response[i][parameter]]["PSN_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["PSN_INDEX"]=processed['Total']["PSN_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("CDRIVER")){
				processed[survey_response[i][parameter]]["CDRIVER_INDEX"]=processed[survey_response[i][parameter]]["CDRIVER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["CDRIVER_INDEX"]=processed['Total']["CDRIVER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("ORG")){
				processed[survey_response[i][parameter]]["ORG_INDEX"]=processed[survey_response[i][parameter]]["ORG_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["ORG_INDEX"]=processed['Total']["ORG_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
		}
		processed[survey_response[i][parameter]]["COUNT"]++;
		processed['Total']["COUNT"]++;
		if((USER_ENGAGED/ENGAGEMENT_QUESTION_COUNT)>=3.75){
			processed[survey_response[i][parameter]]["ENGAGED_COUNT"]++;
			processed['Total']["ENGAGED_COUNT"]++;
		}
		}catch(err){}
	}
	for(i in processed){
		if(ENGAGEMENT_QUESTION_COUNT>0)
			processed[i]["ENGAGE_INDEX"]=(processed[i]["ENGAGE_INDEX"]/(ENGAGEMENT_QUESTION_COUNT*processed[i]["COUNT"]));
		if(MANAGER_QUESTION_COUNT>0)
			processed[i]["MANAGER_INDEX"]=(processed[i]["MANAGER_INDEX"]/(MANAGER_QUESTION_COUNT*processed[i]["COUNT"]));
		if(LEADER_QUESTION_COUNT>0)
			processed[i]["LEADER_INDEX"]=(processed[i]["LEADER_INDEX"]/(LEADER_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WFH_QUESTION_COUNT>0)
			processed[i]["WFH_INDEX"]=(processed[i]["WFH_INDEX"]/(WFH_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WFO_QUESTION_COUNT>0)
			processed[i]["WFO_INDEX"]=(processed[i]["WFO_INDEX"]/(WFO_QUESTION_COUNT*processed[i]["COUNT"]));
		if(HR_QUESTION_COUNT>0)
			processed[i]["HR_INDEX"]=(processed[i]["HR_INDEX"]/(HR_QUESTION_COUNT*processed[i]["COUNT"]));
		if(WB_QUESTION_COUNT>0)
			processed[i]["WB_INDEX"]=(processed[i]["WB_INDEX"]/(WB_QUESTION_COUNT*processed[i]["COUNT"]));
		if(OTHER_QUESTION_COUNT>0){
			processed[i]["OTHER_INDEX"]=(processed[i]["OTHER_INDEX"]/(WB_QUESTION_COUNT*processed[i]["COUNT"]));
			processed[i]["OTHER_INDEX"] = '-';
		}
		if(INNVO_QUESTION_COUNT>0){
			processed[i]["INNOVATION_INDEX"]=(processed[i]["INNOVATION_INDEX"]/(INNVO_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTA_QUESTION_COUNT>0){
			processed[i]["JOTA_INDEX"]=(processed[i]["JOTA_INDEX"]/(JOTA_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTB_QUESTION_COUNT>0){
			processed[i]["JOTB_INDEX"]=(processed[i]["JOTB_INDEX"]/(JOTB_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTC_QUESTION_COUNT>0){
			processed[i]["JOTC_INDEX"]=(processed[i]["JOTC_INDEX"]/(JOTC_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(JOTD_QUESTION_COUNT>0){
			processed[i]["JOTD_INDEX"]=(processed[i]["JOTD_INDEX"]/(JOTD_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(PSN_QUESTION_COUNT>0){
			processed[i]["PSN_INDEX"]=(processed[i]["PSN_INDEX"]/(PSN_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(CUSTOMER_QUESTION_COUNT>0){
			processed[i]["CDRIVER_INDEX"]=(processed[i]["CDRIVER_INDEX"]/(CUSTOMER_QUESTION_COUNT*processed[i]["COUNT"]));
		}
		if(ORG_QUESTION_COUNT>0){
			processed[i]["ORG_INDEX"]=(processed[i]["ORG_INDEX"]/(ORG_QUESTION_COUNT*processed[i]["COUNT"]));
		}
	}
	// //console.log(processed);
	return processed;
}
/*function get_color(number,min,max,mean){
	if(number<mean){
		var value = (number-min)/(mean-min);
		if(value<0.2){
			return "#ba000d";
		}else if(value<0.4){
			return "#bb2630";
		}else if(value<0.6){
			return "#bc4c54";
		}else if(value<0.8){
			return "#bc7277";
		}else if(value<0.97){
			return "#bd989b";
		}else{
			return "#bebebe";
		}
	}else if(number==mean){
		return "#bebebe";
	}else{
		var value = ((number-mean)/(max-mean));
		if(value<0.03){
			return "#bebebe";
		}else if(value<0.2){
			return "#9ab19f";
		}else if(value<0.4){
			return "#76a580";
		}else if(value<0.6){
			return "#519861";
		}else if(value<0.8){
			return "#2d8c42";
		}else{
			return "#087f23";
		}
	}
}*/

/*Word Cloud Functions*/
                             
                             
function wordFreq(string) {
    var words = string.replace(/[^0-9a-zA-Z]/gi,' ')
				.toLowerCase()				
				.replace(/[.]/g, '')
				.split(/\s/);
	words = remove_stopwords(words);
    var freqMap = {};
    words.forEach(function(w) {
		if(w!=''){
			if (!freqMap[w]) {
				freqMap[w] = 0;
			}
			freqMap[w] += 1;
		}
    });
	var arr = [];
    for (var word in freqMap) {
        if (freqMap.hasOwnProperty(word)) {
			temp = [];
			temp["word"]=word;
			temp["count"]=freqMap[word];
            arr.push(temp);
        }
    }
	arr.sort(function(a, b){return b.count - a.count});
    return arr;
}
function remove_stopwords(words) {
    res = [];
	stopwords = ['i','me','my','myself','we','our','ours','ourselves','you','your','yours','yourself','yourselves','he','him','his','himself','she','her','hers','herself','it','its','itself','they','them','their','theirs','themselves','what','which','who','whom','this','that','these','those','am','is','are','was','were','be','been','being','have','has','had','having','do','does','did','doing','a','an','the','and','but','if','or','because','as','until','while','of','at','by','for','with','about','against','between','into','through','during','before','after','above','below','to','from','up','down','in','out','on','off','over','under','again','further','then','once','here','there','when','where','why','how','all','any','both','each','few','more','most','other','some','such','no','nor','not','only','own','same','so','than','too','very','s','t','can','will','just','don','should','now','called',''];
    for(i=0;i<words?.length;i++) {
       if(!stopwords.includes(words[i])&&isNaN(words[i])&&words[i].length>1){
           res.push(words[i]);
       }
    }
    return res;
}


function get_color_material(){
	const Colors = ['#F44336','#E91E63','#FA029E','#9C27B0','#673AB7','#3F51B5','#2196F3','#03A9F4','#00BCD4','#009688','#4CAF50','#8BC34A','#CDDC39','#FFEB3B','#FFC107','#FF9800','#FF5722','#795548','#9E9E9E','#607D8B','#000000'];
	return Colors[Math.floor(Math.random()*Colors.length)];
}


function word_cloud(id,arr){
	
	var result = arr;
	i=0;
    while (i < arr.length) {
       if(result[i]["count"]<2)
			break;
	   i=i+1;
	   if(i==50)
			break;
    }	
	if(i>50)
		i=50;
	if(i==0)
	{
		i=1;
	}
	result = result.slice(0, i);
	var min = 999999;
	var max = 0;
	for(var i in result){
		var count = result[i]["count"];
		if(min>count){
			min=count;
		}
		if(max<count){
			max=count;
		}
	}
	var wordScale = d3.scaleLinear().domain([min, max]).range([12,72]);
	var margin = {top: 2, right: 2, bottom: 2, left: 2},
		width = $('#'+id).actual('width') - margin.left - margin.right,
		height = 420 - margin.top - margin.bottom;

	var svg = d3.select("#"+id).append("svg")
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom)
	  .append("g")
		.attr("transform",
			  "translate(" + margin.left + "," + margin.top + ")");
			  
	var layout = d3.layout.cloud()
	  .size([width, height])
	  .words(result.map(function(d) { return {text: d.word, size: +d.count}; }))
	  .padding(1)
	  .fontSize(function(d) { 
	  return wordScale(d.size); })
	  //.on("end", draw);
	  .on("end", function(words){
		////console.log(words);
		svg
		.append("g")
		  .attr("transform", "translate(" + layout.size()[0] / 2 + "," + layout.size()[1] / 2 + ")")
		  .selectAll("text")
			.data(words)
		  .enter().append("text")
			.style("font-size", function(d) {return d.size + "px"; })
			.style("fill", function(d) {return get_color_material(); })
			.attr("text-anchor", "middle")
			.attr("transform", function(d) {
			  return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
			})
			.text(function(d) { return d.text; });
		}); 
	layout.start();
}
                       
                       
                       
function randomString(length) {
	var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}


function scorecard_send_bulk(survey_id,type){
	if(confirm("Are you sure you want to send the Scorecards to the users?")){
		$.get("survey.php?method=scorecard_send&survey_id="+encodeURI(survey_id)+"&type="+encodeURI(type)+"&output=json", function(data) {
			snackbar(data.message);
		});
	}
}
function scorecard_send(survey_id,type,user_id){
	if(confirm("Are you sure you want to send the Scorecards to the users?")){
		$.get("survey.php?method=scorecard_send&survey_id="+encodeURI(survey_id)+"&type="+encodeURI(type)+"&user_id="+encodeURI(user_id)+"&output=json", function(data) {
			snackbar(data.message);
		});
	}
}

function zzz(){
	return "zzz";
}

var $messages = $(".messagesContent"),
  d,
  h,
  m,
  messageCount = 0;

$("#messagesContent").ready(function () {
  //console.log('On messages content loaded');
  $messages.mCustomScrollbar();
  setTimeout(function () {
    kyaraMessage();
  }, 100);
});

function updateScrollbar() {
  $messages.mCustomScrollbar("update").mCustomScrollbar("scrollTo", "bottom", {
    scrollInertia: 10,
    timeout: 0,
  });
}

function setDate() {
  d = new Date();
  if (m != d.getMinutes()) {
    m = d.getMinutes();
    $('<div class="timestamp">' + d.getHours() + ":" + m + "</div>").appendTo(
      $("#message").last()
    );
    $('<div class="checkmark-sent-delivered">&check;</div>').appendTo(
      $("#message").last()
    );
    $('<div class="checkmark-read">&check;</div>').appendTo($("#message").last());
  }
}

function insertMessage() {
  msg = $("#messageInput").val();
  if ($.trim(msg) == "") {
    return false;
  }
  $('<div class="message message-personal" id="message">' + msg + "</div>")
    .appendTo($(".mCSB_container"))
    .addClass("new");
  setDate();
  updateScrollbar();
  $("#messageInput").val(null);
  if (messageCount == 2) {
    askKyara(msg);
  } else if (messageCount == 3) {
    if (msg.toLowerCase() == 'y' || msg.toLowerCase() == 'yes') {
      kyaraMessage("That's great! Is there anything else I can help you with?");
    } else if (msg.toLowerCase() == 'n' || msg.toLowerCase() == 'no') {
      $('#diagnostic_tab.nav-item').click();
      kyaraMessage("Navigating to the Diagnostic tab to identify the key issues and actions you can take for this team...");
  }
  } else {
    kyaraMessage();
  }
}

$("#sendButton").click(function () {
  insertMessage();
});

$(window).on("keydown", function (e) {
  if (e.which == 13) {
    insertMessage();
    return false;
  }
});

const askKyara = async (msg) => {
  var filtersFormatted = new Array();
  filters.map((filter) => {
    var temp = {};
    temp[filter["title"]] = filter["value"];
    filtersFormatted.push(temp);
  });
  const response = await fetch("http://127.0.0.1:5000/saveResponse", {
    method: "POST",
    crossDomain: true,
    body: JSON.stringify({ userResponse: msg, dashFilters: filtersFormatted }), // string or object
    headers: {
      "Content-Type": "application/json",
    },
  });
  const kyaraResposnse = await response.json(); //extract JSON from the http response
  ////console.log(kyaraResposnse);

  kyaraResposnse.filters.map((filter) => {
    var tempKey = filter.key.replace(/\s+/g,"_");
    filter_unselect(tempKey);
    filter.val.map((filterVal) => {
      var temp = filterVal.replace(/\s+/g,"_");
      //console.log('#' + tempKey + '_' + temp.toLowerCase());
      $('#' + tempKey + '_' + temp.toLowerCase()).click();
      filter_apply();
    });
  });

  setTimeout(function() {
  //var temp = kyaraResposnse["cf-label"];
  var temp = "The engagement of the team is " + $("#engagement_perc_1").text().toString();
  temp += ", high performers are " + performance + "%";
  temp += ", and the attrition will be " + attrition + "%.";

  if (kyaraResposnse["resources"][0] === "Engagement Index") {
    temp = "The engagement index is: " + $("#engagement_index").text().toString();
  }
  else if (kyaraResposnse["resources"][0] === "Predicted Attrition") {
    temp = "The predicted attrition is: " + $("#predicted_attrition").text().toString();
  }
  else if (kyaraResposnse["resources"][0] === "Predicted Performance") {
    temp = "The predicted performance is: " + $("#predicted_performance").text().toString();
  }
  else if (kyaraResposnse["resources"][0] === "Predicted High Performance") {
    temp = "The predicted high performance is: " + $("#predicted_high_performance").text().toString();
  }
  else if (kyaraResposnse["resources"][0] === "Responses") {
    temp = $("#num_of_reponses_1").text().toString() + "responses have been recorded";
  }
  else if (kyaraResposnse["resources"][0] === "Engagement %") {
    temp = "The engagement % is: " + $("#engagement_perc_1").text().toString();
  }
  else if (kyaraResposnse["resources"][0] === "Positivity Index") {
    temp = "The positivity index is: " + $("#positivity_index").text().toString();
  }
  kyaraMessage(temp);
  setDate();
  updateScrollbar();
  }, 1000);
};

function kyaraMessage(msg) {
//console.log('Inside Kyara Message...');
  
  $(
    '<div class="message loading new" id="messageLoading"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure><span></span></div>'
  ).appendTo($(".mCSB_container"));
//console.log('Added loading..');
  updateScrollbar();

  setTimeout(function () {
    $("#messageLoading").remove();
    //console.log('Removed loading..');
    if (messageCount == 0) {
      $(
        '<div class="message new"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          "Hi there.. I'm Kyara!" +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");

      $(
        '<div class="message new"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          "What is your top strategic objective in the next 2 quarters?" +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");
    } else if (messageCount == 1) {
      $(
        '<div class="message new"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          "What is the key demographic you are looking at to achieve this?" +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");
    } else if (messageCount == 2) {
      $(
        '<div class="message new" id="message"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          msg +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");
      $( 
        '<div class="message new" id="message"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          "Do you think with these parameters this team will deliver?" +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");
    } else {
      $(
        '<div class="message new" id="message"><figure class="avatar"><img src="./images/kyaraLogo.jpg" /></figure>' +
          msg +
          "</div>"
      )
        .appendTo($(".mCSB_container"))
        .addClass("new");
    }

    setDate();
    updateScrollbar();
    messageCount++;
  }, 1000 + Math.random() * 20 * 100);
}

$("#sendButton").click(function () {
  $(".menu .items span").toggleClass("active");
  $(".menu .button").toggleClass("active");
});

$("#chatCircle").click(function () {
    //console.log("Logo Clicked");
    $("#chatCircle").hide();
    $("#popup").toggle();
  });


$("#menuButton").click(function () {
    $("#popup").hide();
    $("#chatCircle").show();
  });

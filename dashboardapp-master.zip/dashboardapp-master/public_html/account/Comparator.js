var dataComprator;
var benchmarkComprator;
var filtered_dataComprator;
var questions_originalComprator;
var questionsComprator;
var min_limitComprator;
var managerComprator;
var filtersComprator = new Array();
var filters_activeComprator;
var ENGAGEMENT_QUESTION_COUNTComp=0;
var MANAGER_QUESTION_COUNTComp=0;
var LEADER_QUESTION_COUNTComp=0;
var WFH_QUESTION_COUNTComp=0;
var WFO_QUESTION_COUNTComp=0;
var HR_QUESTION_COUNTComp=0;
var WB_QUESTION_COUNTComp=0;
var OTHER_QUESTION_COUNTComp=0;
var OPEN_QUESTION_COUNTComp=0;
var INNVO_QUESTION_COUNTComp=0;
var JOTA_QUESTION_COUNTComp=0;
var JOTB_QUESTION_COUNTComp=0;
var JOTC_QUESTION_COUNTComp=0;
var JOTD_QUESTION_COUNTComp=0;
var PSN_QUESTION_COUNTComp=0;
var ORG_QUESTION_COUNTComp = 0;
var INDEXComp = {};
var filterDataJoinComprator = new Array();
var compare_surveyComprator = {};
var filterTextNew = "Comparator";


function filter_resetComprator(){
	filter_initComprator(filterDataJoinComprator).then(() => {
		filter_applyComprator();
	});
}


function filter_unselectComparator(input){
	
	//////console.log(input);
	//////console.log(filters);
	// console.log(document.getElementById(filtersComprator[i]["name"]+"_"+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()))
	for(var i in filtersComprator){
		if(filtersComprator[i]["name"]===input){
			for(var j in filtersComprator[i]["value"]){
				 console.log(document.getElementById(filterTextNew+filtersComprator[i]["name"]+"_"+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()))
				document.getElementById(filterTextNew+filtersComprator[i]["name"]+"_"+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked = false;
			}
		}
	}
}


function filter_option_text_changeComparator(input){
	const id = input.id.replace("_search","")+"_option";
	const value = input.value.toLowerCase();
	////console.log(id+" "+value);
	$("#"+id+" div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
}



function encryptData(data,key){
	return CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(key),{
	mode: CryptoJS.mode.ECB,
	padding: CryptoJS.pad.Pkcs7
  }).toString();
}

function decryptData(data,key){
  return CryptoJS.AES.decrypt(data, CryptoJS.enc.Utf8.parse(key),{
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  }).toString(CryptoJS.enc.Utf8);
}


function filter_applyComprator(){
	

	filtered_dataComprator = new Array();
	filters_activeComprator = new Array();
	jQuery.extend(true,filters_activeComprator,filtersComprator);
	for(var i in filters_activeComprator){
		filters_activeComprator[i]["value"] = [];
	}
	//////console.log(filters_activeComprator)
	
	// comprator filter
	for(var i in filtersComprator){
		for(j in filtersComprator[i].value){
			try{
			
				if(document.getElementById(filterTextNew+filtersComprator[i]["name"]+`_`+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked){
					filters_activeComprator[i]["value"].push(filtersComprator[i]["value"][j]);
				}
			}catch(err){
				//console.log("Error: "+filtersComprator[i]["name"]+`_`+filtersComprator[i]["value"][j]);
				////console.log(err);
			}
		}
	}
	
	/// end here 
	var filter_text="";
	for(var i in filtersComprator){
		if(filters_activeComprator[i].value.length<filtersComprator[i].value.length){
			filter_text = filter_text+filters_activeComprator[i].title+"("+filters_activeComprator[i].value.toString()+")  ";
		}
	}   
	
	for(var i in dataComprator){
		var valid = true;
		for(var j in filters_activeComprator){
			if(!filters_activeComprator[j].value.includes(dataComprator[i][filters_activeComprator[j]["name"]])){
				valid=false;
			}
		}
		if(valid){			
			filtered_dataComprator.push(JSON.parse(JSON.stringify(dataComprator[i])));
		}
	}
	
	
	if(filter_text.length < 120)
	{
		document.getElementById("filter_textComprator").innerHTML = "<strong>(# "+filtered_dataComprator.length+")</strong> "+filter_text;
	}
	else
	{
		
		let tempText = filter_text.substring(0,240);
		tempText = `${tempText}......`;
		document.getElementById("filter_textComprator").innerHTML = "<strong>(# "+filtered_dataComprator.length+")</strong> "+tempText;
	}
	
  //  ////console.log(min_limit);
	if(filtered_dataComprator.length<min_limitComprator.min_filter){
		filtered_dataComprator = new Array();
		for(var i in dataComprator){
			filtered_dataComprator.push(JSON.parse(JSON.stringify(dataComprator[i])));
		}
		document.getElementById("filter_textComprator").innerHTML=document.getElementById("filter_textComprator").innerHTML+" <span style=\"font-size:14px\" >Not Enough Data (Showing Everything)<span>";
		modal("Not Enough Data","Data is too few to show insights <br> Showing all the data. Please select filter such that more data is selected");
	}
	

	
	comparator_changeComparator();
	
}


async function filter_initComprator(json){
	
	//console.log("JSOn Value ",json);
	filterDataJoinComprator = json;
	filtersComprator = new Array();
	
	for(var i in json[0]){
		if(i.startsWith("p_")){
			var filter_item  = new Array();
			filter_item.name=i;
			filter_item.title=i.replace("p_","").replace("_"," ").toProperCase();
			filter_item.value = new Array();
			filtersComprator.push(filter_item);
		}
	}
	for(var i in json){
		for(var j in filtersComprator){
			var column = filtersComprator[j].name;
			var value = json[i][column];
			if(!filtersComprator[j]["value"].includes(value)){
				filtersComprator[j]["value"].push(value);
			}
		}
	}
	for(var j in filtersComprator){
		filtersComprator[j]["value"].sort();
	}
	var filter_html = "";
	for(var i in filtersComprator){
		filter_html=filter_html+`<div class="col-lg-2 col-md-4 col-sm-6">
		<div class="card text-dark bg-light mt-3" >
		<div class="bg-primary text-white card-header font-weight-bold" style="white-space:nowrap; overflow: hidden; text-overflow: ellipsis;" onclick="filter_unselectComparator('`+filtersComprator[i]["name"]+`')" ><i class="far fa-minus-square float-right" style="display: inline-block;" title="Unselect All" ></i><span  title="`+filtersComprator[i]["title"]+`">`+filtersComprator[i]["title"]+`</span></div>
		<input class="form-control" id="`+filterTextNew+filtersComprator[i]["name"]+`_search" onkeyup="filter_option_text_changeComparator(this)" placeholder="Type `+filtersComprator[i]["title"]+` here" >
		<div class="card-body" style="height:200px; overflow: scroll; scrollbar-width: thin;" ><div id="`+filterTextNew+filtersComprator[i]["name"]+`_option">`;
		for(j in filtersComprator[i].value){
			filter_html=filter_html+`<div class="custom-control custom-checkbox">
			<input class="custom-control-input" type="checkbox" id="`+filterTextNew+filtersComprator[i]["name"]+`_`+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`" checked="checked">
			<label class="custom-control-label" for="`+filterTextNew+filtersComprator[i]["name"]+`_`+filtersComprator[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`"> `+filtersComprator[i]["value"][j]+`</label>
			</div>`;
		}
		filter_html=filter_html+`</div></div>
		</div>
		</div>`;
	}
	document.getElementById("container_filterComprator").innerHTML = filter_html;
	ENGAGEMENT_QUESTION_COUNTComp=0;
	MANAGER_QUESTION_COUNTComp=0;
	LEADER_QUESTION_COUNTComp=0;
	WFH_QUESTION_COUNTComp=0;
	WFO_QUESTION_COUNTComp=0;
	HR_QUESTION_COUNTComp=0;
	WB_QUESTION_COUNTComp=0;
	OTHER_QUESTION_COUNTComp=0;
	INNVO_QUESTION_COUNTComp=0;
	JOTA_QUESTION_COUNTComp=0;
	JOTB_QUESTION_COUNTComp=0;
	JOTC_QUESTION_COUNTComp=0;
	JOTD_QUESTION_COUNTComp=0;
	PSN_QUESTION_COUNTComp=0;
	ORG_QUESTION_COUNTComp =0;
	OPEN_QUESTION_COUNTComp=0;
	for(var i in json[0]){
		if(i.startsWith("ENGAGE")){
			ENGAGEMENT_QUESTION_COUNTComp++;
		}else if(i.startsWith("LEADER")){
			LEADER_QUESTION_COUNTComp++;
		}else if(i.startsWith("MANAGER")){
			MANAGER_QUESTION_COUNTComp++;
		}else if(i.startsWith("WFH")){
			WFH_QUESTION_COUNTComp++;
		}else if(i.startsWith("WFO")){
			WFO_QUESTION_COUNTComp++;
		}else if(i.startsWith("HR")){
			HR_QUESTION_COUNTComp++;
		}else if(i.startsWith("WB")){
			WB_QUESTION_COUNTComp++;
		}else if(i.startsWith("CUSTOM")){
			OTHER_QUESTION_COUNTComp++;
		}else if(i.startsWith("INNV")){
			INNVO_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("OPEN")){
			OPEN_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("JOTA")){
			JOTA_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("JOTB")){
			JOTB_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("JOTC")){
			JOTC_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("JOTD")){
			JOTD_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("PSN")){
			PSN_QUESTION_COUNTComp++;
		}
		else if(i.startsWith("ORG")){
			ORG_QUESTION_COUNTComp++;
		}
	}
	return true;
}



function dashboard_initComparator(survey_id){
	loadingComprator(true);
	document.getElementById("comparator_tableComprator").innerHTML = "";
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
		  /*$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=question_get", function(questions_response){
			$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=benchmark", function(benchmark_response){*/
				$.post("/account/survey.php",{
					"survey_id": survey_id,
					"method": "dashboard",
					"key": encryptData(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
				    try{
				
					dataComprator = JSON.parse(decryptData(response.data.response,crypt.decrypt(response.key)));
					questions_originalComprator = JSON.parse(decryptData(response.data.question,crypt.decrypt(response.key)));
					benchmarkComprator = JSON.parse(decryptData(response.data.benchmark,crypt.decrypt(response.key)));
					min_limitComprator = JSON.parse(decryptData(response.data.min_limit,crypt.decrypt(response.key)));
					try{
					managerComprator = JSON.parse(decryptData(response.data.manager,crypt.decrypt(response.key)));
					//////console.log(manager);
				
					}
					catch(err)
					{
						////console.log(err);
					}
					}catch(err){
						loadingComprator(false);
						snackbarCompator("Unable to Load the Dashboard");
						$('[href="#scorecard"]').tab('show');
						loaded_dashboardComprator = false;
					}
					
					filter_initComprator(dataComprator).then(() => {
						///init_benchmark();
						init_heatmapComprator();
						filter_applyComprator();
						loadingComprator(false);
					});
				}).fail(err =>{
					snackbarCompator("loadingComprator Failed");
				
					console.dir(err);
					loadingComprator(false);
				});	


				// for mapping Response 
				
				// $.post("/account/survey.php",
				// {
					// "survey_id": survey_id,
					// "method": "businessImpact",
					// "key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA")
				// },
				// function(data,status){
					
					// managerInformation = JSON.parse(data);
					
					// console.log("Business Impact Data array ",managerInformation);
					
					
					 
				// });
					
	
			/*}).fail(err =>{
					
				snackbarCompator("loadingComprator Failed");
				loadingComprator(false);
			});;
		}).fail(err =>{
			snackbarCompator("loadingComprator Failed");
			loadingComprator(false);
		});;*/

}



function survey_editComparator(survey_idCompatot) {
	
	 dataComprator;
	 benchmarkComprator;
	 filtered_dataComprator;
	 questions_originalComprator;
	 questionsComprator;
	 min_limitComprator;
	 managerComprator;
	 filtersComprator = new Array();
	 filters_activeComprator;
	 ENGAGEMENT_QUESTION_COUNTComp=0;
	 MANAGER_QUESTION_COUNTComp=0;
	 LEADER_QUESTION_COUNTComp=0;
	 WFH_QUESTION_COUNTComp=0;
	 WFO_QUESTION_COUNTComp=0;
	 HR_QUESTION_COUNTComp=0;
	 WB_QUESTION_COUNTComp=0;
	 OTHER_QUESTION_COUNTComp=0;
	 INNVO_QUESTION_COUNTComp=0;
	 JOTA_QUESTION_COUNTComp=0;
	 JOTB_QUESTION_COUNTComp=0;
	 JOTC_QUESTION_COUNTComp=0;
	 JOTD_QUESTION_COUNTComp=0;
	 PSN_QUESTION_COUNTComp=0;
	 OPEN_QUESTION_COUNTComp=0;
	 ORG_QUESTION_COUNTComp=0;
	 INDEXComp = {};
	 filterDataJoinComprator;
	 compare_surveyComprator = {};
	loaded_dashboardComprator = false;
	loaded_mappingComprator = false;
	loaded_statusComprator = false;
	loaded_scorecardComprator = false;
	loaded_action_planComprator = false;
	$.get("survey.php?method=edit&survey_id="+survey_idCompatot, function(data) {
		document.getElementById("survey_manageComprator").innerHTML=data;
		opened_survey_idComprator = survey_idCompatot;
		
		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if(target=="#new_comparator"&& !loaded_dashboardComprator){
				dashboard_initComparator(opened_survey_idComprator);
				loaded_dashboardComprator = true;
			}
		});
		$('[data-toggle="popover"]').popover();
		$('[data-toggle="tooltip"]').tooltip();
	});
}


function init_heatmapComprator(){

	var attribute_html=document.getElementById("heatmap_parameter").value;
	var ENGAGE=false;
	var LEADER=false;
	var MANAGER=false;
	var WFH=false;
	var WFO=false;
	var HR=false;
	var WB=false;
	var CUSTOM=false;
	var INNVOTION = false;
	var JOTA = false;
	var JOTB = false;
	var JOTC = false;
	var JOTD = false;
	var PSN = false;
	var ORG = false;
	for(var i in questions_originalComprator){
		if(questions_originalComprator[i]["code"].startsWith("ENGAGE")){
			ENGAGE=true;
		}else if(questions_originalComprator[i]["code"].startsWith("LEADER")){
			LEADER=true;
		}else if(questions_originalComprator[i]["code"].startsWith("MANAGER")){
			MANAGER=true;
		}else if(questions_originalComprator[i]["code"].startsWith("WFH")){
			WFH=true;
		}else if(questions_originalComprator[i]["code"].startsWith("WFO")){
			WFO=true;
		}else if(questions_originalComprator[i]["code"].startsWith("HR")){
			HR=true;
		}else if(questions_originalComprator[i]["code"].startsWith("WB")){
			WB=true;
		}else if(questions_originalComprator[i]["code"].startsWith("CUSTOM")){
			CUSTOM=true;
			//////console.log(questions_original[i]["code"]);
		}else if(questions_originalComprator[i]["code"].startsWith("INNV")){
			INNVOTION=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("JOTA")){
			JOTA=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("JOTB")){
			JOTB=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("JOTC")){
			JOTC=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("JOTD")){
			JOTD=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("PSN")){
			PSN=true;
		}
		else if(questions_originalComprator[i]["code"].startsWith("ORG")){
			ORG=true;
		}
	}
	//attribute_html=attribute_html+`<option value="ALL" >All</option>`;
	if(ENGAGE){
		attribute_html=attribute_html+`<option value="ENGAGE" >Engagement</option>`;
	}
	if(LEADER){
		attribute_html=attribute_html+`<option value="LEADER" >Leader</option>`;
	}
	if(MANAGER){
		attribute_html=attribute_html+`<option value="MANAGER" >Manager</option>`;
	}
	if(WFH){
		attribute_html=attribute_html+`<option value="WFH" >Work From Home</option>`;
	}
	if(WFO){
		attribute_html=attribute_html+`<option value="WFO" >Work from Office</option>`;
	}
	if(HR){
		attribute_html=attribute_html+`<option value="HR" >Human Resource</option>`;
	}
	if(WB){
		attribute_html=attribute_html+`<option value="WB" >Well Being</option>`;
	}
	if(CUSTOM){
		attribute_html=attribute_html+`<option value="CUSTOM" >Custom</option>`;
	}
	if(INNVOTION){
		attribute_html=attribute_html+`<option value="INNV" >Innovation</option>`;
	}
	if(JOTA){
		attribute_html=attribute_html+`<option value="JOTA" >Employee Productivity and Motivation</option>`;
	}
	if(JOTB){
		attribute_html=attribute_html+`<option value="JOTB" >Leadership Trust & Direction</option>`;
	}
	if(JOTC){
		attribute_html=attribute_html+`<option value="JOTC" >Employee Retention</option>`;
	}
	if(JOTD){
		attribute_html=attribute_html+`<option value="JOTD" >Work, Process & Technology</option>`;
	}
	if(PSN){
		attribute_html=attribute_html+`<option value="PSN" >Psychological Safety Net</option>`;
	}
	if(ORG){
		attribute_html=attribute_html+`<option value="ORG" >Organization</option>`;
	}
	//document.getElementById("heatmap_attribute").innerHTML = attribute_html;
	document.getElementById("comparator_attributeComprator").innerHTML = attribute_html;
	
	var parameter_html="";//`<option value="NONE" >None</option>`;
	for(var i in filtersComprator){
		parameter_html=parameter_html+`<option value="`+filtersComprator[i]["name"]+`" >`+filtersComprator[i]["title"]+`</option>`;
	}
	//document.getElementById("heatmap_parameter").innerHTML = parameter_html;
	document.getElementById("comparator_parameterComprator").innerHTML = parameter_html;
	//heatmap_change();
}


function comparator_setupComprator(){
	var compare_surveyComprator_id = document.getElementById('comparator_surveyCompretor').value;
	
	loadingComprator(true);
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
				$.post("/account/survey.php",{
					"survey_id": compare_surveyComprator_id,
					"method": "dashboard",
					"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
					loadingComprator(false);
				    try{
					compare_surveyComprator.data = JSON.parse(decryptData(response.data.response,crypt.decrypt(response.key)));
                             
					compare_surveyComprator.questions = JSON.parse(decryptData(response.data.question,crypt.decrypt(response.key)));
                             //////console.log(compare_surveyComprator.questions);
					compare_surveyComprator.limit = JSON.parse(decryptData(response.data.min_limit,crypt.decrypt(response.key)));
                             //////console.log(compare_surveyComprator.limit);
							 
					let finalData = dataComprator.concat(compare_surveyComprator.data);
					
					filter_initComprator(finalData).then(() => {
						///init_benchmark();
						init_heatmapComprator();
						filter_applyComprator();
						loadingComprator(false);
					});
					
				    //filter_initComprator(finalData);
					
					comparator_changeComparator();
					}catch(err){
						////console.log(err);
						//snackbarCompator("Unable to Load the the Comparator");
					}
					}).fail(err =>{
					snackbarCompator("loadingComprator Failed");
					loadingComprator(false);
				});		
}


function comparator_changeComparator(){
	var attribute = document.getElementById("comparator_attributeComprator").value;
	var parameter = document.getElementById("comparator_parameterComprator").value;

	var value = new Array();
	var processed = new Array();
	for(i in filtersComprator){
		if(filtersComprator[i]["name"]===parameter){
			jQuery.extend(true,value,filtersComprator[i].value);
			//value=filtersComprator[i].value;
		}
	}
	
	value.push('Total');
	var survey_original = survey_process_comparatorComp(filtered_dataComprator,questions_originalComprator,attribute,parameter);
	compare_surveyComprator.filtered_data = [];
	
	// comparator filter
	//console.log("")
	for(var i in compare_surveyComprator.data){
		var valid = true;
		// Need for chnage start here 
		for(var j in filters_activeComprator){
			if(filters_activeComprator[j].value.length < filtersComprator[j].value.length){
				// console.log("filtersComprator  ",filtersComprator[j]);
				// ////console.log(filters_activeComprator[j]);
				if(!filters_activeComprator[j].value.includes(compare_surveyComprator.data[i][filters_activeComprator[j]["name"]])){
					valid=false; 
					break;
				}
			}
		}
		// end here 
		if(valid){
			compare_surveyComprator.filtered_data.push(JSON.parse(JSON.stringify(compare_surveyComprator.data[i])));
		}
	}
		
	/// end here 
	
	var survey_comparator = survey_process_comparatorComp(compare_surveyComprator.filtered_data,compare_surveyComprator.questions,attribute,parameter);

	var survey_original_name = document.getElementById('survey_name').value;
	var sel = document.getElementById("comparator_surveyCompretor");
	
	var survey_comparator_name= sel.options[sel.selectedIndex].text
	//Setup UI
	var max=0;
	var min=100;
	var comparator_table=`<table class="table"><thead><tr>`;
	comparator_table=comparator_table+`<td>Parameter</td><td>Survey Name</td><td>Responses</td>`;
	//////console.log(survey_original);
	if(ENGAGEMENT_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="ENGAGE")){
		comparator_table=comparator_table+`<td>Engagement</td><td>Engagement Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("ENGAGE")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(LEADER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="LEADER")){
		comparator_table=comparator_table+`<td>Leader Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("LEADER")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(MANAGER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="MANAGER")){
		comparator_table=comparator_table+`<td>Manager Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("MANAGER")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WFH_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WFH")){
		comparator_table=comparator_table+`<td>Work from Home</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WFH")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WFO_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WFO")){
		comparator_table=comparator_table+`<td>Work From Office Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WFO")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(HR_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="HR")){
		comparator_table=comparator_table+`<td>Human Resource Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("HR")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(WB_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WB")){
		comparator_table=comparator_table+`<td>Well Being Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("WB")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	if(OTHER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="CUSTOM")){
		comparator_table=comparator_table+`<td>Additional</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("CUSTOM")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(INNVO_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="INNV")){
		comparator_table=comparator_table+`<td>Innovation Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("INNV")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTA_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTA")){
		comparator_table=comparator_table+`<td>Employee Productivity and Motivation Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTA")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTB_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTB")){
		comparator_table=comparator_table+`<td>Leadership Trust & Direction Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTB")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTC_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTC")){
		comparator_table=comparator_table+`<td>Employee Retention Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTC")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(JOTD_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTD")){
		comparator_table=comparator_table+`<td>Work, Process & Technology Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("JOTD")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if(PSN_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="PSN")){
		comparator_table=comparator_table+`<td>psychological Safety Net Index</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("PSN")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	
	if( ORG_QUESTION_COUNTComp >0&&(attribute==="ALL"||attribute==="ORG")){
		comparator_table=comparator_table+`<td>Organization</td>`;
		for(var i in survey_original[value[0]]["questions"]){
			if( survey_original[value[0]]["questions"][i]["code"].startsWith("ORG")){
				comparator_table=comparator_table+`<td style="max-width:120px;" data-toggle="tooltip" title="`+survey_original[value[0]]["questions"][i]["question"]+`" >`+survey_original[value[0]]["questions"][i]["driver"]+`</td>`;
			}
		}
	}
	

	var min =0;
	var max=100;
	for(var i in survey_original){
		var showNA = false;
		var showNACompare = false;
		if(survey_comparator[i]["COUNT"]<min_limitComprator.min_filter){
			showNACompare=true;
		}
		if(survey_original[i]["COUNT"]<min_limitComprator.min_filter){
			showNA=true;
		}else{
			comparator_table=comparator_table+`<tr `;
			if(i==='Total'){
			comparator_table=comparator_table+' style="font-weight:900;font-size:24px;" ';}
			comparator_table=comparator_table+`><td class="p-0"><p class="pt-3">`+i+`</p></td><td class="p-0"><p class="p-2 mb-0" style="overflow: hidden; white-space: nowrap;">`+survey_original_name+`</p><p class="p-2 mb-0"  style="overflow: hidden; white-space: nowrap;">`+survey_comparator_name+`</p></td><td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["COUNT"]+`</p><p class="p-2 mb-0" >`+survey_comparator[i]["COUNT"]+`</p></td>`;
			
			if(ENGAGEMENT_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="ENGAGE")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td><td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+Math.round(survey_original[i]["ENGAGED_COUNT"]*100/survey_original[i]["COUNT"])+`%</p><p class="p-2 mb-0" >`+(showNACompare?"NA":Math.round(survey_comparator[i]["ENGAGED_COUNT"]*100/survey_comparator[i]["COUNT"]))+`%</p></td>`;
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["ENGAGE_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["ENGAGE_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("ENGAGE")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			 
			if(LEADER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="LEADER")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["LEADER_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["LEADER_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("LEADER")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(MANAGER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="MANAGER")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["MANAGER_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["MANAGER_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("MANAGER")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WFH_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WFH")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WFH_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WFH_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WFH")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WFO_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WFO")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WFO_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WFO_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WFO")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(HR_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="HR")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["HR_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["HR_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("HR")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(WB_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="WB")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["WB_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["WB_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("WB")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(OTHER_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="CUSTOM")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+'-'+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("CUSTOM")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			if(INNVO_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="INNV")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["INNOVATION_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["INNOVATION_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("INNV")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(JOTA_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTA")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["JOTA_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["JOTA_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTA")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if(JOTB_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTB")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["JOTB_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["JOTB_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTB")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			
			if(JOTC_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTC")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["JOTC_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["JOTC_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTC")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			
			if(JOTD_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="JOTD")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["JOTD_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["JOTD_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("JOTD")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			
			if(PSN_QUESTION_COUNTComp>0&&(attribute==="ALL"||attribute==="PSN")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["PSN_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["PSN_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("PSN")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
			
			if( ORG_QUESTION_COUNTComp >0&&(attribute==="ALL"||attribute==="ORG")){
				if(showNA){
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
				}else{
					comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >`+survey_original[i]["ORG_INDEX"].toFixed(2)+`</p><p class="p-2 mb-0" >`+(showNACompare?"NA":survey_comparator[i]["ORG_INDEX"].toFixed(2))+`</p></td>`;
				}
				for(var j in survey_original[i]["questions"]){
					if( survey_original[i]["questions"][j]["code"].startsWith("ORG")){
						if(showNA){
							comparator_table=comparator_table+`<td class="p-0"><p class="p-2 mb-0" >NA</p></td>`;
						}else{
							if(survey_comparator[i]["questions"][j]!=undefined)
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],(showNACompare?"NA":survey_comparator[i]["questions"][j]["result"]));
							else
								comparator_table=comparator_table+comparator_cellComprator(survey_original[i]["questions"][j]["result"],"NA");
						}
					}
				}
			}
		}
		comparator_table=comparator_table+`</tr>`
	} 
	comparator_table=comparator_table+`</tr></thead><tbody>`;
	comparator_table=comparator_table+`</tbody></table>`;
	document.getElementById("comparator_tableComprator").innerHTML=comparator_table;
	$('[data-toggle="tooltip"]').tooltip();	
	$('.double-scroll').doubleScroll({  resetOnWindowResize: true  }); 
}




function survey_process_comparatorComp(survey_response,question_array_input,attribute/*driver*/,parameter){
	//////console.log(question_array);

	question_array = {};
	for(i in question_array_input){
		question_array[question_array_input[i]["code"]] = question_array_input[i];
	}
	
	var value = new Array();
	var processed = new Array();
	for(i in filtersComprator){
		if(filtersComprator[i]["name"]===parameter){
			value=filtersComprator[i].value;
		}
	}
	value.push('Total');
	for(var i in value){
		processed[value[i]]=new Array();
		processed[value[i]]["questions"]=new Array();
		jQuery.extend(true,processed[value[i]]["questions"],question_array);
		if(ENGAGEMENT_QUESTION_COUNTComp>0){
			processed[value[i]]["ENGAGE_INDEX"]=0;
			processed[value[i]]["ENGAGED_COUNT"]=0;
		}
		if(MANAGER_QUESTION_COUNTComp>0)
			processed[value[i]]["MANAGER_INDEX"]=0;
		if(LEADER_QUESTION_COUNTComp>0)
			processed[value[i]]["LEADER_INDEX"]=0;
		if(WFH_QUESTION_COUNTComp>0)
			processed[value[i]]["WFH_INDEX"]=0;
		if(WFO_QUESTION_COUNTComp>0)
			processed[value[i]]["WFO_INDEX"]=0;
		if(HR_QUESTION_COUNTComp>0)
			processed[value[i]]["HR_INDEX"]=0;
		if(WB_QUESTION_COUNTComp>0)
			processed[value[i]]["WB_INDEX"]=0;
		if(OTHER_QUESTION_COUNTComp>0)
			processed[value[i]]["OTHER_INDEX"]=0;
		if(INNVO_QUESTION_COUNTComp>0)
			processed[value[i]]["INNOVATION_INDEX"]=0;
		if(JOTA_QUESTION_COUNTComp>0)
			processed[value[i]]["JOTA_INDEX"]=0;
		if(JOTB_QUESTION_COUNTComp>0)
			processed[value[i]]["JOTB_INDEX"]=0;
		if(JOTC_QUESTION_COUNTComp>0)
			processed[value[i]]["JOTC_INDEX"]=0;
		if(JOTD_QUESTION_COUNTComp>0)
			processed[value[i]]["JOTD_INDEX"]=0;
		if(PSN_QUESTION_COUNTComp>0)
			processed[value[i]]["PSN_INDEX"]=0;
		if(ORG_QUESTION_COUNTComp >0)
			processed[value[i]]["ORG_INDEX"]=0;
		processed[value[i]]["COUNT"]=0;
	}
	for(var i in survey_response){
		try{
		var USER_ENGAGED = 0;
		for(var j in processed[value[0]]["questions"]){
			var code = processed[value[0]]["questions"][j]["code"];
			if(code.startsWith("ENGAGE")||code.startsWith("LEADER")||code.startsWith("MANAGER")||code.startsWith("WFH")||code.startsWith("WFO")||code.startsWith("HR")||code.startsWith("WB")||code.startsWith("CUSTOM") ||code.startsWith("INNV") ||code.startsWith("JOTA") ||code.startsWith("JOTB") ||code.startsWith("JOTC") ||code.startsWith("JOTD") || code.startsWith("PSN") || code.startsWith("ORG") ){
					if(survey_response[i][code]>=4){
						processed[survey_response[i][parameter]]["questions"][j]["result"]["positive"]++;
						processed['Total']["questions"][j]["result"]["positive"]++;
					}else if(survey_response[i][code]<=2){
						processed[survey_response[i][parameter]]["questions"][j]["result"]["negative"]++;
						processed['Total']["questions"][j]["result"]["negative"]++;
					}else{
						processed[survey_response[i][parameter]]["questions"][j]["result"]["neutral"]++;
						processed['Total']["questions"][j]["result"]["neutral"]++;
					}
			}
			if(code.startsWith("ENGAGE")){
				processed[survey_response[i][parameter]]["ENGAGE_INDEX"]=processed[survey_response[i][parameter]]["ENGAGE_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["ENGAGE_INDEX"]=processed['Total']["ENGAGE_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				USER_ENGAGED=USER_ENGAGED+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("LEADER")){
				processed[survey_response[i][parameter]]["LEADER_INDEX"]=processed[survey_response[i][parameter]]["LEADER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["LEADER_INDEX"]=processed['Total']["LEADER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("MANAGER")){
				processed[survey_response[i][parameter]]["MANAGER_INDEX"]=processed[survey_response[i][parameter]]["MANAGER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["MANAGER_INDEX"]=processed['Total']["MANAGER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WFH")){
				processed[survey_response[i][parameter]]["WFH_INDEX"]=processed[survey_response[i][parameter]]["WFH_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WFH_INDEX"]=processed['Total']["WFH_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WFO")){
				processed[survey_response[i][parameter]]["WFO_INDEX"]=processed[survey_response[i][parameter]]["WFO_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WFO_INDEX"]=processed['Total']["WFO_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("HR")){
				processed[survey_response[i][parameter]]["HR_INDEX"]=processed[survey_response[i][parameter]]["HR_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["HR_INDEX"]=processed['Total']["HR_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("WB")){
				processed[survey_response[i][parameter]]["WB_INDEX"]=processed[survey_response[i][parameter]]["WB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["WB_INDEX"]=processed['Total']["WB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("CUSTOM")){
				processed[survey_response[i][parameter]]["OTHER_INDEX"]=processed[survey_response[i][parameter]]["OTHER_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["CUSTOM"]=processed['Total']["CUSTOM"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("INNV")){
				processed[survey_response[i][parameter]]["INNOVATION_INDEX"]=processed[survey_response[i][parameter]]["INNOVATION_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["INNOVATION_INDEX"]=processed['Total']["INNOVATION_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTA")){
				processed[survey_response[i][parameter]]["JOTA_INDEX"]=processed[survey_response[i][parameter]]["JOTA_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTA_INDEX"]=processed['Total']["JOTA_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTB")){
				processed[survey_response[i][parameter]]["JOTB_INDEX"]=processed[survey_response[i][parameter]]["JOTB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTB_INDEX"]=processed['Total']["JOTB_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("JOTC")){
				processed[survey_response[i][parameter]]["JOTC_INDEX"]=processed[survey_response[i][parameter]]["JOTC_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTC_INDEX"]=processed['Total']["JOTC_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("JOTD")){
				processed[survey_response[i][parameter]]["JOTD_INDEX"]=processed[survey_response[i][parameter]]["JOTD_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["JOTD_INDEX"]=processed['Total']["JOTD_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}else if(code.startsWith("PSN")){
				processed[survey_response[i][parameter]]["PSN_INDEX"]=processed[survey_response[i][parameter]]["PSN_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["PSN_INDEX"]=processed['Total']["PSN_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
			else if(code.startsWith("ORG")){
				processed[survey_response[i][parameter]]["ORG_INDEX"]=processed[survey_response[i][parameter]]["ORG_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
				processed['Total']["ORG_INDEX"]=processed['Total']["ORG_INDEX"]+parseInt(survey_response[i][question_array[j]["code"]]);
			}
		}
		processed[survey_response[i][parameter]]["COUNT"]++;
		processed['Total']["COUNT"]++;
		if((USER_ENGAGED/ENGAGEMENT_QUESTION_COUNTComp)>=3.75){
			processed[survey_response[i][parameter]]["ENGAGED_COUNT"]++;
			processed['Total']["ENGAGED_COUNT"]++;
		}
		}catch(err){}
	}
	for(i in processed){
		if(ENGAGEMENT_QUESTION_COUNTComp>0)
			processed[i]["ENGAGE_INDEX"]=(processed[i]["ENGAGE_INDEX"]/(ENGAGEMENT_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(MANAGER_QUESTION_COUNTComp>0)
			processed[i]["MANAGER_INDEX"]=(processed[i]["MANAGER_INDEX"]/(MANAGER_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(LEADER_QUESTION_COUNTComp>0)
			processed[i]["LEADER_INDEX"]=(processed[i]["LEADER_INDEX"]/(LEADER_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(WFH_QUESTION_COUNTComp>0)
			processed[i]["WFH_INDEX"]=(processed[i]["WFH_INDEX"]/(WFH_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(WFO_QUESTION_COUNTComp>0)
			processed[i]["WFO_INDEX"]=(processed[i]["WFO_INDEX"]/(WFO_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(HR_QUESTION_COUNTComp>0)
			processed[i]["HR_INDEX"]=(processed[i]["HR_INDEX"]/(HR_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(WB_QUESTION_COUNTComp>0)
			processed[i]["WB_INDEX"]=(processed[i]["WB_INDEX"]/(WB_QUESTION_COUNTComp*processed[i]["COUNT"]));
		if(OTHER_QUESTION_COUNTComp>0){
			processed[i]["OTHER_INDEX"]=(processed[i]["OTHER_INDEX"]/(WB_QUESTION_COUNTComp*processed[i]["COUNT"]));
			processed[i]["OTHER_INDEX"] = '-';
		}
		if(INNVO_QUESTION_COUNTComp>0){
			processed[i]["INNOVATION_INDEX"]=(processed[i]["INNOVATION_INDEX"]/(INNVO_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}
		if(JOTA_QUESTION_COUNTComp>0){
			processed[i]["JOTA_INDEX"]=(processed[i]["JOTA_INDEX"]/(JOTA_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}
		if(JOTB_QUESTION_COUNTComp>0){
			processed[i]["JOTB_INDEX"]=(processed[i]["JOTB_INDEX"]/(JOTB_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}
		if(JOTC_QUESTION_COUNTComp>0){
			processed[i]["JOTC_INDEX"]=(processed[i]["JOTC_INDEX"]/(JOTC_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}
		if(JOTD_QUESTION_COUNTComp>0){
			processed[i]["JOTD_INDEX"]=(processed[i]["JOTD_INDEX"]/(JOTD_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}if(PSN_QUESTION_COUNTComp>0){
			processed[i]["PSN_INDEX"]=(processed[i]["PSN_INDEX"]/(PSN_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}if(ORG_QUESTION_COUNTComp>0){
			processed[i]["ORG_INDEX"]=(processed[i]["ORG_INDEX"]/(ORG_QUESTION_COUNTComp*processed[i]["COUNT"]));
		}
	}
	// ////console.log(processed);
	return processed;
}



function comparator_cellComprator(result,result2){
	var number = Math.round(result["positive"]*100/(result["positive"]+result["negative"]+result["neutral"]));
	var number_compare = 0;
	var number_diff = 0;
	if(result!="NA"){
		number_compare = Math.round(result2["positive"]*100/(result2["positive"]+result2["negative"]+result2["neutral"]));
		number_diff = number_compare-number;
		number_compare = number_compare+"%";
	}
	else
		number_compare = "NA";
	//return `<td style="color:#000;" >`+number+`%<br>`+number_compare+`%</td>`;
	return `<td class="p-0"><p class="p-2 mb-0 text-center" style="color:#ffffff; background-color:`+(number_diff>3?"#ba000d":(number_diff<-3?"#087f23":"#ffbf00"))+`; white-space: nowrap; text-overflow: ellipsis; ">`+number+`%</p><p class="p-2 mb-0  text-center" >`+number_compare+`</p>`;
}





/*
	Image Downloading Function
*/

function downloadAsImageComprator(id,filename){                           
                                      
         html2canvas($('#'+id), 
         {
	      background: "#fff",
          onrendered: function (canvas) {
          var a = document.createElement('a');
          a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
          a.download = filename+'.jpg';
          a.click();
                                      
                                      
     	}
                                         
      });                           
}

// Excel Download of Heatmap and comparator

var downloadasExcelComprator = (function() {
	
	var uri = 'data:application/vnd.ms-excel;base64,'
	  , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	  , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	  , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	return function(table, name) {
	  if (!table.nodeType) 
	     table = document.getElementById(table)
	  var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}

	  //window.location.href  = uri + base64(format(template, ctx))
	 var link = document.createElement("a");
     link.download = name+".xls";
     link.download = name+".xls";
     link.href = uri + base64(format(template, ctx));
     link.click();

	}
  })();
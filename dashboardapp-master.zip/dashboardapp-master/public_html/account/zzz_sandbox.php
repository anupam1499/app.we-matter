<?php
include("../../includes/config.php");
confirm_logged_in();
$title="Dashboard";
include(app_header());
include('../../includes/layout/dashboard.php');?>
<?include(app_script());?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.actual/1.0.19/jquery.actual.min.js"></script>
<script src="https://d3js.org/d3.v4.js"></script>
<script src="https://cdn.jsdelivr.net/gh/holtzy/D3-graph-gallery@master/LIB/d3.layout.cloud.js"></script>
<script src="dashboard.js<?php echo "?".time();?>"></script>
<script>
$(function() {
    dashboard_init(3);
	$('[data-toggle="popover"]').popover();
    $('[data-toggle="tooltip"]').tooltip();
});
$('body').on('click', function (e) {
    if ($(e.target).data('toggle') !== 'popover'
        && $(e.target).parents('.popover.in').length === 0) { 
        $('[data-toggle="popover"]').popover('hide');
    }
});
</script>
<?php include(app_footer());?>
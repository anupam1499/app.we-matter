<?php
include("../../includes/config.php");
//$data = json_decode(,TRUE);
/*$file_name = "../../tmp/files/".function generate_salt(16) ;
file_put_contents($file_name.".json",$_REQUEST["data"]);
shell_exec("python3 -m report.py ".$file_name.".json ".$file_name.".pptx");
header("ContentType:application/presenation")
readfile($file_name".pptx");
unlink($file_name".json");
unlink($file_name".pptx");*/
//echo "HELLLOOO";

//echo $survey['survey_id'];
//trigger exception in a "try" block
confirm_logged_in();

try {

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $filters = strval($_REQUEST['filters']);
        $survey_id=$_REQUEST['survey_id'];
        $mode=$_REQUEST['mode'];
      	$company_name= strval($_SESSION['role_selected']['account_name']); 
		$logo_url=$_SESSION["role_selected"]["account"]["logo_url"];
        $filename=strval(mt_rand(1,10000000));
        $myfile = fopen('Report_Generation/tempdata/'.$filename.".json", "w") or die("Unable to open file!");
        $txt = $filters;
        fwrite($myfile, $txt);
        fclose($myfile);

      
        $command = escapeshellcmd("/usr/bin/python3 /home/app/public_html/account/Report_Generation/my_script.py $survey_id $filename $mode '$company_name' $logo_url");
		//echo "/usr/bin/python3 /home/app/public_html/account/Report_Generation/my_script.py $survey_id $filename $mode '$company_name' $logo_url";
        shell_exec($command);
		$fname=$filename;
        $filename=$filename.".pptx";

        if(file_exists('Report_Generation/tempdata/'.$filename)){
            //$finfo = finfo_open(FILEINFO_MIME_TYPE);
            //header('Content-Type: ' . finfo_file($finfo, $filename));
            //finfo_close($finfo);
			header('Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation');
            header('Content-Disposition: attachment; filename='.basename($filename));
            ob_clean();
            flush();
            readfile('Report_Generation/tempdata/'.$filename);
            //unlink('Report_Generation/tempdata/'.$fname.".json");
            //unlink('Report_Generation/tempdata/'.$fname.".pptx");
            //unlink('Report_Generation/tempdata/'.$fname.".txt");
            exit;

        }
        else{
            //unlink('Report_Generation/tempdata/'.$fname.".json");
			//unlink('Report_Generation/tempdata/'.$fname.".txt");
        }

    }
} 
catch(Exception $e) {
      $myfile = fopen("php_error.txt", "w") or die("Unable to open file!");
        $txt = $e->getMessage();
        fwrite($myfile, $txt);
        fclose($myfile);
  
}

?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../../includes/config.php");
confirm_logged_in();
$title="Url";
$method="manage";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];


if($_SESSION["role_selected"]["role_id"]=="1"||$method=="display"){
	
}else{
	redirect_to("/user/home.php");
}

$output="html";
if(isset($_REQUEST["output"]))
	$output=$_REQUEST["output"];

if($method==="display"){
	$url = ToArray(execute_query("SELECT * FROM `url` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND ((`type` = 1 and `id` = ".mysql_prep($_SESSION["user_id"])." ) OR (`type`=3 AND (".$_SESSION["role_selected"]["role_id"]."=1 OR ".$_SESSION["role_selected"]["role_id"]."=2)) OR  `type` = 2 ) AND `url_id` = ".$_REQUEST["url_id"]." LIMIT 1"));
	if(isset($url["url_id"])&&$url["url_id"]===$_REQUEST["url_id"]){
		$title = $url["url_name"];
		include(app_header());
		echo $url["url"];
		include(app_script());
		include(app_footer());
	}else{
		redirect_to("/user/home.php");
	}
}else if($method==="view"){
	$page=0;
	if(isset($_REQUEST["page"]))
		$page=$_REQUEST["page"];

	$q="";
	if(isset($_REQUEST["q"]))
		$q=$_REQUEST["q"];

	$urls = url_list($q,$page);
	$url_count = url_count($q);
	if($output==="json"){
		$response["total"] = $url_count;
		$response["url"] = $urls;
		json_output($response);
	}else{
	?>
	<div class="card card-primary">
		<div class="card-heading">
            <button type="button" class="btn btn-secondary float-right ml-1" onclick="url_add()" ><i class="fa fa-plus" ></i></button>
			<?php
			if((($page+1)*30)<$url_count)
               echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"url_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
               echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
			if($page!=0)
               echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"url_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
			?>
		<form class="form-inline" action="" onsubmit="return false;">
            <div class="input-group">
                <input id="url_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>">
                <span class="input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="url_view(0)" ><i class="fa fa-search" ></i></button>
                </span>
            </div>
			</form>
		</div>
		<table class="table">
			<tr>
			<th>Url Name</th>
			<th>Access Type</th>
			<th>Manage</th>
			</tr>
				<?php
					foreach($urls as $url){
						echo "<tr><td>".$url["url_name"]."</td><td>".($url["type"]==="2"?"All":($url["type"]==="3"?"Admins and Leaders":($url["type"]==="1"?user_get($url["id"])["email"]:"Unknown")))."</td><td> ";
						echo "<button class=\"btn btn-secondary ml-1\" title=\"Edit\" type=\"button\" onclick=\"url_edit(".$url["url_id"].")\" ><i class=\"fa fa-pen\" ></i></button>";
						echo "<button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
							<i class=\"fas fa-trash\" ></i>
						  </button>
						  <div class=\"dropdown-menu\">
							<button class=\"dropdown-item\"  onclick=\"url_delete(".$url["url_id"].")\" >Confirm Delete?</button>
						  </div>";
						echo "</td></tr>";
					}
				?>
		</table>
	</div>
	<?
	exit(0);
	}
}
else if($method==="add"){
	if(isset($_REQUEST["submit"],$_REQUEST["url_name"],$_REQUEST["type"],$_REQUEST["url"])){
		$ids = array();
		if($_REQUEST["type"]==="1"){
			$emails = explode("\n",$_REQUEST["email_list"]);
			$email_str = "'zzz'";
			foreach($emails as $email){
				$email_str = $email_str.",'".mysql_prep($email)."'";
			}
			$ids_temp = ToArrays(execute_query("SELECT DISTINCT `U`.`user_id` FROM `user` U
				LEFT JOIN `account_linking` AL ON `U`.`user_id` = `AL`.`user_id`
				WHERE `AL`.`account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."' AND `email` in (".$email_str.")"));
			foreach($ids_temp as $id){
				$ids[] = $id["user_id"];
			}
		}
		$url = url_add($_REQUEST["url_name"],$_REQUEST["type"],$ids,$_REQUEST["url"]);
		if($output==="json"){
			json_output($url);
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("submit,url_name,url are required variable");
		}else{
			?><form id="url_form" action="url.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="add">
			<div class="form-group">
				<label>URL Name:</label>
				<input class="form-control" name="url_name" type="text" placeholder="URL Name" value="" required>
			</div>
			<div class="form-group">
				<label>Type:</label>
				<select name="type" required class="form-control" onchange="url_type_change(this.value);">
					<option value="2">All</option>
					<option value="3">Admins and Leaders</option>
					<option value="1">User</option>
				</select>
				</div>
			<div id="email_list_group" class="form-group">
				<label>Email List: Enter 1 per line</label>
				<textarea class="form-control" name="email_list" placeholder="manager@email.com" required></textarea>
			</div>
			<div class="form-group">
				<label>URL:</label>
				<input class="form-control" name="url" type="text" placeholder="Paste your url Text here" required />
			</div>
			<input type="hidden" name="submit" value="Add" />
			<button class="btn btn-success" type="button" onclick="url_submit()">Add</button>
			<button class="btn btn-secondary" type="button" onclick="url_view(url_page)">Back</button>
			</form><?php
			exit(0);
		}
	}
}else if($method==="edit"){
	if(isset($_REQUEST["submit"],$_REQUEST["url_id"],$_REQUEST["url_name"],$_REQUEST["url"])){
		$url = url_edit($_REQUEST["url_id"],$_REQUEST["url_name"],$_REQUEST["url"]);
		if($output==="json"){
			json_output($url);
		}else{
			echo "Success";
		}
	}else{
		$url = url_get($_REQUEST["url_id"]);
		if($output==="json"){
			json_message("submit,url_id,url_name,url are required variable");
		}else{
			?><form  id="url_form" action="url.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="edit">
			<input class="form-control" name="url_id" type="hidden" value="<?echo $url["url_id"];?>">
			<div class="form-group">
				<label>URL Name:</label>
				<input class="form-control" name="url_name" type="text" placeholder="URL Name" value="<?echo $url["url_name"];?>" required>
			</div>
			<div class="form-group">
				<label>URL:</label>
				<input class="form-control" name="url" type="text" placeholder="Paste your url Text here" value="<?echo $url["url"];?>" required />
			</div>
			<input type="hidden" name="submit" value="Save" />
			<button class="btn btn-success" type="button" onclick="url_submit()">Save</button>
			<button class="btn btn-secondary" type="button" onclick="url_view(url_page)">Back</button>
			</form>
		<?php exit(0);
		}
	}
}else if($method==="delete"){
	if(isset($_REQUEST["url_id"])){
		url_delete($_REQUEST["url_id"]);
		if($output==="json"){
			json_message("The object is successfully deleted");
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("url_id is a required variable");
		}else{
			echo "Failed";
		}
	}
}else if($method==="manage"){
	if($output==="json"){
		json_output($urls);
	}else{
		include(app_header());?>
<section class="content">
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="url_manage">
	</div>
</div>
</section>
	<?php include(app_script()); ?>
<script>
var url_page = 0;
$(function() {
	url_view(url_page);
});
function url_view(page) {
	url_page = page;
	var url_search_text = "";
	try{url_search_text = document.getElementById("url_search_text").value;}catch(err){}
	$.get("url.php?method=view&q="+encodeURI(url_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("url_manage").innerHTML=data;
	});
}
function url_add() {
	$.get("url.php?method=add", function(data) {
		document.getElementById("url_manage").innerHTML=data;
		url_type_change(2)
	});
}
function url_edit(url_id) {
	$.get("url.php?method=edit&url_id="+url_id, function(data) {
		document.getElementById("url_manage").innerHTML=data;
	});
}
function url_delete(url_id,url_name) {
		$.get("url.php?method=delete&url_id="+url_id, function( data ) {
			url_view(url_page);
		});
}
function url_submit() {
			$.ajax({
			  url: 'url.php', 
			  type: 'POST',
			  data: new FormData($('#url_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				url_view(url_page);
				snackbar("Data Saved");
			}).fail(function(){
				snackbar("Saving Failed");
			});
}
function url_type_change(type){
	if(type==1){
		document.getElementById("email_list_group").style.display = "block";
	}else{
		document.getElementById("email_list_group").style.display = "none";
	}
}
</script>
<?php include(app_footer());
	}
}

function url_add($url_name,$type,$ids,$url){
	print_r($ids);
	if($type!="1"){
		return url_get(execute_insert_query("INSERT INTO `url`(`url_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`url`) VALUES ('".mysql_prep($url_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep(0)."','".mysql_prep($url)."');"));
	}else{
		foreach($ids as $id){
			echo "INSERT INTO `url`(`url_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`url`) VALUES ('".mysql_prep($url_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep($id)."','".mysql_prep($url)."');";
			$url_data[] =  url_get(execute_insert_query("INSERT INTO `url`(`url_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`url`) VALUES ('".mysql_prep($url_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep($id)."','".mysql_prep($url)."');"));
		}
		return $url_data;
	}
}
function url_edit($url_id,$url_name,$url){
	execute_query("UPDATE `url` SET `modified_at` = ".get_sql_india_time().",`url_name` = '".mysql_prep($url_name)."',`url`='".mysql_prep($url)."' WHERE `url_id` = ".mysql_prep($url_id)." AND `account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."'");
	return url_get($_REQUEST["url_id"]);
}
function url_delete($url_id){
	execute_query("DELETE FROM `url` WHERE `url_id` = ".mysql_prep($url_id));
	return true;
}
function url_get($url_id){
	return ToArray(execute_query("SELECT * FROM `url` WHERE `url_id` = ".mysql_prep($url_id)));
}
function url_list($q,$page){
	return ToArrays(execute_query("SELECT * FROM `url` WHERE `url_name` like '%".mysql_prep($q)."%' LIMIT 30 OFFSET ".($page*30)));
}
function url_count($q){
	return ToArray(execute_query("SELECT count(*) as url_count FROM `url` WHERE `url_name` like '%".mysql_prep($q)."%' "))["url_count"];
}
?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../../includes/config.php");
confirm_logged_in();
$title="Embed";
$method="manage";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];


if($_SESSION["role_selected"]["role_id"]=="1"||$method=="display"){
	
}else{
	redirect_to("/user/home.php");
}

$output="html";
if(isset($_REQUEST["output"]))
	$output=$_REQUEST["output"];

if($method==="display"){
	$embed = ToArray(execute_query("SELECT * FROM `embed` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND ((`type` = 1 and `id` = ".mysql_prep($_SESSION["user_id"])." ) OR (`type`=3 AND (".$_SESSION["role_selected"]["role_id"]."=1 OR ".$_SESSION["role_selected"]["role_id"]."=2)) OR  `type` = 2 ) AND `embed_id` = ".$_REQUEST["embed_id"]." LIMIT 1"));
	if(isset($embed["embed_id"])&&$embed["embed_id"]===$_REQUEST["embed_id"]){
		$title = $embed["embed_name"];
		include(app_header());
		echo $embed["embed"];
		include(app_script());
		include(app_footer());
	}else{
		redirect_to("/user/home.php");
	}
}else if($method==="view"){
	$page=0;
	if(isset($_REQUEST["page"]))
		$page=$_REQUEST["page"];

	$q="";
	if(isset($_REQUEST["q"]))
		$q=$_REQUEST["q"];

	$embeds = embed_list($q,$page);
	$embed_count = embed_count($q);
	if($output==="json"){
		$response["total"] = $embed_count;
		$response["embed"] = $embeds;
		json_output($response);
	}else{
	?>
	<div class="card card-primary">
		<div class="card-heading">
            <button type="button" class="btn btn-secondary float-right ml-1" onclick="embed_add()" ><i class="fa fa-plus" ></i></button>
			<?php
			if((($page+1)*30)<$embed_count)
               echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"embed_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
               echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
			if($page!=0)
               echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"embed_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
			?>
		<form class="form-inline" action="" onsubmit="return false;">
            <div class="input-group">
                <input id="embed_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>">
                <span class="input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="embed_view(0)" ><i class="fa fa-search" ></i></button>
                </span>
            </div>
			</form>
		</div>
		<table class="table">
			<tr>
			<th>Embed Name</th>
			<th>Access Type</th>
			<th>Manage</th>
			</tr>
				<?php
					foreach($embeds as $embed){
						echo "<tr><td>".$embed["embed_name"]."</td><td>".($embed["type"]==="2"?"All":($embed["type"]==="3"?"Admins and Leaders":($embed["type"]==="1"?user_get($embed["id"])["email"]:"Unknown")))."</td><td> ";
						echo "<button class=\"btn btn-secondary ml-1\" title=\"Edit\" type=\"button\" onclick=\"embed_edit(".$embed["embed_id"].")\" ><i class=\"fa fa-pen\" ></i></button>";
						echo "<button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
							<i class=\"fas fa-trash\" ></i>
						  </button>
						  <div class=\"dropdown-menu\">
							<button class=\"dropdown-item\"  onclick=\"embed_delete(".$embed["embed_id"].")\" >Confirm Delete?</button>
						  </div>";
						echo "</td></tr>";
					}
				?>
		</table>
	</div>
	<?
	exit(0);
	}
}
else if($method==="add"){
	if(isset($_REQUEST["submit"],$_REQUEST["embed_name"],$_REQUEST["type"],$_REQUEST["embed"])){
		$ids = array();
		if($_REQUEST["type"]==="1"){
			$emails = explode("\n",$_REQUEST["email_list"]);
			$email_str = "'zzz'";
			foreach($emails as $email){
				$email_str = $email_str.",'".mysql_prep($email)."'";
			}
			$ids_temp = ToArrays(execute_query("SELECT DISTINCT `U`.`user_id` FROM `user` U
				LEFT JOIN `account_linking` AL ON `U`.`user_id` = `AL`.`user_id`
				WHERE `AL`.`account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."' AND `email` in (".$email_str.")"));
			foreach($ids_temp as $id){
				$ids[] = $id["user_id"];
			}
		}
		$embed = embed_add($_REQUEST["embed_name"],$_REQUEST["type"],$ids,$_REQUEST["embed"]);
		if($output==="json"){
			json_output($embed);
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("submit,embed_name,embed are required variable");
		}else{
			?><form id="embed_form" action="embed.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="add">
			<div class="form-group">
				<label>Embed Name:</label>
				<input class="form-control" name="embed_name" type="text" placeholder="Embed Name" value="" required>
			</div>
			<div class="form-group">
				<label>Type:</label>
				<select name="type" required class="form-control" onchange="embed_type_change(this.value);">
					<option value="2">All</option>
					<option value="3">Admins and Leaders</option>
					<option value="1">User</option>
				</select>
				</div>
			<div id="email_list_group" class="form-group">
				<label>Email List: Enter 1 per line</label>
				<textarea class="form-control" name="email_list" placeholder="manager@email.com" required></textarea>
			</div>
			<div class="form-group">
				<label>Embed:</label>
				<textarea style="height:240px;" class="form-control" name="embed" type="text" placeholder="Paste your embed Text here" required></textarea>
			</div>
			<input type="hidden" name="submit" value="Add" />
			<button class="btn btn-success" type="button" onclick="embed_submit()">Add</button>
			<button class="btn btn-secondary" type="button" onclick="embed_view(embed_page)">Back</button>
			</form><?php
			exit(0);
		}
	}
}else if($method==="edit"){
	if(isset($_REQUEST["submit"],$_REQUEST["embed_id"],$_REQUEST["embed_name"],$_REQUEST["embed"])){
		$embed = embed_edit($_REQUEST["embed_id"],$_REQUEST["embed_name"],$_REQUEST["embed"]);
		if($output==="json"){
			json_output($embed);
		}else{
			echo "Success";
		}
	}else{
		$embed = embed_get($_REQUEST["embed_id"]);
		if($output==="json"){
			json_message("submit,embed_id,embed_name,embed are required variable");
		}else{
			?><form  id="embed_form" action="embed.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="edit">
			<input class="form-control" name="embed_id" type="hidden" value="<?echo $embed["embed_id"];?>">
			<div class="form-group">
				<label>Embed Name:</label>
				<input class="form-control" name="embed_name" type="text" placeholder="Embed Name" value="<?echo $embed["embed_name"];?>" required>
			</div>
			<div class="form-group">
				<label>Embed:</label>
				<textarea style="height:240px;" class="form-control" name="embed" type="text" placeholder="Paste your embed Text here" required><?echo $embed["embed"];?></textarea>
			</div>
			<input type="hidden" name="submit" value="Save" />
			<button class="btn btn-success" type="button" onclick="embed_submit()">Save</button>
			<button class="btn btn-secondary" type="button" onclick="embed_view(embed_page)">Back</button>
			</form>
		<?php exit(0);
		}
	}
}else if($method==="delete"){
	if(isset($_REQUEST["embed_id"])){
		embed_delete($_REQUEST["embed_id"]);
		if($output==="json"){
			json_message("The object is successfully deleted");
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("embed_id is a required variable");
		}else{
			echo "Failed";
		}
	}
}else if($method==="manage"){
	if($output==="json"){
		json_output($embeds);
	}else{
		include(app_header());?>
<section class="content">
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="embed_manage">
	</div>
</div>
</section>
	<?php include(app_script()); ?>
<script>
var embed_page = 0;
$(function() {
	embed_view(embed_page);
});
function embed_view(page) {
	embed_page = page;
	var embed_search_text = "";
	try{embed_search_text = document.getElementById("embed_search_text").value;}catch(err){}
	$.get("embed.php?method=view&q="+encodeURI(embed_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("embed_manage").innerHTML=data;
	});
}
function embed_add() {
	$.get("embed.php?method=add", function(data) {
		document.getElementById("embed_manage").innerHTML=data;
		embed_type_change(2)
	});
}
function embed_edit(embed_id) {
	$.get("embed.php?method=edit&embed_id="+embed_id, function(data) {
		document.getElementById("embed_manage").innerHTML=data;
	});
}
function embed_delete(embed_id,embed_name) {
		$.get("embed.php?method=delete&embed_id="+embed_id, function( data ) {
			embed_view(embed_page);
		});
}
function embed_submit() {
			$.ajax({
			  url: 'embed.php', 
			  type: 'POST',
			  data: new FormData($('#embed_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				embed_view(embed_page);
				snackbar("Data Saved");
			}).fail(function(){
				snackbar("Saving Failed");
			});
}
function embed_type_change(type){
	if(type==1){
		document.getElementById("email_list_group").style.display = "block";
	}else{
		document.getElementById("email_list_group").style.display = "none";
	}
}
</script>
<?php include(app_footer());
	}
}

function embed_add($embed_name,$type,$ids,$embed){
	print_r($ids);
	if($type!="1"){
		return embed_get(execute_insert_query("INSERT INTO `embed`(`embed_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`embed`) VALUES ('".mysql_prep($embed_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep(0)."','".mysql_prep($embed)."');"));
	}else{
		foreach($ids as $id){
			echo "INSERT INTO `embed`(`embed_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`embed`) VALUES ('".mysql_prep($embed_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep($id)."','".mysql_prep($embed)."');";
			$embed_data[] =  embed_get(execute_insert_query("INSERT INTO `embed`(`embed_name`,`created_at`, `modified_at`,`account_id`,`type`,`id`,`embed`) VALUES ('".mysql_prep($embed_name)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($type)."','".mysql_prep($id)."','".mysql_prep($embed)."');"));
		}
		return $embed_data;
	}
}
function embed_edit($embed_id,$embed_name,$embed){
	execute_query("UPDATE `embed` SET `modified_at` = ".get_sql_india_time().",`embed_name` = '".mysql_prep($embed_name)."',`embed`='".mysql_prep($embed)."' WHERE `embed_id` = ".mysql_prep($embed_id)." AND `account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."'");
	return embed_get($_REQUEST["embed_id"]);
}
function embed_delete($embed_id){
	execute_query("DELETE FROM `embed` WHERE `embed_id` = ".mysql_prep($embed_id));
	return true;
}
function embed_get($embed_id){
	return ToArray(execute_query("SELECT * FROM `embed` WHERE `embed_id` = ".mysql_prep($embed_id)));
}
function embed_list($q,$page){
	return ToArrays(execute_query("SELECT * FROM `embed` WHERE `embed_name` like '%".mysql_prep($q)."%' LIMIT 30 OFFSET ".($page*30)));
}
function embed_count($q){
	return ToArray(execute_query("SELECT count(*) as embed_count FROM `embed` WHERE `embed_name` like '%".mysql_prep($q)."%' "))["embed_count"];
}
?>
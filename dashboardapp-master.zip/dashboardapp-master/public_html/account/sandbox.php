<?php 
include("../../includes/config.php");
$survey_id=1;
echo "Hello";
//echo survey_process_v2($survey_id);
//json_output(scorecard_params_v2("1","1","18","mike.rohr@codegenerator.gq"));
//echo survey_process($survey_id);
?>
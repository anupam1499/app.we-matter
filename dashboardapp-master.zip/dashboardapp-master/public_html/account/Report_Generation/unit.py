import pandas as pd
import numpy as np
from collections import Counter
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.util import Pt
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
import math
from pptx.oxml.xmlchemy import OxmlElement
import datetime
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE
from pptx.util import Inches
from pptx.chart.data import ChartData
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_TICK_MARK
from pptx.enum.chart import XL_LABEL_POSITION
from pptx.enum.chart import XL_LEGEND_POSITION
from pptx.chart.data import XySeriesData, XyChartData,BubbleChartData
from pptx.enum.chart import XL_CHART_TYPE
from pptx.chart.data import XySeriesData
import time
from pandas import json_normalize
import json
import re
import urllib.request 


def unit_solve(filters,filename,survey_id,company_name,logo_url):
    f = open("/home/app/survey_data/all_questions.json")
    d=json.load(f)
    drivers = json_normalize(d)
    f.close()

    f = open("/home/app/survey_data/"+str(survey_id)+"/response.json")
    urllib.request.urlretrieve(logo_url, "/home/app/survey_data/"+str(survey_id)+"/logo.png")
    logo_path="/home/app/survey_data/"+str(survey_id)+"/logo.png"
    d=json.load(f)
    df = json_normalize(d)

    f = open("/home/app/survey_data/"+str(survey_id)+"/questions.json")
    d=json.load(f)
    question_grp = json_normalize(d)

    def xml_slides(presentation):
            return presentation.slides._sldIdLst  # pylint: disable=protected-access

    def move_slide(presentation, old_index, new_index):  ## enter presentation object, the old index of slide you want to move and new index
            xml_slides = presentation.slides._sldIdLst  
            slides = list(xml_slides)
            xml_slides.remove(slides[old_index])
            xml_slides.insert(new_index, slides[old_index])

    def delete_slide(presentation,  index):              # enter presentation object and index of slide to be deleted 
            xml_slides = presentation.slides._sldIdLst  # pylint: disable=W0212
            slides = list(xml_slides)
            xml_slides.remove(slides[index])

    def set_font(run,name,size,clr,bold):
        font = run.font
        font.name = name
        font.size = Pt(size)
        font.color.rgb=clr
        font.bold = bold
        font.italic = None 

    def find_placeholders(slide):
        for shape in slide.shapes:
            if shape.is_placeholder:
                phf = shape.placeholder_format
                print('%d, %s' % (phf.idx, phf.type))

    def find_shapes(slide):
        c=0
        for shape in slide.shapes:
            if shape.has_text_frame:
                print(shape.text,"index =",c)
            c+=1

    QCodes=drivers['code'].to_list()

    cols=[i for i in df.columns if i in QCodes and not i.startswith('OPEN')]

    data=df[cols]


    data=df
    for i in filters:
        data=data[data[i].isin(filters[i])]

    filter_val='Unit'

    data=data.dropna()
    n_responses=len(data)

    data=data[cols]
    data.head()

    if len(data)>=1:
        pass
    else:
        print("No entries found")

    recs=drivers.description.to_list()
    for i in range(len(recs)):
        reccom=recs[i]
        if reccom=='No Recommendations':
            recs[i]=''
        else:
            reccom=reccom.replace('</li>','\n')
            reccom=reccom.replace('<ol>','')
            reccom=reccom.replace('</ol>','')
            reccom=reccom.replace('<li>','')
            lst=reccom.split('\n')
            lst=[i.rstrip() for i in lst]
            lst=[i.lstrip() for i in lst]
            lst=lst[0:len(lst)-1]
            recs[i]="\n".join(lst)

    surveys = drivers['code'].to_list()
    surveys = [re.match(r'[^\d]+', x).group(0) for x in surveys]

    d_statement=dict()
    d_surveys=dict()
    d_drivers=dict()
    d_groups=dict()
    d_rec=dict()

    #lbls=drivers['Driver Label'].to_list()
    qcodes=drivers['code'].to_list()
    ques=drivers['question'].to_list()
    #surveys=drivers['Survey'].to_list()
    driv_name=drivers['driver'].to_list()
    groups=drivers['group'].to_list()


    for i in range(len(qcodes)):
    #    d_labels[qcodes[i]]=lbls[i]
        d_statement[qcodes[i]]=ques[i]
        d_surveys[qcodes[i]]=surveys[i]
        d_drivers[qcodes[i]]=driv_name[i]
        d_groups[qcodes[i]]=groups[i]
        d_rec[qcodes[i]]=recs[i]

    date=df[['completed']]
    date=date[['completed']].sort_values(by='completed',ascending=False)
    date=date.dropna()
    date.index=np.arange(len(date))
    end=date['completed'][0]
    start=date['completed'][len(date)-1]                       

    if df['completed'].dtype!='<M8[ns]':
        try:
            end=datetime.datetime.strptime(end, '%Y-%m-%d %H:%M')     ### survey end
            start=datetime.datetime.strptime(start, '%Y-%m-%d %H:%M') ### survey start; first response
        except:
            try:
                end=datetime.datetime.strptime(end, '%Y-%m-%d %H:%M:')     ### survey end
                start=datetime.datetime.strptime(start, '%Y-%m-%d %H:%M:') ### survey start; first response   
            except:
                try:
                    end=datetime.datetime.strptime(end, '%Y-%d-%m %H:%M')     ### survey end
                    start=datetime.datetime.strptime(start, '%Y-%d-%m %H:%M') ### survey start; first response
                except:
                    pass
        
    final_date=end + datetime.timedelta(days=2)   
    final_date=str(final_date)                                   ### date of report generation

    template_name="Report_Generation/Template/New FilterCopy.pptx"
    prs = Presentation(template_name)
    date=final_date


    slides=prs.slides
    slide=prs.slides[0]

    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    shapes=slide.shapes
    text_frame = shapes[6].text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = company_name+" | "+final_date[8:10]+"/"+final_date[5:7]+"/"+final_date[:4]    ### Fill name and date of report
    set_font(run,"Century Gothic",18,RGBColor(0x00, 0x20, 0x60),True)

    slide=slides[1]
    shape=slide.shapes[2]

    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    text_frame = shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text="People engagement at "+company_name+" to drive future growth"
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)


    slide=slides[7]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0
        
    shapes=slides[7].shapes
    start=str(start)
    text_frame=shapes[6].text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = start[8:10]+"/"+start[5:7]+"/"+start[:4]
    set_font(run,"Century Gothic",16,RGBColor(0x00, 0x00, 0x00),True)

    end=str(end)
    text_frame=shapes[7].text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = end[8:10]+"/"+end[5:7]+'/'+end[:4]
    set_font(run,"Century Gothic",16,RGBColor(0x00, 0x00, 0x00),True)

    final_date=str(final_date)
    text_frame=shapes[8].text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = final_date[8:10]+"/"+final_date[5:7]+"/"+final_date[:4]
    set_font(run,"Century Gothic",16,RGBColor(0x00, 0x00, 0x00),True)

    find_placeholders(slides[8])

    slide=slides[8]

    placeholder=slide.placeholders[14]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    shape=slides[8].placeholders[13]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = "Engagement at "+company_name
    set_font(run,"Century Gothic",30,RGBColor(0x00, 0x00, 0x00),True)

    data_full=df[cols]
    data_full=data_full.dropna()
    data_full.head()

    replace=[['Strongly Agree',5],['Agree',4],['Neither Agree nor Disagree',3],['Disagree',2],['Strongly Disagree',1]]

    for i in replace:
        data=data.replace(i[0],int(i[1]))

    for i in replace:
        data_full=data_full.replace(i[0],int(i[1]))

    for colm in data.columns:
        data[colm]=pd.to_numeric(data[colm])
        data_full[colm]=pd.to_numeric(data_full[colm])

    engage_cols=[i for i in cols if i.startswith('ENGAGE')]
    engage_data1=data_full[engage_cols]
    engage_data2=data[engage_cols]

    def engage_stats(engage_data):
        EI=engage_data.mean().mean()
        d=dict()
        n=len(engage_data)
        for i in engage_data.columns:
            c=Counter(engage_data[i])
            pos=c[4]+c[5]
            neg=c[1]+c[2]
            d[i]=dict()
            d[i]['pos']=int(round(pos/n*100))
            d[i]['neg']=int(round(neg/n*100))
        return EI,d

    def engage_average(engage):
        engage = engage.assign(Average=pd.Series(engage.sum(axis=1)/len(engage.columns)).values)
        return engage

    def count_categories(engage):
        cats=[]
        for i in engage.Average.to_list():
            if i>=3.75:
                cats.append('Engaged')
            elif i>=3.00:
                cats.append('Nearly Engaged')
            elif i>=2.00:
                cats.append('Not Engaged')
            else:
                cats.append('Disengaged')
        engage = engage.assign(Engagement=pd.Series(cats).values)
        return engage

    EI1,d1=engage_stats(engage_data1)
    EI2,d2=engage_stats(engage_data2)

    engage_data1=engage_average(engage_data1[engage_cols])
    engage_data2=engage_average(engage_data2[engage_cols])
 
    engage_data1=count_categories(engage_data1)
    engage_data2=count_categories(engage_data2)

    engage_data1.head()

    Counter(engage_data2.Engagement)

    destructive = "#DE6A73"
    serious = "#EFB5B9"
    indifferent = "#A0D1FF"
    hp = "#4EB5FF"

    def gauge(d_overall,d_unit,slide): 
        tot=0
        for i in d_overall:
            tot+=d_overall[i]
        x=d_overall['Engaged']/tot*100
        destructive = RGBColor(0xDE, 0x6A, 0x73)
        serious =  RGBColor(0xEF, 0xB5, 0xB9)
        indifferent =  RGBColor(0xA0, 0xD1, 0xFF)
        hp =  RGBColor(0x4E, 0xB5, 0xFF)
        clr=None
        title=""
        def get_title(x):
            if x>=66:
                clr=hp
                title="High Performance Range"
            elif x>=46: 
                clr=indifferent
                title="Indifferent Range"
            elif x>=30:
                clr=serious
                title="Serious Range"
            else:
                clr=destructive
                title="Destructive Range"
            return title,clr
            
        title,clr=get_title(x)
        arc_value=108+(x)*1.08
        shapes=slide.shapes
            
        adj=shapes[6].adjustments
        adj[1]=arc_value
        fill=shapes[6].fill
        fill.solid()
        fill.fore_color.rgb=clr
        
        frame=shapes[7].text_frame
        frame.clear()
        p=frame.paragraphs[0]
        run=p.add_run()
        run.text=str(round(x))+"%"
        run.font.size=Pt(25)
        run.font.color.rgb=clr
        fill=shapes[7].fill
        fill.background()    
        
        
        frame=shapes[10].text_frame
        frame.clear()
        p=frame.paragraphs[0]
        run=p.add_run()
        run.text=title
        run.font.size=Pt(18)
        run.font.color.rgb=clr
        fill=shapes[10].fill
        fill.background()
        p=frame.add_paragraph()
        run=p.add_run()
        run.text=str(len(data_full))+" Responses"
        run.font.size=Pt(18)
        run.font.color.rgb=clr
        p.alignment = PP_ALIGN.CENTER

        
        tot=0
        for i in d_unit:
            tot+=d_unit[i]
        x=d_unit['Engaged']/tot*100 
        arc_value=108+(x)*1.08
        shapes=slide.shapes
            
        title,clr=get_title(x)
        
        adj=shapes[12].adjustments
        adj[1]=arc_value
        fill=shapes[12].fill
        fill.solid()
        fill.fore_color.rgb=clr
        
        frame=shapes[13].text_frame
        frame.clear()
        p=frame.paragraphs[0]
        run=p.add_run()
        run.text=str(round(x))+"%"
        run.font.size=Pt(25)
        run.font.color.rgb=clr
        fill=shapes[13].fill
        fill.background()    
        
        
        frame=shapes[16].text_frame
        frame.clear()
        p=frame.paragraphs[0]
        run=p.add_run()
        run.text=title
        run.font.size=Pt(18)
        run.font.color.rgb=clr
        fill=shapes[16].fill
        fill.background()    
        p=frame.add_paragraph()
        run=p.add_run()
        run.text=str(len(data))+" Responses"
        run.font.size=Pt(18)
        run.font.color.rgb=clr
        p.alignment = PP_ALIGN.CENTER


    gauge(Counter(engage_data1.Engagement),Counter(engage_data2.Engagement),slides[9])

    slide=slides[9]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    def color_wheel(polarity,val):
        if polarity=='pos':
            if val>=75:
                return RGBColor(0x4E, 0xB5, 0xFF)
            if val>=60:
                return RGBColor(0xA0, 0xD1, 0xFF)
            elif val>=40:
                return RGBColor(0xEF, 0xB5, 0xB9)
            else:
                return RGBColor(0xDE, 0x6A, 0x73)
        else:
            if val<=20:
                return RGBColor(0x4E, 0xB5, 0xFF)
            if val<=35:
                return RGBColor(0xA0, 0xD1, 0xFF)
            elif val<=50:
                return RGBColor(0xEF, 0xB5, 0xB9)
            else:
                return RGBColor(0xDE, 0x6A, 0x73)

    drvs=list(engage_cols)
    drvs.sort()

    slide=slides[10]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    shapes = slide.shapes

    lst=[23,24,25,26,27,28,29,30,31,32]

    for i in range(10):
        drvr=drvs[int(i/2)]
        shape=shapes[lst[i]]
        text_frame=shapes[lst[i]].text_frame
        text_frame.clear()
        p = text_frame.paragraphs[0]
        run = p.add_run()
        key=None
        if i%2==0:
            key='pos'
            txt=str(d2[drvr][key])
        else:
            key='neg'
            txt=str(d2[drvr][key])
        run.text=txt+'%'
        
        set_font(run,"Century Gothic",18,RGBColor(0x00, 0x00, 0x00),True)
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = color_wheel(key,d2[drvr][key])
        
        
    lst=[35,36,37,38,39,40,41,42,43,44]
    for i in range(10):
        drvr=drvs[int(i/2)]
        shape=shapes[lst[i]]
        text_frame=shapes[lst[i]].text_frame
        text_frame.clear()
        p = text_frame.paragraphs[0]
        run = p.add_run()
        key=None
        if i%2==0:
            key='pos'
            txt=str(d1[drvr][key])
        else:
            key='neg'
            txt=str(d1[drvr][key])
        run.text=txt+'%'
        
        set_font(run,"Century Gothic",18,RGBColor(0x00, 0x00, 0x00),True)
        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = color_wheel(key,d1[drvr][key])

    slide=slides[11]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0


    c=Counter(engage_data1.Engagement)
    c_unit=Counter(engage_data2.Engagement)

    find_placeholders(slides[11])

    def bar_plot(c,c_unit,slide):
        tot=0
        for i in c:
            tot+=c[i]
        perc_c=dict()
        for i in c:
            perc_c[i]=c[i]*100/tot

        tot=0
        for i in c_unit:
            tot+=c_unit[i]
        perc_c_unit=dict()
        for i in c_unit:
            perc_c_unit[i]=c_unit[i]*100/tot


        keys=['Disengaged','Not Engaged','Nearly Engaged','Engaged']
        for i in keys:
            if i not in perc_c:
                perc_c[i]=0
            if i not in perc_c_unit:
                perc_c_unit[i]=0
        vals=(perc_c[i] for i in keys)
        vals_unit=(perc_c_unit[i] for i in keys)
        
        placeholder = slide.placeholders[16]  # idx key, not position
        placeholder.name
        placeholder.placeholder_format.type

        chart_data = ChartData()
        chart_data.categories = keys
        chart_data.add_series('Overall', vals)
        chart_data.add_series('Unit', vals_unit)

        graphic_frame = placeholder.insert_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, chart_data)
        chart = graphic_frame.chart

        category_axis = chart.category_axis
        category_axis.has_major_gridlines = False
        category_axis.has_minor_gridlines = False
        
        value_axis = chart.value_axis
        value_axis.has_minor_gridlines = False
        value_axis.has_major_gridlines = False
        value_axis.visible = False
        
        series=chart.series[0]
        series.format.fill.solid()
        series.format.fill.fore_color.rgb=RGBColor(0x18, 0x18, 0x30)
        l=len(series.points)
        points=series.points
        values=series.values
        for i in range(l):
            point=points[i]
            point.data_label.text_frame.text=str(int(values[i]))+"%"
            
            
        series=chart.series[1]
        series.format.fill.solid()
        series.format.fill.fore_color.rgb=RGBColor(0x00, 0x83, 0xA9)
        l=len(series.points)
        points=series.points
        values=series.values
        for i in range(l):
            point=points[i]
            point.data_label.text_frame.text=str(int(values[i]))+"%"
            
    #    chart.plots[0].vary_by_categories = False
        chart.category_axis.format.line.width = 0
    #   chart.value_axis.format.line.width = 33
        category_axis.format.line.color.rgb = RGBColor(255, 255, 255)
        chart.has_title=False
        chart.has_legend=False
    
        plot = chart.plots[0]
        plot.gap_width=300
        plot.has_data_labels = True
        data_labels = plot.data_labels
        data_labels.font.size = Pt(14)
        data_labels.font.color.rgb = RGBColor(0x00, 0x00, 0x00)
        data_labels.position = XL_LABEL_POSITION.OUTSIDE_END

    bar_plot(c,c_unit,slides[11])

    slide=slides[11]

    def positivity_index(c):
            keys=['Engaged','Not Engaged','Disengaged']
            for k in keys:
                if k not in c:
                    c[k]=0
            try:
                return c['Engaged']/(c['Disengaged']+c['Not Engaged'])
            except Exception as e:
                if c['Engaged']==0:
                    return 0
                elif c['Disengaged']+c['Not Engaged']==0:
                    return '∞'

    slide=slides[11]

    shape=slides[11].placeholders[15]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    PI=positivity_index(c_unit)
    run.text = "The number of people engaged to every disengaged/not engaged person is "+str(round(PI))+" as against a benchmark of 4"
    set_font(run,"Century Gothic",20,RGBColor(0x00, 0x00, 0x00),True)

    shape=slide.shapes[9]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    PI=positivity_index(c_unit)
    run.text = "{:.2f}".format(PI)
    set_font(run,"Century Gothic",16,RGBColor(0xFF, 0xFF, 0xFF),True)


    p.alignment = PP_ALIGN.CENTER
    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Positivity Index"
    set_font(run,"Century Gothic",12,RGBColor(0xFF, 0xFF, 0xFF),True)
    p.alignment = PP_ALIGN.CENTER



    shape=slide.shapes[6]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text =  "The number of people engaged for every disengaged/non engaged person is "+str(round(PI))
    set_font(run,"Century Gothic",14,RGBColor(0xFF, 0xFF, 0xFF),True)


    p.alignment = PP_ALIGN.CENTER


    shape=slide.shapes[5]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    PI_overall=positivity_index(c)
    run.text = "{:.2f}".format(PI_overall)
    set_font(run,"Century Gothic",16,RGBColor(0xFF, 0xFF, 0xFF),True)


    p.alignment = PP_ALIGN.CENTER
    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Positivity Index"
    set_font(run,"Century Gothic",12,RGBColor(0xFF, 0xFF, 0xFF),True)
    p.alignment = PP_ALIGN.CENTER

    shape=slide.shapes[8]
    text_frame=shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text =  "The number of people engaged for every disengaged/non engaged person is "+str(round(PI_overall))
    set_font(run,"Century Gothic",14,RGBColor(0xFF, 0xFF, 0xFF),True)


    p.alignment = PP_ALIGN.CENTER

    def c_categories(data):
        cats=[]
        for i in data.Average.to_list():
            if i>=3.75:
                cats.append('Engaged')
            elif i>=3.00:
                cats.append('Nearly Engaged')
            elif i>=2.00:
                cats.append('Not Engaged')
            else:
                cats.append('Disengaged')
        data['Engagement']=cats
        return data

    def stats(data):
        idx=data.mean().mean()
        d=dict()
        n=len(data)
        for i in data.columns:
            c=Counter(data[i])
            pos=c[4]+c[5]
            neg=c[1]+c[2]
            d[i]=dict()
            d[i]['pos']="{:.2f}".format(pos/n)
            d[i]['neg']="{:.2f}".format(neg/n)
        return idx,d

    def c_wheel(vals,vals1):
        colors=[]
        for i in range(len(vals)):
            if vals1[i]>=75 and vals[i]>=0.5:
                colors.append("#4EB5FF")
            elif vals1[i]>=50 and vals[i]>=0.5:
                colors.append("#A0D1FF")
            elif vals1[i]<=50 and vals[i]>=0.5:
                colors.append("#DE6A73")
            elif vals1[i]<=50 and vals[i]<=0.5:
                colors.append("#F9D1D2")
            else:
                colors.append("#F2F2F2")
        return colors

    def scatterchart(slide,correlation,performance,columns):
        cols=[d_drivers[i] for i in columns]
        placeholder=slide.placeholders[21]

        chart_data = BubbleChartData()

        towards_excellence = chart_data.add_series('Towards Excellence')
        improvement = chart_data.add_series('Improvement')
        excellence = chart_data.add_series('Excellence')
        low_focus = chart_data.add_series('Low Focus')
        not_critical = chart_data.add_series('Not Critical')
        quadrant=chart_data.add_series('Quadrant')


        quadrant.add_data_point(0.90, 77, 0.0001)
        quadrant.add_data_point(0.85, 52, 0.0001)
        quadrant.add_data_point(0.90, 4, 0.0001)
        quadrant.add_data_point(0, 4, 0.0001)
        quadrant.add_data_point(0, 52, 0.0001)

        labels=dict()
        labels['Towards Excellence']=[]
        labels['Excellence']=[]
        labels['Improvement']=[]
        labels['Low Focus']=[]
        labels['Not Critical']=[]
        
        quadrant_classify=[]

        for i in range(len(correlation)):
            corr=correlation[i]
            perf=performance[i]
            if corr>0.5 and perf>=75:
                excellence.add_data_point(correlation[i], performance[i], 1)
                labels['Excellence'].append(cols[i])
                quadrant_classify.append("Excellence")
            elif corr>0.5 and perf>=50:
                towards_excellence.add_data_point(correlation[i], performance[i], 1)
                labels['Towards Excellence'].append(cols[i])
                quadrant_classify.append("Towards Excellence")
            elif corr>0.5:
                improvement.add_data_point(correlation[i], performance[i], 1)
                labels['Improvement'].append(cols[i])
                quadrant_classify.append("Improvement")
            elif corr<0.5 and perf<=50:
                low_focus.add_data_point(correlation[i], performance[i], 1)
                labels['Low Focus'].append(cols[i])
                quadrant_classify.append("Low Focus")
            else:
                not_critical.add_data_point(correlation[i], performance[i], 1)
                labels['Not Critical'].append(cols[i])
                quadrant_classify.append("Not Critical")


        graphic_frame = placeholder.insert_chart(XL_CHART_TYPE.BUBBLE,chart_data=chart_data)
        chart = graphic_frame.chart
        chart.chart_type

        category_axis = chart.category_axis
        category_axis.has_major_gridlines = False
        category_axis.has_minor_gridlines = False
        category_axis.has_title = False
        category_axis.format.line.fill.background()
        category_axis.maximum_scale=1
        category_axis.minimum_scale=0
        tick_labels = category_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
        tick_labels.font.size=Pt(10)


        value_axis = chart.value_axis
        value_axis.has_minor_gridlines = False
        value_axis.has_major_gridlines = False
        value_axis.has_title = False
        value_axis.format.line.fill.background()
        value_axis.maximum_scale=100
        value_axis.minimum_scale=0
        tick_labels = value_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
        tick_labels.font.size=Pt(10)


        for series in chart.series:
            if series.name!='Quadrant':
                fill = series.format.fill
                fill.solid()
                fill.fore_color.rgb = mini_c_wheel(series.name)
                points=series.points
                label_list=labels[series.name]
                for i in range(len(label_list)):
                    point=points[i]
                    frame=point.data_label.text_frame
                    frame.clear()
                    p=frame.paragraphs[0]
                    run=p.add_run()
                    run.text=label_list[i]
                    run.font.size=Pt(11)
                    run.font.color.rgb = mini_c_wheel(series.name)


        quads=['Excellence','Towards Excellence','Improvement','Low Focus','Not Critical']

        points=chart.series[5].points
        for i in range(len(quads)):
            p=points[i]
            p.format.fill.background()
            frame=p.data_label.text_frame
            frame.clear()
            p=frame.paragraphs[0]
            run=p.add_run()
            run.text=quads[i]
            run.font.size=Pt(10)
            run.font.color.rgb = mini_c_wheel(quads[i])

        chart.has_legend = False
        chart.has_title=False

        plot=graphic_frame.chart.plots[0]
        plot.bubble_scale=20
        return quadrant_classify

    def mini_c_wheel(name):
            if name=="Excellence":
                return RGBColor(0x4E, 0xB5, 0xFF)
            elif name=="Towards Excellence":
                return RGBColor(0xA0, 0xD1, 0xFF)
            elif name=="Improvement":
                return RGBColor(0xDE, 0x6A,0x73)
            elif name=="Low Focus":
                return RGBColor(0xF9, 0xD1,0xD2)
            else:
                return RGBColor(0xF2, 0xF2, 0xF2)

    surveys=dict()
    for i in data.columns:
        if i[:len(i)-2] not in surveys:
            surveys[i[:len(i)-2]]=1
    surveys=[i for i in list(surveys.keys()) if i not in ['ENGAGE']]

    survey_data_full=dict()
    survey_data=dict()
    count=12

    towards_excellence=[]
    improve=[]
    excellence=[]

    for s in surveys:
        cols=[i for i in data.columns if d_surveys[i]==s]
        df_survey=data_full[cols]
        idx,d=stats(df_survey)
        survey_data_full[s]=dict()
        survey_data_full[s]['perc']=d
        survey_data_full[s]['index']=idx
        
        df_survey=data[cols]
        idx,d=stats(df_survey)
        survey_data[s]=dict()
        survey_data[s]['perc']=d
        survey_data[s]['index']=idx
        df_survey=df_survey.assign(eng=pd.Series(engage_data2.Average).values)
        vals=df_survey.corr()['eng'].to_list()
        vals=vals[:len(vals)-1]
        vals1=[]
        for i in range(len(vals)):
                vals1.append(float(d[cols[i]]['pos'])*100)     ### Percentage positive responses for each driver in survey
            
        dframe=pd.DataFrame({'vals':vals,'vals1':vals1,'cols':cols})
        dframe=dframe.dropna()
        vals=dframe['vals'].to_list()
        vals1=dframe['vals1'].to_list()
        cols=dframe['cols'].to_list()

        slide=slides[count]

        quadrant_classify=scatterchart(slide,vals,vals1,cols)

            
        placeholder=slide.placeholders[10]
        picture = placeholder.insert_picture(logo_path)
        picture.crop_top = 0
        picture.crop_left = 0
        picture.crop_bottom = 0
        picture.crop_right = 0
            
        
        text_frame=slide.placeholders[15].text_frame
        text_frame.clear()
        p = text_frame.paragraphs[0]
        run = p.add_run()
        run.text="Prioritization of "+d_surveys[cols[0]]+" Drivers on basis of Impact and Absolute Score" 
        set_font(run,"Century Gothic",20,RGBColor(0x00, 0x00, 0x00),True)        
        
        slide=prs.slides[count]
        shape=slide.placeholders[20]
        text_frame=shape.text_frame
        text_frame.clear()
        p = text_frame.paragraphs[0]
        run = p.add_run()
        run.text="Drivers"

        for i in range(len(cols)):
            p = text_frame.add_paragraph()
            run = p.add_run()
            run.text = d_drivers[cols[i]]
            clr=mini_c_wheel(quadrant_classify[i])
            set_font(run,"Century Gothic",11,clr,False)
            if vals1[i]>=75 and vals[i]>=0.5:
                excellence.append([cols[i],vals[i],vals1[i]])               
            elif vals1[i]>=50 and vals[i]>=0.5:
                towards_excellence.append([cols[i],vals[i],vals1[i]])
            elif vals1[i]<50 and vals[i]>=0.5:
                improve.append([cols[i],vals[i],vals1[i]])
        count+=1

    ct=count
    while ct<22:
        delete_slide(prs,count)
        ct+=1

    towards_excellence=[i for i in towards_excellence if d_surveys[i[0]] != 'CUSTOM'] 
    improve=[i for i in improve if d_surveys[i[0]] != 'CUSTOM'] 
    excellence=[i for i in excellence if d_surveys[i[0]] != 'CUSTOM'] 
      
    towards_excellence.sort(key = lambda towards_excellence: towards_excellence[1],reverse=True)
    top_te=towards_excellence[:min(len(towards_excellence),3)]
    top_te

    improve.sort(key = lambda improve: improve[1],reverse=True)
    top_ip=improve[:min(len(improve),3)]
    top_ip

    excellence.sort(key = lambda excellence: excellence[1],reverse=True)
    top_e=excellence[:min(len(excellence),3)]

    def SubElement(parent, tagname, **kwargs):
            element = OxmlElement(tagname)
            element.attrib.update(kwargs)
            parent.append(element)
            return element

    def _set_cell_border(cell):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        for lines in ['a:lnL','a:lnR','a:lnT','a:lnB']:
            ln = SubElement(tcPr, lines,w='0', cap='flat', cmpd='sng', algn='ctr')
            solidFill = SubElement(ln, 'a:NoFill')

    slide=slides[count]

    def fill_table(slide,lst,strng):
        table_placeholder=slide.placeholders[18]
        l=len(lst)
        shape = table_placeholder.insert_table(rows=l+1, cols=5)
        table = shape.table

        headers=['Driver','Ownership/Group','Impact on Engagement','Driver Parameter Score','Priority of Action']
        for i in range(5):
            cell = table.cell(0, i)
            _set_cell_border(cell)
            fill = cell.fill
            fill.background()
            t_frame=cell.text_frame
            t_frame.clear()
            p = t_frame.paragraphs[0]
            run = p.add_run()
            run.text=headers[i]
            set_font(run,"Century Gothic",14,RGBColor(0xF5, 0x82, 0x20),True)
            p.alignment = PP_ALIGN.CENTER


        for i in range(1,l+1):
            driver=lst[i-1]
            texts=[d_drivers[driver[0]], d_surveys[driver[0]],"{:.2f}".format(driver[1]), "{:.2f}".format(driver[2]/100),strng]
            for j in range(5):
                cell = table.cell(i, j)
                _set_cell_border(cell)
                fill = cell.fill
                fill.background()
                t_frame=cell.text_frame
                t_frame.clear()
                p = t_frame.paragraphs[0]
                run = p.add_run()
                run.text=texts[j]
                font = run.font
                font.size = Pt(12.99)
                font.name="Century Gothic"
                if j==0:
                    font.color.rgb=RGBColor(0xA0, 0xD1, 0xFF)
                else:
                    font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
                p.alignment = PP_ALIGN.CENTER

        if l==3:
            size=0.75
        elif l==2:
            size=1
        else:
            size=1.5

        for row in table.rows: 
                    row.height=Inches(size)


        table_placeholder=slide.placeholders[19]
        l=len(lst)
        shape = table_placeholder.insert_table(rows=l+1, cols=2)
        table = shape.table

        headers=['Driver','Statement']
        for i in range(2):
            cell = table.cell(0, i)
            _set_cell_border(cell)
            fill = cell.fill
            fill.background()
            t_frame=cell.text_frame
            t_frame.clear()
            p = t_frame.paragraphs[0]
            run = p.add_run()
            run.text=headers[i]
            set_font(run,"Century Gothic",11,RGBColor(0xF5, 0x82, 0x20),True)
            p.alignment = PP_ALIGN.CENTER

        for i in range(1,l+1):
            driver=lst[i-1]
            texts=[d_drivers[driver[0]], d_statement[driver[0]]]
            for j in range(2):
                cell = table.cell(i, j)
                _set_cell_border(cell)
                fill = cell.fill
                fill.background()
                t_frame=cell.text_frame
                t_frame.clear()
                p = t_frame.paragraphs[0]
                run = p.add_run()
                run.text=texts[j]
                font = run.font
                font.size = Pt(10)
                font.name="Century Gothic"
                if j==0:
                    font.color.rgb=RGBColor(0xA0, 0xD1, 0xFF)
                else:
                    font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
                p.alignment = PP_ALIGN.CENTER
        table.columns[0].width=2399665+550000
        table.columns[1].width=2399665*4-550000

    find_placeholders(slides[count])

    if top_te==[]:
        delete_slide(prs,count)
    else:
        slide=slides[count]
        placeholder=slide.placeholders[10]
        picture = placeholder.insert_picture(logo_path)
        picture.crop_top = 0
        picture.crop_left = 0
        picture.crop_bottom = 0
        picture.crop_right = 0
        fill_table(slides[count],top_te,"Towards Excellence")
        count+=1

    slide=slides[count]
    if top_ip==[]:
        delete_slide(prs,count)
    else:
        placeholder=slide.placeholders[10]
        picture = placeholder.insert_picture(logo_path)
        picture.crop_top = 0
        picture.crop_left = 0
        picture.crop_bottom = 0
        picture.crop_right = 0
        fill_table(slide,top_ip,"Improvement")
        count+=1

    def wellbeing_category_index(data):
        return data.mean().mean()


    def edit_font(run,sz):
        font = run.font
        font.name = 'Century Gothic'
        font.size = Pt(sz)
        font.color.rgb=RGBColor(0x00, 0x00, 0x00)
        font.bold = True
        font.italic = None


    WB=True
    if 'WB' in survey_data:
        codes=list(survey_data['WB']['perc'].keys())
        codes.sort()
        
        wb_c=[]
        wbc=dict()
        for i in codes:
            group=d_groups[i]
            if group in wb_c:
                wbc[group].append(i)
            else:
                wbc[group]=[i]
                wb_c.append(group)
        
        
        for cat in wb_c:
            arr=wbc[cat]
            idx=wellbeing_category_index(data[arr])

            slide=prs.slides[count]
            placeholder=slide.placeholders[10]
            picture = placeholder.insert_picture(logo_path)
            picture.crop_top = 0
            picture.crop_left = 0
            picture.crop_bottom = 0
            picture.crop_right = 0
            
            shapes = slide.shapes



            text_frame=shapes[6].text_frame
            text_frame.clear()
            p = text_frame.paragraphs[0]
            run = p.add_run()
            run.text="{:.2f}".format(idx)
            set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)

            idx=wellbeing_category_index(data_full[arr])

            text_frame=shapes[5].text_frame
            text_frame.clear()
            p = text_frame.paragraphs[0]
            run = p.add_run()
            run.text="{:.2f}".format(idx)
            set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
     
            t=len(arr)

            start=3042000
            block_height=min(3214800/t-50000,1007999)


            for k in arr:
                top=start+50000
                left= 583200
                width=2844359
                height=block_height

                shape = shapes.add_shape(
                    MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height
                )
                fill = shape.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(0xE6, 0xE6, 0xE6)
                shape.shadow.visible=False
                shape.shadow.transparency=100
                shape.outline=None
                shape.line.fill.background()
                text_frame=shape.text_frame
                text_frame.clear()
                p = text_frame.paragraphs[0]
                run = p.add_run()
                factor=block_height/1007999
                run.text=d_drivers[k]
                set_font(run,"Century Gothic",factor*18,RGBColor(0x00, 0x00, 0x00),True)



                top = start+50000
                left= 5200000
                width=6372001
                height=block_height

                shape = shapes.add_shape(
                    MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height
                )
                fill = shape.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(0xE6, 0xE6, 0xE6)
                shape.shadow.visible=False
                shape.shadow.transparency=100
                shape.outline=None
                shape.line.fill.background()
                text_frame=shape.text_frame
                text_frame.clear()
                p = text_frame.paragraphs[0]
                run = p.add_run()
                factor=block_height/1007999
                run.text=d_statement[k]
                set_font(run,"Century Gothic",factor*18,RGBColor(0x00, 0x00, 0x00),True)



                top = start+40000
                left= 3333599
                width=939600
                height=block_height+20000

                shape = shapes.add_shape(
                    MSO_SHAPE.RECTANGLE, left, top, width, height
                )

                fill = shape.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(0x18, 0x18, 0x30)

                shape.outline=None
                shape.line.fill.background()
                shape.shadow.visible=False
                shape.shadow.transparency=100
                text_frame=shape.text_frame
                text_frame.clear()
                p = text_frame.paragraphs[0]
                run = p.add_run()
                factor=block_height/1007999

                run.text=str(round(float(survey_data_full['WB']['perc'][k]['pos'])*100))+"%"
                set_font(run,"Century Gothic",factor*20,RGBColor(0xFF, 0xFF, 0xFF),True)

                top = start+40000
                left= 4308199
                width=939600
                height=block_height+20000

                shape = shapes.add_shape(
                    MSO_SHAPE.RECTANGLE, left, top, width, height
                )

                fill = shape.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(0x00, 0x83, 0xA9)

                shape.outline=None
                shape.line.fill.background()
                shape.shadow.visible=False
                shape.shadow.transparency=100
                text_frame=shape.text_frame
                text_frame.clear()
                p = text_frame.paragraphs[0]
                run = p.add_run()
                factor=block_height/1007999

                run.text=str(round(float(survey_data['WB']['perc'][k]['pos'])*100))+"%"
                set_font(run,"Century Gothic",factor*20,RGBColor(0xFF, 0xFF, 0xFF),True)


                start=start+50000+block_height

            count+=1
    else:
        for i in range(3):
            delete_slide(prs,count)

    slide=slides[count]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    def calc_lines(driv):
        lines=0
        for i in driv:
            if type(d_rec[i])==float:
                pass
            else:
                spl=d_rec[i].split('\n')
                spl=[j for j in spl if j!='']
                for i in spl:
                    ln=len(i)
                    add=math.ceil(ln/74)
                    lines+=add+1
        f=None
        if lines>=48:
            f=9.5
            fact=0.15
        elif lines>=37:
            f=10.5
            fact=0.15
        elif lines>= 29:
            f=11.5
            fact=0.17
        elif lines>=25:
            f=12
            fact=0.18
        elif lines>=22:
            f=13
            fact=0.21
        elif lines>=16:
            f=13.5
            fact=0.21
        else:
            f= 15
            fact=0.21

        return f,lines,fact

    if top_te:
        te=data[[i[0] for i in top_te ]]
        ix,sts=stats(te)
        fields=['Negative','Neutral','Positive']
        temp=pd.DataFrame(columns=fields)

        driv=[i[0] for i in top_te]
        ne=[float(sts[i]['neg'])*100 for i in driv]
        pos=[float(sts[i]['pos'])*100 for i in driv]
        temp['Negative']=ne
        temp['Positive']=pos
        temp['Neutral']=100-temp['Negative']-temp['Positive']
        temp.index=[d_drivers[i] for i in driv]

        chart_data = CategoryChartData()
        chart_data.categories = list(temp.index)
        categories=list(temp.index)
        negative=temp['Negative'].to_list()
        neutral=temp['Neutral'].to_list()
        positive=temp['Positive'].to_list()

        chart_data.add_series("Negative", (i for i in negative))
        chart_data.add_series("Neutral", (i for i in neutral))
        chart_data.add_series("Positive", (i for i in positive))


        placeholder=slide.placeholders[20]
        graphic_frame = placeholder.insert_chart(XL_CHART_TYPE.BAR_STACKED_100, chart_data)


        chart = graphic_frame.chart
        chart.has_title=False

        category_axis = chart.category_axis
        category_axis.has_major_gridlines = False
        category_axis.has_minor_gridlines = False
        category_axis.format.line.fill.background()
        tick_labels = category_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)   
        tick_labels.font.size=Pt(11)

        value_axis = chart.value_axis
        value_axis.has_minor_gridlines = False
        value_axis.has_major_gridlines = False
        value_axis.format.line.fill.background()
        value_axis.visible = True
        tick_labels = value_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
        tick_labels.font.size=Pt(11)


        plot=chart.plots[0]
        plot.has_data_labels = True
        data_labels = plot.data_labels
        data_labels.font.size = Pt(12)
        data_labels.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

        for series in chart.series:
            if series.name=='Negative':
                series.format.fill.solid()
                series.format.fill.fore_color.rgb= RGBColor(0xEF, 0xB5, 0xB9)
            elif series.name=='Neutral':
                series.format.fill.solid()
                series.format.fill.fore_color.rgb= RGBColor(0xEA, 0xEA, 0xEA)        
            else:
                series.format.fill.solid()
                series.format.fill.fore_color.rgb=RGBColor(0xA0, 0xD1, 0xFF)  

        driv=[i[0] for i in top_te]

        f,lns,fact=calc_lines(driv)
        
        slide=slides[count]
        
        table_placeholder=slide.placeholders[19]
        l=len(top_te)
        shape = table_placeholder.insert_table(rows=l+1, cols=2)
        table = shape.table

        headers=['Driver','Towards Excellence Recommendations']
        for i in range(2):
                cell = table.cell(0, i)
                _set_cell_border(cell)
                fill = cell.fill
                fill.background()
                t_frame=cell.text_frame
                t_frame.clear()
                p = t_frame.paragraphs[0]
                run = p.add_run()
                run.text=headers[i]
                set_font(run,"Century Gothic",f,RGBColor(0xF5, 0x82, 0x20),True)


        for i in range(1,l+1):
                driver=top_te[i-1]
                if d_rec[driver[0]]=='':   ## in case no recommendation for that driver, skip and leave row blank
                    for j in range(2):
                        cell = table.cell(i, j)
                        _set_cell_border(cell)
                        fill = cell.fill
                        fill.background()
                        t_frame=cell.text_frame
                        t_frame.clear()
                        p = t_frame.paragraphs[0]
                        run = p.add_run()
                        run.text="\n"
                else:
                    texts=[d_drivers[driver[0]], d_rec[driver[0]]]
                    for j in range(2):
                        cell = table.cell(i, j)
                        _set_cell_border(cell)
                        fill = cell.fill
                        fill.background()
                        t_frame=cell.text_frame
                        t_frame.clear()
                        p = t_frame.paragraphs[0]
                        run = p.add_run()
                        run.text=texts[j]+"\n"
                        font = run.font
                        font.size = Pt(f)
                        font.name="Century Gothic"
                        if j==0:
                            font.color.rgb=RGBColor(0xA0, 0xD1, 0xFF)
                        else:
                            font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)



        table.columns[0].width=int(3697145*2*fact)
        table.columns[1].width=3697145*2-table.columns[0].width
        count+=1
        
    else:
        delete_slide(prs,count)


    find_placeholders(slides[16])

    slides=prs.slides

    slide=slides[count]
    placeholder=slide.placeholders[10]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    if top_ip:
        ti=data[[i[0] for i in top_ip ]]
        ix,sts=stats(ti)
        fields=['Negative','Neutral','Positive']
        temp=pd.DataFrame(columns=fields)

        driv=[i[0] for i in top_ip]
        ne=[float(sts[i]['neg'])*100 for i in driv]
        pos=[float(sts[i]['pos'])*100 for i in driv]
        temp['Negative']=ne
        temp['Positive']=pos
        temp['Neutral']=100-temp['Negative']-temp['Positive']
        temp.index=[d_drivers[i] for i in driv]
        

        chart_data = CategoryChartData()
        chart_data.categories = list(temp.index)
        categories=list(temp.index)
        negative=temp['Negative'].to_list()
        neutral=temp['Neutral'].to_list()
        positive=temp['Positive'].to_list()

        chart_data.add_series("Negative", (i for i in negative))
        chart_data.add_series("Neutral", (i for i in neutral))
        chart_data.add_series("Positive", (i for i in positive))


        placeholder=slide.placeholders[20]
        graphic_frame = placeholder.insert_chart(XL_CHART_TYPE.BAR_STACKED_100, chart_data)


        chart = graphic_frame.chart
        chart.has_title=False
        category_axis = chart.category_axis
        category_axis.has_major_gridlines = False
        category_axis.has_minor_gridlines = False
        category_axis.format.line.fill.background()
        tick_labels = category_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)   
        tick_labels.font.size=Pt(11)

        value_axis = chart.value_axis
        value_axis.has_minor_gridlines = False
        value_axis.has_major_gridlines = False
        value_axis.format.line.fill.background()
        value_axis.visible = True
        tick_labels = value_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
        tick_labels.font.size=Pt(11)


        plot=chart.plots[0]
        plot.has_data_labels = True
        data_labels = plot.data_labels
        data_labels.font.size = Pt(12)
        data_labels.font.color.rgb = RGBColor(0x00, 0x00, 0x00)

        for series in chart.series:
            if series.name=='Negative':
                series.format.fill.solid()
                series.format.fill.fore_color.rgb= RGBColor(0xEF, 0xB5, 0xB9)
            elif series.name=='Neutral':
                series.format.fill.solid()
                series.format.fill.fore_color.rgb= RGBColor(0xEA, 0xEA, 0xEA)        
            else:
                series.format.fill.solid()
                series.format.fill.fore_color.rgb=RGBColor(0xA0, 0xD1, 0xFF)  
        

            
            
        driv=[i[0] for i in top_ip]
        driv
        f,lns,fact=calc_lines(driv)
        
        slide=slides[count]
        
        table_placeholder=slide.placeholders[19]
        l=len(top_ip)
        shape = table_placeholder.insert_table(rows=l+1, cols=2)
        table = shape.table

        headers=['Driver','Improve Recommendations']
        for i in range(2):
                cell = table.cell(0, i)
                _set_cell_border(cell)
                fill = cell.fill
                fill.background()
                t_frame=cell.text_frame
                t_frame.clear()
                p = t_frame.paragraphs[0]
                run = p.add_run()
                run.text=headers[i]
                set_font(run,"Century Gothic",f,RGBColor(0xF5, 0x82, 0x20),True)


        for i in range(1,l+1):
                driver=top_ip[i-1]
                if type(d_rec[driver[0]])==float:   ## in case no recommendation for that driver, skip and leave row blank
                    for j in range(2):
                        cell = table.cell(i, j)
                        _set_cell_border(cell)
                        fill = cell.fill
                        fill.background()
                        t_frame=cell.text_frame
                        t_frame.clear()
                        p = t_frame.paragraphs[0]
                        run = p.add_run()
                        run.text="\n"
                else:
                    texts=[d_drivers[driver[0]], d_rec[driver[0]]]
                    for j in range(2):
                        cell = table.cell(i, j)
                        _set_cell_border(cell)
                        fill = cell.fill
                        fill.background()
                        t_frame=cell.text_frame
                        t_frame.clear()
                        p = t_frame.paragraphs[0]
                        run = p.add_run()
                        run.text=texts[j]+"\n"
                        font = run.font
                        font.size = Pt(f)
                        font.name="Century Gothic"
                        if j==0:
                            font.color.rgb=RGBColor(0xA0, 0xD1, 0xFF)
                        else:
                            font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)



        table.columns[0].width=int(3697145*2*fact)
        table.columns[1].width=3697145*2-table.columns[0].width
        count+=1
    else:
        delete_slide(prs,count)

    slide=slides[count]

    def color_wheel1(val):
            if val>=70:
                return RGBColor(0x4E, 0xB5, 0xFF)
            elif val>=55:
                return RGBColor(0xEF, 0xB5, 0xB9)
            else:
                return RGBColor(0xDE, 0x6A, 0x73)

    def driver_perc(d_overall,d_unit,d_drivers,slide,column_set):
        driv=[]
        pos=[]
        colors = []
            

        keys=[i for i in column_set]
        values_unit=(float(d_unit[i]['pos'])*100 for i in keys)
        values_overall=(float(d_overall[i]['pos'])*100 for i in keys)
        keys=[d_drivers[i] for i in keys ]

        placeholder = slide.placeholders[21]  # idx key, not position
        placeholder.name
        placeholder.placeholder_format.type

        chart_data = ChartData()
        chart_data.categories = keys
        chart_data.add_series('Unit', values_unit)
        chart_data.add_series('Overall', values_overall)

        graphic_frame = placeholder.insert_chart(XL_CHART_TYPE.BAR_CLUSTERED, chart_data)
        chart = graphic_frame.chart
        chart.chart_type
        
        category_axis = chart.category_axis
        category_axis.has_major_gridlines = False
        category_axis.has_minor_gridlines = False
        chart.has_title=False

        tick_labels = category_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)    
        tick_labels.font.size=Pt(12)


        value_axis = chart.value_axis
        value_axis.has_minor_gridlines = False
        value_axis.has_major_gridlines = False
        value_axis.visible = False
        tick_labels = value_axis.tick_labels
        tick_labels.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
        tick_labels.font.size=Pt(12)


        series=chart.series[0]
        l=len(series.points)
        points=series.points
        values=series.values
        for i in range(l):
            point=points[i]
            fill = point.format.fill
            fill.solid()
            fill.fore_color.rgb = color_wheel1(values[i])
            frame=point.data_label.text_frame
            para=frame.paragraphs[0]
            run=para.add_run()
            run.text=str(round(int(values[i])))+"%"
            run.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
            run.font.size=Pt(14)
            

        series=chart.series[1]
        l=len(series.points)
        points=series.points
        values=series.values
        for i in range(l):
            point=points[i]
            fill = point.format.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(0xA6,0xA6,0xA6)
            frame=point.data_label.text_frame
            para=frame.paragraphs[0]
            run=para.add_run()
            run.text=str(int(values[i]))+"%"
            run.font.color.rgb=RGBColor(0xFF, 0xFF, 0xFF)
            run.font.size=Pt(14)

            
    #    chart.plots[0].vary_by_categories = False
        chart.category_axis.format.line.width = 0
        category_axis.format.line.color.rgb = RGBColor(255, 255, 255)
        chart.has_legend = False

        plot = chart.plots[0]
        plot.gap_width=150
        plot.has_data_labels = True
        data_labels = plot.data_labels
        data_labels.font.size = Pt(12)
        data_labels.font.color.rgb = RGBColor(255, 255, 255)
        data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
        chart.has_legend = False

    surveys=[i for i in surveys if i!='WB']


    n_surveys=len(surveys)
    add=0
    for s in surveys:
        cls=[i for i in df.columns if i.startswith(s)]
        n_slides=math.ceil(len(cls)/4)
        add+=n_slides-1

    for s in surveys:
        cols=[i for i in data.columns if d_surveys[i]==s]
        n_slides=math.ceil(len(cols)/4)
        per_slide=math.ceil(len(cols)/n_slides)
        for i in range(n_slides):
            print(count)
            if i==n_slides-1:
                column_set=cols[i*per_slide:]
            else:
                column_set=cols[i*per_slide:i*per_slide+per_slide]

            column_set=column_set[::-1]
            slide=slides[count]
            placeholder=slide.placeholders[10]
            picture = placeholder.insert_picture(logo_path)
            picture.crop_top = 0
            picture.crop_left = 0
            picture.crop_bottom = 0
            picture.crop_right = 0

            d_unit=survey_data[s]['perc']
            idx=survey_data[s]['index']
            d_overall=survey_data_full[s]['perc']


            driver_perc(d_overall,d_unit,d_drivers,slide,column_set)


            t_frame=slide.placeholders[15].text_frame
            t_frame.clear()
            p=t_frame.paragraphs[0]
            run=p.add_run()
            run.text=d_surveys[cols[0]]+" Excellence"
            set_font(run,"Century Gothic",24,RGBColor(0x00, 0x00, 0x00),True)


            t_frame=slide.placeholders[17].text_frame
            t_frame.clear()
            p=t_frame.paragraphs[0]
            run=p.add_run()
            run.text="{:.2f}".format(idx)
            set_font(run,"Century Gothic",30,RGBColor(0xF5, 0x82, 0x20),True)
            p.alignment = PP_ALIGN.CENTER
            p=t_frame.add_paragraph()
            run=p.add_run()
            run.text=d_surveys[cols[0]]+" Index"
            set_font(run,"Century Gothic",10,RGBColor(0xFF, 0xFF, 0xFF),True)
            p.alignment = PP_ALIGN.CENTER



            t_frame=slide.placeholders[20].text_frame
            t_frame.clear()
            p=t_frame.paragraphs[0]
            run=p.add_run()
            run.text=str(n_responses)
            set_font(run,"Century Gothic",30,RGBColor(0xF5, 0x82, 0x20),True)
            p.alignment = PP_ALIGN.CENTER
            p=t_frame.add_paragraph()
            run=p.add_run()
            run.text="No. of Responses"
            set_font(run,"Century Gothic",10,RGBColor(0xFF, 0xFF, 0xFF),True)
            p.alignment = PP_ALIGN.CENTER

            count+=1
            print()
            print('-----------------------------------------------------')
            print()
            print()


    if n_surveys<4:
        while n_surveys<4:
            delete_slide(prs,count)
            n_surveys+=1

    if n_surveys+add<15:
        curr=n_surveys+add
        while curr<15:
            delete_slide(prs,count)
            curr+=1

    slide=slides[count]

    placeholder=slide.placeholders[14]
    picture = placeholder.insert_picture(logo_path)
    picture.crop_top = 0
    picture.crop_left = 0
    picture.crop_bottom = 0
    picture.crop_right = 0

    destructive = "#DE6A73"
    serious = "#EFB5B9"
    indifferent = "#A0D1FF"
    hp = "#4EB5FF"

    PI_col=None
    if PI>=4:
        PI_col=RGBColor(0x4E, 0xB5, 0xFF)
    elif PI>=3:
        PI_col=RGBColor(0xA0, 0xD1, 0xFF)
    elif PI>=2:
        PI_col=RGBColor(0xEF, 0xB5, 0xB9)
    else:
        PI_col=RGBColor(0xDE, 0x6A, 0x73)

    n_responses=len(data)


    E_perc=c_unit['Engaged']/n_responses*100

    E_col=None
    if E_perc>=75:
        E_col=RGBColor(0x4E, 0xB5, 0xFF)
    elif E_perc>=45:
        E_col=RGBColor(0xA0, 0xD1, 0xFF)
    elif E_perc>=30:
        E_col=RGBColor(0xEF, 0xB5, 0xB9)
    else:
        E_col=RGBColor(0xDE, 0x6A, 0x73)

    shape=slide.shapes[3]
    text_frame = shape.text_frame
    text_frame.clear()
    p = text_frame.paragraphs[0]
    run = p.add_run()
    run.text = "Engagement Score"
    set_font(run,"Century Gothic",24,RGBColor(0x4E, 0xB5, 0xFF),True)

    run=p.add_run()
    run.text=' is '
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)

    run=p.add_run()
    run.text= str(round(E_perc))+"%"+"\n" 
    set_font(run,"Century Gothic",24,E_col,True)



    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Positivity Index"
    set_font(run,"Century Gothic",24,RGBColor(0xA0, 0xD1, 0xFF),True)
    run=p.add_run()
    run.text=' is '
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    run=p.add_run()
    run.text= "{:.2f}".format(PI)+" : "+"1 " 
    set_font(run,"Century Gothic",24,PI_col,True)
    run=p.add_run()
    run.text= "which means that the number of people engaged for every disengaged/non engaged person is "
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    run=p.add_run()
    run.text= str(round(PI))+"\n"
    set_font(run,"Century Gothic",24,PI_col,True)


    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Top"
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    run=p.add_run()
    run.text=' Improvement '
    set_font(run,"Century Gothic",24,RGBColor(0xDE, 0x6A, 0x73),True)
    run=p.add_run()
    run.text='drivers : '
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    if len(top_ip)==0:
        run=p.add_run()
        run.text= " None\n" 
        set_font(run,"Century Gothic",24,RGBColor(0xDE, 0x6A, 0x73),True)
    else:
        s=""
        for i in range(len(top_ip)-1):
            s+=d_drivers[top_ip[i][0]]+", "
        s+=d_drivers[top_ip[len(top_ip)-1][0]]+"\n"
        run=p.add_run()
        run.text= s
        set_font(run,"Century Gothic",24,RGBColor(0xDE, 0x6A, 0x73),True)

        
        
    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Top"
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    run=p.add_run()
    run.text=' Towards excellence '
    set_font(run,"Century Gothic",24,RGBColor(0xA0, 0xD1, 0xFF),True)
    run=p.add_run()
    run.text='drivers : '
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    if len(top_te)==0:
        run=p.add_run()
        run.text= " None\n" 
        set_font(run,"Century Gothic",24,RGBColor(0xA0, 0xD1, 0xFF),True)
    else:
        s=""
        for i in range(len(top_te)-1):
            s+=d_drivers[top_te[i][0]]+", "
        s+=d_drivers[top_te[len(top_te)-1][0]]+"\n"
        run=p.add_run()
        run.text= s
        set_font(run,"Century Gothic",24,RGBColor(0xA0, 0xD1, 0xFF),True)
        

    p = text_frame.add_paragraph()
    run = p.add_run()
    run.text = "Top"
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    run=p.add_run()
    run.text=' Excellence '
    set_font(run,"Century Gothic",24,RGBColor(0x4E, 0xB5, 0xFF),True)
    run=p.add_run()
    run.text='drivers : '
    set_font(run,"Century Gothic",24,RGBColor(0xFF, 0xFF, 0xFF),True)
    if len(top_e)==0:
        run=p.add_run()
        run.text= " None\n" 
        set_font(run,"Century Gothic",24,RGBColor(0x4E, 0xB5, 0xFF),True)
    else:
        s=""
        for i in range(len(top_e)-1):
            s+=d_drivers[top_e[i][0]]+", "
        s+=d_drivers[top_e[len(top_e)-1][0]]+"\n"
        run=p.add_run()
        run.text= s
        set_font(run,"Century Gothic",24,RGBColor(0x4E, 0xB5, 0xFF),True)
    prs.save('Report_Generation/tempdata/'+ filename +'.pptx')

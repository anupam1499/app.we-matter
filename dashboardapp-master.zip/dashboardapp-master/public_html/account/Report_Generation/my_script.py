#!/usr/bin/env python3
import sys
try:

  import sys
  import re
  import traceback
  import pandas as pd
  import numpy as np
  from collections import Counter
  from pptx import Presentation
  from pptx.dml.color import RGBColor
  from pptx.enum.dml import MSO_THEME_COLOR
  from pptx.util import Pt
  from pptx.util import Inches, Pt
  from pptx.enum.shapes import MSO_SHAPE
  from pptx.enum.text import PP_ALIGN
  import math
  from pptx.oxml.xmlchemy import OxmlElement
  import datetime
  from pptx.chart.data import CategoryChartData
  from pptx.enum.chart import XL_CHART_TYPE
  from pptx.util import Inches
  from pptx.chart.data import ChartData
  from pptx.chart.data import CategoryChartData
  from pptx.enum.chart import XL_TICK_MARK
  from pptx.enum.chart import XL_LABEL_POSITION
  from pptx.enum.chart import XL_LEGEND_POSITION
  from pptx.chart.data import XySeriesData, XyChartData,BubbleChartData
  from pptx.enum.chart import XL_CHART_TYPE
  from pptx.chart.data import XySeriesData
  import time
  from pandas import json_normalize
  import json
  import overall
  from overall import solve
  from unit import unit_solve
  import urllib.request 
  import os



  print(sys.argv[1])
  survey_id=sys.argv[1]
  filename=sys.argv[2]
  mode=sys.argv[3]
  company_name=sys.argv[4]
  logo_url=sys.argv[5]
  if mode=='0':
          solve(filename,survey_id,company_name,logo_url)
  else:
    file1 = open('Report_Generation/tempdata/'+filename+".txt", 'w')
    f=open('Report_Generation/tempdata/'+filename+".json")
    d=json.load(f)
    filters=dict()
    for i in d:
      choices=d[i].split('|')
      filters[i]=choices[:len(choices)-1]
     # for i in choices:
     #   file1.write(i+'\n')
    file1.write(logo_url)
    file1.close()
    unit_solve(filters,filename,survey_id,company_name,logo_url)
    f.close()

except Exception as e:
    try:
      with open('Report_Generation/log.txt', 'a') as f:
          f.write(traceback.format_exc())
          f.write(str(os.getcwd()))

    except Exception as e:
      with open('Report_Generation/log.txt', 'a') as f:
          f.write(str(e))
          f.write(traceback.format_exc())
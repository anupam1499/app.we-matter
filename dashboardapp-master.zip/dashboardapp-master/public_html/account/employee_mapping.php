<?php
include("../../includes/config.php");
//print_r($_FILES);
//print_r($_REQUEST);
//;
if(file_exists($_FILES["upload_file"]["tmp_name"])){
	$file = fopen($_FILES["upload_file"]["tmp_name"],"r");
	$input = array();
	$headers = fgetcsv($file);
	while(! feof($file)){
	  $input[] = fgetcsv($file);
	}
	fclose($file);
	$manager = array();
	$email = array();
	foreach($input as $item){
		if($item[2]!="")
			$manager[$item[2]][]=$item[1];
		$email[$item[1]]=$item[0];
	}
	if($_REQUEST["method"]==="manager"){
		foreach($manager as $manager_id => $employee_ids){
			foreach($employee_ids as $employee_id){
				$data["email"]=$email[$manager_id];
				$data["id"]=$manager_id;
				$data["employee_id"]=$employee_id;
				$response[] = $data;
			}
		}
		csv_output("Manager Mapping",$response);
		exit(0);
	}else if($_REQUEST["method"]==="leader"){
		$leaders = array();
		foreach($manager as $manager_id => $employee_ids){
			foreach($employee_ids as $employee_id){
				if(count($manager[$employee_id])>0){
					if(!isset($leaders[$manager_id])){
						$leaders[$manager_id] = array();
					}
					$leaders[$manager_id] = array_unique(array_merge($leaders[$manager_id],$employee_ids,$manager[$employee_id]),SORT_REGULAR);
				}
			}
		}
		//$length = strlen(json_encode($leaders,true));
		$length = 0;
		$count=0;
		//echo $count." - ".$length."<br>";
		while($length!=strlen(json_encode($leaders,true))&&$count<5){
			$length  =  strlen(json_encode($leaders,true));
			$leaders = map_leaders($leaders);
			$count++;
			//echo $count." - ".$length."<br>";
		}
		//exit(0);
		$response = array();
		foreach($leaders as $leader_id => $employee_ids){
			foreach($employee_ids as $employee_id){
				$data["email"]=$email[$leader_id];
				$data["id"]=$leader_id;
				$data["employee_id"]=$employee_id;
				$response[] = $data;
			}
		}
		csv_output("Leader Mapping",$response);
	}
}else{
	echo "Invalid File";
}
exit(0);
function map_leaders($leaders){
	$response = array();
	foreach($leaders as $leader_id => $employee_ids){
		$response[$leader_id] = $employee_ids;
		foreach($employee_ids as $employee_id){
			if(count($leaders[$employee_id])>0){
				$response[$leader_id] = array_unique(array_merge($response[$leader_id],$leaders[$employee_id]),SORT_REGULAR);
			}
		}
	}
	return $response;
}
?>
<?php include("../../includes/config.php");
$title="Action Plan";
$method="manage";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];

$survey_id=0;
if(isset($_REQUEST["survey_id"]))
	$survey_id=$_REQUEST["survey_id"];
		
$user_id=$_SESSION["user_id"];
if(isset($_REQUEST["user_id"])){
	if(ToArray(execute_query("SELECT count(*) AS is_mapped FROM `survey_mapping` WHERE `employee_id` in (SELECT `id` FROM `account_linking` WHERE `user_id` = ".mysql_prep($_REQUEST["user_id"])." ) AND `survey_id` = ".mysql_prep($survey_id)))["is_mapped"]>0||$survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){
		$user_id=$_REQUEST["user_id"];
	}
}

if($method==="list"){
	$action_plans = action_plan_list($survey_id,$user_id);
	$response["action_plan"] = $action_plans;
	$survey = survey_get($_REQUEST["survey_id"]);
	$employees = ToArrays(execute_query("SELECT DISTINCT `employee_id` FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `user_id` = ".mysql_prep($user_id)." AND `survey_id` = ".mysql_prep($survey["survey_id"]).";"));
	$employees = flatten_array($employees,"employee_id");
	$employees = array_map('trim', $employees); 
	$limits = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	if(($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2")&&!isset($_REQUEST["user_id"])){
			$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
	}else{
			$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND `AL`.`id` in ('".implode("','",$employees)."');"));
	}
	$response["action_plan_user"]= ToArrays(execute_query("SELECT `U`.`user_id`,`AL`.`name`,`AL`.`id`,`U`.`email`,
			COALESCE(completed,0) AS completed,
			COALESCE(total,0) AS total FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			LEFT JOIN (
				SELECT `AP`.`action_user_id` as user_id, count(*) AS total,
				SUM(CASE WHEN `AP`.`status` = 'Completed' AND `AP`.`action_category` != 'Manager' THEN 1 WHEN `AP`.`action_category` = 'Manager' THEN COALESCE(`S`.status,0) ELSE 0 END) AS completed 
				FROM `action_plan` AP
				LEFT JOIN (
				SELECT `action_plan_id`,
				SUM(CASE WHEN `status` = 'Completed' THEN 1 ELSE 0 END)/COUNT(*) AS status 
				FROM `action_plan_recipient`
				WHERE `action_plan_id` in (SELECT `action_plan_id` FROM `action_plan` WHERE `survey_id` = ".mysql_prep($survey["survey_id"]).")
				GROUP BY 1
				) S ON `S`.`action_plan_id` = `AP`.`action_plan_id`
				WHERE `survey_id` = ".mysql_prep($survey["survey_id"])." AND `AP`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." GROUP BY 1
			) C ON `C`.`user_id` = `U`.`user_id`
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `U`.`user_id` in (".implode(",",flatten_array($user_ids,"user_id")).");"));
		$response["action_plan_driver"]= ToArrays(execute_query("SELECT `AP`.`action_category`,`AP`.`action_driver`, count(*) AS total,
		SUM(CASE WHEN `AP`.`status` = 'Completed' AND `AP`.`action_category` != 'Manager' THEN 1 WHEN `AP`.`action_category` = 'Manager' THEN COALESCE(`S`.status,0) ELSE 0 END) AS completed 
		FROM `action_plan` AP
		LEFT JOIN (
		SELECT `action_plan_id`,
		SUM(CASE WHEN `status` = 'Completed' THEN 1 ELSE 0 END)/COUNT(*) AS status 
		FROM `action_plan_recipient`
		WHERE `action_plan_id` in (SELECT `action_plan_id` FROM `action_plan` WHERE `survey_id` = ".mysql_prep($survey["survey_id"]).")
		GROUP BY 1
		) S ON `S`.`action_plan_id` = `AP`.`action_plan_id`
		WHERE `survey_id` = ".mysql_prep($survey["survey_id"])." AND `AP`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `AP`.`action_user_id` in (".implode(",",flatten_array($user_ids,"user_id")).") GROUP BY 1,2;"));
		json_output($response);
}else if($method==="add"){
	if(isset(
		$_REQUEST["survey_id"],
		$_REQUEST["action_category"],
		$_REQUEST["action_driver"]
	)){
		foreach ($_REQUEST as $key => $value)  {
			if(startsWith($key,"action_text_")){
				$indexes[] = str_replace("action_text_","",$key);
			}
		}
		foreach($indexes as $index){
			if(trim($_REQUEST["action_text_".$index])!=""){
				$action_plan = action_plan_add(
				$_REQUEST["survey_id"],
				$_SESSION["role_selected"]["account_id"],
				$user_id,
				$_REQUEST["action_template_id_".$index],
				$_REQUEST["action_category"],
				$_REQUEST["action_text_".$index],
				"",//$_REQUEST["progress_text"],
				1,//$_REQUEST["status"],
				"",//$_REQUEST["intervention"],
				"",//$_REQUEST["action_type"],
				$_REQUEST["action_driver"],
				$_REQUEST["target_date_".$index],
				$_SESSION["user_id"]);
				if($_REQUEST["action_category"]==="Manager"){
					//Add Mapped Manager Subordinates
					$employee_ids = execute_query("SELECT `employee_id` FROM `survey_mapping` WHERE `type`=1 AND `user_id`=".mysql_prep($user_id)." AND `survey_id` = ".mysql_prep($_REQUEST["survey_id"]));
					$employee_ids = flatten_array($employee_ids,"employee_id") ;
					foreach($employee_ids AS $employee_id){
						execute_query("INSERT INTO `action_plan_recipient`(`action_plan_id`, `recipient_emp_id`, `created_at`, `modified_at`) VALUES ('".mysql_prep($action_plan["action_plan_id"])."','".mysql_prep($employee_id)."',".get_sql_india_time().",".get_sql_india_time().");");
					}
				}
				$action_plans[]=$action_plan;
			}
		}
		json_output($action_plans);
	}else{
		json_message("survey_id,action_category,action_driver are required variable");
	}
}else if($method==="get"){
	if(isset($_REQUEST["action_plan_id"])){
		$action_plan = action_plan_get($_REQUEST["action_plan_id"]);
		json_output($action_plan);
	}else{
		json_message("action_plan_id is a required variable");
	}
}else if($method==="edit"){
	if(isset(
		$_REQUEST["submit"],
		$_REQUEST["action_plan_id"],
		$_REQUEST["action_user_id"],
		$_REQUEST["action_category"],
		$_REQUEST["action_text"],
		$_REQUEST["progress_text"],
		$_REQUEST["status"],
		$_REQUEST["intervention"],
		$_REQUEST["action_type"],
		$_REQUEST["action_driver"],
		$_REQUEST["target_date"],
		$_REQUEST["creator_user_id"]
	)){
		$action_plan = action_plan_edit(
			$_REQUEST["action_plan_id"],
			$_REQUEST["action_user_id"],
			$_REQUEST["action_category"],
			$_REQUEST["action_text"],
			$_REQUEST["progress_text"],
			$_REQUEST["status"],
			$_REQUEST["intervention"],
			$_REQUEST["action_type"],
			$_REQUEST["action_driver"],
			$_REQUEST["target_date"],
			$_REQUEST["creator_user_id"]
		);
		json_output($action_plan);
	}else{
		json_message("submit,action_plan_id,action_user_id,action_recipient_id,action_recipient_emp_id,action_category,action_text,progress_text,status,intervention,action_type,action_driver,target_date,creator_user_id are required variable");
		}
}else if($method==="delete"){
	if(isset($_REQUEST["action_plan_id"])){
		if(action_plan_delete($_REQUEST["action_plan_id"]))
			json_message("The object is successfully deleted");
		else
			json_message("Unauthorized Access");
	}else{
		json_message("action_plan_id is a required variable");
	}
}else if($method==="action_template"){
	$action_plan_templates=[];
	if(isset($_REQUEST["action_question_code"],$_REQUEST["action_category"],$_REQUEST["survey_id"])){
		$action_plan_templates = ToArrays(execute_query("SELECT `AT`.* FROM `action_template` AS AT
		LEFT JOIN `action_plan` AS AP ON `AT`.`action_template_id`=`AP`.`action_template_id` AND `action_user_id` = ".mysql_prep($user_id)." AND `AP`.`survey_id` = ".mysql_prep($_REQUEST["survey_id"])."
		WHERE `AT`.`action_category` = '".mysql_prep($_REQUEST["action_category"])."' AND `AT`.`action_question_code` = '".mysql_prep($_REQUEST["action_question_code"])."' AND `AP`.`action_template_id` IS NULL"));
	}
	json_output($action_plan_templates);
}else if($method==="action_bulk_assign"){
	set_time_limit(900);
	if(isset($_REQUEST["survey_id"])){
		$survey = survey_get($_REQUEST["survey_id"]);
		if($survey["account_id"]===$_SESSION["role_selected"]["account_id"]&&$_SESSION["role_selected"]["role_id"]==="1"&&$_SESSION["user_id"]===$survey["user_id"]){
			$scores = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey["survey_id"]."/score.json"),TRUE);
			$limits = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
			$users_temp = ToArray(execute_query("SELECT `user_id`,`id` FROM `account_linking` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `id` != '';"));
			foreach($users_temp as $user){
				$user_ids[$user["id"]]=$user["user_id"];
			}
			$action_template_temp = ToArray(execute_query("SELECT * FROM `action_template`"));
			foreach($action_template_temp as $action_template){
				$action_templates[$action_template["action_question_code"]][]=$action_template;
			}
			foreach($scores["MANAGER"] AS $id => $score){
				if($score["count"]>=$limits["min_scorecard"]&&isset($user_ids[$id])){
					unset($temp_score);
					foreach($score["score"] AS $question_code => $value){
						if(startsWith($question_code,"MANAGER")){
							$temp_score[$question_code]=$value;
						}
					}
					asort($temp_score);
					$temp_score = array_slice($temp_score,0,3);
					foreach($temp_score as $question_code => $value){
						foreach($action_templates[$question_code] as $action){
							$action_plan = action_plan_add($survey["survey_id"],$_SESSION["role_selected"]["account_id"],$user_ids[$id],$action["action_template_id"],$action["action_category"],$action["action_text"],"","Created",$action["intervention"],$action["action_type"],$action["action_driver"],date('Y-m-d',(time()+19800+(8*7*24*3600))),$_SESSION["user_id"]);
							if(isset($action_plan["action_plan_id"])&&$action_plan["action_plan_id"]>0){
								foreach($score["employee_list"] AS $employee_id){
									execute_query("INSERT INTO `action_plan_recipient`(`action_plan_id`, `recipient_emp_id`, `created_at`, `modified_at`) VALUES ('".mysql_prep($action_plan["action_plan_id"])."','".mysql_prep($employee_id)."',".get_sql_india_time().",".get_sql_india_time().");");
								}
							}
						}
						
					}
				}
			}
			foreach($scores["HR"] AS $id => $score){
				if($score["count"]>=$limits["min_scorecard"]&&isset($user_ids[$id])){
					unset($temp_score);
					foreach($score["score"] AS $question_code => $value){
						if(startsWith($question_code,"HR")){
							$temp_score[$question_code]=$value;
						}
					}
					asort($temp_score);
					$temp_score = array_slice($temp_score,0,3);
					foreach($temp_score as $question_code => $value){
						foreach($action_templates[$question_code] as $action){
							$action_plan = action_plan_add($survey["survey_id"],$_SESSION["role_selected"]["account_id"],$user_ids[$id],$action["action_template_id"],$action["action_category"],$action["action_text"],"","Created",$action["intervention"],$action["action_type"],$action["action_driver"],date('Y-m-d',(time()+19800+(8*7*24*3600))),$_SESSION["user_id"]);
						}
					}
				}
			}
			foreach($scores["LEADER"] AS $id => $score){
				if($score["count"]>=$limits["min_scorecard"]&&isset($user_ids[$id])){
					//LEADER
					unset($temp_score);
					foreach($score["score"] AS $question_code => $value){
						if(startsWith($question_code,"LEADER")){
							$temp_score[$question_code]=$value;
						}
					}
					asort($temp_score);
					$temp_score = array_slice($temp_score,0,2);
					foreach($temp_score as $question_code => $value){
						foreach($action_templates[$question_code] as $action){
							$action_plan = action_plan_add($survey["survey_id"],$_SESSION["role_selected"]["account_id"],$user_ids[$id],$action["action_template_id"],$action["action_category"],$action["action_text"],"","Created",$action["intervention"],$action["action_type"],$action["action_driver"],date('Y-m-d',(time()+19800+(8*7*24*3600))),$_SESSION["user_id"]);
						}
					}
					//WFH
					unset($temp_score);
					foreach($score["score"] AS $question_code => $value){
						if(startsWith($question_code,"WFH")){
							$temp_score[$question_code]=$value;
						}
					}
					asort($temp_score);
					$temp_score = array_slice($temp_score,0,2);
					foreach($temp_score as $question_code => $value){
						foreach($action_templates[$question_code] as $action){
							$action_plan = action_plan_add($survey["survey_id"],$_SESSION["role_selected"]["account_id"],$user_ids[$id],$action["action_template_id"],$action["action_category"],$action["action_text"],"","Created",$action["intervention"],$action["action_type"],$action["action_driver"],date('Y-m-d',(time()+19800+(8*7*24*3600))),$_SESSION["user_id"]);
						}
					}
					//WB
					unset($temp_score);
					foreach($score["score"] AS $question_code => $value){
						if(startsWith($question_code,"WB")){
							$temp_score[$question_code]=$value;
						}
					}
					asort($temp_score);
					$temp_score = array_slice($temp_score,0,2);
					foreach($temp_score as $question_code => $value){
						foreach($action_templates[$question_code] as $action){
							$action_plan = action_plan_add($survey["survey_id"],$_SESSION["role_selected"]["account_id"],$user_ids[$id],$action["action_template_id"],$action["action_category"],$action["action_text"],"","Created",$action["intervention"],$action["action_type"],$action["action_driver"],date('Y-m-d',(time()+19800+(8*7*24*3600))),$_SESSION["user_id"]);
						}
					}
				}
			}
			json_message("Action Plan Assignment Processed");
		}else{
			json_message("Unauthorized Access");
		}
	}else{
		json_message("Invalid Survey ID");
	}
}else if($method==="mark"){
	if(isset($_REQUEST["action_plan_id"])){
		execute_query("UPDATE `action_plan` SET `progress_text`='".mysql_prep($_REQUEST["progress_text"])."',`status`='".mysql_prep($_REQUEST["status"])."' WHERE `action_plan_id` = '".mysql_prep($_REQUEST["action_plan_id"])."' AND `action_user_id`=".mysql_prep($_SESSION["user_id"]).";");
		$response = action_plan_get($_REQUEST["action_plan_id"]);
		if($response["action_user_id"]!=$_SESSION["user_id"]){
			json_message("Unauthorized Access");
			exit(0);
		}
	}else if(isset($_REQUEST["action_plan_recipient_id"])){
		if(ToArray(execute_query("SELECT `action_user_id` FROM `action_plan` WHERE `action_plan_id` in (SELECT `action_plan_id` FROM `action_plan_recipient` WHERE `action_plan_recipient_id` =  '".mysql_prep($_REQUEST["action_plan_recipient_id"])."');"))["action_user_id"]===$_SESSION["user_id"]){
			execute_query("UPDATE `action_plan_recipient` SET `progress_text`='".mysql_prep($_REQUEST["progress_text"])."',`status`='".mysql_prep($_REQUEST["status"])."' WHERE `action_plan_recipient_id` = '".mysql_prep($_REQUEST["action_plan_recipient_id"])."';");
			$response = ToArray(execute_query("SELECT * FROM `action_plan_recipient` WHERE `action_plan_recipient_id` = '".mysql_prep($_REQUEST["action_plan_recipient_id"])."';"));
		}else{
			json_message("Unauthorized Access");
			exit(0);
		}
	}else{
		json_message("action_plan_id or  action_plan_recipient_id is a required parameter");
	}
	json_output($response);
}else if($method==="dashboard"){
	/*$q = "";
	if(isset($_REQUEST["q"]))
		$q = $_REQUEST["q"];
	$page = 0;
	if(isset($_REQUEST["page"]))	
		$page = $_REQUEST["page"];*/
	$survey = survey_get($_REQUEST["survey_id"]);
	$employees = ToArrays(execute_query("SELECT DISTINCT `employee_id` FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `user_id` = ".mysql_prep($_SESSION["user_id"])." AND `survey_id` = ".mysql_prep($survey["survey_id"]).";"));
	$employees = flatten_array($employees,"employee_id");
	$employees = array_map('trim', $employees); 
	$limits = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){
		// $user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			// FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
			$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
			// $user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%');"))["user_count"];
			// $total = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." ;"))["user_count"];
	}else{
		// $user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			// FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') AND `AL`.`id` in ('".implode("','",$employees)."') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
			$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND `AL`.`id` in ('".implode("','",$employees)."');"));
			// $user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') AND `AL`.`id` in ('".implode("','",$employees)."');"))["user_count"];
			// $total = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			// LEFT JOIN 
				// `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				// AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			// WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND `AL`.`id` in ('".implode("','",$employees)."');"))["user_count"];
	}
	$user_ids = flatten_array($user_ids,"user_id");
	$response["action_plan_user"]= ToArrays(execute_query("SELECT `U`.`user_id`,`AL`.`name`,`AL`.`id`,`U`.`email`,
			COALESCE(completed,0) AS completed,
			COALESCE(total,0) AS total FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			LEFT JOIN (
				SELECT `AP`.`action_user_id` as user_id, count(*) AS total,
				SUM(CASE WHEN `AP`.`status` = 'Completed' AND `AP`.`action_category` != 'Manager' THEN 1 WHEN `AP`.`action_category` = 'Manager' THEN COALESCE(`S`.status,0) ELSE 0 END) AS completed 
				FROM `action_plan` AP
				LEFT JOIN (
				SELECT `action_plan_id`,
				SUM(CASE WHEN `status` = 'Completed' THEN 1 ELSE 0 END)/COUNT(*) AS status 
				FROM `action_plan_recipient`
				WHERE `action_plan_id` in (SELECT `action_plan_id` FROM `action_plan` WHERE `survey_id` = ".mysql_prep($survey["survey_id"]).")
				GROUP BY 1
				) S ON `S`.`action_plan_id` = `AP`.`action_plan_id`
				WHERE `survey_id` = ".mysql_prep($survey["survey_id"])." AND `AP`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." GROUP BY 1
			) C ON `C`.`user_id` = `U`.`user_id`
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `U`.`user_id` in (".implode(",",$user_ids).");"));
		$response["action_plan_driver"]= ToArrays(execute_query("SELECT `AP`.`action_category`,`AP`.`action_driver`, count(*) AS total,
		SUM(CASE WHEN `AP`.`status` = 'Completed' AND `AP`.`action_category` != 'Manager' THEN 1 WHEN `AP`.`action_category` = 'Manager' THEN COALESCE(`S`.status,0) ELSE 0 END) AS completed 
		FROM `action_plan` AP
		LEFT JOIN (
		SELECT `action_plan_id`,
		SUM(CASE WHEN `status` = 'Completed' THEN 1 ELSE 0 END)/COUNT(*) AS status 
		FROM `action_plan_recipient`
		WHERE `action_plan_id` in (SELECT `action_plan_id` FROM `action_plan` WHERE `survey_id` = ".mysql_prep($survey["survey_id"]).")
		GROUP BY 1
		) S ON `S`.`action_plan_id` = `AP`.`action_plan_id`
		WHERE `survey_id` = ".mysql_prep($survey["survey_id"])." AND `AP`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." GROUP BY 1,2;"));
		//$response["count"]=$user_count;
		//$response["total"]=$total;
		json_output($response);
}else if($method==="user_score"){
	$survey = survey_get($_REQUEST["survey_id"]);
	$scores = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey["survey_id"]."/score.json"),TRUE);
	$id = ToArray(execute_query("SELECT `id` FROM `account_linking` WHERE `user_id` = ".mysql_prep($user_id)." AND `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])))["id"];
	if(isset($scores["MANAGER"][$id])){
		$response["MANAGER"]=$scores["MANAGER"][$id];
	}
	if(isset($scores["LEADER"][$id])){
		$response["LEADER"]=$scores["LEADER"][$id];
	}
	if(isset($scores["HR"][$id])){
		$response["HR"]=$scores["HR"][$id];
	}
	if(isset($scores["ORGANIZATION"])){
		$response["ORGANIZATION"]=$scores["ORGANIZATION"];
	}
	json_output($response);
}else if($method==="manage"){
	if($output==="json"){
		json_output($action_plans);
	}else{
		include(app_header());?>
<section class="content">
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="action_plan_manage">
	</div>
</div>
</section>
<?php include(app_script()); ?>
<script src="action_plan.js"></script>
<?php include(app_footer());
	}
}

function action_plan_add($survey_id,$account_id,$action_user_id,$action_template_id,$action_category,$action_text,$progress_text,$status,$intervention,$action_type,$action_driver,$target_date,$creator_user_id){
	return action_plan_get(execute_insert_query("INSERT INTO `action_plan`(
	`created_at`,
	`modified_at`,
	`survey_id`,
	`account_id`,
	`action_user_id`,
	`action_template_id`,
	`action_category`,
	`action_text`,
	`progress_text`,
	`status`,
	`intervention`,
	`action_type`,
	`action_driver`,
	`target_date`,
	`creator_user_id`)
	VALUES (
	".get_sql_india_time().",
	".get_sql_india_time().",
	'".mysql_prep($survey_id)."',
	'".mysql_prep($account_id)."',
	'".mysql_prep($action_user_id)."',
	'".mysql_prep($action_template_id)."',
	'".mysql_prep($action_category)."',
	'".mysql_prep($action_text)."',
	'".mysql_prep($progress_text)."',
	'".mysql_prep($status)."',
	'".mysql_prep($intervention)."',
	'".mysql_prep($action_type)."',
	'".mysql_prep($action_driver)."',
	'".mysql_prep($target_date)."',
	'".mysql_prep($creator_user_id)."'
	)"));
}
function action_plan_edit($action_plan_id,$account_id,$action_user_id,$action_category,$action_text,$progress_text,$status,$intervention,$action_type,$action_driver,$target_date,$creator_user_id){
	execute_query("UPDATE `action_plan` SET 
	`modified_at` = ".get_sql_india_time().",
	`account_id`='".mysql_prep($account_id)."',
	`action_user_id`='".mysql_prep($action_user_id)."',
	`action_category`='".mysql_prep($action_category)."',
	`action_text`='".mysql_prep($action_text)."',
	`progress_text`='".mysql_prep($progress_text)."',
	`status`='".mysql_prep($status)."',
	`intervention`='".mysql_prep($intervention)."',
	`action_type`='".mysql_prep($action_type)."',
	`action_driver`='".mysql_prep($action_driver)."',
	`target_date`='".mysql_prep($target_date)."',
	`creator_user_id`='".mysql_prep($creator_user_id)."'
	 WHERE `action_plan_id` = ".mysql_prep($action_plan_id));
	return action_plan_get($_REQUEST["action_plan_id"]);
}
function action_plan_delete($action_plan_id){
	$action_plan = action_plan_get($action_plan_id);
	if($action_plan["creator_user_id"]===$_SESSION["user_id"]){
		execute_query("DELETE FROM `action_plan_recipient` WHERE `action_plan_id` = ".mysql_prep($action_plan_id));
		execute_query("DELETE FROM `action_plan` WHERE `action_plan_id` = ".mysql_prep($action_plan_id));
		return true;
	}else{
		return false;
	}
}
function action_plan_get($action_plan_id){
	$action_plan = ToArray(execute_query("SELECT * FROM `action_plan` WHERE `action_plan_id` = ".mysql_prep($action_plan_id)));
	$action_plan["recipient"] = ToArrays(execute_query("SELECT * FROM `action_plan_recipient` WHERE `action_plan_id` = ".mysql_prep($action_plan_id)));
	return $action_plan;
}
function action_plan_list($survey_id,$user_id){
	$actions=[];
	$action_plans = ToArrays(execute_query("SELECT * FROM `action_plan` 
	WHERE `survey_id`=".mysql_prep($survey_id)." AND `action_user_id`=".mysql_prep($user_id)." AND `account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
	foreach($action_plans as $action_plan){
			$action_plan["recipient"] = ToArrays(execute_query("SELECT * FROM `action_plan_recipient` WHERE `action_plan_id` = ".mysql_prep($action_plan["action_plan_id"])));
			$actions[]=$action_plan;
	}
	return $actions;
}
?>
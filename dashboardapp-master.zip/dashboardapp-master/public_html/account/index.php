<?php
include("../../includes/config.php");
redirect_to(PROTOCOL.WEBSITE_URL);
?>
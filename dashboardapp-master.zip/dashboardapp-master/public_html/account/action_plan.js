var selected_action_plan_id = 0;
var action_add_count=0;
var action_plan_user_score=0;
//Loggedin User Function
function action_plan_list() {
	$.get("action_plan.php?method=list&survey_id="+encodeURI(opened_survey_id), function(data) {
	var html = `
		<div class="card">
		<div class="card-header">
            <button type="button" 
			class="btn btn-secondary float-right ml-1" 
			onclick="action_plan_add()" >
			<i class="fa fa-plus" ></i>
			</button>
		</div>
		<div class="card-body table-responsive">
		<table id="action_table" class="table ">
		<thead>
			<tr>
			<th></th>
			<th style="width:40%;min-width:320px;">Action Plan</th>
			<th>Category</th>
			<th>Driver</th>
			<th>Target</th>
			<th>Manage</th>
			</tr></thead><tbody>`;
        for (var i = 0; i < data.action_plan.length; i++) {
            html+= `<tr>
			<td style="vertical-align: top;">`;
			if(data.action_plan[i]["action_category"]==="Manager"){
				html+= `<i id="action_mark_check_`+data.action_plan[i].action_plan_id+`" class="fas fa-plus p-2 mt-4" data-toggle="collapse" data-target="#action_recipient_list_`+data.action_plan[i].action_plan_id+`" aria-expanded="false" aria-controls="collapse");">`;
			}else{
				html+= `<i id="action_mark_check_`+data.action_plan[i].action_plan_id+`" class="far `+(data.action_plan[i].status=="Completed"?"fa-check-square text-success":"fa-square")+`  p-2  mt-4" onclick="action_mark(1,` + data.action_plan[i].action_plan_id + `);">`;
			}
			html+=`</td>
			<td><p class="font-weight-bold" id="action_text_` + data.action_plan[i].action_plan_id + `">` + data.action_plan[i].action_text+`</p>`;
			html+=`<p class="small" id="action_response_` + data.action_plan[i].action_plan_id+ `">` + data.action_plan[i].progress_text+`</p>`;
			html+=`<div class="collapse mt-2" id="action_recipient_list_`+data.action_plan[i].action_plan_id+`">`;
			if(data.action_plan[i]["action_category"]==="Manager"){
				for (var j = 0; j < data.action_plan[i].recipient.length; j++) {
					html+=`<i id="action_recipient_mark_check_`+data.action_plan[i].recipient[j].action_plan_recipient_id+`" class="far `+(data.action_plan[i].recipient[j].status=="Completed"?"fa-check-square  text-success":"fa-square")+` m-1  p-2" onclick="action_mark(2,` +data.action_plan[i].recipient[j].action_plan_recipient_id+ `,`+data.action_plan[i].action_plan_id+`);"></i> <span class="font-weight-bold" id="action_recipient_`+data.action_plan[i].recipient[j].action_plan_recipient_id+`" >`+data.action_plan[i].recipient[j].recipient_emp_id+`</span> <p class="small" id="action_recipient_response_` + data.action_plan[i].recipient[j].action_plan_recipient_id + `">` + data.action_plan[i].recipient[j].progress_text+`</p>`;
				}
			}
			html+=`</div></td>
			<td>` + data.action_plan[i]["action_category"] + `</td>
			<td>` + data.action_plan[i]["action_driver"] + `</td>
			<td>
			<!--<div title="Type" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["action_type"] + `</div>
			<div title="Intervention" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["intervention"] + `</div>-->
			<div title="Target Date" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["target_date"]  +`</div>`+`</td> 
			<td>`;
			if(data.action_plan[i].creator_user_id==user_session.user_id){
				html+=`<button type="button"
				class="btn btn-danger dropdown-toggle ml-1"
				data-toggle="dropdown">
					<i class="fas fa-trash" ></i>
				</button>
				<div class="dropdown-menu">
					<button class="dropdown-item"  
					onclick="action_plan_delete(` + data.action_plan[i]["action_plan_id"] + `)" >
					Confirm Delete?
					</button>
				</div>`;
			}
			html+=`</td>
			</tr>`;
        }
        html+= `</tbody>
		</table>
		</div>
	</div>`;
        document.getElementById("action_plan_manage").innerHTML = html;
		$('#action_table').DataTable({ visible: true,"paging": false,initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						if(column["0"]==2||column["0"]==3){
							var select = $('<br><select style="max-width:120px;"><option value=""></option></select>')
								.appendTo( $(column.header()) )
								.on( 'change', function () {
									var val = $.fn.dataTable.util.escapeRegex(
										$(this).val()
									);

									column
										.search( val ? '^'+val+'$' : '', true, false )
										.draw();
								} );

							column.data().unique().sort().each( function ( d, j ) {
								select.append( '<option value="'+d+'">'+d+'</option>' )
							} );
						}
					} );
				}
			});
		//Dashboard Data
		var html = `
		<div class="card">`;
		html = html + `<div class="card-body table-responsive">
		<div class="row">
		<div class="col-xl-4" ><canvas id="action_status_chart" style="min-height:240px;"></canvas></div>
		<div class="col-xl-8" ><canvas id="action_driver_chart"></canvas></div>
		</div>
		<table id="action_plan_dashboard_table" class="table "><thead><th>Employees</th></thead><tbody>`;
        for (var i = 0; i < data.action_plan_user.length; i++) {
            html = html + `<tr onclick="action_plan_user_list(` + data.action_plan_user[i]["user_id"] + `)"><td><div class="text-center"><span id="action_name_` + data.action_plan_user[i]["user_id"] + `" style="float:left;">` + data.action_plan_user[i]["name"] + `</span><span id="action_emp_id_` + data.action_plan_user[i]["user_id"] + `">`+data.action_plan_user[i]["id"]+ `</span><span id="action_email_` + data.action_plan_user[i]["user_id"] + `" style="float:right;">`+data.action_plan_user[i]["email"]+`</span></div><span>`;
			if(data.action_plan_user[i].total>0)
				html = html + `<div class="progress bg-secondary">
			  <div class="progress-bar bg-success" role="progressbar" style="width: `+Math.round(data.action_plan_user[i].completed*100/data.action_plan_user[i].total)+`%;" aria-valuenow="`+data.action_plan_user[i].completed+`" aria-valuemin="0" aria-valuemax="`+data.action_plan_user[i].total+`"> (`+data.action_plan_user[i].completed.toFixed(2)+`/ `+data.action_plan_user[i].total+`) `+Math.round(data.action_plan_user[i].completed*100/data.action_plan_user[i ].total)+`% </div>
			</div>`;
			else
				html = html + `No Action Plan Allocated`;
			html = html + `</span></td>
			</tr>`;
        }
        html = html + `</tbody>
		</table>
		</div>
	</div>`;
		document.getElementById("action_plan_dashboard").innerHTML=html;
		 $('#action_plan_dashboard_table').dataTable( {
			"paging": false
		} );
		if(data.action_plan_user.length<1)
			$("#action_plan_dashboard_tab").addClass("d-none");
		else 
			$("#action_plan_dashboard_tab").removeClass("d-none");
		action_plan_user_chart('action_status_chart',data.action_plan_user);
		action_plan_driver_chart('action_driver_chart',data.action_plan_driver);
	});
}
function action_plan_driver_chart(id,action_plan_driver){
	var incomplete=[];
		var completed=[];
		var label=[];
		for(var i=0;i<action_plan_driver.length;i++){
			if(action_plan_driver[i].action_category=='Manager')
				label.push('M'+" - "+action_plan_driver[i].action_driver);
			if(action_plan_driver[i].action_category=='Leader')
				label.push('L'+" - "+action_plan_driver[i].action_driver);
			if(action_plan_driver[i].action_category=='Organization')
				label.push('O'+" - "+action_plan_driver[i].action_driver);
			completed.push(action_plan_driver[i].completed);
			incomplete.push(action_plan_driver[i].total-action_plan_driver[i].completed);
		}
		var driver_ctx = document.getElementById(id).getContext('2d');
		var driver_chart= new Chart(driver_ctx, {
			type: 'bar',
			data: {
				labels: label,
				datasets: [{
					label: 'Incomplete',
					data: incomplete,
					backgroundColor: 'rgba(255, 99, 132, 0.8)',
					borderWidth: 0
				},{
					label: 'Competed',
					data: completed,
					backgroundColor: 'rgba(75, 192, 192, 0.8)',
					borderWidth: 0
				}]
			},
			options: {
				scales: {
					xAxes: [{
						stacked: true
					}],
					yAxes: [{
						stacked: true,
						ticks: {
							beginAtZero: true
						}
					}]
				}
			}
		});
}
function action_plan_user_chart(id,action_plan_user){
	var count=[0,0,0,0,0,0];
		var label=['Not Started','0-25%','25-50%','50-75%','75-100%','Completed'];
		for(var i=0;i<action_plan_user.length;i++){
			if(action_plan_user[i].total>0){
				if(action_plan_user[i].completed==0){
					count[0]++;
				}else if(action_plan_user[i].completed/action_plan_user[i].total<0.25){
					count[1]++;
				}else if(action_plan_user[i].completed/action_plan_user[i].total<0.5){
					count[2]++;
				}else if(action_plan_user[i].completed/action_plan_user[i].total<0.75){
					count[3]++;
				}else if(action_plan_user[i].completed/action_plan_user[i].total<0.9999999){
					count[4]++;
				}else{
					count[5]++;
				}
			}
		}
		var status_ctx = document.getElementById(id).getContext('2d');
		var status_chart = new Chart(status_ctx, {
			type: 'bar',
			data: {
				labels: label,
				datasets: [{
					label: 'Status',
					data: count,
					backgroundColor:'rgba(54, 162, 235, 0.8)',
					borderWidth: 0
				}]
			},
			options: {
				responsive: true,
				maintainAspectRatio: true,
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero: true
						}
					}]
				}
			}
		});
}
function action_plan_add() {
		$.get("action_plan.php?method=user_score&survey_id="+encodeURI(opened_survey_id), function(data) {
			action_plan_user_score=data;
			var manager_count = 0;
			var leader_count = 0;
			try{manager_count=data["MANAGER"].count}catch(err){}
			try{leader_count=data["LEADER"].count}catch(err){}
			document.getElementById("action_plan_manage").innerHTML=`<form class="mt-2" id="action_plan_form" action="action_plan.php" method="POST" onsubmit="action_plan_submit(); return false;" >
			<input class="form-control" name="method" type="hidden" value="add">
			<input class="form-control" name="survey_id" type="hidden" value="`+opened_survey_id+`">
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label>Action Category:</label>
						<select class="form-control" id="action_category" name="action_category" onchange="action_category_change()">
							<option>Manager</option>`
							+(leader_count>0?`<option>Leader</option>
							<option>Organization</option>`:``)+
						`</select>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label>Action Driver:</label>
						<select id="action_question_code" class="form-control" name="action_question_code" onchange="action_question_code_change(0)">
						</select>
						<input id="action_driver" name="action_driver" type="hidden">
						</select>
					</div>
				</div>
			</div>
			<div id="action_area">
			</div>
			<div class="row">
				<div class="col-sm-12 m-3 text-center">
					<button id="action_add_new_entry_button" class="btn btn-success  mx-auto d-none" type="button" onclick="action_add_new_entry('')" value="Add"><i class="fas fa-plus"></i></button>					
				</div>
			</div>
			<button class="btn btn-success" type="submit" name="submit" value="Add">Add All</button>
			<button class="btn btn-secondary" type="button" onclick="action_plan_list()">Back</button>
			</form>`;
			action_category_change();
		});	
}
function action_plan_submit() {
	$.ajax({
		url: '/account/action_plan.php', 
		type: 'POST',
		data: new FormData($('#action_plan_form')[0]),
		processData: false,
		contentType: false
	}).done(function(data){
		action_plan_list();
		snackbar("Data Saved");
	}).fail(function(){
		snackbar("Saving Failed");
	});
}
function action_plan_delete(action_plan_id) {
	$.get("action_plan.php?method=delete&action_plan_id="+action_plan_id, function( data ) {
		action_plan_list(opened_survey_id);
	});
}
function action_mark(type,id,parent_action_id=0){
	var action_plan = "";	
	var action_recipient = "";
	var progress_text="";
	if(type==1){
		action_plan = document.getElementById("action_text_"+id).innerHTML;
		progress_text = document.getElementById("action_response_"+id).innerHTML;
	}else{
		action_plan = document.getElementById("action_text_"+parent_action_id).innerHTML;
		action_recipient = document.getElementById("action_recipient_"+id).innerHTML;
		progress_text = document.getElementById("action_recipient_response_"+id).innerHTML;
	}
	var html = action_plan+`<br>`+(action_recipient!=""?"For: <b>"+action_recipient+"</b><br>":"")+`
	<form id="action_mark_form" action="/account/action_plan.php" method="POST" onsubmit="action_mark_submit();  return false;" >`;
		if(type==1)
			html +=`<input type="hidden" name="action_plan_id" value="`+id+`">`;
		else if(type==2)
			html +=`<input type="hidden" name="action_plan_recipient_id" value="`+id+`">`;
		html +=`<input type="hidden" name="method" value="mark">
		<div class="form-group mt-3">
			<label>Describe how you resolved this in at least 50 words</label>
			<textarea style="height:240px;" class="form-control" id="progress_text" name="progress_text" required>`+progress_text+`</textarea>
		</div>
		<div class="form-group mt-3">
			<select id="action_status" name="status" class="form-control">
				<option selected="selected" value="Completed">Completed</option>
				<option  value="In Progress">In Progress</option>
			</select>
		</div>
		<p id="action_modal_message" class="text-danger" ></p>
		<button type="submit" value="save" class="btn btn-success m-3">Save</button>
		
	</form>`;
	modal('Mark Action Status',html);
}

function action_mark_submit(){
	var progress_text =  $("#progress_text").val();
	var action_status =  $("#action_status").val();
	if(action_status=="Completed"&&progress_text.length>=300||action_status=="In Progress"){
		$.ajax({
			url: '/account/action_plan.php', 
			type: 'POST',
			data: new FormData($('#action_mark_form')[0]),
			processData: false,
			contentType: false
		}).done(function(data){
			if(data.hasOwnProperty("action_plan_recipient_id")){
				$("#action_recipient_mark_check_"+data.action_plan_recipient_id).removeClass();
				if(data.status=="Completed"){
					$("#action_recipient_mark_check_"+data.action_plan_recipient_id).addClass("far fa-check-square text-success m-1  p-2 ");
				}else{
					$("#action_recipient_mark_check_"+data.action_plan_recipient_id).addClass("far fa-square m-1  p-2 ");
				}
				$("#action_recipient_response_"+data.action_plan_recipient_id).html(data.progress_text);
			}else{
				$("#action_mark_check_"+data.action_plan_id).removeClass();
				if(data.status=="Completed"){
					$("#action_mark_check_"+data.action_plan_id).addClass("far fa-check-square text-success mt-4 p-2 ");
				}else{
					$("#action_mark_check_"+data.action_plan_id).addClass("far fa-square mt-4 p-2 ");
				}
				$("#action_response_"+data.action_plan_id).html(data.progress_text);
			}
			$('#modal').modal('hide');
			snackbar("Data Saved");
		}).fail(function(){
			snackbar("Saving Failed");
		});
	}else{
		$("#action_modal_message").html("'Completed' status requires atleast 300 chars. You have written "+progress_text.length+" chars. Write more or save it as 'In Progress'");
	}
}
//Loggedin User Dashboard Functions
function action_plan_user_list(user_id){
	$.get("action_plan.php?method=list&user_id="+user_id+"&survey_id="+encodeURI(opened_survey_id), function(data) {
		var html = `<div id="action_plan_user_manage">
		<div class="card">
		<div class="card-header">
			<button type="button" 
			class="btn btn-secondary float-right ml-1" 
			onclick="action_plan_user_add(`+user_id+`)" >
			<i class="fa fa-plus" ></i>
			</button>
		</div><div class="card-body table-responsive">
			<div class="row">`;
		if(data.action_plan_user.length>0&&data.action_plan_driver.length>0){
			html+= `
			<div class="col-xl-4" ><canvas id="action_status_chart_`+user_id+`" style="min-height:240px;"></canvas></div>
			<div class="col-xl-8" ><canvas id="action_driver_chart_`+user_id+`"></canvas></div>`;
		}
		html+= `<div class="col-xl-12"><table id="action_user_table" class="table ">
		<thead>
			<tr>
			<th></th>
			<th style="width:40%;min-width:320px;">Action Plan</th>
			<th>Category</th>
			<th>Driver</th>
			<th>Target</th>
			<th>Manage</th>
			</tr></thead><tbody>`;
		for (var i = 0; i < data.action_plan.length; i++) {
			html+= `<tr>
			<td style="vertical-align: top;">`;
			if(data.action_plan[i]["action_category"]==="Manager"){
				html+= `<i id="action_mark_check_`+data.action_plan[i].action_plan_id+`" class="fas fa-plus p-2 mt-4" data-toggle="collapse" data-target="#action_recipient_list_`+data.action_plan[i].action_plan_id+`" aria-expanded="false" aria-controls="collapse");">`;
			}else{
				html+= `<i id="action_mark_check_`+data.action_plan[i].action_plan_id+`" class="far `+(data.action_plan[i].status=="Completed"?"fa-check-square text-success":"fa-square")+`  p-2  mt-4">`;
			}
			html+=`</td>
			<td><p class="font-weight-bold" id="action_text_` + data.action_plan[i].action_plan_id + `">` + data.action_plan[i].action_text+`</p>`;
			html+=`<p class="small" id="action_response_` + data.action_plan[i].action_plan_id+ `">` + data.action_plan[i].progress_text+`</p>`;
			html+=`<div class="collapse mt-2" id="action_recipient_list_`+data.action_plan[i].action_plan_id+`">`;
			if(data.action_plan[i]["action_category"]==="Manager"){
				for (var j = 0; j < data.action_plan[i].recipient.length; j++) {
					html+=`<i id="action_recipient_mark_check_`+data.action_plan[i].recipient[j].action_plan_recipient_id+`" class="far `+(data.action_plan[i].recipient[j].status=="Completed"?"fa-check-square  text-success":"fa-square")+` m-1  p-2" ></i> <span class="font-weight-bold" id="action_recipient_`+data.action_plan[i].recipient[j].action_plan_recipient_id+`" >`+data.action_plan[i].recipient[j].recipient_emp_id+`</span> <p class="small" id="action_recipient_response_` + data.action_plan[i].recipient[j].action_plan_recipient_id + `">` + data.action_plan[i].recipient[j].progress_text+`</p>`;
				}
			}
			html+=`</div></td>
			<td>` + data.action_plan[i]["action_category"] + `</td>
			<td>` + data.action_plan[i]["action_driver"] + `</td>
			<td>
			<!--<div title="Type" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["action_type"] + `</div>
			<div title="Intervention" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["intervention"] + `</div>-->
			<div title="Target Date" data-toggle="tooltip" data-placement="left">` + data.action_plan[i]["target_date"]  +`</div>`+`</td> 
			<td>`;
			if(data.action_plan[i].creator_user_id==user_session.user_id){
				html+=`<button type="button"
				class="btn btn-danger dropdown-toggle ml-1"
				data-toggle="dropdown">
					<i class="fas fa-trash" ></i>
				</button>
				<div class="dropdown-menu">
					<button class="dropdown-item"  
					onclick="action_plan_user_delete(` + data.action_plan[i]["action_plan_id"] + `,`+data.action_plan[i].action_user_id+`)" >
					Confirm Delete?
					</button>
				</div>`;
			}
			html+=`</td>
			</tr>`;
		}
		html+= `</tbody>
		</table>
		</div>
		</div>
		</div>
	</div>
	</div>`;
		var name = document.getElementById('action_name_'+user_id).innerHTML;
		var emp_id = document.getElementById('action_emp_id_'+user_id).innerHTML;
		var email = document.getElementById('action_email_'+user_id).innerHTML;
		modal(name+"("+emp_id+") "+email ,html);
		$('#action_user_table').DataTable({ visible: true,"paging": false,initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						if(column["0"]==2||column["0"]==3){
							var select = $('<br><select style="max-width:120px;"><option value=""></option></select>')
								.appendTo( $(column.header()) )
								.on( 'change', function () {
									var val = $.fn.dataTable.util.escapeRegex(
										$(this).val()
									);

									column
										.search( val ? '^'+val+'$' : '', true, false )
										.draw();
								} );

							column.data().unique().sort().each( function ( d, j ) {
								select.append( '<option value="'+d+'">'+d+'</option>' )
							} );
						}
					} );
				}
		 });
		 if(data.action_plan_user.length>0&&data.action_plan_driver.length>0){
			action_plan_user_chart('action_status_chart_'+user_id,data.action_plan_user);
			action_plan_driver_chart('action_driver_chart_'+user_id,data.action_plan_driver);
		 }			
	});
}
function action_plan_user_add(user_id) {
		$.get("action_plan.php?method=user_score&user_id="+user_id+"&survey_id="+encodeURI(opened_survey_id), function(data) {
			action_plan_user_score=data;
			var manager_count = 0;
			var leader_count = 0;
			var hr_count =0;
			try{manager_count=data.MANAGER.employee_list.length}catch(err){}
			try{leader_count=data.LEADER.employee_list.length}catch(err){}
			try{hr_count=data.HR.employee_list.length}catch(err){}
			var html = `<form class="mt-2" id="action_plan_user_form" action="action_plan.php" method="POST" onsubmit="action_plan_user_submit(); return false;" >
			<input class="form-control" name="method" type="hidden" value="add">
			<input class="form-control" name="survey_id" type="hidden" value="`+opened_survey_id+`">
			<input id="action_user_id" class="form-control" name="user_id" type="hidden" value="`+user_id+`">
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label>Action Category:</label>
						<select class="form-control" id="action_category" name="action_category" onchange="action_category_change()">`
							+(manager_count>0?`<option>Manager</option>`:``)
							+(leader_count>0?`<option>Leader</option><option>Organization</option>`:``)
							+(hr_count>0?`<option>HR</option>`:``)+
						`</select>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label>Action Driver:</label>
						<select id="action_question_code" class="form-control" name="action_question_code" onchange="action_question_code_change(`+user_id+`)">
						</select>
						<input id="action_driver" name="action_driver" type="hidden">
						</select>
					</div>
				</div>
			</div>
			<div id="action_area">
			</div>
			<div class="row">
				<div class="col-sm-12 m-3 text-center">
					<button id="action_add_new_entry_button" class="btn btn-success  mx-auto d-none" type="button" onclick="action_add_new_entry('')" value="Add"><i class="fas fa-plus"></i></button>					
				</div>
			</div>
			<button class="btn btn-success" type="submit" name="submit" value="Add">Add All</button>
			</form>`;
			document.getElementById("action_plan_user_manage").innerHTML=html;
			action_category_change();
		});
}
function action_plan_user_submit() {
	var user_id=document.getElementById('action_user_id').value;
	$.ajax({
		url: '/account/action_plan.php', 
		type: 'POST',
		data: new FormData($('#action_plan_user_form')[0]),
		processData: false,
		contentType: false
	}).done(function(data){
		snackbar("Data Saved");
		$('#modal').modal('hide');
		action_plan_user_list(user_id);
		action_plan_list();
	}).fail(function(){
		snackbar("Saving Failed");
	});
}
function action_plan_user_delete(action_plan_id,user_id) {
	$.get("action_plan.php?method=delete&action_plan_id="+action_plan_id, function( data ) {
		$('#modal').modal('hide');
		action_plan_user_list(user_id);
		action_plan_list(opened_survey_id);
	});
}
function survey_action_plan_push(){
	var verification = prompt("This will add the action plan based on the survey responses.\r\nPlease perform this action after the survey is closed.\r\nPlease type \"I confirm that the survey is closed\" in the below input box", "");
	if (verification == "I confirm that the survey is closed") {
		$.get("/account/action_plan.php?method=action_bulk_assign&survey_id="+opened_survey_id, function( data ) {
			snackbar(data.message);
		});
	}else{
		snackbar("Incorrect Text");
	}
	
}
//Common Functions
function action_category_change(){
	var action_category = document.getElementById('action_category').value;
	if(action_category=="Manager"){
		var score =action_plan_user_score.MANAGER.score;
						var html = `<option disabled selected="selected">Select</option><optgroup label="Manager">`;
						if(typeof score.MANAGER01 !== 'undefined')
						html +=`<option value="MANAGER01" style="color:`+(score.MANAGER01>=75?"#4caf50":(score.MANAGER01>=55?"#ffc107":"#f44336"))+`">Goal Setting (`+Math.round(score.MANAGER01)+`)</option>`;
						if(typeof score.MANAGER02 !== 'undefined')
						html +=`<option value="MANAGER02" style="color:`+(score.MANAGER02>=75?"#4caf50":(score.MANAGER02>=55?"#ffc107":"#f44336"))+`">Allignment of goals (`+Math.round(score.MANAGER02)+`)</option>`;
						if(typeof score.MANAGER03 !== 'undefined')
						html +=`<option value="MANAGER03" style="color:`+(score.MANAGER03>=75?"#4caf50":(score.MANAGER03>=55?"#ffc107":"#f44336"))+`">Feedback (`+Math.round(score.MANAGER03)+`)</option>`;
						if(typeof score.MANAGER04 !== 'undefined')
						html +=`<option value="MANAGER04" style="color:`+(score.MANAGER04>=75?"#4caf50":(score.MANAGER04>=55?"#ffc107":"#f44336"))+`">Resources (`+Math.round(score.MANAGER04)+`)</option>`;
						if(typeof score.MANAGER05 !== 'undefined')
						html +=`<option value="MANAGER05" style="color:`+(score.MANAGER05>=75?"#4caf50":(score.MANAGER05>=55?"#ffc107":"#f44336"))+`">Appreciation and Recognition (`+Math.round(score.MANAGER05)+`)</option>`;
						if(typeof score.MANAGER06 !== 'undefined')
						html +=`<option value="MANAGER06" style="color:`+(score.MANAGER06>=75?"#4caf50":(score.MANAGER06>=55?"#ffc107":"#f44336"))+`">Diversity of Thought (`+Math.round(score.MANAGER06)+`)</option>`;
						if(typeof score.MANAGER07 !== 'undefined')
						html +=`<option value="MANAGER07" style="color:`+(score.MANAGER07>=75?"#4caf50":(score.MANAGER07>=55?"#ffc107":"#f44336"))+`">Care (`+Math.round(score.MANAGER07)+`)</option>`;
						if(typeof score.MANAGER08 !== 'undefined')
						html +=`<option value="MANAGER08" style="color:`+(score.MANAGER08>=75?"#4caf50":(score.MANAGER08>=55?"#ffc107":"#f44336"))+`">Learn and Grow (`+Math.round(score.MANAGER08)+`)</option>`;
						if(typeof score.MANAGER09 !== 'undefined')
						html +=`<option value="MANAGER09" style="color:`+(score.MANAGER09>=75?"#4caf50":(score.MANAGER09>=55?"#ffc107":"#f44336"))+`">Coaching (`+Math.round(score.MANAGER09)+`)</option>`;
						if(typeof score.MANAGER10 !== 'undefined')
						html +=`<option value="MANAGER10" style="color:`+(score.MANAGER10>=75?"#4caf50":(score.MANAGER10>=55?"#ffc107":"#f44336"))+`">Positive Team (`+Math.round(score.MANAGER10)+`)</option>`;
						html +=`</optgroup>`;
						document.getElementById('action_question_code').innerHTML =html;
	}else if(action_category=="Leader"){
		var score =action_plan_user_score.LEADER.score;
				var html =`<option disabled selected="selected">Select</option><optgroup label="Leader">`;
						if(typeof score.LEADER01 !== 'undefined')
							html +=`<option value="LEADER01" style="color:`+(score.LEADER01>=75?"#4caf50":(score.LEADER01>=55?"#ffc107":"#f44336"))+`">Business Confidence (`+Math.round(score.LEADER01)+`)</option>`;
						if(typeof score.LEADER02 !== 'undefined')
							html +=`<option value="LEADER02" style="color:`+(score.LEADER02>=75?"#4caf50":(score.LEADER02>=55?"#ffc107":"#f44336"))+`">Direction (`+Math.round(score.LEADER02)+`)</option>`;
						if(typeof score.LEADER03 !== 'undefined')
							html +=`<option value="LEADER03" style="color:`+(score.LEADER03>=75?"#4caf50":(score.LEADER03>=55?"#ffc107":"#f44336"))+`">Communication (`+Math.round(score.LEADER03)+`)</option>`;
						if(typeof score.LEADER04 !== 'undefined')
							html +=`<option value="LEADER04" style="color:`+(score.LEADER04>=75?"#4caf50":(score.LEADER04>=55?"#ffc107":"#f44336"))+`">Purpose (`+Math.round(score.LEADER04)+`)</option>`;
						if(typeof score.LEADER05 !== 'undefined')
							html +=`<option value="LEADER05" style="color:`+(score.LEADER05>=75?"#4caf50":(score.LEADER05>=55?"#ffc107":"#f44336"))+`">People Focus (`+Math.round(score.LEADER05)+`)</option>`;
						if(typeof score.LEADER06 !== 'undefined')
							html +=`<option value="LEADER06" style="color:`+(score.LEADER06>=75?"#4caf50":(score.LEADER06>=55?"#ffc107":"#f44336"))+`">Customer Centricity (`+Math.round(score.LEADER06)+`)</option>`;
						if(typeof score.LEADER07 !== 'undefined')
							html +=`<option value="LEADER07" style="color:`+(score.LEADER07>=75?"#4caf50":(score.LEADER07>=55?"#ffc107":"#f44336"))+`">Accountability (`+Math.round(score.LEADER07)+`)</option>`;
					html +=`</optgroup>`;
				document.getElementById('action_question_code').innerHTML = html;
	}else if(action_category=="Organization"){
		var score =action_plan_user_score.LEADER.score;
		var html = `<option disabled selected="selected">Select</option><optgroup label="Organization - Well Being">`;
						if(typeof score.WB01 !== 'undefined')
						html +=`<option value="WB01" style="color:`+(score.WB01>=75?"#4caf50":(score.WB01>=55?"#ffc107":"#f44336"))+`">Health (`+Math.round(score.WB01)+`)</option>`;
						if(typeof score.WB02 !== 'undefined')
						html +=`<option value="WB02" style="color:`+(score.WB02>=75?"#4caf50":(score.WB02>=55?"#ffc107":"#f44336"))+`">Diet & Rest (`+Math.round(score.WB02)+`)</option>`;
						if(typeof score.WB03 !== 'undefined')
						html +=`<option value="WB03" style="color:`+(score.WB03>=75?"#4caf50":(score.WB03>=55?"#ffc107":"#f44336"))+`">Anxiety and Depression (`+Math.round(score.WB03)+`)</option>`;
						if(typeof score.WB04 !== 'undefined')
						html +=`<option value="WB04" style="color:`+(score.WB04>=75?"#4caf50":(score.WB04>=55?"#ffc107":"#f44336"))+`">Transaction Management (`+Math.round(score.WB04)+`)</option>`;
						if(typeof score.WB05 !== 'undefined')
						html +=`<option value="WB05" style="color:`+(score.WB05>=75?"#4caf50":(score.WB05>=55?"#ffc107":"#f44336"))+`">Financial Planning (`+Math.round(score.WB05)+`)</option>`;
						if(typeof score.WB06 !== 'undefined')
						html +=`<option value="WB06" style="color:`+(score.WB06>=75?"#4caf50":(score.WB06>=55?"#ffc107":"#f44336"))+`">Best Friend (`+Math.round(score.WB06)+`)</option>`;
						if(typeof score.WB07 !== 'undefined')
						html +=`<option value="WB07" style="color:`+(score.WB07>=75?"#4caf50":(score.WB07>=55?"#ffc107":"#f44336"))+`">Family time (`+Math.round(score.WB07)+`)</option>`;
						if(typeof score.WB08 !== 'undefined')
						html +=`<option value="WB08" style="color:`+(score.WB08>=75?"#4caf50":(score.WB08>=55?"#ffc107":"#f44336"))+`">Rejuvenation (`+Math.round(score.WB08)+`)</option>`;
					html +=`</optgroup>
					<optgroup label="Organization - Work from home">`;
						if(typeof score.WFH01 !== 'undefined')
						html +=`<option value="WFH01" style="color:`+(score.WFH01>=75?"#4caf50":(score.WFH01>=55?"#ffc107":"#f44336"))+`">Technology Tools and Internet Bandwidth (`+Math.round(score.WFH01)+`)</option>`;
						if(typeof score.WFH02 !== 'undefined')
						html +=`<option value="WFH02" style="color:`+(score.WFH02>=75?"#4caf50":(score.WFH02>=55?"#ffc107":"#f44336"))+`">Workspace at Home (`+Math.round(score.WFH02)+`)</option>`;
						if(typeof score.WFH03 !== 'undefined')
						html +=`<option value="WFH03" style="color:`+(score.WFH03>=75?"#4caf50":(score.WFH03>=55?"#ffc107":"#f44336"))+`">Online Work Processes (`+Math.round(score.WFH03)+`)</option>`;
						if(typeof score.WFH04 !== 'undefined')
						html +=`<option value="WFH04" style="color:`+(score.WFH04>=75?"#4caf50":(score.WFH04>=55?"#ffc107":"#f44336"))+`">Motivation & Focus (`+Math.round(score.WFH04)+`)</option>`;
						if(typeof score.WFH05 !== 'undefined')
						html +=`<option value="WFH05" style="color:`+(score.WFH05>=75?"#4caf50":(score.WFH05>=55?"#ffc107":"#f44336"))+`">Remote Team Discussion (`+Math.round(score.WFH05)+`)</option>`;
						if(typeof score.WFH06 !== 'undefined')
						html +=`<option value="WFH06" style="color:`+(score.WFH06>=75?"#4caf50":(score.WFH06>=55?"#ffc107":"#f44336"))+`">Remote Client/Vendor meetings (`+Math.round(score.WFH06)+`)</option>`;
					html +=`</optgroup>`;
					document.getElementById('action_question_code').innerHTML =html;
	}else if(action_category=="HR"){
		var score =action_plan_user_score.HR.score;
		var html = `<option disabled selected="selected">Select</option><optgroup label="HR">`;
						if(typeof score.HR01 !== 'undefined')
						html +=`<option value="HR01" style="color:`+(score.HR01>=75?"#4caf50":(score.HR01>=55?"#ffc107":"#f44336"))+`">Performance Management (`+Math.round(score.HR01)+`)</option>`;
						if(typeof score.HR02 !== 'undefined')
						html +=`<option value="HR02" style="color:`+(score.HR02>=75?"#4caf50":(score.HR02>=55?"#ffc107":"#f44336"))+`">Work Tasks (`+Math.round(score.HR02)+`)</option>`;
						if(typeof score.HR03 !== 'undefined')
						html +=`<option value="HR03" style="color:`+(score.HR03>=75?"#4caf50":(score.HR03>=55?"#ffc107":"#f44336"))+`">Learning and Development (`+Math.round(score.HR03)+`)</option>`;
						if(typeof score.HR04 !== 'undefined')
						html +=`<option value="HR04" style="color:`+(score.HR04>=75?"#4caf50":(score.HR04>=55?"#ffc107":"#f44336"))+`">Career Opportunities (`+Math.round(score.HR04)+`)</option>`;
						if(typeof score.HR05 !== 'undefined')
						html +=`<option value="HR05" style="color:`+(score.HR05>=75?"#4caf50":(score.HR05>=55?"#ffc107":"#f44336"))+`">Pay-Performance Linkage (`+Math.round(score.HR05)+`)</option>`;
						if(typeof score.HR06 !== 'undefined')
						html +=`<option value="HR06" style="color:`+(score.HR06>=75?"#4caf50":(score.HR06>=55?"#ffc107":"#f44336"))+`">Benefits	 (`+Math.round(score.HR06)+`)</option>`;
						if(typeof score.HR07 !== 'undefined')
						html +=`<option value="HR07" style="color:`+(score.HR07>=75?"#4caf50":(score.HR07>=55?"#ffc107":"#f44336"))+`">People/HR practices (`+Math.round(score.HR07)+`)</option>`;
						if(typeof score.HR08 !== 'undefined')
						html +=`<option value="HR08" style="color:`+(score.HR08>=75?"#4caf50":(score.HR08>=55?"#ffc107":"#f44336"))+`">Brand (`+Math.round(score.HR08)+`)</option>`;
						if(typeof score.HR09 !== 'undefined')
						html +=`<option value="HR09" style="color:`+(score.HR09>=75?"#4caf50":(score.HR09>=55?"#ffc107":"#f44336"))+`">Delivery on Promise	 (`+Math.round(score.HR09)+`)</option>`;
						if(typeof score.HR10 !== 'undefined')
						html +=`<option value="HR10" style="color:`+(score.HR10>=75?"#4caf50":(score.HR10>=55?"#ffc107":"#f44336"))+`">Empathy HR (`+Math.round(score.HR10)+`)</option>`;
						if(typeof score.HR12 !== 'undefined')
						html +=`<option value="HR12" style="color:`+(score.HR12>=75?"#4caf50":(score.HR12>=55?"#ffc107":"#f44336"))+`">PMS (`+Math.round(score.HR12)+`)</option>`;
					html +=`</optgroup>`;
					document.getElementById('action_question_code').innerHTML = html;
	}
	document.getElementById('action_area').innerHTML="";
	$('#action_add_new_entry_button').addClass("d-none");
}
function action_question_code_change(user_id){
		document.getElementById('action_driver').value = $( "#action_question_code option:selected" ).text().replace(/\([^\)]*\)/i,'').trim();
		var action_question_code = document.getElementById('action_question_code').value;
		var action_category = document.getElementById('action_category').value;
		document.getElementById('action_area').innerHTML="";
		$.get("/account/action_plan.php?method=action_template&action_question_code="+action_question_code+"&action_category="+action_category+"&survey_id="+opened_survey_id+(user_id>0?"&user_id="+user_id:""), function( data ) {
			action_add_count=1;
			var html="";
			for(var i in data){
				action_add_new_entry(data[i].action_text,data[i].action_template_id,"Process","Start","");
			}
			action_add_new_entry("",0,"Process","Start","");
			$('#action_add_new_entry_button').removeClass("d-none");
		});
}
function action_add_new_entry(text,action_template_id="0",intervention="",action_type="",target_date=""){
	if(action_template_id=="0"){
		action_template_id= -1024 - Math.floor(Math.random()*(1048576*1048576));
	}
	var html=`<div id="template_`+action_template_id+`" class="row"> <div class="col-sm-12 col-md-8">
					<div class="form-group">
						<label>Action Text:</label>
						<textarea style="height:100px;" class="form-control" name="action_text_`+action_add_count+`" type="text" value="">`+text+`</textarea>
						<input type="hidden" name="action_template_id_`+action_add_count+`"  value="`+action_template_id+`">
					</div>
					</div>
					<!--<div class="col-sm-6 col-md-2">
					<div class="form-group">
						<label>Intervention:</label>
						<select class="form-control" name="intervention_`+action_add_count+`">
							<option>Process</option>
							<option>Behavior</option>
							<option>Skill</option>
							<option>Technology</option>
							<option>Communication</option>
						</select>
						</div>
					</div>
					<div class="col-sm-6 col-md-2">
					<div class="form-group">
						<label>Action Type:</label>
						<select class="form-control" name="action_type_`+action_add_count+`">
							<option>Start</option>
							<option>Stop</option>
							<option>Continue</option>
							<option>Improve</option>
						</select>
					</div>
					</div>-->
					<div class="col-sm-12 col-md-3">
					<div class="form-group">
						<label>Target Date:</label>
						<div class="input-group date" id="target_date_`+action_add_count+`" data-target-input="nearest">
							<input type="text" name="target_date_`+action_add_count+`" class="form-control datetimepicker-input" data-target="#target_date_`+action_add_count+`"  data-toggle="datetimepicker"/>
							<div class="input-group-append" data-target="#target_date_`+action_add_count+`" data-toggle="datetimepicker">
								<div class="input-group-text"><i class="fa fa-calendar"></i></div>
							</div>
						</div>  
					</div>
					</div>
					<div class="col-sm-12 col-md-1 mt-2">
						<button class="btn btn-danger mt-4" type="button" onclick="remove_template('template_`+action_template_id+`')" ><i class="fas fa-trash"></i></button>
					</div>
					</div>`; 
					document.getElementById('action_area').insertAdjacentHTML('beforeend', html);
					var target = new Date(new Date().getTime() + (56 * 24 * 60 * 60 * 1000));
					$('#target_date_'+action_add_count).datetimepicker({
						viewMode: 'years',
						format: 'YYYY-MM-DD',
						defaultDate: target
					});
					action_add_count++;
}
function remove_template(id){
	document.getElementById(id).innerHTML = '';
}

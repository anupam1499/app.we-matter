<?php
include("../../includes/config.php");
//include("download.php");
// error_reporting(E_ALL);
// ini_set('display_errors', '1');

confirm_logged_in();
$title="Survey";
$method="manage";
if(isset($_REQUEST["method"]))
	$method = $_REQUEST["method"];




$output="html";
if(isset($_REQUEST["output"]))
	$output=$_REQUEST["output"];
if(!in_array($method,array("manage","view","add")))
{
	$survey_temp = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id`=".mysql_prep($_REQUEST["survey_id"])));
	$permission = ToArray(execute_query("SELECT count(*) AS permission FROM `survey_mapping` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `user_id` = ".mysql_prep($_SESSION["user_id"]).";"))["permission"];
	
	if($survey_temp["user_id"]!=$_SESSION["user_id"]&&$permission<1&&$_SESSION["role_selected"]["role_id"]!="1"&&$_SESSION["role_selected"]["role_id"]!="2")
    {
		if($output==="json"){
			json_message("Unauthorized Access");
		}
      	else{
			echo "<center>Unauthorized Access</center>";
			exit(0);
		}
	}
}

if($method==="view"){
	$page=0;
	if(isset($_REQUEST["page"]))
		$page=$_REQUEST["page"];

	$q="";
	if(isset($_REQUEST["q"]))
		$q=$_REQUEST["q"];

	$surveys = survey_list($q,$page);
	$survey_count = survey_count($q);
	if($output==="json"){
		$response["total"] = $survey_count;
		$response["survey"] = $surveys;
		json_output($response);
	}else{
	?>
	<div class="card card-primary">
		<div class="card-heading">
            <?php 
			if($_SESSION["role_selected"]["role_id"]==="1"){
			?>
				<button type="button" class="btn btn-secondary float-right ml-1" onclick="survey_add()" ><i class="fa fa-plus" ></i></button>
			<?php
			}
			?>
			<?php
			if((($page+1)*12)<$survey_count)
               echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"survey_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
		    echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
			if($page!=0)
               echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"survey_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
			?>
		<form class="form-inline" action="" onsubmit="return false;">
            <div class="input-group">
                <input id="survey_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo htmlspecialchars($q);?>" onkeypress="if(event.keyCode==13) survey_view(0);">
                <span class="input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="survey_view(0)" ><i class="fa fa-search" ></i></button>
                </span>
            </div>
			</form>
		</div>
		<table class="table">
			<tr>
			<th>Survey Name </th>
			<th align="right" style="text-align: right;">Manage</th>
			</tr>
				<?php
					foreach($surveys as $survey){

						echo "\n<tr><td onclick=\"survey_edit(".$survey["survey_id"]."); survey_editComparator(".$survey["survey_id"]."); \" >".$survey["survey_name"]."</td><td align=\"right\" >\n";
						echo "<button class=\"btn btn-secondary ml-1\" title=\"Edit\" type=\"button\" onclick=\"survey_edit(".$survey["survey_id"]."); survey_editComparator(".$survey["survey_id"]."); \" ><i class=\"fa fa-arrow-right\" ></i></button>";
						
					
						
						if($survey["user_id"]===$_SESSION["user_id"]){
							echo "<button class=\"btn btn-secondary ml-1\" title=\"Process\" type=\"button\" onclick=\"survey_process(".$survey["survey_id"].")\" ><i class=\"fa fa-cog\" ></i></button>";
						echo "<button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">

								<i class=\"fas fa-trash\" ></i>
							  </button>
							  <div class=\"dropdown-menu\">
								<button class=\"dropdown-item\"  onclick=\"survey_delete(".$survey["survey_id"].")\" >Confirm Delete?</button>
							  </div>";
							echo "\n</td></tr>\n";
						}
					}
				?>
		</table>
	</div>
	<?php
	exit(0);
	}
}

else if($method==="add"){
	if(isset($_REQUEST["submit"],$_REQUEST["survey_name"],$_REQUEST["survey_group"])&&$_SESSION["role_selected"]["role_id"]==="1"){
		if(isset($_REQUEST["ENGAGE"])){
			$module["name"]="Engagement";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/ENGAGE.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["LEADER"])){
			$module["name"]="Leadership";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/LEADER.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["MANAGER"])){
			$module["name"]="Manager 1";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/MANAGER01.lsg'));
			$modules[] = $module;
			
			$module["name"]="Manager 2";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/MANAGER02.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["HR"])){
			$module["name"]="HR 1";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/HR01.lsg'));
			$modules[] = $module;
			
			$module["name"]="HR 2";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/HR02.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["WB"])){
			$module["name"]="Well Being 1";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/WB01.lsg'));
			$modules[] = $module;
			
			$module["name"]="Well Being 2";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/WB02.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["WFH"])){
			$module["name"]="Work From Home";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/WFH.lsg'));
			$modules[] = $module;
		}
		if(isset($_REQUEST["OPEN"])){
			$module["name"]="Open";
			$module["description"]="";
			$module["data"]=base64_encode(file_get_contents(ROOT_DIRECTORY.'/includes/question_group/OPEN.lsg'));
			$modules[] = $module;
		}
		$survey = survey_add($_REQUEST["survey_name"],$_REQUEST["survey_group"],$modules);
		if($output==="json"){
			json_output($survey);
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("submit,survey_name,survey_group,account_id,user_id are required variable");
		}else{
			?><form id="survey_form" action="survey.php" method="POST" onsubmit="survey_submit();return false;">
			<input class="form-control" name="method" type="hidden" value="add">
			<div class="form-group">
				<label>Survey Name:</label>
				<input class="form-control" id="survey_name" name="survey_name" type="text" placeholder="Type your Survey Name here" value="" required>
			</div>
			<div class="form-group">
				<label>Survey Group:</label>
				<select class="form-control" name="survey_group">
					<option value="Employee Satisfaction">Employee Satisfaction</option>
					<option value="Customer Satisfaction">Customer Satisfaction</option>
					<option value="Others">Others</option>
				</select>
				<!--<input class="form-control" name="survey_group" type="text" placeholder="Survey Group" value="" required>-->
			</div>
			<div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="ENGAGE" name="ENGAGE" checked>
				<label class="custom-control-label" for="ENGAGE">Engagement</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="LEADER" name="LEADER" checked>
				<label class="custom-control-label" for="LEADER">Leadership</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="MANAGER" name="MANAGER" checked>
				<label class="custom-control-label" for="MANAGER">Manager</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="WB" name="WB" checked>
				<label class="custom-control-label" for="WB" >Well Being</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="HR" name="HR" checked>
				<label class="custom-control-label" for="HR" >HR</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="WFH" name="WFH" checked>
				<label class="custom-control-label" for="WFH" >Work from House</label>
			  </div>
			  <div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="OPEN" name="OPEN" checked>
				<label class="custom-control-label" for="OPEN" >Open Ended</label>
			  </div>
			<!--<div class="form-group">
				<label>Account Id:</label>
				<input class="form-control" name="account_id" type="text" placeholder="Account Id" value="" required>
				</div>
			<div class="form-group">
				<label>User Id:</label>
				<input class="form-control" name="user_id" type="text" placeholder="User Id" value="" required>
				</div>-->
			<input type="hidden" name="submit" value="Add" />
			<div class="form-group">
			<button class="btn btn-success" type="submit" >Add</button>
			<button class="btn btn-default" type="button" onclick="survey_view(survey_page)">Back</button>
			</div>
			</form><?php
			exit(0);
		}
	}
}
else if($method==="edit"){
	if(isset($_REQUEST["submit"],$_REQUEST["survey_id"],$_REQUEST["survey_name"],$_REQUEST["survey_group"])&&$_SESSION["role_selected"]["role_id"]){
		$survey = survey_edit($_REQUEST["survey_id"],$_REQUEST["sync_frequency"],$_REQUEST["scorecard"],$_REQUEST["dashboard"],$_REQUEST["dashboard_qualitative"],$_REQUEST["dashboard_diagnostic"],$_REQUEST["action_plan"],$_REQUEST["comparator"],$_REQUEST['report'],$_REQUEST['new_comparator'],$_REQUEST['engagementCA'],$_REQUEST['businessImpact'],$_REQUEST['heatMap'],$_REQUEST['allDrivers']);
		
		// Below code added by Gaurav Kumar
		// $survey = survey_editComparator($_REQUEST["survey_id"],$_REQUEST["sync_frequency"],$_REQUEST["scorecard"],$_REQUEST["dashboard"],$_REQUEST["dashboard_qualitative"],$_REQUEST["dashboard_diagnostic"],$_REQUEST["action_plan"],$_REQUEST["comparator"],$_REQUEST['report'],$_REQUEST['new_comparator']);
		
		// Gaurav added code section end here
		if($output==="json"){
			json_output($survey);
		}else{
			echo "Success";
		}
	}else{
		$survey = survey_get($_REQUEST["survey_id"]);
		$dashboard_count = ToArray(execute_query("SELECT count(*) AS dashboard_count FROM `survey_mapping`  M
		LEFT JOIN `participant` P ON `P`.`employee_id` = `M`.`employee_id` AND `P`.`survey_id` = ".$survey["survey_id"]."
		WHERE `type` = 3 AND `M`.`survey_id` = ".$survey["survey_id"]." AND `user_id` = ".$_SESSION["user_id"]." AND `P`.`status`!='N';"))["dashboard_count"];
		$limits = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
		if($output==="json"){
			json_message("submit,survey_id,survey_name,survey_group,account_id,user_id are required variable");
		}else{
			?>
			<ul class="nav nav-tabs">
			  <li class="nav-item">
				<a class="nav-link" onclick="survey_view(survey_page)" ><i class="fas fa-arrow-left"></i> Back</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#survey_details">Details </a>
			  </li>
			  <?php if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#status">Status</a>
			  </li>
			  <?php }?>
			  <?php if($survey["scorecard"]){ ?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#scorecard">Scorecard</a>
			  </li>
			  <?php }?>
			  <?php if((($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"||$dashboard_count>=$limits["min_filter"])&&$survey["dashboard"])){?>
			  <li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#dashboard">Dashboard</a>
			  </li>
			   <?php }?>
			  <?php if($survey["user_id"]===$_SESSION["user_id"]){?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#mapping">Mapping</a>
			  </li>
			  <?php }?>
			  <?php /*if(ToArray(execute_query("SELECT count(*) action_plan_count FROM `action_plan` WHERE `survey_id`= ".mysql_prep($survey["survey_id"])." AND `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"]).";"))["action_plan_count"]>0&&$survey["action_plan"]){*/
			   if($survey["action_plan"]){?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#action_plan">Action Plan</a>
			  </li>
			  <?php }?>
			  <?php /*if(ToArray(execute_query("SELECT count(*) action_plan_count FROM `action_plan` WHERE `survey_id`= ".mysql_prep($survey["survey_id"])." AND `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"]).";"))["action_plan_count"]>0&&$survey["action_plan"]){*/
			   if($survey["businessImpact"]){?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#businessImpact">Business Impact</a>
			  </li>
			  <?php }?>
			   <?php /*if(ToArray(execute_query("SELECT count(*) action_plan_count FROM `action_plan` WHERE `survey_id`= ".mysql_prep($survey["survey_id"])." AND `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"]).";"))["action_plan_count"]>0&&$survey["action_plan"]){*/
			   if($survey["new_comparator"]){?>
			  <li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#new_comparator">Comparator</a>
			  </li>
			  <?php }?>
			</ul>
			<!-- Tab panes -->
			<div class="tab-content">
			  <div class="tab-pane" id="status">
			 <!--  <div class="card text-white bg-secondary" >
				<div class="card-header bg-dark font-weight-bold" data-toggle="collapse" data-target="#container_filter_group" aria-expanded="false" aria-controls="container_filter_group">
				Filter <span id="filter_text" style="font-size: 60%;"></span>
				</div>
				<div class="collapse" id="container_filter_group">
					<div class="card-body row" id="container_filter">
					</div>
					<div class="card-footer bg-dark">&nbsp;
						<button class="btn btn-success btn-sm float-right mr-2" onclick="filter_apply()" >Apply</button> &nbsp; 
						<button class="btn btn-secondary btn-sm float-right mr-2" onclick="filter_reset()" >Reset</button>
					</div>
				</div>
			</div> -->
				<div class="row">
					<div class="col-sm-6">
						<select id="status_select" class="form-control" onchange="status_change()">
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 table-responsive" id="status_table">
					</div>
				</div>
			  </div>
			  
			  <div class="tab-pane" id="scorecard"></div>
			  <div class="tab-pane" id="dashboard">

			  <?php include('../../includes/layout/dashboard.php')?>
			  </div>
			  
			  <div class="tab-pane" id="businessImpact">
			  <?php// include('../../includes/layout/Business_Impact.php')?>
			  </div>
			  
			   <div class="tab-pane" id="new_comparator">
			  <?php include('../../includes/layout/Comparator.php')?>
			  </div>
			  <div class="tab-pane active m-2" id="survey_details">
			  <?php //print_r($survey);?>
				<div class="row">
				<div class="col-md-9 col-lg-6">
				<form  id="survey_form" action="survey.php" method="POST">
					<input class="form-control" name="method" type="hidden" value="edit">
					<input class="form-control" name="survey_id" type="hidden" value="<?echo $survey["survey_id"];?>">
					<div class="form-group">
						<label>Survey Name:</label>
						<input class="form-control"  id="survey_name" name="survey_name" type="text" placeholder="Survey Name" value="<?echo $survey["survey_name"];?>" readonly>
					</div>
					<div class="form-group">
						<label>Survey Group:</label>
						<input class="form-control" name="survey_group" type="text" placeholder="Survey Group" value="<?echo $survey["survey_group"];?>" readonly>
					</div>
					<?if($survey["user_id"]===$_SESSION["user_id"]){?>
					<div class="form-group">
						<label>Sync Frequency <?echo "<small>(Synced at: ".$survey["synced_at"].")</small>";?></label>
						<select name="sync_frequency" class="form-control">
							<option value="1" <?echo ($survey["sync_frequency"]==="1"?"selected=\"selected\"":"");?> >Hourly</option>
							<option value="6" <?echo ($survey["sync_frequency"]==="6"?"selected=\"selected\"":"");?> >Once in 6 hours</option>
							<option value="24" <?echo ($survey["sync_frequency"]==="24"?"selected=\"selected\"":"");?> >Once in a day</option>
							<option value="168" <?echo ($survey["sync_frequency"]==="168"?"selected=\"selected\"":"");?> >Once in a week</option>
							<option value="876000" <?echo ($survey["sync_frequency"]==="876000"?"selected=\"selected\"":"");?> >Never</option>
						</select>
					</div>
					<div class="form-group">
						<label>Scorecard</label>
						<select name="scorecard" class="form-control">
							<option value="0" <?echo ($survey["scorecard"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["scorecard"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Dashboard</label>
						<select name="dashboard" class="form-control">
							<option value="0" <?echo ($survey["dashboard"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["dashboard"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Dashboard : Qualitative</label>
						<select name="dashboard_qualitative" class="form-control">
							<option value="0" <?echo ($survey["dashboard_qualitative"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["dashboard_qualitative"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Dashboard: Diagnostic</label>
						<select name="dashboard_diagnostic" class="form-control">
							<option value="0" <?echo ($survey["dashboard_diagnostic"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["dashboard_diagnostic"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Action Plan</label>
						<select name="action_plan" class="form-control">
							<option value="0" <?echo ($survey["action_plan"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["action_plan"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Trend</label>
						<select name="comparator" class="form-control">
							<option value="0" <?echo ($survey["comparator"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["comparator"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Comparator</label>
						<select name="new_comparator" class="form-control">
							<option value="0" <?echo ($survey["new_comparator"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["new_comparator"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Business Impact</label>
						<select name="businessImpact" class="form-control">
							<option value="0" <?echo ($survey["businessImpact"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["businessImpact"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Report</label>
						<select name="report" class="form-control">
							<option value="0" <?echo ($survey["report"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["report"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>All Driver</label>
						<select name="allDrivers" class="form-control">
							<option value="0" <?echo ($survey["allDrivers"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["allDrivers"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Heatmap</label>
						<select name="heatMap" class="form-control">
							<option value="0" <?echo ($survey["heatMap"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["heatMap"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<div class="form-group">
						<label>Engagement CA</label>
						<select name="engagementCA" class="form-control">
							<option value="0" <?echo ($survey["engagementCA"]==="0"?"selected=\"selected\"":"");?> >No</option>
							<option value="1" <?echo ($survey["engagementCA"]==="1"?"selected=\"selected\"":"");?> >Yes</option>
						</select>
					</div>
					<input type="hidden" name="output" value="json" />
					<input type="hidden" name="submit" value="Save" />
					<button class="btn btn-success" type="button" onclick="survey_submit()">Save</button>
					<button class="btn btn-warning" type="button" onclick="survey_action_plan_push()">Push action plan</button>
					<?}else{
						echo "Synced at: ".$survey["synced_at"];
					}?>
					
				</form>
				</div>
				</div>
			  </div>
			  <div class="tab-pane" id="mapping">
				<div class="row">
					<div class="col-lg-8 mb-3" id="user_mapped">
					</div>
					<div class="col-lg-4">
						<ul class="nav nav-tabs">
						  <li class="nav-item">
							<a class="nav-link active" data-toggle="tab" href="#mapping_section">Mapping</a>
						  </li>
						  <li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#mapping_tool">Mapping Generator Tool</a>
						  </li>
						</ul>
						<!-- Tab panes -->
						<div class="card">
							<div class="card-body pl-0 pr-0">
								<div class="tab-content">
								  <div class="tab-pane active pl-3 pr-3" id="mapping_section">
										<form id="mapping_form" enctype="multipart/form-data" method="post" action="survey.php" > 
											<input type="hidden" name="method" value="map_add">
											<input type="hidden" name="submit" value="Add">
											<input type="hidden" name="survey_id" value="<?php echo $survey["survey_id"]?>">
											<div class="form-group">
												<label>Mapping Type</label>
												<select name="type" class="form-control">
													<option value="1">Manager Scorecard</option>
													<option value="2">Leader Scorecard</option>
													<option value="3">Dashboard</option>
													<option value="4">HR</option>
												</select>
											</div>
											<div class="form-group">
												<label>Mapping Details</label>
												<small>email,id,employee_id</small>
												<textarea id="mapping_content" name="mapping_content" style="height:200px;" class="form-control" placeholder="manager1@email.com,MAN01,EMP01&#10;manager1@email.com,MAN01,EMP02&#10;manager2@email.com,MAN02,EMP03"></textarea>
											</div>
											<div class="form-group">
												<label>Or Upload Mapping File  <a class="btn btn-sm btn-secondary" href="?method=map_template" title="Download Template" target="_blank"><i class="fas fa-download"></i></a></label>
												<input type="file" id="mapping_file" name="mapping_file" accept="csv">
											</div>
											<div class="form-group">
												<button class="btn btn-success" onclick="mapping_add();return false;" >Add</button>
											</div>
										</form>
										<hr>
										<form id="mapping_clone_form" enctype="multipart/form-data" method="post" action="survey.php" >
											<div class="form-group">
												<label>Clone Mapping from</label>
												<input type="hidden" name="method" value="map_clone">
												<input type="hidden" name="submit" value="Clone">
												<input type="hidden" name="survey_id" value="<?php echo $survey["survey_id"]?>">
												<select type="file" class="form-control select2" name="survey_id_map" required>
												<?php $options = ToArrays(execute_query("SELECT `survey_id`,`survey_name` FROM `survey` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
												foreach($options as $option){
													echo "<option value=\"".$option["survey_id"]."\">".$option["survey_name"]."</options>";
												}
												?>
												</select>
											</div>
											<div class="form-group">
												<button class="btn btn-success" onclick="mapping_clone();return false;" >Clone</button>
											</div>
										</form>
									</div>
									<div class="tab-pane pl-3 pr-3" id="mapping_tool">
									<form action="employee_mapping.php" method="POST" enctype="multipart/form-data" target="_blank">
									<div class="form-group">
									<label>Template (CSV)</label><br><small>(email,employee_id,manager_code)</small>
									<input type="file" id="upload_file" name="upload_file" accept="csv" required>
									</div>
									<button class="btn btn-primary" type="submit" name="method" value="manager">Manager Template</button>
									<button class="btn btn-primary" type="submit" name="method" value="leader">Leader Template</button>
									</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			  </div>
				<div class="tab-pane" id="action_plan">
					<ul class="nav nav-tabs mt-3">
					  <li id="action_plan_manage_tab" class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#action_plan_manage">My Plan</a>
					  </li>
					   <li id="action_plan_dashboard_tab" class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#action_plan_dashboard" >Dashboard</a>
					  </li>
					</ul>
					<div class="tab-content">
						<div class="tab-pane active"  role="tabpanel" id="action_plan_manage">
						</div>
						<div class="tab-pane"  role="tabpanel" id="action_plan_dashboard">
						</div>
					</div>
				</div>
		<?php exit(0);
		}
	}
}else if($method==="delete"){
	if(isset($_REQUEST["survey_id"])&&$_SESSION["role_selected"]["role_id"]==="1"){
		survey_delete($_REQUEST["survey_id"]);
		if($output==="json"){
			json_message("The object is successfully deleted");
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("survey_id is a required variable");
		}else{
			echo "Failed";
		}
	}
}else if($method==="process"){
	if(isset($_REQUEST["survey_id"]) && $_SESSION["role_selected"]["role_id"]==="1"){
		$survey_id = $_REQUEST["survey_id"];
		$COUNT = survey_process($survey_id);
		if($output==="json"){
			json_message($COUNT." Reponses Processed");
		}else{
			session_message($COUNT." Reponses Processed","success");
			redirect_to("survey.php");
		}
	}else{
		if($output==="json"){
			json_message("Invalid survey_id");
		}else{
			session_message("Invalid survey_id","danger");
			redirect_to("survey.php");
		}
	}
}else if($method==="status"){
	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	if(isset($survey)&&($_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2")){
		$dir = ROOT_DIRECTORY."/survey_data/".$survey["survey_id"];
		$aes_key = generate_salt(16);
		$crypt="";
		$isvalid = openssl_public_encrypt($aes_key,$crypt,decrypt($_REQUEST["key"],"Vng7HPqGYASynERA"));
		$response["key"]=base64_encode($crypt);
		$response["data"] = encrypt(file_get_contents($dir."/participants.json"),$aes_key);
		$response["min_limit"] = encrypt(json_encode(ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"].";")),true),$aes_key);
		ob_start("ob_gzhandler");
		json_output($response);
		exit(0);
	}else{
		json_message("Unauthorized Access");
	}
}elseif($method==="map_view"){
	$survey = survey_get($_REQUEST["survey_id"]);
	if($survey["user_id"]===$_SESSION["user_id"]&&$_SESSION["role_selected"]["role_id"]==="1"){
		$q="";
		if(isset($_REQUEST["q"]))
			$q = $_REQUEST["q"];
		$page=0;
		if(isset($_REQUEST["page"]))
			$page = $_REQUEST["page"];
		
		$survey_id = 0;
		if(isset($_REQUEST["survey_id"]))
			$survey_id = $_REQUEST["survey_id"];
		
		$users = ToArrays(execute_query("SELECT `U`.`user_id`,`U`.`email`,
			COALESCE(manager_subordinate,0) AS manager_subordinate,
			COALESCE(leader_subordinate,0) AS leader_subordinate,
			COALESCE(dashboard_subordinate,0) AS dashboard_subordinate,
			COALESCE(hr_subordinate,0) AS hr_subordinate	
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			LEFT JOIN (
				SELECT user_id, SUM(CASE WHEN `type` = 1 THEN 1 ELSE 0 END) AS manager_subordinate,
				SUM(CASE WHEN `type` = 2 THEN 1 ELSE 0 END) AS leader_subordinate,
				SUM(CASE WHEN `type` = 3 THEN 1 ELSE 0 END) AS dashboard_subordinate ,
				SUM(CASE WHEN `type` = 4 THEN 1 ELSE 0 END) AS hr_subordinate
				FROM `survey_mapping` M
				WHERE `M`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `M`.`survey_id` = ".$survey_id." GROUP BY 1
			) C ON `C`.`user_id` = `U`.`user_id`
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
		$user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%');"))["user_count"];
				
		if($_REQUEST["output"]==="json"){
			$response["count"]=$user_count;
			$response["page"]=$page;
			$response["users"]=$users;
			json_output($response);
		}else{
			?>
			<div class="card">
			  <div class="card-header">
			<?php
					if((($page+1)*30)<$user_count)
					   echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"map_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
					   echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
					if($page!=0)
					   echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"map_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
					echo "<div class=\"dropdown d-inline float-right ml-1\"><button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
						<i class=\"fas fa-list\" ></i>
					  </button>
					  <div class=\"dropdown-menu\">
						<button class=\"dropdown-item\"  onclick=\"mapping_delete('All')\" >Confirm Delete <b>All</b> User Mapping?</button>
					  </div>
					  </div>";
					?>
					<form class="form-inline" action="" onsubmit="return false;">
						<div class="input-group">
							<input id="mapping_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>" onkeypress="if(event.keyCode==13) map_view(0);">
							<span class="input-group-append">
								<button type="button" class="btn btn-secondary" onclick="map_view(0)" ><i class="fa fa-search" ></i></button>
							</span>
						</div>
					</form>
			  </div>
			  <div id="mapping_manage" class="card-body table-responsive mb-3">
				<table class="table">
				<tr><th>Email</th><th>Manager SC</th><th>Leader SC</th><th>Dashboard</th><th>HR</th><th style="width:160px" >Manage</th></tr>
				<?php
				foreach($users as $user){
					echo "<tr><td>".$user["email"]."</td><td>".$user["manager_subordinate"]."</td><td>".$user["leader_subordinate"]."</td><td>".$user["dashboard_subordinate"]."</td><td>".$user["hr_subordinate"]."</td><td>";
						echo "<div class=\"dropdown d-inline\"><button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
							<i class=\"fas fa-list\" ></i>
						  </button>
						  <div class=\"dropdown-menu\">
							<button class=\"dropdown-item\"  onclick=\"mapping_delete(".$user["user_id"].")\" >Confirm Delete User Mapping?</button>
						  </div>
						  </div>";
					echo "</td></tr>";
				}
				?>
				</table>
			  </div>
			</div>
			<?
		}
	}else{
		if($_REQUEST["output"]==="json"){
			json_message("Invalid Access");
		}else{
			echo "<center>Invalid Access</center>";
		}
	}
}else if($method==="map_template"){
	$data["email"]="ceo@email.com";
	$data["id"]="CEOID01";
	$data["employee_id"]="EMPID01";
	$response[] = $data;
	$data["email"]="manager1@email.com";
	$data["id"]="MAN01";
	$data["employee_id"]="EMPID01";
	$response[] = $data;
	$data["email"]="manager1@email.com";
	$data["id"]="MAN01";
	$data["employee_id"]="EMPID02";
	$response[] = $data;
	$data["email"]="manager2@email.com";
	$data["id"]="MAN02";
	$data["employee_id"]="EMPID03";
	$response[] = $data;
	csv_output("Mapping Template",$response);	
}

else if($method==="map_clone"){
	$survey = survey_get($_REQUEST["survey_id"]);
	if($survey["user_id"]===$_SESSION["user_id"]&&$_SESSION["role_selected"]["role_id"]==="1"){
		execute_query("INSERT INTO `survey_mapping` ( `account_id`, `survey_id`, `user_id`, `type`, `employee_id`)
		SELECT `account_id`, '".mysql_prep($_REQUEST["survey_id"])."' AS survey_id, `user_id`, `type`, `employee_id` FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `survey_id` = ".$_REQUEST["survey_id_map"]);
		json_message("Mapping Cloned Successfully");
	}else{
		json_message("Unauthorized Access");
	}	
}else if($method==="map_add"){
	$survey = survey_get($_REQUEST["survey_id"]);
	if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"){
		//1 Manager SC  || 2 Leader SC || 3 Dashboard
		$response="Data Added Successfully after filtering";
		if(isset($_REQUEST["submit"],$_REQUEST["type"])&&((isset($_REQUEST["mapping_content"])&&$_REQUEST["mapping_content"]!="")||file_exists($_FILES["mapping_file"]["tmp_name"]))){
			if(file_exists($_FILES["mapping_file"]["tmp_name"])){
				if (($handle = fopen($_FILES['mapping_file']['tmp_name'], "r")) !== FALSE) {
					$header = fgetcsv($handle);
					$data = array();
					$email_list = array();
					if($header[0]==="email"&&$header[1]==="id"&&$header[2]==="employee_id"){
						while (($input = fgetcsv($handle)) !== FALSE) {
							$email = mysql_prep(trim(strtolower($input[0])));
							if(filter_var($email, FILTER_VALIDATE_EMAIL)){
								$map["email"]=$email;
								$map["id"]=trim($input[1]);
								$map["employee_id"]=trim($input[2]);
								$data[] = $map;
								$email_list[] = $email;
							}
						}
					}else{
						json_message("Invalid Template");
					}
				}else{
					json_message("Unable to open the file");
				}
			}else{
				$mapping_contents = explode("\r\n",$_REQUEST["mapping_content"]);
				$data = array();
				$email_list = array();
				foreach($mapping_contents as $mapping_content){
					$temp = explode(",",$mapping_content);
					$email = mysql_prep(trim(strtolower($temp[0])));
					if(filter_var($email, FILTER_VALIDATE_EMAIL)){
						$map["email"]=$email;
						$map["id"]=trim($temp[1]);
						$map["employee_id"]=trim($temp[2]);
						$data[] = $map;
						$email_list[] = $email;
					}
				}
			}
			$email_list=array_unique($email_list);		
			$users = ToArrays(execute_query("SELECT `U`.`user_id`,`U`.`email`,COALESCE(`AL`.`role_id`,0) as role_id FROM `user` U 
			LEFT JOIN `account_linking` AL ON `AL`.`user_id`=`U`.`user_id` AND `account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."'
			WHERE `email` in ("."'".implode("','",$email_list)."' AND `email` != '' ".");"));
			$user_list=array();
			foreach($users as $user){
				$user_list[$user["email"]] = $user;
			}
			foreach($data as $map){
				$user = $user_list[$map["email"]];
				if(!isset($user["user_id"])){
					$password = strtolower(generate_salt(8));
					$user_id = execute_insert_query("INSERT INTO `user`(`email`,`password`,`created_at`,`modified_at`) VALUES ('".mysql_prep($map["email"])."','".mysql_prep(password_encrypt($password))."',".get_sql_india_time().",".get_sql_india_time().");");
					$user_temp = user_get($user_id);
					$user["user_id"]= $user_temp["user_id"];
					$user["email"]= $user_temp["email"];
					$user["role_id"]=0;
				}
				if(!isset($user["role_id"])||$user["role_id"]<1){
					$account_linking_id = execute_insert_query("INSERT INTO `account_linking`(`account_id`, `role_id`, `user_id`,`id`) VALUES ('".mysql_prep($_SESSION["role_selected"]["account_id"])."',".mysql_prep(3).",".mysql_prep($user["user_id"]).",'".mysql_prep($map["id"])."');");
					if($account_linking_id>0){
						$user["role_id"]=3;
					}
				}
				if(!isset($user_list[$map["email"]]["user_id"])){
					$user_list[$user["email"]] =$user; 
				}
				if(isset($user["user_id"],$user["role_id"])&&$user["user_id"]>0&&$user["role_id"]>0){
					execute_insert_query("INSERT INTO `survey_mapping`(`account_id`, `survey_id`, `user_id`, `type`, `employee_id`) VALUES ('".mysql_prep($_SESSION["role_selected"]["account_id"])."',".mysql_prep($_REQUEST["survey_id"]).",".$user["user_id"].",".mysql_prep($_REQUEST["type"]).",'".mysql_prep($map["employee_id"])."');");
				}
			}
		}else{
			$response="API data is missing";
		}
		json_message($response);
	}else{
		json_message("Unauthorized Access");
	}
	exit(0);
}else if($method==="map_delete"){
	$survey = survey_get($_REQUEST["survey_id"]);
	if($survey["user_id"]===$_SESSION["user_id"]&&$_SESSION["role_selected"]["role_id"]==="1"){
		if(isset($_REQUEST["user_id"])){
			if($_REQUEST["user_id"]==="All"){
				execute_query("DELETE FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `survey_id` = ".mysql_prep($_REQUEST["survey_id"]));
			}else{
				execute_query("DELETE FROM `survey_mapping` WHERE `user_id` = ".$_REQUEST["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `survey_id` = ".mysql_prep($_REQUEST["survey_id"]));
			}
			json_message("User mapping removed");
		}else{
			json_message("user_id is a required paramter");
		}
	}else{
		json_message("Unauthorized Access");
	}
}else if($method==="scorecard_view"){
	$q = "";
	if(isset($_REQUEST["q"]))
		$q = $_REQUEST["q"];
	$page = $_REQUEST["page"];
	$survey_id = $_REQUEST["survey_id"];
	$survey = survey_get($_REQUEST["survey_id"]);
	$employees = ToArrays(execute_query("SELECT DISTINCT `employee_id` FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `user_id` = ".$_SESSION["user_id"]." AND `survey_id` = ".mysql_prep($survey_id).";"));
	$employees = flatten_array($employees,"employee_id");
	$employees = array_map('trim', $employees); 
	$limits = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	// echo 'role selectd '.$_SESSION["role_selected"]["account_id"];
	// echo 'user id'.$_SESSION["user_id"];
	// echo 'q '.$q;
	// echo 'page '.$page;
	//exit(0);
	if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){
		//echo 'inside if ';
		$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
			$user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%');"))["user_count"];
	}else{
		
		$user_ids = ToArrays(execute_query("SELECT `U`.`user_id`
			FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') AND `AL`.`id` in ('".implode("','",$employees)."') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
			$user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') AND `AL`.`id` in ('".implode("','",$employees)."');"))["user_count"];
	}
	$user_ids = flatten_array($user_ids,"user_id");
	//echo ' user_id '.implode(',',$user_ids);
	$users = ToArrays(execute_query("SELECT `U`.`user_id`,`U`.`email`,
			COALESCE(manager_subordinate,0) AS manager_subordinate,
			COALESCE(leader_subordinate,0) AS leader_subordinate FROM `user` U
			LEFT JOIN 
				`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
				AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
			LEFT JOIN (
				SELECT user_id, SUM(CASE WHEN `type` = 1 THEN 1 ELSE 0 END) AS manager_subordinate,
				SUM(CASE WHEN `type` = 2 THEN 1 ELSE 0 END) AS leader_subordinate  
				FROM `survey_mapping` M
				LEFT JOIN `participant` P ON `P`.`employee_id` = `M`.`employee_id` AND `P`.`survey_id` = ".mysql_prep($survey["survey_id"])."
				WHERE `M`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `M`.`survey_id`='".mysql_prep($survey["survey_id"])."' AND `M`.`user_id` in (".implode(",",$user_ids).")  GROUP BY 1
			) C ON `C`.`user_id` = `U`.`user_id`
			WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `U`.`user_id` in (".implode(",",$user_ids).");"));
	$mapping = ToArrays(execute_query("SELECT `M`.`type`,count(*) AS number FROM `survey_mapping` M 
	LEFT JOIN `participant` P ON `P`.`employee_id` = `M`.`employee_id` AND `P`.`survey_id` = ".mysql_prep($survey_id)."
	WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `user_id` = ".$_SESSION["user_id"]." AND `M`.`survey_id` = ".mysql_prep($survey_id)." AND `P`.`status` != 'N' GROUP BY 1;"));
	$mapping_data["manager"]=0;
	$mapping_data["leader"]=0;
	$mapping_data["dashboard"]=0;
	foreach($mapping as $item){
		if($item["type"]==="1"){
			$mapping_data["manager"]=$item["number"];
		}else if($item["type"]==="2"){
			$mapping_data["leader"]=$item["number"];
		}else if($item["type"]==="3"){
			$mapping_data["dashboard"]=$item["number"];
		}
	}
	?>
	<div class="row m-1">
		<?php if($mapping_data["manager"]>0){?>
		<div class="col-xl-3 col-md-6 mb-1">
			<?php if($mapping_data["manager"]>=$limits["min_scorecard"]){ ?>
			<a style="text-decoration: none;" href="?method=scorecard_download&type=1&output=pdf&survey_id=<?echo $survey_id;?>&user_id=<?echo $_SESSION["user_id"];?>" target="_blank">
			<?}else{?>
				<a style="text-decoration: none;" href="#" onclick="modal('Error','Not Enough Responses'); return false;">
			<?}?>
				<div class="card border-left-primary shadow h-100 py-2">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="h5 font-weight-bold text-gray-800 text-uppercase mb-1">
									<?echo $_SESSION["role_selected"]["name"]." (".$_SESSION["role_selected"]["id"].")"?>
								</div>
								<div class="text-xs mb-0 font-weight-bold text-primary">Manager Scorecard</div>
							</div>
							<div class="col-auto">
								<i class="fas fa-download fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php }?>
		<?php if($mapping_data["leader"]>0){?>
		<div class="col-xl-3 col-md-6 mb-1">
			<?php if($mapping_data["manager"]>=$limits["min_scorecard"]){ ?>
			<a style="text-decoration: none;" href="?method=scorecard_download&type=2&output=pdf&survey_id=<?echo $survey_id;?>&user_id=<?echo $_SESSION["user_id"];?>" target="_blank">
			<?}else{?>
				<a style="text-decoration: none;" href="#" onclick="modal('Error','Not Enough Responses'); return false;">
			<?}?>
				<div class="card border-left-success shadow h-100 py-2">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="h5 font-weight-bold text-gray-800 text-uppercase mb-1">
									<?echo $_SESSION["role_selected"]["name"]." (".$_SESSION["role_selected"]["id"].")"?>
								</div>
								<div class="text-xs mb-0 font-weight-bold text-success">Leader Scorecard</div>
							</div>
							<div class="col-auto">
								<i class="fas fa-download fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php }?>
	</div>
	<div class="card">
	  <div class="card-header">
	<?php
			if((($page+1)*30)<$user_count)
			   echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"survey_scorecard_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
			   echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
			if($page!=0)
			   echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"survey_scorecard_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
			?>
			<?php if($survey["user_id"]===$_SESSION["user_id"]){?>
			<button class="btn btn-secondary float-right ml-1" onclick="scorecard_send_bulk(<?echo $survey_id;?>,2)" title="Send Scorecard to All Leaders" ><i class="fas fa-paper-plane"></i> Leader</button> 
			
			<button class="btn btn-secondary float-right ml-1"  onclick="scorecard_send_bulk(<?echo $survey_id;?>,1)" title="Send Scorecard to All Managers"><i class="fas fa-paper-plane"></i> Manager</button>
			
			
			<?}?>
			<form class="form-inline" action="" onsubmit="return false;">
				<div class="input-group">
					<input id="survey_scorecard_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>" onkeypress="if(event.keyCode==13) survey_scorecard_view(0);">
					<span class="input-group-append">
						<button type="button" class="btn btn-secondary" onclick="survey_scorecard_view(0)" ><i class="fa fa-search" ></i></button>
					</span>
				</div>
				<small> <?echo "&nbsp;&nbsp;&nbsp;&nbsp; (Showing ".(($page*30)+1)." to ". min((($page+1)*30),$user_count)." of ".$user_count." Results)";?></small>
			</form>
	  </div>
	<?if($user_count>0){?>
	 
	  <div id="user_manage" class="card-body table-responsive">
		<table class="table">
		<tr><th>Email</th><th>Manager Scorecard</th><th>Leader Scorecard</th></tr>
		<?php 
			//print_r($users);
			//print_r($scorecard['user']);
		?>
		<?php
		foreach($users as $user){
			if($user["manager_subordinate"]>0||$user["leader_subordinate"]>0){
				echo "<tr><td>".$user["email"]."</td><td>";
				if($user["manager_subordinate"]>0){
					if($user["manager_subordinate"]>=$limits["min_scorecard"]){
						echo "<a title=\"Download\" class=\"btn btn-secondary ml-1\" href=\"survey.php?method=scorecard_download&type=1&output=pdf&survey_id=".$survey_id."&user_id=".$user["user_id"]."\" target=\"_blank\"><i class=\"fas fa-download\"></i></a>";
						echo "<a title=\"View\" class=\"btn btn-secondary ml-1\" href=\"survey.php?method=scorecard_download&type=1&output=html&survey_id=".$survey_id."&user_id=".$user["user_id"]."\" target=\"_blank\"><i class=\"fas fa-eye\"></i></a>";
						
					}else{
						echo "<button class=\"btn btn-danger ml-1\" title=\"Not enough responses\" onclick=\"modal('Error','Not Enough Responses');\" ><i class=\"fas fa-download\"></i></button>";
						echo "<button class=\"btn btn-danger ml-1\" title=\"Not enough responses\" onclick=\"modal('Error','Not Enough Responses');\" ><i class=\"fas fa-eye\"></i></button>";
					}
				}
				echo "</td><td>";
				if($user["leader_subordinate"]>0){
					if($user["leader_subordinate"]>=$limits["min_scorecard"]){
						echo "<a title=\"Download\" class=\"btn btn-secondary ml-1\" href=\"survey.php?method=scorecard_download&type=2&output=pdf&survey_id=".$survey_id."&user_id=".$user["user_id"]."\" target=\"_blank\"><i class=\"fas fa-download\"></i></a>";
						echo "<a title=\"View\" class=\"btn btn-secondary ml-1\" href=\"survey.php?method=scorecard_download&type=2&output=html&survey_id=".$survey_id."&user_id=".$user["user_id"]."\" target=\"_blank\"><i class=\"fas fa-eye\"></i></a>";
					}else{
						echo "<button class=\"btn btn-danger ml-1\" title=\"Not enough responses\" onclick=\"modal('Error','Not Enough Responses'); \" ><i class=\"fas fa-download\"></i></button>";
						echo "<button class=\"btn btn-danger ml-1\" title=\"Not enough responses\" onclick=\"modal('Error','Not Enough Responses'); \" ><i class=\"fas fa-eye\"></i></button>";
					}
				}
					
				echo "</td>";
				echo "</tr>";
			}
		}
		?>
		</table>
	  </div>
	 <?}?>
	 </div>
	<?
}else if($method==="scorecard_download"){

	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	//print_r('OKAY call done'.$survey);
	$permission = ToArray(execute_query("SELECT count(*) AS permission FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `user_id` = ".$_SESSION["user_id"]." AND `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND employee_id in (SELECT `id` FROM `account_linking` WHERE `user_id` = ".mysql_prep($_REQUEST["user_id"])." AND `account_id` =".$_SESSION["role_selected"]["account_id"]." );"))["permission"];
	if($permission<1&&$_SESSION["user_id"]===$_REQUEST["user_id"]){
		$permission=1;
	}
	if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"||$permission>0){
		$scorecard = scorecard_params($_REQUEST["survey_id"],$_REQUEST["type"],$_SESSION["role_selected"]["account_id"],user_get($_REQUEST["user_id"])["email"]);
		$account_logo_url = ToArray(execute_query("SELECT `logo_url` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]))["logo_url"];
		$account_name = ToArray(execute_query("SELECT `account_name` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]))["account_name"];
		$mapping_count = ToArray(execute_query("SELECT count(*) mapping_count FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `survey_id`= ".mysql_prep($_REQUEST["survey_id"])." AND `user_id`= ".mysql_prep($_REQUEST["user_id"])." AND `type`=".mysql_prep($_REQUEST["type"])))["mapping_count"];
		$min_limit = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
		if($scorecard["team"]["count"]>=$min_limit["min_scorecard"]){
			//print_r($scorecard["team"]["count"]);
			
			$template = "";
			$output_name = "";
			if($_REQUEST["type"]==="2"){
				$title="Leader Scorecard";
				$template = ROOT_DIRECTORY."/includes/layout/scorecard_leader.php";
				$output_name = "Leader Scorecard";
			}else{
				$title="Manager Scorecard";
				$template = ROOT_DIRECTORY."/includes/layout/scorecard_manager.php";
				$output_name = "Manager Scorecard";
			}
			if($_REQUEST["output"]==="pdf"){
				ob_start();
				include($template);
				$path = "/tmp/score_".generate_salt(16).".html";
				file_put_contents(PUBLIC_DIRECTORY.$path,ob_get_clean());
				$url = PROTOCOL.WEBSITE_URL.$path;
				$output = PUBLIC_DIRECTORY.$path.".pdf";
				shell_exec(ROOT_DIRECTORY.'/lib/wkhtmltopdf -O landscape --zoom 0.9 --javascript-delay 300 --header-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-header.php?logo_url=".urlencode($account_logo_url)."".'" --footer-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-footer.php".'" "'.$url.'" "'.$output.'"');
				header('Content-Description: File Transfer');
				header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
				header("Cache-Control: public"); // needed for internet explorer
				header("Content-Type: application/pdf");
				header("Content-Length:".filesize($output));
				header("Content-Disposition: attachment; filename=\"".$output_name.": ".$scorecard["user"]["id"].".pdf"."\"");
				readfile($output);
				unlink(PUBLIC_DIRECTORY.$path);
				unlink(PUBLIC_DIRECTORY.$path.".pdf");
			}else{ 
				ob_start();
				include($template);
				echo ob_get_clean();
			}
		}else{
			echo "<center><br><br><br><br><br><br><h1>Not Enough Data</h1></center>";
		}
	}else{
		echo "<center><br><br><br><br><br><br><h1>Unauthorized Access</h1></center>";
	}
}else if($method==="scorecard_excelDownload"){
	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	
	$permission = ToArray(execute_query("SELECT count(*) AS permission FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `user_id` = ".$_SESSION["user_id"]." AND `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND employee_id in (SELECT `id` FROM `account_linking` WHERE  AND `account_id` =".$_SESSION["role_selected"]["account_id"]." );"))["permission"];
	$permission=1;
	if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"||$permission>0){
		$scorecard = scorecard_paramsForExcel($_REQUEST["survey_id"],1,$_SESSION["role_selected"]["account_id"]);	
		// print_r('@@@@');
		// print_r($scorecard);
		//json_output($scorecard); 
		//echo "Hello world";
		echo json_encode($scorecard,JSON_FORCE_OBJECT);
		
		//exit(0);
		// $account_logo_url = ToArray(execute_query("SELECT `logo_url` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]))["logo_url"];
		// $account_name = ToArray(execute_query("SELECT `account_name` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]))["account_name"];
		// $mapping_count = ToArray(execute_query("SELECT count(*) mapping_count FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `survey_id`= ".mysql_prep($_REQUEST["survey_id"])." AND `user_id`= ".mysql_prep($_REQUEST["user_id"])." AND `type`=".mysql_prep($_REQUEST["type"])))["mapping_count"];
		// $min_limit = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
		// if($scorecard["team"]["count"]>=$min_limit["min_scorecard"]){
			//print_r($scorecard["team"]["count"]);
			
			// $template = "";
			// $output_name = "";
			// if($_REQUEST["type"]==="2"){
				// $title="Leader Scorecard";
				// $template = ROOT_DIRECTORY."/includes/layout/scorecard_leader.php";
				// $output_name = "Leader Scorecard";
			// }else{
				// $title="Manager Scorecard";
				// $template = ROOT_DIRECTORY."/includes/layout/scorecard_manager.php";
				// $output_name = "Manager Scorecard";
			// }
			// if($_REQUEST["output"]==="pdf"){
				// ob_start();
				// include($template);
				// $path = "/tmp/score_".generate_salt(16).".html";
				// file_put_contents(PUBLIC_DIRECTORY.$path,ob_get_clean());
				// $url = PROTOCOL.WEBSITE_URL.$path;
				// $output = PUBLIC_DIRECTORY.$path.".pdf";
				// shell_exec(ROOT_DIRECTORY.'/lib/wkhtmltopdf -O landscape --zoom 0.9 --javascript-delay 300 --header-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-header.php?logo_url=".urlencode($account_logo_url)."".'" --footer-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-footer.php".'" "'.$url.'" "'.$output.'"');
				// header('Content-Description: File Transfer');
				// header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
				// header("Cache-Control: public"); // needed for internet explorer
				// header("Content-Type: application/pdf");
				// header("Content-Length:".filesize($output));
				// header("Content-Disposition: attachment; filename=\"".$output_name.": ".$scorecard["user"]["id"].".pdf"."\"");
				// readfile($output);
				// unlink(PUBLIC_DIRECTORY.$path);
				// unlink(PUBLIC_DIRECTORY.$path.".pdf");
			// }else{ 
				// ob_start();
				// include($template);
				// echo ob_get_clean();
			// }
		// }else{
			// echo "<center><br><br><br><br><br><br><h1>Not Enough Data</h1></center>";
		// }
	}else{
		echo "<center><br><br><br><br><br><br><h1>Unauthorized Access</h1></center>";
	}
}else if($method==="scorecard_send"){
	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	if($survey["user_id"]===$_SESSION["user_id"]){
		if(isset($_REQUEST["user_id"])){
			execute_query("INSERT INTO `scorecard_send`(`account_id`, `user_id`,`survey_id`, `scorecard_type`, `status`, `created_at`, `modified_at`) VALUES (".mysql_prep($_SESSION["role_selected"]["account_id"]).",".mysql_prep($_SESSION["user_id"]).",".mysql_prep($survey["survey_id"]).",".mysql_prep($_REQUEST["type"]).",1,".get_sql_india_time().",".get_sql_india_time().");");
			json_message("1 Scorecard Added to Queue");
		}else{
			$limit = ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]));
			$users = ToArray(execute_query("SELECT `U`.`user_id`,count(*) user_count
			FROM `user` U
			LEFT JOIN `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` AND `AL`.`account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])."
			INNER JOIN `survey_mapping` SM ON `SM`.`user_id` = `U`.`user_id` AND `SM`.`type` =  ".mysql_prep($_REQUEST["type"])." AND `SM`.`account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `SM`.`survey_id` = ".mysql_prep($survey["survey_id"])."
			INNER JOIN `participant` P ON `P`.`employee_id` = `SM`.`employee_id` AND `P`.`survey_id` = ".mysql_prep($survey["survey_id"])." AND status != 'N'
			WHERE `AL`.`account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." GROUP BY 1 HAVING user_count>=".mysql_prep($limit["min_scorecard"])));
			foreach($users  as $user){
				execute_query("INSERT INTO `scorecard_send`(`account_id`, `user_id`,`survey_id`, `scorecard_type`, `status`, `created_at`, `modified_at`) VALUES (".mysql_prep($_SESSION["role_selected"]["account_id"]).",".mysql_prep($user["user_id"]).",".mysql_prep($survey["survey_id"]).",".mysql_prep($_REQUEST["type"]).",1,".get_sql_india_time().",".get_sql_india_time().");");
			}
			json_message(count($users)." Scorecards Added to Queue");
		}
		shell_exec("/usr/bin/sh ".PUBLIC_DIRECTORY."/cron/scorecard_send.sh > /dev/null 2>/dev/null &");
	}else{
		json_message("You are not authoerized to send Scorecards");
	}
}else if($method==="dashboard"){
	
	//echo "Method dashboards wala code access ";
	
	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($_REQUEST["survey_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	$mapping_count = ToArray(execute_query("SELECT count(*) mapping_count FROM `survey_mapping` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `survey_id`= ".mysql_prep($_REQUEST["survey_id"])." AND `user_id`= ".$_SESSION["user_id"]." AND `type`=3"))["mapping_count"];
	if(isset($survey)&&($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"||$mapping_count>0)){
		//exit(0);
        
		$dir = ROOT_DIRECTORY."/survey_data/".$survey["survey_id"];
		$aes_key = generate_salt(16);
		$crypt="";
		$isvalid = openssl_public_encrypt($aes_key,$crypt,decrypt($_REQUEST["key"],"Vng7HPqGYASynERA"));
		$response["key"]=base64_encode($crypt);
		$response["data"]["survey"] = encrypt(json_encode($survey,true),$aes_key);
		$dir = ROOT_DIRECTORY."/survey_data/".$survey["survey_id"];
		$questions = json_decode(file_get_contents($dir."/questions.json"),true);
		$question_data_temp = ToArrays(execute_query("SELECT * FROM `question`"));
      	//echo $question_data_temp;
		//print_r($question_data_temp);
		//exit(0);

		foreach($question_data_temp as $question){		
			$question_data[$question["code"]] = $question;
			unset($question_data[$question["code"]]["code"]);
		}
		$question_response = array();
		foreach($questions as $question){
			$data["code"]=$question["title"];
			//$data["question"]=$question_data[$question["title"]]["question"];
			$data["question"]=trim(strip_tags($question["question"]));
			$data["group"]=$question_data[$question["title"]]["group"];
			$data["driver"]=$question_data[$question["title"]]["driver"];
			$data["recommendation"]=$question_data[$question["title"]]["recommendation"];
			$data["hint"]=$question_data[$question["title"]]["hint"];
			$data["description"]=$question_data[$question["title"]]["description"];
			//$data["outcome"]=$question_data[$question["title"]]["driver"];
			$data["index"]=0;
			$data["result"]["positive"]=0;
			$data["result"]["neutral"]=0;
			$data["result"]["negative"]=0;
			$question_response[] = $data;
		}


      
		$response["data"]["question"] = encrypt(json_encode($question_response,true),$aes_key);
		$response["data"]["min_limit"] = encrypt(json_encode(ToArray(execute_query("SELECT `min_scorecard`,`min_filter`,`min_predictive`,`min_diagnostic` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"].";")),true),$aes_key);
		$benchmark_response = array();
		$industries = ToArrays(execute_query("SELECT DISTINCT `industry` FROM `benchmark` WHERE 1 "));
		$data = ToArrays(execute_query("SELECT * FROM `benchmark` WHERE 1"));
		foreach($industries as $industry){
			foreach($data as $item){
				if($item["industry"]===$industry["industry"]){
					unset($item["industry"]);
					$data_temp["positive"]=$item["positive"];
					$data_temp["neutral"]=$item["neutral"];
					$data_temp["negative"]=$item["negative"];
					$benchmark_response[$industry["industry"]][$item["question_code"]] = $data_temp;
				}
			}
		}
      
      
		$response["data"]["benchmark"] = encrypt(json_encode($benchmark_response,true),$aes_key);
     
		if($survey["user_id"]===$_SESSION["user_id"]||$_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){
          	if(file_exists($dir."/manager.json"))
            {
          
			 $response["data"]["manager"] = encrypt(json_encode(json_decode(file_get_contents($dir."/score.json"),TRUE)["MANAGER"],TRUE),$aes_key);
            }
            else{
              $response["data"]["manager"] = encrypt(json_encode(json_decode(file_get_contents($dir."/score.json"),TRUE)["MANAGER"],TRUE),$aes_key);
              
            }
              $response["data"]["response"] = encrypt(file_get_contents($dir."/response.json"),$aes_key);
		}else{
				$employee_ids = ToArrays(execute_query("SELECT DISTINCT `employee_id` FROM `survey_mapping` WHERE `type` = 3 AND `survey_id` = ".$survey["survey_id"]." AND `user_id` = ".$_SESSION["user_id"]));
				$employee_ids = flatten_array($employee_ids,"employee_id");
				$responses = json_decode(file_get_contents($dir."/response.json"),TRUE);
				$result = array();
				foreach($responses as $item){
					if(in_array($item["employee_id"],$employee_ids)){
						$result[] = $item;
					}
				}
				unset($responses);
				$response["data"]["response"] = encrypt(json_encode($result,true),$aes_key);
				unset($result);
				
				//$responses = json_decode(file_get_contents($dir."/manager.json"),TRUE);
				$responses = json_decode(file_get_contents($dir."/score.json"),TRUE)["MANAGER"];
				$result = array();
				foreach($responses as $id => $item){
					if(in_array($id ,$employee_ids)){
						$result[] = $item;
					}
				}
				unset($responses);
				//$response["data"]["manager"] = encrypt(json_encode($result,true),$aes_key);
				$response["data"]["manager"] = 	encrypt(json_encode($result,TRUE),$aes_key);
				unset($result);
				
		}
		json_output($response);   
		exit(0);
	}else{
        
		json_message("Unauthorized Access");
	}
}
else if($method==="openEndQuestion")
{
	
	//$survey = ToArray(execute_query("SELECT * FROM `openended_option` WHERE `option_code` in ".mysql_prep($_REQUEST["questionCodes"])));
	 $survey = ToArray(execute_query("SELECT * FROM `openended_option`"));
	 json_output($survey);
	 exit(0);	
	
	// $conn1 = mysqli_connect("localhost","dev_survey","NSnqWF7ixmeu","dev_survey");
	
	//$roleAccountId= $_SESSION['role_selected']['account_id'];
	
	// $sql = "SELECT ques.sid,ques.title,aws.code from `questions` ques inner join answers aws on ques.qid= aws.qid where ques.sid='8' and aws.code LIKE 'OPO%'";
	// $result = mysqli_query($conn1,$sql);
	// $response = array();
	// if(mysqli_num_rows($result) > 0)
	// {
		// while($row  = mysqli_fetch_assoc($result))
		// {
			// $response [] = array(
				// "sid"=>$row['sid'],
				// "title"=>$row['title'],
				// "code"=>$row['code']
			// );
		// }
	// }
	
	// $responseFinal = array();
	// foreach($response as $key => $values)
	// {
		// if($survey['option_code'] == $response[i])
	// }
	//echo json_encode($survey);
}
else if($method==="openEndQuestionData")
{
	$conn1 = mysqli_connect("localhost","survey_db","2n8m48re","survey_db");
	//$roleAccountId= $_SESSION['role_selected']['account_id'];
	$sql = "SELECT ques.sid,ques.title,aws.code from `questions` ques inner join answers aws on ques.qid= aws.qid where ques.sid=".$_REQUEST["survey_id"]." and aws.code LIKE 'OPO%'";
	$result = mysqli_query($conn1,$sql);
	$response = array();
	if(mysqli_num_rows($result) > 0)
	{
		while($row  = mysqli_fetch_assoc($result))
		{
			$response [] = array(
				"sid"=>$row['sid'],
				"title"=>$row['title'],
				"code"=>$row['code']
			);
		}
	}
	
	echo json_encode($response);
}
else if($method === "allResponseData")
{
	
}
else if($method==="businessImpact")
{
	$conn1 = mysqli_connect("localhost","dev_app","NSnqWF7ixmeu","dev_app");
	
	$roleAccountId= $_SESSION['role_selected']['account_id'];
	
	$sql = "SELECT name,`user_id` FROM `account_linking` WHERE account_id='$roleAccountId' ";
	
	
	$result = mysqli_query($conn1,$sql);
	$response = array();
	if(mysqli_num_rows($result) > 0)
	{
		while($row  = mysqli_fetch_assoc($result))
		{
			$response [] = array(
				
				"id"=>$row['user_id'],
				"managerName"=>$row['name']
			);
		}
	}
	
	
	
	echo json_encode($response);
	
	
    // $surID = $_REQUEST['survey_id'];
	
	
	// $conn1 = mysqli_connect("localhost","dev_survey","NSnqWF7ixmeu","dev_survey");
	
	//$surID = $survey["survey_id"];
	// $surID = "1";
	
	// $sql = "SELECT DISTINCT(attribute_11) as managerID FROM tokens_".$surID." where attribute_11 !='' ";
	
	// $result = mysqli_query($conn1,$sql);
	
	// $response = array();
	// $totalData = array();
	
	// $yaxis  = 0;
	// $xaxis = 0;
	
	// if(mysqli_num_rows($result) > 0)
	// {
		// while($row = mysqli_fetch_assoc($result))
		// {
			
			// $managerID = $row['managerID'];
			
			//$sql2 = "select * from tokens_1 where attribute_11='$managerID' ";
			
			// $sql2 = "select sur.1X92X454,sur.1X92X455,sur.1X92X456,sur.1X92X457,sur.1X92X458,tok.attribute_10 from tokens_1 tok inner join survey_1 sur on 
			// sur.token = tok.token where tok.attribute_11='$managerID' ";
			
			// $result2 = mysqli_query($conn1,$sql2);
			
			// if(mysqli_num_rows($result2) > 0)
			// {
				// $divident = mysqli_num_rows($result2);
				// $yaxis = 0;
				// $xaxis = 0;
				// while($row2 = mysqli_fetch_assoc($result2))
				// {
					// $yaxis = $yaxis +  intval($row2['attribute_10']);
					
					// $xaxis = $xaxis + ( intval($row2['1X92X454']) + intval($row2['1X92X455']) + intval($row2['1X92X456']) + intval($row2['1X92X457']) + intval($row2['1X92X458'])) / 5;
							
				// }
			// }
			
			// $yaxis = $yaxis / $divident;
			// $xaxis = $xaxis  / $divident;
			
			// $qurdinate = "";
			
			// if($yaxis > 100 && $xaxis < 3.8 )
			// {
				// $qurdinate = "Risk Zone";
			// }
			// else if($yaxis >= 100 && $xaxis > 3.8)
			// {
				// $qurdinate = "Optimized";
			// }
			// else if(($yaxis <= 100 && $yaxis >=75) && $xaxis < 3.8  )
			// {
				// $qurdinate = "";
			// }
			// else if( ($yaxis <= 100 && $yaxis >=75) && $xaxis > 3.8)
			// {
				// $qurdinate = "Sub-Optimized";
			// }
		    // else if(($yaxis < 75 && $yaxis >=0) && $xAxis < 3.8  )
			// {
				// $qurdinate = "Non-Performing";
			// }
			// else if(($yaxis <= 75 && $yaxis >=0) && $xaxis > 3.8)
			// {
				// $qurdinate = "Country Club";
			// }
			
			
			// $response [] = array(
				
				// "yAxis"=>$yaxis,
				// "xAxis"=>$xaxis,
				// "quadrant"=>$qurdinate
			// );
			
		// }
	// }


	//echo json_encode($response);
	
}else if($method==="manage"){

	if($output==="json"){
		json_output($surveys);
	}else{
		include(app_header());?>
<section class="content" id="survey_manage">
<!--<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="survey_manage">
	</div>
</div>-->
</section>
<section class="content" id="survey_manageComprator" style="display:none">
<!--<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="survey_manage">
	</div>
</div>-->
</section>
	<?php include(app_script()); ?>
<!--Canvas JS-->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.actual/1.0.19/jquery.actual.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
<script src="https://www.chartjs.org/samples/latest/utils.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jqdoublescroll@1.0.0/jquery.doubleScroll.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/crypto-js@4.0.0/crypto-js.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsencrypt@3.0.0-rc.1/bin/jsencrypt.min.js" integrity="sha256-4xqOnXFoVsFwPwWKaSfakiMj56xTMRXhkjJuLzrKOio=" crossorigin="anonymous"></script>
<script src="https://d3js.org/d3.v4.js"></script>
<script src="https://cdn.jsdelivr.net/gh/holtzy/D3-graph-gallery@master/LIB/d3.layout.cloud.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="//unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
          
<script>
    function openChatbot() {
        console.log("Open Chatbot");
        console.log(document.getElementById('open_comment').value);
        $("#chatCircle").hide();
        $("#popup").show();
    }
    function closeChatbot() {
        $("#popup").hide();
        $("#chat-circle").show();
    }
</script>

          
<?php
	if(ENV==="devel"||(isset($_SESSION["devel"])&&$_SESSION["devel"]==="1")){
		echo "<script src=\"Comparator.js?".time()."\"></script>"."\r\n";
		echo "<script src=\"survey.8IN0whJJrMWssO0so7Dd70XD8iT4PlaN.js?".time()."\"></script>"."\r\n";
		echo "<script src=\"action_plan.js?".time()."\"></script>"."\r\n";
	}else{
		echo "<script src=\"Comparator.js?".time()."\"></script>"."\r\n";
		echo "<script src=\"survey.js?".time()."\"></script>";
		echo "<script src=\"action_plan.js?".time()."\"></script>"."\r\n";
		
	}	
?>
<script>
var loaded_dashboard = false;
var loaded_mapping = false;
var loaded_status = false;
var opened_survey_id = 0;
var mapping_page = 0;
var survey_page = 0;
var survey_scorecard_page = 0;
var status_data;


var loaded_dashboardComprator = false;
var loaded_mappingComprator = false;
var loaded_statusComprator = false;
var opened_survey_idComprator = 0;
var mapping_pageComprator = 0;
var survey_pageComprator = 0;
var survey_scorecard_pageComprator = 0;
var status_dataComprator;


var user_session = JSON.parse(jsonEscape(`<?php echo json_encode($_SESSION)?>`));
function jsonEscape(str)  {
    return str.replace(/\n/g, "\\\\n").replace(/\r/g, "\\\\r").replace(/\t/g, "\\\\t");
}
$(function() {
	survey_view(survey_page);
});
$('body').on('click', function (e) {
    if ($(e.target).data('toggle') !== 'popover'
        && $(e.target).parents('.popover.in').length === 0) {
        $('[data-toggle="popover"]').popover('hide');
    }
});

function exalSheetForManager()
{
	console.log('Hello wold functionc call');
}
</script>

<?php include(app_footer());
	}
}
?>
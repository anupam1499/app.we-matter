<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
$title="My Scorecard";
include("../../includes/config.php");
confirm_logged_in();

if(isset($_REQUEST["survey_id"])){
	$scorecard = scorecard_params($_REQUEST["survey_id"],$_REQUEST["type"],$_SESSION["role_selected"]["account_id"],$_SESSION["email"]);
	$account_logo_url = ToArray(execute_query("SELECT `logo_url` FROM `account` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]))["logo_url"];
	$template = "";
	$output_name = "";
	if($_REQUEST["type"]==="2"){
		$title="Leader Scorecard";
		$template = ROOT_DIRECTORY."/includes/layout/scorecard_leader_v2.php";
		$output_name = "Leader Scorecard";
	}else{
		$title="Manager Scorecard";
		$template = ROOT_DIRECTORY."/includes/layout/scorecard_manger_v2.php";
		$output_name = "Manager Scorecard";
	}
	if($_REQUEST["output"]==="pdf"){
		ob_start();
		include($template);
		$path = "/tmp/score_".generate_salt(16).".html";
		file_put_contents(PUBLIC_DIRECTORY.$path,ob_get_clean());
		$url = PROTOCOL.WEBSITE_URL.$path;
		$output = PUBLIC_DIRECTORY.$path.".pdf";
		shell_exec(ROOT_DIRECTORY.'/lib/wkhtmltopdf -O landscape --zoom 0.9 --javascript-delay 300 --header-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-header.php?logo_url=".urlencode($account_logo_url)."".'" --footer-html "'.PROTOCOL.WEBSITE_URL."/asset/html/scorecard-footer.php".'" "'.$url.'" "'.$output.'"');
		header('Content-Description: File Transfer');
		header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
		header("Cache-Control: public"); // needed for internet explorer
		header("Content-Type: application/pdf");
		header("Content-Length:".filesize($output));
		header("Content-Disposition: attachment; filename=\"".$output_name.": ".$scorecard["user"]["id"].".pdf"."\"");
		readfile($output);
		unlink(PUBLIC_DIRECTORY.$path);
		unlink(PUBLIC_DIRECTORY.$path.".pdf");
	}else{
		//$title=$user["survey"]["survey_name"];
		//include(app_header());
		//print_r($scorecard);
		ob_start();
		include($template);
		echo ob_get_clean();
		//include(app_script());
		//include(app_footer());
	}
}else{
	include(app_header());
?>
<div class="card">
  <div class="card-header">
    My Score Cards
  </div>
  <div class="card-body">
	<?php 
	$surveys=ToArrays(execute_query("SELECT * FROM `survey` WHERE `survey_group` = 'ESAT' AND `account_id` = ".$_SESSION["role_selected"]["account_id"]));
	echo "<table id=\"scorecard_table\" class=\"table table-bordered\" ><thead><tr><th>Name</th>";
	if($_SESSION["map"]["manager_subordinate"]>0)
		echo "<th>Manager</th>";
	if($_SESSION["map"]["leader_subordinate"]>0)
		echo "<th>Leader</th>";
	echo "</tr></thead><tbody>";
	foreach($surveys as $survey){
		echo "<tr><td>".$survey["survey_name"]."</td>";
		if($_SESSION["map"]["manager_subordinate"]>0)
			echo "<td><a title=\"View\" class=\"btn btn-secondary\" href=\"my_scorecard.php?type=1&output=html&survey_id=".$survey["survey_id"]."\"><i class=\"fas fa-eye\"></i></a> <a title=\"Download\" class=\"btn btn-secondary\" href=\"my_scorecard.php?type=1&output=pdf&survey_id=".$survey["survey_id"]."\" target=\"_blank\"><i class=\"fas fa-download\"></i></a></td>";
		if($_SESSION["map"]["leader_subordinate"]>0)
			echo "<td><a title=\"View\" class=\"btn btn-secondary\" href=\"my_scorecard.php?type=2&output=html&survey_id=".$survey["survey_id"]."\"><i class=\"fas fa-eye\"></i></a> <a title=\"Download\" class=\"btn btn-secondary\" href=\"my_scorecard.php?type=2&output=pdf&survey_id=".$survey["survey_id"]."\" target=\"_blank\"><i class=\"fas fa-download\"></i></a></td>";
		echo "</tr>";
	}
	echo "</tbody></table>";
	?>
  </div>
</div>
<?php include(app_script());?>
<script>
$(document).ready( function () {
    $('#scorecard_table').DataTable( {
        "lengthMenu": [[-1], ["All"]]
    });
} );
</script>
<?php include(app_footer());?>
<?php  }?>
var fullData;
var benchmark;
var filtered_data;
var questions_original;
var questions;
var min_limit;
var manager;
var filters = new Array();
var filters_active;
var ENGAGEMENT_QUESTION_COUNT=0;
var MANAGER_QUESTION_COUNT=0;
var LEADER_QUESTION_COUNT=0;
var WFH_QUESTION_COUNT=0;
var WFO_QUESTION_COUNT=0;
var HR_QUESTION_COUNT=0;
var WB_QUESTION_COUNT=0;
var OTHER_QUESTION_COUNT=0;
var OPEN_QUESTION_COUNT=0;
var INDEX = {};
var CORRELATION_QUESTION_DATA = [];


var businessImpactData = []
var managerInformation = []

var compare_survey = {};
var _data;
var status_min_limit;
var heatmap_table;
var comment;
var attrition;
var performance;

var noOfTimes1  = 0;
var noOfTimes2  = 0;
var noOfTimes3  = 0;

var chart1 = null;
var chart2 = null;
var chart3 = null;
var optionsF;
var maxValueofY =0;



// Business Impact Veriable 

var xAxis = [];
var yAxis = [];
var quadrantBusImpact = [] ;

var riskZone = 0;
var riskCount =0;
	
var nonPerforming = 0;
var nonPerCount = 0 ;
	
var optimized = 0;
var optimizedCount = 0;
	
var subOptimized = 0;
var subOptimizedCount = 0 ;
	
var countryClub = 0;
var countryClubCount =0;

var setBusinessImpactFilter= true;
           
function survey_editBusinessImpact(survey_id) {
	loaded_dashboard = false;
	loaded_mapping = false;
	loaded_status = false;
	loaded_scorecard = false;
	loaded_action_plan = false;
	$.get("survey.php?method=edit&survey_id="+survey_id, function(data) {
		document.getElementById("survey_manage").innerHTML=data;
		opened_survey_id = survey_id;
		
		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if(target=="#status"&&!loaded_status){
				status_view();
				loaded_status = true;
			}else if(target=="#scorecard"&&!loaded_scorecard){
				survey_scorecard_view(survey_scorecard_page);
				loaded_scorecard = true;
			}else if(target=="#dashboard"&& !loaded_dashboard){
				dashboard_init(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#business_Impact"&& !loaded_dashboard){
				dashboard_init(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#mapping"&&!loaded_mapping){
				map_view(mapping_page);
				loaded_mapping = true;
			}else if(target=="#action_plan"&&!loaded_action_plan){
				action_plan_list();
				loaded_action_plan=true;
			}
		});
		$('[data-toggle="popover"]').popover();
		$('[data-toggle="tooltip"]').tooltip();
	});
}

function survey_edit(survey_id) {
	loaded_dashboard = false;
	loaded_mapping = false;
	loaded_status = false;
	loaded_scorecard = false;
	loaded_action_plan = false;
	$.get("survey.php?method=edit&survey_id="+survey_id, function(data) {
		document.getElementById("survey_manage").innerHTML=data;
		opened_survey_id = survey_id;
		
		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			var target = $(e.target).attr("href");
			if(target=="#status"&&!loaded_status){
				status_view();
				loaded_status = true;
			}else if(target=="#scorecard"&&!loaded_scorecard){
				survey_scorecard_view(survey_scorecard_page);
				loaded_scorecard = true;
			}else if(target=="#dashboard"&& !loaded_dashboard){
				dashboard_init(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#business_Impact"&& !loaded_dashboard){
				console.log("Bisumes Init");
				dashboard_init(opened_survey_id);
				loaded_dashboard = true;
			}else if(target=="#mapping"&&!loaded_mapping){
				map_view(mapping_page);
				loaded_mapping = true;
			}else if(target=="#action_plan"&&!loaded_action_plan){
				action_plan_list();
				loaded_action_plan=true;
			}
		});
		$('[data-toggle="popover"]').popover();
		$('[data-toggle="tooltip"]').tooltip();
	});
}

function survey_view(page) {
	survey_page = page;
    noOfTimes1  = 0;
    noOfTimes2  = 0;
    noOfTimes3  = 0;
	var survey_search_text = "";
	try{survey_search_text = document.getElementById("survey_search_text").value;}catch(err){}
	
	$.get("survey.php?method=view&q="+encodeURI(survey_search_text)+"&page="+encodeURI(page), function(data) {
		document.getElementById("survey_manage").innerHTML=data;
	});
}


function survey_delete(survey_id) {
		$.get("survey.php?method=delete&survey_id="+survey_id, function( data ) {
			survey_view(survey_page);
		});
}

function survey_process(survey_id){
	$.get("survey.php?method=process&output=json&survey_id="+survey_id, function( data ) {
		snackbar(data.message);
	});
}
function survey_submit() {
			loading(true);
			$.ajax({
			  url: 'survey.php', 
			  type: 'POST',
			  data: new FormData($('#survey_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				survey_view(survey_page);
				snackbar("Data Saved");
				loading(false);
			}).fail(function(){
				snackbar("Saving Failed");
				loading(false);
			});
}



function dashboard_init(survey_id){
	loading(true);
	console.log("call Huaa fine !!!")
	console.log("hello");
	var RSAkey = "";
	var PublicKey = "";
	var crypt = new JSEncrypt({default_key_size: 1024});
	crypt.getKey();
		  /*$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=question_get", function(questions_response){
			$.getJSON("https://lime.codegenerator.gq/account/survey.php?survey_id="+encodeURI(survey_id)+"&method=benchmark", function(benchmark_response){*/
				$.post("/account/survey.php",{
					"survey_id": survey_id,
					"method": "dashboard",
					"key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA"),
				},function(response){
				    try{

					data = JSON.parse(decrypt(response.data.response,crypt.decrypt(response.key)));
					questions_original = JSON.parse(decrypt(response.data.question,crypt.decrypt(response.key)));
					benchmark = JSON.parse(decrypt(response.data.benchmark,crypt.decrypt(response.key)));
					min_limit = JSON.parse(decrypt(response.data.min_limit,crypt.decrypt(response.key)));
					try{
					manager = JSON.parse(decrypt(response.data.manager,crypt.decrypt(response.key)));
					////console.log(manager);
					}
					catch(err)
					{
						//console.log(err);
					}
					}catch(err){
						loading(false);
						snackbar("Unable to Load the Dashboard");
						$('[href="#scorecard"]').tab('show');
						loaded_dashboard = false;
					}
					
					filter_init(data).then(() => {
						init_benchmark();
						init_heatmap();
						filter_apply();
						loading(false);
					});
				}).fail(err =>{
					snackbar("Loading Failed");
					console.log("lol");
					console.dir(err);
					loading(false);
				});	


				// for mapping Response 
				
				// $.post("/account/survey.php",
				// {
					// "survey_id": survey_id,
					// "method": "businessImpact",
					// "key": encrypt(crypt.getPublicKey(),"Vng7HPqGYASynERA")
				// },
				// function(data,status){
					
					// managerInformation = JSON.parse(data);
					
					// console.log("Business Impact Data array ",managerInformation);
					
					
					 
				// });
					
	
			/*}).fail(err =>{
					
				snackbar("Loading Failed");
				loading(false);
			});;
		}).fail(err =>{
			snackbar("Loading Failed");
			loading(false);
		});;*/

}

function encrypt(data,key){
	return CryptoJS.AES.encrypt(data, CryptoJS.enc.Utf8.parse(key),{
	mode: CryptoJS.mode.ECB,
	padding: CryptoJS.pad.Pkcs7
  }).toString();
}

function decrypt(data,key){
  return CryptoJS.AES.decrypt(data, CryptoJS.enc.Utf8.parse(key),{
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  }).toString(CryptoJS.enc.Utf8);
}

function init_benchmark(){
	var benchmark_html="";
	for(var industry in benchmark){
		benchmark_html  = benchmark_html+`<option>`+industry+`</option>`;
	}
	document.getElementById('benchmark_select').innerHTML = benchmark_html;
}

function benchmark_change(){
	var industry = document.getElementById('benchmark_select').value;
	for(var j in questions){
		if(questions[j]["code"].startsWith("ENGAGE")){
			ENGAGE_BENCHMARK_GRAPH("BENCHMARK_"+questions[j]["code"]+"_CHART",+benchmark[industry][questions[j]["code"]]["positive"],+benchmark[industry][questions[j]["code"]]["neutral"],+benchmark[industry][questions[j]["code"]]["negative"]);
		}
	}
	benchmark_index = ((+benchmark[industry]["ENGAGEALL"]["positive"]*100)/(+benchmark[industry]["ENGAGEALL"]["positive"]+ +benchmark[industry]["ENGAGEALL"]["negative"]));
	document.getElementById('benchmark_index').innerHTML = benchmark_index+"%";
}
async function filter_init(json){
	filters = new Array();
	for(var i in json[0]){
		if(i.startsWith("p_")){
			var filter_item  = new Array();
			filter_item.name=i;
			filter_item.title=i.replace("p_","").replace("_"," ").toProperCase();
			filter_item.value = new Array();
			filters.push(filter_item);
		}
	}
	for(var i in json){
		for(var j in filters){
			var column = filters[j].name;
			var value = json[i][column];
			if(!filters[j]["value"].includes(value)){
				filters[j]["value"].push(value);
			}
		}
	}
	for(var j in filters){
		filters[j]["value"].sort();
	}
	var filter_html = "";
	for(var i in filters){
		filter_html=filter_html+`<div class="col-lg-2 col-md-4 col-sm-6">
		<div class="card text-dark bg-light mt-3" >
		<div class="bg-primary text-white card-header font-weight-bold" style="white-space:nowrap; overflow: hidden; text-overflow: ellipsis;" onclick="filter_unselect('`+filters[i]["name"]+`')" ><i class="far fa-minus-square float-right" style="display: inline-block;" title="Unselect All" ></i><span  title="`+filters[i]["title"]+`">`+filters[i]["title"]+`</span></div>
		<input class="form-control" id="`+filters[i]["name"]+`_search" onkeyup="filter_option_text_change(this)" placeholder="Type `+filters[i]["title"]+` here" >
		<div class="card-body" style="height:200px; overflow: scroll; scrollbar-width: thin;" ><div id="`+filters[i]["name"]+`_option">`;
		for(j in filters[i].value){
			filter_html=filter_html+`<div class="custom-control custom-checkbox">
			<input class="custom-control-input" type="checkbox" id="`+filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`" checked="checked">
			<label class="custom-control-label" for="`+filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()+`"> `+filters[i]["value"][j]+`</label>
			</div>`;
		}
		filter_html=filter_html+`</div></div>
		</div>
		</div>`;
	}
	document.getElementById("container_filter").innerHTML = filter_html;
	ENGAGEMENT_QUESTION_COUNT=0;
	MANAGER_QUESTION_COUNT=0;
	LEADER_QUESTION_COUNT=0;
	WFH_QUESTION_COUNT=0;
	WFO_QUESTION_COUNT=0;
	HR_QUESTION_COUNT=0;
	WB_QUESTION_COUNT=0;
	OTHER_QUESTION_COUNT=0;
	OPEN_QUESTION_COUNT=0;
	for(var i in json[0]){
		if(i.startsWith("ENGAGE")){
			ENGAGEMENT_QUESTION_COUNT++;
		}else if(i.startsWith("LEADER")){
			LEADER_QUESTION_COUNT++;
		}else if(i.startsWith("MANAGER")){
			MANAGER_QUESTION_COUNT++;
		}else if(i.startsWith("WFH")){
			WFH_QUESTION_COUNT++;
		}else if(i.startsWith("WFO")){
			WFO_QUESTION_COUNT++;
		}else if(i.startsWith("HR")){
			HR_QUESTION_COUNT++;
		}else if(i.startsWith("WB")){
			WB_QUESTION_COUNT++;
		}else if(i.startsWith("CUSTOM")){
			OTHER_QUESTION_COUNT++;
		}else if(i.startsWith("OPEN")){
			OPEN_QUESTION_COUNT++;
		}
	}
	return true;
}

function filter_option_text_change(input){
	const id = input.id.replace("_search","")+"_option";
	const value = input.value.toLowerCase();
	////console.log(id+" "+value);
	$("#"+id+" div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
}

function filter_unselect(input){
	////console.log(input);
	////console.log(filters);
	for(var i in filters){
		if(filters[i]["name"]===input){
			for(var j in filters[i]["value"]){
				document.getElementById(filters[i]["name"]+"_"+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked = false;
			}
		}
	}
}

function filter_reset(){
	filter_init(data).then(() => {
		//console.log("hello");
		filter_apply();
	});
}

function filter_apply(){
	
	console.log("hello filter_apply Okay");
	filtered_data = new Array();
	filters_active = new Array();
	jQuery.extend(true,filters_active,filters);
	for(var i in filters_active){
		filters_active[i]["value"] = [];
	}
	////console.log(filters_active)
	for(var i in filters){
		for(j in filters[i].value){
			try{
				if(document.getElementById(filters[i]["name"]+`_`+filters[i]["value"][j].replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()).checked){
					filters_active[i]["value"].push(filters[i]["value"][j]);
				}
			}catch(err){
				console.log("Error: "+filters[i]["name"]+`_`+filters[i]["value"][j]);
				//console.log(err);
			}
		}
	}
	var filter_text="";
	for(var i in filters){
		if(filters_active[i].value.length<filters[i].value.length){
			filter_text = filter_text+filters_active[i].title+"("+filters_active[i].value.toString()+")  ";
		}
	}   
	
	for(var i in data){
		var valid = true;
		for(var j in filters_active){
			if(!filters_active[j].value.includes(data[i][filters_active[j]["name"]])){
				valid=false;
			}
		}
		if(valid){			
			filtered_data.push(JSON.parse(JSON.stringify(data[i])));
		}
	}
	document.getElementById("filter_text").innerHTML = "<strong>(# "+filtered_data.length+")</strong> "+filter_text;
  //  //console.log(min_limit);
	if(filtered_data.length<min_limit.min_filter){
		filtered_data = new Array();
		for(var i in data){
			filtered_data.push(JSON.parse(JSON.stringify(data[i])));
		}
		document.getElementById("filter_text").innerHTML=document.getElementById("filter_text").innerHTML+" <span style=\"font-size:14px\" >Not Enough Data (Showing Everything)<span>";
		modal("Not Enough Data","Data is too few to show insights <br> Showing all the data. Please select filter such that more data is selected");
	}
	update_ui();
	////console.log(filtered_data)
}


function update_ui(){
	questions = [];
	jQuery.extend(true,questions,questions_original);
	var MANAGER_INDEX = 0
	var ENGAGE_INDEX = 0;
	var LEADER_INDEX = 0;
	var WFH_INDEX = 0;
	var WFO_INDEX = 0;
	var HR_INDEX = 0;
	var WB_INDEX = 0;
	var ENGAGED=0;
	var NEARLY_ENGAGED=0;
	var NOT_ENGAGED=0;
	var DISENGAGED=0;
    var PERFORMANCE_HIGH=0;
    var PERFORMANCE_GOOD=0;
    var PERFORMANCE_AVG=0;
    var PERFORMANCE_LOW=0;
	var ATTRITION_RISK=0;
	var ATTRITION_HIGH=0;
	var ATTRITION_MEDIUM=0;
	var ATTRITION_LOW=0;
	var ATTRITION_RETAIN=0;
	var DIAGNOSTICS = {};
	
    riskZone = 0;
	riskCount =0;
		
	nonPerforming = 0;
	nonPerCount = 0 ;
		
	optimized = 0;
	optimizedCount = 0;
		
	subOptimized = 0;
	subOptimizedCount = 0 ;
		
	countryClub = 0;
	countryClubCount =0;
	businessImpactData = [];
	
	console.log("Dataset is ",data);
	
	//document.getElementById('correlation_scatterplot').innerHTML = JSON.stringify(CORRELATION_QUESTION_DATA, null, 2);
	////console.log(CORRELATION_QUESTION_DATA);
	// Start Business Impact Section here
	// calulating coordinate for Business Impact
	
	//let tempData = data;
	let tempData = filtered_data;
	businessImpactData = [];
	
	//console.log(businessImpactData.length);
	const totalManager =  [...new Set(tempData.map(x=>x.manager_Id))];
	let m=0;
	console.log("Total Manager is : ",totalManager);
	let xValue  = 0;
	let yValue = 0;
	let devident =0;
	let managerName = "";
	let pass = 0;
	

	for(let i=0;i<totalManager.length;i++)
	{
		devident =0;
		xValue = 0;
		yValue = 0;
		managerName = "";
		pass = 0;
		for(let j=0;j<tempData.length;j++)
		{
			if(totalManager[i]  == tempData[j].manager_Id)
			{
				
				if(pass == 0 )
				{
					for(let k=0;k<managerInformation.length;k++)
					{
						if(managerInformation[k].id == totalManager[i] )
						{
							pass = 1;
							managerName = managerInformation[k].managerName;
							break;
						}
					}
				}
				
				yValue = yValue +  parseInt(tempData[j].p_sales);
				xValue = xValue +  ( parseInt(tempData[j].ENGAGE01) + parseInt(tempData[j].ENGAGE02) + parseInt(tempData[j].ENGAGE03) + parseInt(tempData[j].ENGAGE04) + parseInt(tempData[j].ENGAGE05) ) / 5;
			
				devident ++;
			}
			
		}
		
		let quan = "";
		
		yValue = yValue / devident;
		
		xValue = xValue / devident;
		
		if(yValue > 0)
		{
			m++;
			if(yValue > 100 && xValue <= 3.8 )
			{
				riskZone = riskZone + yValue;
				riskCount ++;
				quan = "Risk Zone";
			}
			else if(yValue >= 100 && xValue > 3.8)
			{
				optimized = optimized + yValue;
				optimizedCount ++;
				
				quan = "Optimized";
			}
			else if((yValue <= 100 && yValue >=75) && xValue < 3.8  )
			{
				
				quan = "Risk Zone";
			}
			else if( (yValue <= 100 && yValue >=75) && xValue > 3.8)
			{
				subOptimized = subOptimized + yValue ;
				subOptimizedCount ++;
				quan = "Sub-Optimized";
			}
			else if((yValue < 75 && yValue >=0) && xValue < 3.8  )
			{
				nonPerforming = nonPerforming + yValue;
				nonPerCount ++;
				quan = "Non-Performing";
			}
			else if(( yValue <= 75 && yValue >=0) && xValue > 3.8)
			{
				countryClub = countryClub + yValue;
				countryClubCount ++;
				quan = "Country Club";
			}
			
			
			if(yValue > maxValueofY)
			{
				maxValueofY = yValue;
			}
			
				
			businessImpactData.push({
				"xAxis": xValue,
				"yAxis": yValue,
				"quadrant": quan,
				"teamSize" : devident,
				"managerName" : managerName
			});
		}
	}


	
	// End Business Impact section here
	businessImpact_select_change();
	
	if(ENGAGEMENT_QUESTION_COUNT<1){
		 $("#engagement_tab").addClass("d-none");
		 $("#diagnostic_tab").addClass("d-none");
		 $("#engagement_perc_2_card").addClass("d-none");
		 $("#engagement_index_2_card").addClass("d-none");
		 $('[href="#driver_analysis"]').tab('show');
	}
	if(OPEN_QUESTION_COUNT<1){
		 $("#qualitative_tab").addClass("d-none");
	}
	//comparator_setup();
}


function select_Business_Filter()
{
	let selectedValue = document.getElementById('businessImpact_select').value;
	
	console.log("Filter Value ",selectedValue);
	
	if(selectedValue == "ALL")
	{
		
		setBusinessImpactFilter = true;
		businessImpact_select_change();
	}
	else
	{
		setBusinessImpactFilter = false;
		businessImpact_select_change();
	}
}

// For Business Impact function Start here 
function businessImpact_select_change(){
	
	console.log("filter Data ",filtered_data);
   console.log("All Business Data : ",businessImpactData);
   businessImpactData2 = [];
	id = "businessImpact_scatterplot";
	if(maxValueofY > 0){
	
	var business_select = document.getElementById('businessImpact_select').value;
	
	if(setBusinessImpactFilter == true)
	{
		businessImpactData2 = businessImpactData;
	}
	else
	{
		businessImpactData2 = businessImpactData.filter(selectFilter => selectFilter.quadrant == business_select);
	}
	
	console.log("Busniss select data  ",businessImpactData2);
	
	//var temp_data = CORRELATION_QUESTION_DATA.filter( correlation => { if(correlation.question_code.startsWith(diagnostic_select)||diagnostic_select==="ALL") return true ;} );
	
	//console.log("Temp data find ",temp_data);
	
	// var diagnostic_recommendation=`<table class="table"><tr><th>Competency</th><th>Recommendation</th></tr>`;
	// for(var i in temp_data){
	//	//console.log(data[i]);
		// if(temp_data[i].score<75&&temp_data[i].correlation>=0.5)
			// diagnostic_recommendation = diagnostic_recommendation + `<tr><th>`+temp_data[i].driver+`</th><td>`+temp_data[i].description+`</td></tr>`;
	// }
	// diagnostic_recommendation = diagnostic_recommendation+`</table>`
	// document.getElementById("businessImpact_recommendation").innerHTML=diagnostic_recommendation;
	
	
	document.getElementById(id).innerHTML = '';
	// set the dimensions and margins of the graph
	var margin = {top: 10, right: 30, bottom: 40, left: 50},
	
    width = width = $('#'+id).actual('width') - margin.left - margin.right,
    height = 420 - margin.top - margin.bottom;

	var shape = d3.scaleOrdinal(businessImpactData2.map(d => d.quadrant), d3.symbols.map(s => d3.symbol().type(s)()));	
	// append the svg object to the body of the page
	var Svg = d3.select("#"+id)
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")")
  // Add X axis
  var x = d3.scaleLinear()
    .domain([0,5])
    .range([ 0, width ])
  Svg.append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(x).tickSize(-height*1.3).ticks(10))
    .select(".domain").remove()

  // Add Y axis
  var y = d3.scaleLinear()
    .domain([0, (maxValueofY + 20)])
    .range([ height, 0])
    .nice()
  Svg.append("g")
    .call(d3.axisLeft(y).tickSize(-width*1.3).ticks(7))
    .select(".domain").remove()
	
  // Customization
  Svg.selectAll(".tick line").attr("stroke", "#EBEBEB")

   // Add X axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("x", 40+width/2)
      .attr("y", height + margin.top + 20)
      .text("Team Engagement");

  // Y axis label:
  Svg.append("text")
      .attr("text-anchor", "end")
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left+20)
      .attr("x", 40-(height/2))
      .text("Business Performance");
  Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", 570)
    .attr("y1", 0)
    .attr("x2", 570)
    .attr("y2", height)
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	
	
	
	
   Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    // .attr("x1", 0)
    // .attr("y1", (height/2) * 1.1 )
    // .attr("x2", width)
    // .attr("y2", (height/2) * 1.1 )
	.attr("x1", 0)
    //.attr("y1", (maxValueofY/2) + 153  )
	// .attr("y1", (height - (75 *height) / maxValueofY )   )
    // .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 153  )
	// .attr("y2", (height - (75 *height) / maxValueofY )  )
	// .attr("fill-opacity","0.3")
	// .style("stroke-dasharray", ("3, 3"));
	// Svg.append('line')
    // .style("stroke", "grey")
    // .style("stroke-width", 2)
    // .attr("x1", 0)
    // .attr("y1", (height - (100 *height) / maxValueofY )  )
    // .attr("x2", width)
    // .attr("y2", (height - (100 *height) / maxValueofY )  )
	 .attr("y1", (maxValueofY/2) + 153  )
    .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 153  )
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append('line')
    .style("stroke", "grey")
    .style("stroke-width", 2)
    .attr("x1", 0)
    .attr("y1", (maxValueofY/2) + 115 )
    .attr("x2", width)
    .attr("y2", (maxValueofY/2) + 115 )
	.attr("fill-opacity","0.3")
	.style("stroke-dasharray", ("3, 3"));
	Svg.append("text")
        .attr("transform", "translate(0," + (height-10) + ")")
        .style("fill", "#D64550")
        .attr("font-size", "16px")
        .text("Non-Performing");
	Svg.append("text")
        .attr("transform", "translate(0," + (10) + ")")
        .style("fill", "#FFBF00")
        .attr("font-size", "16px")
        .text("Risk Zone");
	Svg.append("text")
        .attr("transform", "translate("+(width-75) +",10)")
        .style("fill", "#118DFF")
        .attr("font-size", "16px")
        .text("Optimized");
	Svg.append("text")
        .attr("transform", "translate("+(width-105) +","+ ( (maxValueofY/2) + 150 )+")")
        .style("fill", "#A0D1FF")
        .attr("font-size", "16px")
        .text("Sub-Optimized");
	Svg.append("text")
        .attr("transform", "translate("+(width-90) +"," + (height-10) + ")")
        .style("fill", "#F5C4AF")
        .attr("font-size", "16px")
        .text("Country Club");
	
	
	var tooltip = d3.select("#"+id)
    .append("div")
    .style("opacity", 0)
    .attr("class", "tooltip")
    .style("background-color", "white")
    .style("border", "solid")
    .style("border-width", "1px")
    .style("border-radius", "5px")
    .style("padding", "10px")
  // Color scale: give me a specie name, I return a color
    var color = d3.scaleOrdinal()
    .domain(["Non-Performing", "Risk Zone", "Optimized","Sub-Optimized","Country Club" ])
    .range([ "#D64550", "#FFBF00", "#118DFF","#A0D1FF","#F5C4AF"]);
	/*var color = d3.scaleOrdinal()
    .domain(["Leader", "Manager", "Work From Home","Work from Office","Human Resource","Well Being" ])
    .range([ "#1cc88a", "#36b9cc", "#e74a3b","#4e73df","#f6c23e","#858796"]);*/
	
	
	//console.log("Temp data ",temp_data);
  // Add dots
  Svg.append('g')
    .selectAll("dot")
    .data(businessImpactData2)
    .enter()
    .append("circle")
	  .attr("r", 20)
      .attr("cx", function (d) { return x(d.xAxis); } )
      .attr("cy", function (d) { return y(d.yAxis); } )
	  .style("fill", function (d) { return color(d.quadrant) } )
	  .attr("fill-opacity","0.5")
	  .on("mouseover", function(d) {
						tooltip
						  .style("opacity", 1)
					  } )
      .on("mousemove", function(d) {						
						tooltip
						  .html("Team Engagement : <b>"+d.xAxis.toFixed(2)+"</b><br>Business Performance: <b>"+d.yAxis.toFixed(2)+"%</b><br>Manager Name : <b>"+d.managerName+" </b><br>Team Size: <b>"+d.teamSize+"</b>")
						  .style("left", (d3.mouse(this)[0]+90) + "px")
						  .style("top", (d3.mouse(this)[1]) + "px")
						  .style("opacity", 1)
					  } )
      .on("mouseleave", function(d) {
						tooltip
						  .transition()
						  .duration(200)
						  .style("opacity", 0)
					  } );
					  
   /*var symbol = d3.symbol();
   Svg
    .selectAll("dot")
    .data(data)
    .enter()
    .append("path")
	.attr("d",symbol.type(function(d){
		if(d.quadrant == "Not Critical"){ return d3.symbolCross
		} else if (d.quadrant == "Sustenance"){ return d3.symbolDiamond
		} else if (d.quadrant == "Improvement"){ return d3.symbolSquare
		} else if (d.quadrant == "Low Focus"){ return d3.symbolStar
		}}).size(300))
    .attr("fill", function (d) { return color(d.category) } )
	.attr("fill-opacity","0.5")
	.attr('transform',function(d){ return "translate("+x(d.correlation)+","+y(d.score)+")"; });*/
	  $('[data-toggle="tooltip"]').tooltip();
	  
	  //console.log(riskCount,optimizedCount,nonPerCount,countryClubCount,subOptimizedCount);
	  
	let riskZoneData = riskZone / riskCount;
	if(riskZoneData > 0)
	{
	  document.getElementById("riskZoneTitle").innerHTML="Risk Zone";
	  document.getElementById("riskZoneIDNoOf").innerHTML=riskCount;
	  document.getElementById("riskZonedTarget").innerHTML=riskZoneData.toFixed(1);
	}
	else
	{
		document.getElementById("riskZoneTitle").innerHTML="";
	    document.getElementById("riskZoneIDNoOf").innerHTML="";
	    document.getElementById("riskZonedTarget").innerHTML="";
	}
	
	let optimizedData = optimized / optimizedCount ; 
	
	if(optimizedData > 0)
	{
	  document.getElementById("optimizedTitle").innerHTML="Optimized";
	  document.getElementById("optimizedNoOf").innerHTML=optimizedCount;
	  document.getElementById("optimizedTarget").innerHTML=optimizedData.toFixed(1);
	}
	else
	{
	  document.getElementById("optimizedTitle").innerHTML="";
	  document.getElementById("optimizedNoOf").innerHTML="";
	  document.getElementById("optimizedTarget").innerHTML="";
	}
	
	
	let subOptimizedData = subOptimized / subOptimizedCount;
	
	if(subOptimizedData > 0)
	{
	  document.getElementById("subOptimizedTitle").innerHTML="Sub-Optimal";
	  document.getElementById("subOptimizedNoOf").innerHTML=subOptimizedCount;
	  document.getElementById("subOptimizedTarget").innerHTML=subOptimizedData.toFixed(1);	
	}
	else
	{
	  document.getElementById("subOptimizedTitle").innerHTML="";
	  document.getElementById("subOptimizedNoOf").innerHTML="";
	  document.getElementById("subOptimizedTarget").innerHTML="";	
	}
	
	let countryClubData = countryClub / countryClubCount;
	
	if(countryClubData > 0)
	{
	  document.getElementById("countryClubTitle").innerHTML="Country Club";
	  document.getElementById("countryClubNoOf").innerHTML=countryClubCount;
	  document.getElementById("countryClubTarget").innerHTML=countryClubData.toFixed(1);	
	}
	else
	{
	  document.getElementById("countryClubTitle").innerHTML="";
	  document.getElementById("countryClubNoOf").innerHTML="";
	  document.getElementById("countryClubTarget").innerHTML="";
	}
	
	let nonPerformingData = nonPerforming / nonPerCount;
	
	if(nonPerformingData > 0)
	{
		document.getElementById("nonPerformTitle").innerHTML="Non-Performing";
		document.getElementById("nonPerformingNoOf").innerHTML=nonPerCount;
	    document.getElementById("nonPerformingTarget").innerHTML=nonPerformingData.toFixed(1);
	}
	else
	{
		document.getElementById("nonPerformTitle").innerHTML="";
		document.getElementById("nonPerformingNoOf").innerHTML="";
	    document.getElementById("nonPerformingTarget").innerHTML="";
	}
	
	// Details Tables 
	
	// let tableData = `<table class="table">  
	
		// <thead>
			// <tr>
				// <th>Manager Name</th>
				// <th>Team Size</th>
				// <th>Team Engagement</th>
				// <th>Business Performance</th>
				
			// </tr>
		// </thead>
		
		// <tbody>`+
		
		
			// for(let i=0;i<businessImpactData.length;i++)
			// {
				// +`<tr>
					
					// <td>`+ businessImpactData[i].managerName+`</td>
					// <td>`+businessImpactData[i].teamSize+`</td>
					// <td>`+businessImpactData[i].xAxis+`</td>
					// <td>`+businessImpactData[i].yAxis+`</td>
				// </tr>`+
			// }
			
			
		// +`</tbody>
		
		
		
		// </table>`;
		
		//console.log(businessImpactData2.length);
	
		document.getElementById('tableBodyDetails').innerHTML = "";
		
		let tableBody = document.getElementById('tableBodyDetails');
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Risk Zone")
			{
				td1.style.color = "#FFBF00";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Non-Performing")
			{
				td1.style.color = "#D64550";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Optimized")
			{
				td1.style.color = "#118DFF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Sub-Optimized")
			{
				td1.style.color = "#A0D1FF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		
		for(let i=0;i<businessImpactData2.length;i++)
		{
			let tr = document.createElement('tr');
			let td1 = document.createElement('td');
			let td2 = document.createElement('td');
			let td3 = document.createElement('td');
			let td4 = document.createElement('td');
			
			if(businessImpactData2[i].quadrant == "Country Club")
			{
				td1.style.color = "#F5C4AF";
				
				td1.innerHTML = ( businessImpactData2[i].managerName);
				td2.innerHTML = ( businessImpactData2[i].teamSize);
				td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
				td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
		
				tr.appendChild(td1);
				tr.appendChild(td2);
				tr.appendChild(td3);
				tr.appendChild(td4);
				tableBody.appendChild(tr);
			}
		}
		
		
		// for(let i=0;i<businessImpactData2.length;i++)
		// {
			// let tr = document.createElement('tr');
			
			// let td1 = document.createElement('td');
			// let td2 = document.createElement('td');
			// let td3 = document.createElement('td');
			// let td4 = document.createElement('td');
			
			// if(businessImpactData2[i].quadrant == "Risk Zone")
			// {
				// td1.style.color = "#9E9E9E";
			// }
			// else if(businessImpactData2[i].quadrant == "Non-Performing")
			// {
				// td1.style.color = "#D64550";
			// }
			// else if(businessImpactData2[i].quadrant == "Optimized")
			// {
				// td1.style.color = "#118DFF";
			// }
			// else if(businessImpactData2[i].quadrant == "Sub-Optimized")
			// {
				// td1.style.color = "#A0D1FF";
			// }
			// else if(businessImpactData2[i].quadrant == "Country Club")
			// {
				// td1.style.color = "#F5C4AF";
			// }
			
			// td1.innerHTML = ( businessImpactData2[i].managerName);
			// td2.innerHTML = ( businessImpactData2[i].teamSize);
			// td3.innerHTML = ( businessImpactData2[i].xAxis).toFixed(1);
			// td4.innerHTML = ( businessImpactData2[i].yAxis).toFixed(1);
			
			
			// tr.appendChild(td1);
			// tr.appendChild(td2);
			// tr.appendChild(td3);
			// tr.appendChild(td4);
			
			
			// tableBody.appendChild(tr);
			
			
		// }
		
	}else{
		document.getElementById(id).innerHTML = '<center><h2>Not enough Data</h2></center>';
		document.getElementById("businessImpact_recommendation").innerHTML='';
		document.getElementById('correlation_index').innerHTML = '';
	}
}



// Business Impact end here 



/*
	Image Downloading Function
*/






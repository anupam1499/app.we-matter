<?php
include("../../includes/config.php");
confirm_logged_in();
if($_SESSION["role_selected"]["role_id"]!="1"){
	session_message("You don't have permssion to edit users.","danger");
	redirect_to(PROTOCOL.WEBSITE_URL);
}

$title="User";
$method="manage";
if(isset($_REQUEST["method"]))
{
	$method = $_REQUEST["method"];

}
$output="html";
if(isset($_REQUEST["output"]))
	$output=$_REQUEST["output"];

if($method==="add"){
	if(isset($_REQUEST["submit"],$_REQUEST["email_list"],$_REQUEST["type"])){
		$emails = explode("\n",$_REQUEST["email_list"]);
		foreach($emails as $email){
			$email=trim(strtolower($email));
			if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$user = user_get($email);
				if(!$user){
					
					if($_REQUEST["type"]==="2"){
						$user_type="Leader";
					}else if($_REQUEST["type"]==="3"){
						$user_type="User";
					}
					$password = strtolower(generate_salt(8));
					
					$user_id = execute_insert_query("INSERT INTO `user`(`email`,`password`,`created_at`,`modified_at`) VALUES ('".mysql_prep($email)."','".mysql_prep(password_encrypt($password))."',".get_sql_india_time().",".get_sql_india_time().");");
					$user = user_get($user_id);
					
					//$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login&email=".$email."&password=".$password."&submit=login";
					//$message= "You have been added as a ".$user_type."<br>username: ".$email."<br>password: ".$password."<br><br>You can click on the link to login";
					//$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
					//send_mail(APP_EMAIL_ID,APP_NAME,$email,APP_NAME.": Account Activation",get_action_email_template("",APP_NAME,$message,"Login",$login_url));
				}else{
					$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login";
					$message= "You have been added as a ".$user_type;
					//send_mail(APP_EMAIL_ID,APP_NAME,$email,APP_NAME.": Account Activation",get_action_email_template("",APP_NAME,$message,"Login",$login_url));
				}
				
				if($user){
					
					$name=trim(ucwords(preg_replace('/[^a-zA-Z]/s',' ',explode("@",$email)[0]))); 
					execute_insert_query("INSERT INTO `account_linking`(`account_id`, `role_id`, `user_id`,`name`) VALUES ('".mysql_prep($_SESSION["role_selected"]["account_id"])."',".mysql_prep($_REQUEST["type"]).",".$user["user_id"].",'".mysql_prep($name)."');");
				}

			}
		}
		//$user = user_add($_REQUEST["user_name"],$_REQUEST["column1"],$_REQUEST["column2"],$_REQUEST["column3"]);
		if($output==="json"){
			json_output($user);
		}else{
			echo "Success";
		}
	}else{
		if($output==="json"){
			json_message("submit,email_list,type are required variable");
		}else{
			?><form id="user_form" action="user.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="add">
			<div class="form-group">
				<label>User Type</label>
				<select name="type" class="form-control">
					<option value="2">Leader</option>
					<option value="3" selected="selected">Manager/Sub Leader/Grid Leader</option>
				</select>
			</div>
			<div class="form-group">
				<label>Email List</label>
				<textarea id="email_list" name="email_list" style="height:200px;" class="form-control" placeholder="manager1@email.com&#10;manager2@email.com&#10;manager3@email.com"></textarea>
			</div>
			<input type="hidden" name="submit" value="Add" />
			<button class="btn btn-success" type="button" onclick="user_submit()">Add</button>
			<button class="btn btn-secondary" type="button" onclick="user_view(user_page)">Back</button>
			</form><?php
			exit(0);
		}
	}
}else if($method==="send_login_credential"){
	$emails = ToArrays(execute_query("SELECT DISTINCT `U`.`email`
				FROM `user` U
				LEFT JOIN 
					`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
					AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
				WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
	foreach($emails as $email){
		$email = strtolower(trim($email["email"]));
		$auth_code = generate_salt(32);
		execute_query("DELETE FROM `auth` WHERE `auth_type` = 5 AND `email` = '".mysql_prep($email)."';");
		$auth_id = execute_insert_query("INSERT INTO `auth`(`auth_type`, `auth_code`, `email`, `created_at`) VALUES ('5','".mysql_prep($auth_code)."','".mysql_prep($email)."',".get_sql_india_time().");");
		$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=autologin&auth=".$auth_code;
		$message= APP_NAME." has shared the Auto Signin URL with you. Just click on the link/button to signin to the dashboard. ";
		$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
		add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",0,APP_NAME.": Account Signin",$message,"Login",$login_url,1,0,false);
	}
	session_message(count($emails)." mails with auto signin information is being send","success");
	send_mail_start();
	redirect_to("user.php?method=manage");
}else if($method==="user_credential"){
	$emails = ToArrays(execute_query("SELECT DISTINCT `U`.`email`
				FROM `user` U
				LEFT JOIN 
					`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
					AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
				WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `U`.`user_id` = ".mysql_prep($_REQUEST["user_id"]).";"));
	//print_r($emails);
	//exit(0);
	foreach($emails as $email){
		$email = strtolower(trim($email["email"]));
		$auth_code = generate_salt(32);
		execute_query("DELETE FROM `auth` WHERE `auth_type` = 5 AND `email` = '".mysql_prep($email)."';");
		$auth_id = execute_insert_query("INSERT INTO `auth`(`auth_type`, `auth_code`, `email`, `created_at`) VALUES ('5','".mysql_prep($auth_code)."','".mysql_prep($email)."',".get_sql_india_time().");");
		$login_url = PROTOCOL.WEBSITE_URL."/user/userauth.php?method=autologin&auth=".$auth_code;
		$message= APP_NAME." has shared the Auto Signin URL with you. Just click on the link/button to signin to the dashboard. ";
		$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$login_url."\">".$login_url."</a>";
		add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",0,APP_NAME.": Account Signin",$message,"Login",$login_url,1,0,false);
	}
	send_mail_start();
	json_message("Email with auto signin information is being send");
	//session_message(count($emails)." mails with auto signin information is being send","success");
	//redirect_to("user.php?method=manage");
}else if($method==="delete"){
	if(isset($_REQUEST["user_id"])){
		execute_query("DELETE FROM `account_linking` WHERE `user_id` = ".$_REQUEST["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
		execute_query("DELETE FROM `survey_mapping` WHERE `user_id` = ".$_REQUEST["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
		json_message("User removed from your account");
	}else{
		json_message("user_id is a required paramter");
	}
}else if($method==="view"){
	$q="";
	if(isset($_REQUEST["q"]))
		$q = $_REQUEST["q"];
	$page=0;
	if(isset($_REQUEST["page"]))
		$page = $_REQUEST["page"];
		$users = ToArrays(execute_query("SELECT `U`.`user_id`,`U`.`email` FROM `user` U
				LEFT JOIN 
					`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
					AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
				WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%') ORDER BY `U`.`created_at` LIMIT 30 OFFSET ".($page*30).";"));
		$user_count = ToArray(execute_query("SELECT count(*) AS user_count FROM `user` U
				LEFT JOIN 
					`account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
					AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
				WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."  AND (`email` like '%".mysql_prep($q)."%' OR  `name` like '%".mysql_prep($q)."%');"))["user_count"];
				
		if($_REQUEST["output"]==="json"){
			$response["count"]=$user_count;
			$response["page"]=$page;
			$response["users"]=$users;
			json_output($response);
		}else{
			?>
			<div class="card">
			  <div class="card-header">
			  <button type="button" class="btn btn-secondary float-right ml-1" onclick="user_add()" ><i class="fa fa-plus" ></i></button>
			<?php
					
					if((($page+1)*30)<$user_count)
					   echo "<button class=\"btn btn-secondary float-right ml-1\" title=\"Next Page\" type=\"button\" onclick=\"user_view(".($page+1).")\" ><i class=\"fa fa-angle-right\" ></i></button>";
					   echo "<span class=\"btn float-right ml-1\" title=\"Page Number\" type=\"button\" >".($page+1)."</span>";
					if($page!=0)
					   echo "<button  class=\"btn btn-secondary float-right ml-1\" title=\"Previous Page\" type=\"button\" onclick=\"user_view(".($page-1).")\" ><i class=\"fa fa-angle-left\" ></i></button>";
					echo "<button class=\"btn btn-info float-right ml-1\" onclick=\"upload_user_modal();\" title=\"Download\" type=\"button\"> <i class=\"fa fa-upload\"  ></i></button>";
					echo "<a class=\"btn btn-info float-right ml-1\" title=\"Send Credentials\" href=\"?method=send_login_credential\" onclick=\"return confirm('Are you sure you want to email all the user the credentials for logging in?')\"> <i class=\"fa fa-key\" ></i></a>";
					echo "<button class=\"btn btn-danger float-right ml-1\" title=\"Delete Users\" onclick=\"delete_user_modal()\"> <i class=\"fa fa-trash\" ></i></button>";
					?>
					<form class="form-inline" action="" onsubmit="return false;">
						<div class="input-group">
							<input id="user_search_text" type="text" class="form-control" placeholder="Search&hellip;" value="<?php echo $q;?>" onkeypress="if(event.keyCode==13) user_view(0);">
							<span class="input-group-append">
								<button type="button" class="btn btn-secondary" onclick="user_view(0)" ><i class="fa fa-search" ></i></button>
							</span>
						</div>
					</form>
			  </div>
			  <div id="user_manage" class="card-body">
				<table class="table">
				<tr><th>Email</th><!--<th>Manager Subordinate</th><th>Leader Subordinate</th>--><th style="width:160px; text-align:right;" >Manage</th></tr>
				<?php
				foreach($users as $user){
					echo "<tr><td onclick=\"user_profile_view('".$user["user_id"]."')\"><i class=\"fas fa-xs fa-pen mr-3\"></i>".$user["email"]."</td><td>";
						 //echo "<button type=\"button\" class=\"btn btn-secondary ml-1\" onclick=\"user_profile_view('".$user["user_id"]."')\"><i class=\"fas fa-pen\" ></i></button>";
						 echo "<div class=\"dropdown d-inline float-right\">
						  <div class=\"d-inline\">
							  <button type=\"button\" class=\"btn btn-info dropdown-toggle ml-1\" data-toggle=\"dropdown\">
								<i class=\"fas fa-key\" ></i>
							  </button>
							  <div class=\"dropdown-menu\">
								<button class=\"dropdown-item\"  onclick=\"user_credential(".$user["user_id"].")\" >Confirm Send Credentials?</button>
							  </div>						  
						  </div>
						  <div class=\"d-inline\">
							  <button type=\"button\" class=\"btn btn-danger dropdown-toggle ml-1\" data-toggle=\"dropdown\">
								<i class=\"fas fa-trash\" ></i>
							  </button>
							  <div class=\"dropdown-menu\">
								<button class=\"dropdown-item\"  onclick=\"user_delete(".$user["user_id"].")\" >Confirm Delete User?</button>
							  </div>
						  </div>
						  </div>";
					echo "</td></tr>";
				}
				?>
				</table>
			  </div>
			</div>
			<?php
		}
				
}else if($method==="upload"){
if(is_uploaded_file($_FILES['upload_users']['tmp_name'])){
	//session_message("Report Data is Saved","success");
	if (($handle = fopen($_FILES['upload_users']['tmp_name'], "r")) !== FALSE) {
		$header = fgetcsv($handle);
		if($header[0]==="email"&&$header[1]==="role_id"&&$header[2]==="name"&&$header[3]==="id"&&$header[4]==="designation"&&$header[5]==="gender"&&$header[6]==="location"&&$header[7]==="department"){
			while (($data = fgetcsv($handle)) !== FALSE) {
				$info = array();
				$user = ToArray(execute_query("SELECT * FROM `user` WHERE `email` = '".mysql_prep($data[0])."';"));
				if(count($data)>8){
					for($a=8;$a<count($data);$a++){
						$info[$header[$a]]=$data[$a];
					}
				}
				$role_id = "0";
					if($data[1]==="2"||$data[1]==="3"){
						$role_id = $data[1];
					}
				if($user){
					$account = ToArray(execute_query("SELECT * FROM `account_linking` WHERE `user_id` = ".$user["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"].";"));
					if(!$account){
						$account_linking_id = execute_insert_query("INSERT INTO `account_linking`(`account_id`,`user_id`,`role_id`) VALUES (".mysql_prep($_SESSION["role_selected"]["account_id"]).",".mysql_prep($user["user_id"]).",".mysql_prep($role_id).")");
						//$account = ToArray(execute_query("SELECT * FROM `account_linking` WHERE `account_linking_id` = ".$account_linking_id));
					}
				}else{
					$password = strtolower(generate_salt(8));
					$user = new_user($data[0],$password);
					$account_linking_id = execute_insert_query("INSERT INTO `account_linking`(`account_id`,`user_id`,`role_id`) VALUES (".mysql_prep($_SESSION["role_selected"]["account_id"]).",".mysql_prep($user["user_id"]).",".mysql_prep($role_id).")");
					//$account = ToArray(execute_query("SELECT * FROM `account_linking` WHERE `account_linking_id` = ".$account_linking_id));
				}
				execute_query("UPDATE `account_linking` 
				SET ".($role_id!="0"?"`role_id`='".mysql_prep($role_id)."',":"")."
				`name`='".mysql_prep($data[2])."',`id`='".mysql_prep($data[3])."',
				`designation`='".mysql_prep($data[4])."',
				`gender`='".mysql_prep($data[5])."',`location`='".mysql_prep($data[6])."',
				`department`='".mysql_prep($data[7])."',
				`info` = '".mysql_prep(json_encode($info,TRUE))."'
				WHERE `user_id` = ".$user["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"].";");
			}
			json_message("Uploaded Successfully");
			exit(0);
		}else{
			json_message("Data columns not correct. Please download the template ,edit and then upload it.");
			exit(0);
		}
		fclose($handle);
	}
}else{
	json_message("File was not uploaded correctly");
	exit(0);
}
json_message("Unknown Error");
exit(0);
//redirect_to("?method=manage");
}else if($method==="download"){
	$users = ToArrays(execute_query("SELECT `U`.`email`,AL.`role_id`,`AL`.`name`,`AL`.`id`,`AL`.`designation`,`AL`.`gender`,`AL`.`location`,`AL`.`department`,`AL`.`info` FROM `user` U
	LEFT JOIN `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
	AND `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]."
	WHERE `AL`.`account_id` = ".$_SESSION["role_selected"]["account_id"]." ORDER BY `U`.`created_at`;"));
	$response = array();
	foreach($users as $user){
		$temp=$user;
		unset($temp["info"]);
		unset($info);
		if($user["info"]!=""){
			$infos = json_decode($user["info"],true);
			foreach($infos as $key => $value){
				$temp[$key]=$value;
			}
		}
		$response[] = $temp;
	}
	csv_output("Users",$response);
}else if($method==="delete_bulk"){
	if(isset($_REQUEST["submit"],$_REQUEST["email_list"])){
		$emails = explode("\n",$_REQUEST["email_list"]);
		foreach($emails as $email){
			$user = user_get(strtolower(trim($email)));
			if(isset($user["user_id"])){
				execute_query("DELETE FROM `account_linking` WHERE `user_id` = ".$user["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
				execute_query("DELETE FROM `survey_mapping` WHERE `user_id` = ".$user["user_id"]." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
			}
		}
	}
	if($_REQUEST["output"]==="json"){
		json_message("Users are deleted");
	}else{
		redirect_to("user.php");
	}
}else if($method==="profile_view"){
	$user = ToArray(execute_query("SELECT `U`.email,`A`.* FROM `account_linking` A LEFT JOIN `user` U ON `A`.`user_id` = `U`.`user_id` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND `A`.`user_id` = ".mysql_prep($_REQUEST["user_id"])));
	?>
	<div class="card">
	<div class="card-header">User Details</div>
	<div class="card-body">
		<form id="user_profile_form" action="user.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="profile_save">
			<input type="hidden" name="user_id" value="<?php echo $user["user_id"];?>">
			<div class="form-group">
				<label>Email</label>
				<input class="form-control" type="text" name="email" value="<?php echo $user["email"];?>" disabled>
			</div>
			<div class="form-group">
				<label>User Type</label>
				<select name="role_id" class="form-control" <?php echo($user["role_id"]==="1"?"disabled":"");?>>
					<option value="1" <?php echo($user["role_id"]==="1"?"selected=\"selected\"":"");?> disabled>Admin</option>
					<option value="2" <?php echo($user["role_id"]==="2"?"selected=\"selected\"":"");?>>Leader</option>
					<option value="3" <?php echo($user["role_id"]==="3"?"selected=\"selected\"":"");?>>Manager/Sub Leader/Grid Leader</option>
				</select>
			</div>
			<div class="form-group">
				<label>Name</label>
				<input class="form-control" type="text" name="name" value="<?php echo $user["name"];?>">
			</div>
			<div class="form-group">
				<label>Employee ID</label>
				<input class="form-control" type="text" name="id" value="<?php echo $user["id"];?>">
			</div>
			<div class="form-group">
				<label>Designation</label>
				<input class="form-control" type="text" name="designation" value="<?php echo $user["designation"];?>">
			</div>
			<div class="form-group">
				<label>Gender</label>
				<select  class="form-control" name="gender">
					<option value="0"<?php echo ($user["gender"]==="0"?" selected=\"selected\" ":"");?>>Undiscosed</option>
					<option value="1"<?php echo ($user["gender"]==="1"?" selected=\"selected\" ":"");?>>Male</option>
					<option value="2"<?php echo ($user["gender"]==="2"?" selected=\"selected\" ":"");?>>Female</option>
				</select>
			</div>
			<div class="form-group">
				<label>Location</label>
				<input class="form-control" type="text" name="location" value="<?php echo $user["location"];?>">
			</div>
			<div class="form-group">
				<label>Department</label>
				<input class="form-control" type="text" name="department" value="<?php echo $user["department"];?>">
			</div>
			<div class="form-group">
				<label>Info <b>* Can be updated only is csv upload</b></label>
			</div>
			<?php $infos = json_decode($user["info"]);
			foreach($infos as $key => $value){
				echo "<div class=\"form-group\">
						<label>".$key."</label>
						<input class=\"form-control\" value=\"". $value."\" disabled/>
					</div>";
			}
			?>
			
			<input type="hidden" name="submit" value="save" />
			<button class="btn btn-success" type="button" onclick="user_save()">Save</button>
		</form>
	</div>
	<?php
}else if($method==="profile_save"){
	execute_query("UPDATE `account_linking` SET `name`='".mysql_prep($_REQUEST["name"])."',`id`='".mysql_prep($_REQUEST["id"])."',`designation`='".mysql_prep($_REQUEST["designation"])."',`gender`='".mysql_prep($_REQUEST["gender"])."',`location`='".mysql_prep($_REQUEST["location"])."',`department`='".mysql_prep($_REQUEST["department"])."',`info`='".mysql_prep($_REQUEST["info"])."' WHERE `user_id` = ".mysql_prep($_REQUEST["user_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
	if(isset($_REQUEST["role_id"])&&$_REQUEST["role_id"]!="1"){
		execute_query("UPDATE `account_linking` SET `role_id`='".mysql_prep($_REQUEST["role_id"])."' WHERE `user_id` = ".mysql_prep($_REQUEST["user_id"])." AND `account_id` = ".$_SESSION["role_selected"]["account_id"]);
	}
	json_message("Data Saved");
}else{
	include(app_header());?>
	<div class="row">
		<div id="user_manage" class="col-md-6">
			
		</div>
		<div id="user_profile" class="col-md-6">
		</div>
		<!--<div class="col-md-4">
			<div class="card">
			  <div class="card-header">
				User Mapping
			  </div>
			  <div class="card-body">
			  <form id="mapping_form" enctype="multipart/form-data" method="post" action="user.php" > 
				<input type="hidden" name="method" value="map">
				<input type="hidden" name="submit" value="Add">
				<div class="form-group">
					<label>Mapping Type</label>
					<select name="type" class="form-control">
						<option value="3">Manager</option>
						<option value="2">Leader</option>
					</select>
				</div>
				<div class="form-group">
					<label>Mapping Details</label>
					<textarea id="mapping_content" name="mapping_content" style="height:200px;" class="form-control" placeholder="manager1@email.com,EMPID01&#10;manager1@email.com,EMPID02&#10;manager2@email.com,EMPID03"></textarea>
				</div>
				<div class="form-group">
					<label>Or Upload Mapping File  <a class="btn btn-sm btn-secondary" href="?method=mapping_template" title="Download Template" target="_blank"><i class="fas fa-download"></i></a></label>
					<input type="file" id="mapping_file" name="mapping_file" accept="csv">
				</div>
				<div class="form-group">
					<button class="btn btn-success" onclick="mapping_add();return false;" >Add</button>
				</div>
				</form>
			  </div>
			</div>
		</div>-->
	</div>
	<?php 
	include(app_script());?>
	<script>
	var user_page = 0;
	console.log("ON script Load");
	$(function() {
		console.log("ON page Load");
		user_view(user_page);
	});
	function user_view(page) {
		user_page = page;
		var user_search_text = "";
		try{user_search_text = document.getElementById("user_search_text").value;}catch(err){}
		$.get("user.php?method=view&q="+encodeURI(user_search_text)+"&page="+encodeURI(page), function(data) {
			document.getElementById("user_manage").innerHTML=data;
			
		});
	}
	function user_add() {
		$.get("user.php?method=add", function(data) {
			document.getElementById("user_manage").innerHTML=data;
		});
	}
	function user_delete(user_id){
		$.get("user.php?method=delete&user_id="+user_id, function( data ) {
			user_view(user_page);
		});
	}
	function user_credential(user_id){
		$.get("user.php?method=user_credential&user_id="+user_id, function( data ) {
			snackbar(data.message);
		});
	}
	function user_delete_bulk_submit(){
		$.ajax({
		  url: 'user.php', 
		  type: 'POST',
		  data: new FormData($('#user_form_delete_bulk')[0]),
		  processData: false,
		  contentType: false
		}).done(function(data){
			$('#modal').modal('hide');
			user_view(user_page);
		}).fail(function(){
			snackbar("Saving Failed");
		});
	}
	function user_upload_submit(){
		loading(true);
		$('#modal').modal('hide');
		$.ajax({
		  url: 'user.php', 
		  type: 'POST',
		  data: new FormData($('#user_form_upload')[0]),
		  processData: false,
		  contentType: false
		}).done(function(data){
			loading(false);
			
			user_view(user_page);
			snackbar(data.message);
		}).fail(function(){
			loading(false);
			snackbar("Saving Failed");
		});
	}
	function user_submit() {
			$.ajax({
			  url: 'user.php', 
			  type: 'POST',
			  data: new FormData($('#user_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				user_view(user_page);
			}).fail(function(){
				snackbar("Saving Failed");
			});
		}
	function user_profile_view(user_id){
		$.get("user.php?method=profile_view&user_id="+user_id, function(data) {
			document.getElementById("user_profile").innerHTML=data;
			scrollTo("user_profile");
		});
	}
	function user_save(){
		$.ajax({
			  url: 'user.php', 
			  type: 'POST',
			  data: new FormData($('#user_profile_form')[0]),
			  processData: false,
			  contentType: false
			}).done(function(data){
				snackbar(data.message);
			}).fail(function(){
				snackbar("Saving Failed");
			});
	}
	function upload_user_modal(){
		modal("Upload User",`The Uploaded File should be updated version of this <a class="btn btn-warning" href="?method=download" target="_blank"><i class="fa fa-download"></i> File</a><br>
		<form id="user_form_upload" method="POST" enctype="multipart/form-data">
			<input type="hidden" name="method" value="upload">
			<div class="form-group">
				<input type="file" name="upload_users" accept=".csv" required="">
			</div>
			<button class="btn btn-success" type="button" onclick="user_upload_submit()">Upload</button>
		</form>`);
	}
	function delete_user_modal(){
		modal("Delete User Bulk",`<form id="user_form_delete_bulk" action="user.php" method="POST">
			<input class="form-control" name="method" type="hidden" value="delete_bulk">
			<input class="form-control" name="output" type="hidden" value="json">
			<div class="form-group">
				<label>Email List</label>
				<textarea id="email_list" name="email_list" style="height:200px;" class="form-control" placeholder="manager1@email.com&#10;manager2@email.com&#10;manager3@email.com"></textarea>
			</div>
			<input type="hidden" name="submit" value="Delete" />
			<button class="btn btn-success" type="button" onclick="user_delete_bulk_submit()">Delete</button>`);
	}
	</script>
	<?php include(app_footer());
}
?>

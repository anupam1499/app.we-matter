<?php
function send_mail($FROM_EMAIL,$FROM_NAME,$TO,$SUBJECT,$MESSAGE) {
	send_mail_aws_ses($FROM_EMAIL,$FROM_NAME,$TO,$SUBJECT,$MESSAGE);
	/*$headers = "From: ".$FROM_NAME."<".APP_EMAIL_ID.">\r\n";
	$headers .= "Reply-To: ".$FROM_NAME."<".$FROM_EMAIL."\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	$headers .= "X-Priority: 1\r\n"; 
	return mail("$TO","$SUBJECT","$MESSAGE","$headers","-f$FROM_EMAIL");*/
}
function send_mail_aws_ses($FROM_EMAIL,$FROM_NAME,$TO,$SUBJECT,$MESSAGE){
	$credentials = new Aws\Credentials\Credentials('AKIARKI5456K4BYN5ZKS','UZT7qIvd0TX70c6YZU0oHZKRlvk283NNyZa8AHMu');
	$client = Aws\Ses\SesClient::factory(array(
		'version'=> 'latest',     
		'region' => 'ap-south-1',
		'credentials' => $credentials
	));

	$request = array();
	$request['Source'] = APP_NAME.' <'.APP_EMAIL_ID.'>';
	$request['Destination']['ToAddresses'] = array($TO);
	$request['Message']['Subject']['Data'] = $SUBJECT;
	$request['Message']['Body']['Html']['Data'] = $MESSAGE;
	$request['ReplyToAddresses'] = array($FROM_EMAIL);
	try {
		 $result = $client->sendEmail($request);
		 return true;
	} catch (Exception $e) {
			echo $e->getMessage();
		 return false;
	}
}
function get_action_email_template($name,$from,$content,$action_name,$action) {
	ob_start();
	include(ROOT_DIRECTORY."/includes/layout/email_action.php");
	return ob_get_clean();
}
function get_plain_email_template($name,$from,$content) {
	ob_start();
	include(ROOT_DIRECTORY."/includes/layout/email_plain.php");
	return ob_get_clean();
}
function get_empty_email_template($content) {
	ob_start();
	include(ROOT_DIRECTORY."/includes/layout/email_plain.php");
	return ob_get_clean();
}
function get_scorecard_email_template($content,$action_name,$action) {
	ob_start();
	include(ROOT_DIRECTORY."/includes/layout/email_scorecard.php");
	return ob_get_clean();
}
function add_to_mail_queue($from_email,$from_name,$from_user_id,$to_email,$to_name,$to_user_id,$subject,$message,$action_value,$action_url,$notification_type,$notifier_group_id,$send=true){
	if(strpos($from_email,'@')!==false&&strpos($to_email,'@')!==false){
		$notifier_id = execute_insert_query("INSERT INTO `notifier`(`to_name`, `to_email`, `to_user_id`, `from_name`, `from_email`, `from_user_id`, `subject`, `message`, `action_value`, `action_url`, `notification_type`, `email_sent`, `sent_on`, `browser_code`,`notifier_group_id`) VALUES ('".mysql_prep($to_name)."', '".mysql_prep($to_email)."', '".mysql_prep($to_user_id)."', '".mysql_prep($from_name)."', '".mysql_prep($from_email)."', '".mysql_prep($from_user_id)."', '".mysql_prep($subject)."', '".mysql_prep($message)."', '".mysql_prep($action_value)."', '".mysql_prep($action_url)."', '".mysql_prep($notification_type)."', 0, ".get_sql_india_time().", '".generate_auth_code()."',".mysql_prep($notifier_group_id).");");
		$notification = ToArray(execute_query("SELECT * FROM `notifier` WHERE `notifier_id` = ".$notifier_id." LIMIT 1"));
		$message = $message."<img src=\"https://".WEBSITE_URL."/email/email_open_track.php?notifier_id=".$notification["notifier_id"]."&browser_code=".$notification["open_browser_code"]." width=\"1\" title=\"\" alt=\"\">";
		execute_query("UPDATE `notifier` SET `message`= '".mysql_prep($message)."' WHERE `notifier_id`= ".mysql_prep($notification["notifier_id"]));
		if($send)
			shell_exec('sh '.PUBLIC_DIRECTORY.'/cron/email.sh > /dev/null 2>/dev/null &');
		if($notifier_id>0){
			return true;
		}else{
			return false;
		}
	}else
		return false;
}
function send_mail_start(){
	shell_exec('sh '.PUBLIC_DIRECTORY.'/cron/email.sh > /dev/null 2>/dev/null &');
}
?>
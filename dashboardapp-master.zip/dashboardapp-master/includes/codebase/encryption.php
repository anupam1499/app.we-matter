<?php 
function encrypt($data,$key){
    return base64_encode(openssl_encrypt($data, 'AES-128-ECB', $key, OPENSSL_RAW_DATA));
	//return base64_encode(openssl_encrypt($data,"aes-128-cfb", $key, OPENSSL_ZERO_PADDING,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"));
    /*return base64_encode(
		mcrypt_encrypt(
			MCRYPT_RIJNDAEL_128,
			//NETWORK_ENCRYPTION_KEY,
			$key,
			$data,
			MCRYPT_MODE_CFB,
			"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
		));*/
}
function decrypt($data,$key){
	return openssl_decrypt(base64_decode($data), 'AES-128-ECB', $key, OPENSSL_RAW_DATA);
	//return openssl_decrypt(base64_decode($data),"aes-128-cfb", $key,OPENSSL_ZERO_PADDING,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    /*return rtrim( mcrypt_decrypt(
		MCRYPT_RIJNDAEL_128,
		//NETWORK_ENCRYPTION_KEY,
		$key,
		base64_decode($data),
		MCRYPT_MODE_CFB,
		"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
		), "\0");*/
}
function encrypt_file($source, $destination, $key) {
	//$key=NETWORK_ENCRYPTION_KEY;
	$iv="\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
	if (extension_loaded('mcrypt') === true)
		{
		if (is_file($source) === true)
		 {
		  $source = file_get_contents($source);
		  $encryptedSource=TripleDesEncrypt($source,$key,$iv);
			  if (file_put_contents($destination,$encryptedSource, LOCK_EX) !== false)
				   {
						return true;
				   }
				return false;
		 }
		return false;
	}
	return false;
}
 
function decrypt_file($source, $destination, $key) {
	$iv="\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
	if (extension_loaded('mcrypt') === true){
		 if (is_file($source) === true){
			 $source = file_get_contents($source);
			 $decryptedSource=TripleDesDecrypt($source,$key,$iv);
			 if (file_put_contents($destination,$decryptedSource, LOCK_EX) !== false){
					return true;
				}else{
					echo "no read";
					return false;
				}
		 }else{
			echo "no file";
			return false;
		}
	}else{
		 echo "no mcrypt";
		 return false;
	}
}

function TripleDesEncrypt($buffer,$key,$iv) {
	$cipher = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CFB, '');
	$buffer.='___EOT';
	// get the amount of bytes to pad
	$extra = 8 - (strlen($buffer) % 8);
	// add the zero padding
	if($extra > 0) {
	for($i = 0; $i < $extra; $i++) {
	$buffer .= '_';
	}
	}
	mcrypt_generic_init($cipher, $key, $iv);
	$result = mcrypt_generic($cipher, $buffer);
	mcrypt_generic_deinit($cipher);
	//return base64_encode($result);
	return $result;
}
 
function TripleDesDecrypt($buffer,$key,$iv) {
	//$buffer= base64_decode($buffer);
	$cipher = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CFB, '');
	mcrypt_generic_init($cipher, $key, $iv);
	$result = mdecrypt_generic($cipher,$buffer);
	$result=substr($result,0,strpos($result,'___EOT'));
	mcrypt_generic_deinit($cipher);
	return $result;
}
?>
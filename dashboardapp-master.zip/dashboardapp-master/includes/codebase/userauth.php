<?php
function logged_in() {
	if(isset($_SESSION['user_id'])||isset($_SESSION['admin_logged_in']))
		return true;
	else 
		return false;
}
	
function confirm_logged_in(){
	if (!logged_in()) {
		redirect_to(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=login");
	}else if(logged_in()&&isset($_SESSION['email'])&&!isset($_SESSION['role_selected'])){
		redirect_to(PROTOCOL.WEBSITE_URL."/user/account_picker.php");
	}
}

function user_get($data) {
	if(is_numeric($data)){
		if($user = mysqli_fetch_assoc(execute_query("SELECT * FROM `user` WHERE `user_id` = '".mysql_prep($data)."' LIMIT 1"))) {
			return $user;
		}else{
			return false;
		}
	}else{
		if($user = mysqli_fetch_assoc(execute_query("SELECT * FROM `user` WHERE `email` = '".mysql_prep($data)."' LIMIT 1"))){
			return $user;
		}else{
			return false;
		}
	}
}	

function auth_get($data,$type) {
	if(is_numeric($data)){
		if($result = mysqli_fetch_assoc(execute_query("SELECT * FROM `auth` WHERE `auth_id`  = '".mysql_prep($data)."' AND  `auth_type` = '".mysql_prep($type)."' LIMIT 1"))) {
			return $result;
		} else {
			return false;
		}
	}else{
		if($result = mysqli_fetch_assoc(execute_query("SELECT * FROM `auth` WHERE `auth_code` = '".mysql_prep($data)."' AND  `auth_type` = '".mysql_prep($type)."' LIMIT 1"))) {
			return $result;
		} else {
			return false;
		}
	}
}

function LoginSession(){
	$auth_code = generate_salt(32);
	if(isset($_SESSION["user_id"])&&$_SESSION["user_id"]!="0"){
		execute_insert_query("INSERT INTO `auth`(`auth_type`,`email`,`auth_code`,`created_at`, `last_accessed`) VALUES ('3','".mysql_prep($_SESSION["email"])."','".mysql_prep($auth_code)."',".get_sql_india_time().",".get_sql_india_time().");");
		setcookie('LoginSession', $auth_code,time() + (86400 * 365 * 5), "/");
	}
}

function register($email){
	$auth_code = generate_salt(32);
	$auth_id = execute_insert_query("INSERT INTO `auth`(`auth_type`, `auth_code`, `email`, `created_at`) VALUES ('1','".mysql_prep($auth_code)."','".mysql_prep($email)."',".get_sql_india_time().");");
	$auth=mysqli_fetch_assoc(execute_query("SELECT * FROM `auth` WHERE `auth_id`=".$auth_id));
	$message ="";
	$email_activation_email=shorten_url(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=new_user&auth_id=".$auth["auth_id"]."&email=".$auth["email"]."&auth_code=".$auth["auth_code"],"1");
	$message= "Click on the Confirmation button to verify your email id<br>";
	$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$email_activation_email."\">".$email_activation_email."</a>";
	if(add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",0,APP_NAME.": Account Activation",$message,"Activate",$email_activation_email,1,0,true)){
		return true;
	}else{
		return false;
	}
}
function new_user($email,$password){
	$user_id = execute_insert_query("INSERT INTO `user`(`email`,`name`,`password`,`created_at`,`modified_at`) VALUES ('".mysql_prep($email)."','".mysql_prep(extract_name($email))."','".mysql_prep(password_encrypt($password))."',".get_sql_india_time().",".get_sql_india_time().");");
	return user_get($user_id);
}
function forgot_password($email){
	$auth_code = generate_salt(32);
	$auth_id = execute_insert_query("INSERT INTO `auth`(`auth_type`, `auth_code`, `email`, `created_at`) VALUES ('2','".mysql_prep($auth_code)."','".mysql_prep($email)."',".get_sql_india_time().");");
	$auth=mysqli_fetch_assoc(execute_query("SELECT * FROM `auth` WHERE `auth_id`=".$auth_id));
	$message ="";
	$email_activation_email=shorten_url(PROTOCOL.WEBSITE_URL."/user/userauth.php?method=recover_password&auth_id=".$auth["auth_id"]."&email=".$auth["email"]."&auth_code=".$auth["auth_code"],"1");
	$message= "Click on the recovery button to verify your email id<br>";
	$message.= "If you are unable to click the link then copy this URL to the Browser <a href=\"".$email_activation_email."\">".$email_activation_email."</a>";
	if(add_to_mail_queue(APP_EMAIL_ID,APP_NAME,0,$email,"",0,APP_NAME.": Account Recovery",$message,"Recover",$email_activation_email,1,0,true)){
		return true;
	}else{
		return false;
	}
}
function recover_password($email,$password){
	execute_query("UPDATE `user` SET `password` = '".mysql_prep(password_encrypt($password))."',`modified_at`=".get_sql_india_time()." WHERE `email`='".$email."';");
	return true;
}
function login($email,$password){
	if($email===SUPER_ADMIN_EMAIL&&$password===SUPER_ADMIN_PASSWORD){
		$_SESSION["admin_logged_in"]=true;
		$_SESSION["admin_email"]=SUPER_ADMIN_EMAIL;
		return true;
	}
	$user = user_get(mysql_prep($email));
	if ($user) {
		if (password_check($password, $user["password"])) {
			$_SESSION["user_id"]=$user["user_id"];
			$_SESSION["email"]= $user["email"];
			LoginSession();
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}
function logout(){
	if (isset($_COOKIE['LoginSession'])) {
		execute_query("DELETE FROM `auth` WHERE `auth_type`= '3' AND `auth_code` = '".mysql_prep($_COOKIE['LoginSession'])."' ;");
		unset($_COOKIE['LoginSession']);
	}
	unset($_SESSION["user_id"]);
	unset($_SESSION["email"]);
	session_unset();
	session_destroy(); 
}
function password_encrypt($password) {
  $hash_format = "$2y$10$";
  $salt_length = 22;
  $salt = generate_salt($salt_length);
  $format_and_salt = $hash_format . $salt;
  $hash =  crypt($password,$format_and_salt);
  return $hash;
}	
function password_check($password, $existing_hash) {
  $hash = crypt($password, $existing_hash);
  if ($hash === $existing_hash) { 
	return true;
  } else {
	return false;
  }
}
function extract_name($email){
	return ucwords(trim(preg_replace('/[^A-Za-z0-9\-]/',' ',explode("@",$email)[0])));
}
//Login user if the user details are in cookies
if (!logged_in()&&isset($_COOKIE['LoginSession'])){
	if($auth = mysqli_fetch_assoc(execute_query("SELECT `email` FROM `auth` WHERE `auth_type` = 3 AND `auth_code` = '".mysql_prep($_COOKIE['LoginSession'])."';"))){
		$user = user_get($auth["email"]);
		$_SESSION["user_id"] = $user["user_id"];
		$_SESSION["email"]= $user["email"];
	}else{
		unset($_COOKIE['LoginSession']);
	}
}
//Login user if the the user has Auto Login Access Token
if(!logged_in()&&isset($_REQUEST['AutoLogin'])){
	if($auth = mysqli_fetch_assoc(execute_query("SELECT `email` FROM `auth` WHERE `auth_type` = 3 AND `auth_code` = '".$_REQUEST['AutoLogin']."';"))){
		$user = user_get($auth["email"]);
		$_SESSION["user_id"] = $user["user_id"];
		$_SESSION["email"]= $user["email"];
	}
}
if(isset($_COOKIE['LoginSession'])){
	execute_query("UPDATE `auth` SET `last_accessed`= NOW(),`ip`='".mysql_prep($_SERVER['REMOTE_ADDR'])."' WHERE `auth_type` = '3' AND `auth_code`= '".mysql_prep($_COOKIE['LoginSession'])."'");
}
?>
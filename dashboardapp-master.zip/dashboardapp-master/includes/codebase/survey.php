<?php 
function survey_add($survey_name,$survey_group,$modules){
	$survey = survey_get(execute_insert_query("INSERT INTO `survey`(`survey_name`,`survey_group`,`created_at`, `modified_at`,`account_id`,`user_id`) VALUES ('".mysql_prep($survey_name)."','".mysql_prep($survey_group)."',".get_sql_india_time().",".get_sql_india_time().",'".mysql_prep($_SESSION["role_selected"]["account_id"])."','".mysql_prep($_SESSION["user_id"])."')"));
	lime_survey_add($survey["survey_id"],$survey["survey_name"],$modules);
	return $survey;
}
function survey_edit($survey_id,$sync_frequency,$scorecard,$dashboard,$dashboard_qualitative,$dashboard_diagnostic,$action_plan,$comparator,$report){
	execute_query("UPDATE `survey` SET `modified_at` = ".get_sql_india_time().",`sync_frequency` = '".mysql_prep($sync_frequency)."',`scorecard` = '".mysql_prep($scorecard)."',`dashboard` = '".mysql_prep($dashboard)."',`dashboard_qualitative` = '".mysql_prep($dashboard_qualitative)."',`dashboard_diagnostic` = '".mysql_prep($dashboard_diagnostic)."',`action_plan` = '".mysql_prep($action_plan)."',`report` = '".mysql_prep($report)."',`comparator`='".mysql_prep($comparator)."'  WHERE `survey_id` = ".mysql_prep($survey_id)." AND `account_id`='".mysql_prep($_SESSION["role_selected"]["account_id"])."' AND `user_id`='".mysql_prep($_SESSION["user_id"])."';");
	return survey_get($_REQUEST["survey_id"]);
}
function survey_delete($survey_id){
	execute_query("DELETE FROM `survey` WHERE `survey_id` = ".mysql_prep($survey_id)." AND `user_id`='".mysql_prep($_SESSION["user_id"])."';");
	lime_survey_delete($survey_id);
	return true;
}
function survey_get($survey_id){
	return ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($survey_id)));
}
function survey_list($q,$page){
	if($_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2"){
		return ToArrays(execute_query("SELECT * FROM `survey` WHERE `survey_name` like '%".mysql_prep($q)."%' AND `account_id`='".mysql_prep($_SESSION["role_selected"]["account_id"])."' LIMIT 12 OFFSET ".($page*12)));
	}else{
		return ToArrays(execute_query("SELECT * FROM `survey` WHERE `survey_name` like '%".mysql_prep($q)."%' AND `account_id`='".mysql_prep($_SESSION["role_selected"]["account_id"])."' AND `survey_id` IN (SELECT DISTINCT `survey_id` FROM `survey_mapping` WHERE `user_id` = '".mysql_prep($_SESSION["user_id"])."' AND `account_id` = '".mysql_prep($_SESSION["role_selected"]["account_id"])."' )
		LIMIT 12 OFFSET ".($page*12)));
	}
}
function survey_count($q){
	return ToArray(execute_query("SELECT count(*) as survey_count FROM `survey` WHERE `survey_name` like '%".mysql_prep($q)."%' AND `account_id`='".mysql_prep($_SESSION["role_selected"]["account_id"])."' AND `user_id`='".mysql_prep($_SESSION["user_id"])."';"))["survey_count"];
}
?>
<?php
function execute_query($query){
	global $connection;
	return mysqli_query($connection,$query);
}
function execute_insert_query($query){
	global $connection;
	mysqli_query($connection,$query);
	return mysqli_insert_id($connection);
}
function insert_bulk($table,$data){
	$query_common = "INSERT INTO `".$table."` ";
	$columns = array_keys($data[0]);
	$query_common=$query_common."(`".implode("`,`",$columns)."`)";
	$values = array();
	$count=0;
	$total=0;
	foreach($data as $i){
		$value="(";
		foreach($columns as $column){
			if($value!="(")
				$value=$value.",";
			$value=$value."'".mysql_prep($i[$column])."'";
		}
		$value=$value.")";
		$values[]=$value;
		$count++;
		$total++;
		if($count>999){
			execute_query($query_common." VALUES ".implode(',',$values).";");
			$values = array();
			$count=0;
		}
	}
	if($count>0){
		execute_query($query_common." VALUES ".implode(',',$values).";");
	}
	return $total;
}
function milli_to_timestamp($gmt_time){
	return date("Y-m-d h:i:s ",$_REQUEST["modified_after"]/1000);
}
function shorten_url($url,$encrypt){
	return file_get_contents("https://quik.gq/index.php?method=api&auth=".urlencode($encrypt)."&url=".urlencode($url));	
}
function redirect_message($url,$message){
	ob_start();
	include(APP_DIRECTORY."/includes/layout/redirect_message.php");
	return ob_get_clean();
}
function time_mili_to_date_india($time){
	date_default_timezone_set('Asia/Kolkata');
	return date('Y-m-d H:i:s', $time/1000);
}
function json_message($message){
	$data["message"] = $message;
	json_output($data);
}
function json_output($data){
	ob_start("ob_gzhandler");
	header('Content-Type: application/json');
	echo json_encode($data,JSON_PRETTY_PRINT|JSON_NUMERIC_CHECK);
}
function session_message($message,$type){//Type : danger:red , message:blue, warning:orange, success:green
	if(!isset($_SESSION[$type]))
		$_SESSION[$type] = $message;
	else if($_SESSION[$type]==="")
		$_SESSION[$type] = $_SESSION[$type].$message;
	else
		$_SESSION[$type] = $_SESSION[$type]."<br>".$message;
}

function display_message(){
	if(isset($_SESSION["danger"])&&$_SESSION["danger"]!=""){
		echo "<div class=\"alert alert-danger\">
		  <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
		  ".$_SESSION["danger"]."
		</div>";
		unset($_SESSION["danger"]);
	}
	if(isset($_SESSION["warning"])&&$_SESSION["warning"]!=""){
		echo "<div class=\"alert alert-warning\">
		  <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
		  ".$_SESSION["warning"]."
		</div>";
		unset($_SESSION["warning"]);
	}
	if(isset($_SESSION["success"])&&$_SESSION["success"]!=""){
		echo "<div class=\"alert alert-success\">
		  <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
		  ".$_SESSION["success"]."
		</div>";
		unset($_SESSION["success"]);
	}
	if(isset($_SESSION["info"])&&$_SESSION["info"]!=""){
		echo "<div class=\"alert alert-info\">
		  <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
		  ".$_SESSION["info"]."
		</div>";
		unset($_SESSION["info"]);
	}
}
function redirect_to($new_location) {
	header("Location: " . $new_location);
	exit;
}
function mysql_prep($string) {
	global $connection;
	$escaped_string = mysqli_real_escape_string($connection, $string);
	return $escaped_string;
}
function variable_dump(){
	echo "<pre>";
	echo "\n\nSESSION";
	print_r($_SESSION);
	echo "\n\nGET";
	print_r($_GET);
	echo "\n\nPOST";
	print_r($_POST);
	echo "\n\nCOOKIE";
	print_r($_COOKIE);
	echo "</pre>";
	exit();
}

function confirm_query($result_set) {
	if (!$result_set) {
		die("Database query failed.");
	}
}
	
function imagetobase64($image_filename,$maxwidth){
$ext_prod_image =pathinfo($_FILES[$image_filename]["name"], PATHINFO_EXTENSION);
	if(isset($ext_prod_image)&&$ext_prod_image!=""){
	$target_file = "uploads/" . basename($_FILES[$image_filename]["name"]);
	$base64_prod="test";
		if (move_uploaded_file($_FILES[$image_filename]["tmp_name"], $target_file)){
			$thumb = new Imagick($target_file);
			$size = getimagesize($target_file);
			$ratio = $size[0]/$size[1];
			if($maxwidth!=null)
				$thumb->resizeImage($maxwidth,($maxwidth/$ratio),Imagick::FILTER_LANCZOS,1);
			$thumb->writeImage($target_file);
			$thumb->destroy(); 
			$type = pathinfo($target_file, PATHINFO_EXTENSION);
			$data = file_get_contents($target_file);		
			unlink($target_file);
			$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
			return $base64;
		}else{
			return null;
		}
	}else 
		return null;
}
function get_thousands($id){
	return ($id-(($id-1) % 1000))+999;
}
function jsonRemoveUnicodeSequences($struct) {
	return json_encode($struct,JSON_UNESCAPED_UNICODE);
}
function ToArrays($result){
	$new_array = array();
	if($result){
	while( $row = mysqli_fetch_assoc($result)){
		$new_array[] = $row; // Inside while loop
	}
	return $new_array;
	}else{
		return $new_array;
	}
}
function ToArray($result){
	if(mysqli_num_rows($result)==1){
		 return mysqli_fetch_assoc($result);
	}else if(mysqli_num_rows($result)<1){
		return false;
	}else{
		return ToArrays($result);
	}
}
function get_sql_india_time(){
	return " DATE_ADD(UTC_TIMESTAMP(), INTERVAL 330 MINUTE) ";
}
function get_sql_india_time_add_month($month){
	return " DATE_ADD(DATE_ADD(UTC_TIMESTAMP(), INTERVAL 330 MINUTE), INTERVAL ".$month." MONTH) ";
}
function get_sql_india_time_with_time($timestamp){
	return " DATE_ADD(".$timestamp.", INTERVAL 330 MINUTE) ";
}
function get_sql_india_time_add_month_with_time($timestamp,$month){
	return " DATE_ADD(DATE_ADD(".$timestamp.", INTERVAL 330 MINUTE), INTERVAL ".$month." MONTH) ";
}

function get_php_india_time(){
	return (strtotime(gmdate("M d Y H:i:s",  time()))+19800);
}

function reArrayFiles($file_post) {
    $file_ary = array();
    $file_count = count($file_post['name']);
    $file_keys = array_keys($file_post);
    for ($i=0; $i<$file_count; $i++) {
        foreach ($file_keys as $key) {
            $file_ary[$i][$key] = $file_post[$key][$i];
        }
    }
    return $file_ary;
}

function startsWith($string, $regex) {
    return $regex === "" || strrpos($string, $regex, -strlen($string)) !== false;
}
function contains($string, $find){
	if(strpos($string, $find) !== false){
		return true;
	}else{
		return false;
	}
}
function generate_salt($length) {
	return substr(str_replace('+', '.', base64_encode(md5(uniqid(mt_rand(), true)))), 0, $length);
}	
	
function generate_auth_code() {
	return substr(md5(uniqid(mt_rand(), true)), 0, 32);;
}
function csv_output($output_name,$array){
	$header = array_keys($array[0]);
	$fp = fopen('php://output', 'w');
	ob_start("ob_gzhandler");
	if ($fp) {
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment; filename="'.$output_name.'.csv"');
		header('Pragma: no-cache');
		header('Expires: 0');
		fputcsv($fp,$header);
		foreach ($array as $item) {
			fputcsv($fp,$item);
		}
	}
	exit(0);
}
function csv_query($output_name,$query){
	$result =execute_query($query);
	if (!$result) die('Couldn\'t fetch records');
	$fp = fopen('php://output', 'w');
	ob_start("ob_gzhandler");
	if ($fp && $result) {
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment; filename="'.$output_name.'.csv"');
		header('Pragma: no-cache');
		header('Expires: 0');
		$row = mysqli_fetch_assoc($result);
		$header = array_keys($row);
		fputcsv($fp, $header);
		fputcsv($fp, array_values($row));
		while ($row = mysqli_fetch_assoc($result)) {
			fputcsv($fp, array_values($row));
		}
		die;
	}
}
function flatten_array($array,$key){
	$result = array();
	foreach($array as $item){
		$result[]=$item[$key];
	}
	return $result;
}
?>
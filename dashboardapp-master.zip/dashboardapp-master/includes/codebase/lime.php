<?php
function lime_db(){
	$lime_db = mysqli_connect(LIME_DB_SERVER, LIME_DB_USER, LIME_DB_PASS, LIME_DB_NAME);
	if(mysqli_connect_errno()) {
		die("Database connection failed: " . 
			 mysqli_connect_error() . 
			 " (" . mysqli_connect_errno() . ")"
		);
	}else{
		return $lime_db;
	}
}
$lime_db = lime_db();
function lime_mysql_prep($string) {
	global $lime_db;
	return mysqli_real_escape_string($lime_db, $string);
}
function lime_query($query){
	global $lime_db;
	return mysqli_query($lime_db,$query);
}
function lime_insert_query($query){
	global $lime_db;
	mysqli_query($lime_db,$query);
	return mysqli_insert_id($lime_db);
}
function lime_user_add($email){
	$password="$2y$10\$cwiYKQr.Zb0jM1wmMuKvZ.BLXR4EarC95KzGt8DW5bX2gjhmIXXv6";
	$uid = lime_insert_query("INSERT INTO `users` (`users_name`, `password`, `full_name`, `parent_id`, `lang`, `email`, `htmleditormode`, `templateeditormode`, `questionselectormode`, `one_time_pw`, `dateformat`, `created`, `modified`) VALUES ('".lime_mysql_prep($email)."', '".lime_mysql_prep($password)."', '".lime_mysql_prep($email)."', '1', 'en', '".lime_mysql_prep($email)."', 'default', 'default', 'default', NULL, '1', NOW(),NOW()); ");
	lime_insert_query("INSERT INTO `permissions` (`entity`, `entity_id`, `uid`, `permission`, `create_p`, `read_p`, `update_p`, `delete_p`, `import_p`, `export_p`) VALUES ('global', '0', '".lime_mysql_prep($uid)."', 'surveys', '1', '0', '0', '0', '0', '0');");
	lime_insert_query("INSERT INTO `permissions` (`entity`, `entity_id`, `uid`, `permission`, `create_p`, `read_p`, `update_p`, `delete_p`, `import_p`, `export_p`) VALUES ('global', '0', '".lime_mysql_prep($uid)."', 'auth_hash', '0', '1', '0', '0', '0', '0');");
	lime_insert_query("INSERT INTO `permissions` (`entity`, `entity_id`, `uid`, `permission`, `create_p`, `read_p`, `update_p`, `delete_p`, `import_p`, `export_p`) VALUES ('global', '0', '".lime_mysql_prep($uid)."', 'auth_db', '0', '1', '0', '0', '0', '0');");	
}
function lime_session_start(){
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	return $lime_client->get_session_key($_SESSION["email"],LS_PASSWORD,"Authdb");
}
function lime_session_admin_start(){
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	return $lime_client->get_session_key(LS_ADMIN_USERNAME,LS_PASSWORD,"Authdb");
}
function lime_session_end($sessionKey){
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$lime_client->release_session_key($sessionKey);
}
function lime_survey_add($survey_id,$survey_name,$modules){
	$sessionKey = lime_session_start();
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$survey = $lime_client->add_survey($sessionKey,$survey_id,$survey_name,"en",'G');
	//print_r($sessionKey);
	//print_r($survey);
	foreach($modules as $module){
		$lime_client->import_group($sessionKey,$survey_id,$module["data"],"lsg",$module["name"],$module["description"]);
		
	}
	lime_session_end($sessionKey);
	lime_query("UPDATE `surveys` SET `attributedescriptions` = '".mysql_prep('{"firstname":{"encrypted":"N"},"lastname":{"encrypted":"N"},"email":{"encrypted":"N"},"attribute_1":{"description":"employee_id","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_2":{"description":"designation","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_3":{"description":"p_location","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_4":{"description":"p_function","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_5":{"description":"p_organizational_level","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_6":{"description":"p_tenure","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_7":{"description":"p_generation","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""},"attribute_8":{"description":"p_gender","mandatory":"N","encrypted":"N","show_register":"N","cpdbmap":""}}')."' WHERE `sid` = ".mysql_prep($survey_id));
}
function lime_survey_delete($survey_id){
	$sessionKey = lime_session_start();
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$lime_client->delete_survey($sessionKey,$survey_id);
}
function lime_header_clean($string,$header_key){
	$string = trim(str_replace('"',"",$string));
	if(array_key_exists($string,$header_key))
		return $header_key[$string];
	else
		return $string;
}
function lime_get_participants($survey_id,$email,$attributes){
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$session_key = $lime_client->get_session_key(LS_ADMIN_USERNAME,LS_PASSWORD,"Authdb");
	$param["email"] = $email; 
	return $lime_client->list_participants($session_key,$survey_id,0,1,false,$attributes,$param);
}
function scorecard_params($survey_id,$type,$account_id,$email){
	$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `account_id` = ".mysql_prep($account_id)." AND `survey_id` = ".mysql_prep($survey_id)." "));
	$user = ToArray(execute_query("SELECT `U`.`email`,`AL`.* FROM `user` U
		LEFT JOIN `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
		AND `AL`.`account_id` = ".mysql_prep($account_id)." 
		WHERE `U`.`email` = '".mysql_prep($email)."';"));
	$score = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey_id."/score.json"),true);
	if($type==="1")
		$response["team"] = $score["MANAGER"][$user["id"]];
	else if($type==="2")
		$response["team"] = $score["LEADER"][$user["id"]];
	$response["organization"] =$score["ORGANIZATION"]["ALL"];
	$response["user"] = $user;
	$response["survey"] = $survey;
	return $response;
}
function scorecard_params_old($survey_id,$type,$account_id,$email){
		$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `account_id` = ".mysql_prep($account_id)." AND `survey_id` = ".mysql_prep($survey_id)." "));
		$employees = ToArrays(execute_query("SELECT `employee_id` FROM `survey_mapping` WHERE `account_id` = ".mysql_prep($account_id)." AND `user_id` = ".user_get($email)["user_id"]." AND `type` = ".mysql_prep($type)." AND `survey_id` = ".mysql_prep($survey_id)));
		foreach($employees as $employee){
			$employee_list[] = trim($employee["employee_id"]);
		}
		$dir = ROOT_DIRECTORY."/survey_data/".$survey_id;
		$survey_details = json_decode(file_get_contents($dir."/survey.json"),true);
		$questions = json_decode(file_get_contents($dir."/questions.json"),true);
		//$aggregate = json_decode(file_get_contents($dir."/aggregate.json"),true);
		$attributes = json_decode($survey_details["attributedescriptions"],true);
		$attribute_list = [];
		$header_key = [];
		foreach($attributes as $key => $value){
			if(isset($value["description"])){
				$header_key[$key] = $value["description"];
			}else{
				$header_key[$key] = $key;
			}
			$attribute_list[]=$key;
		}
		$user_data = [];
		if(($handle = fopen($dir."/response.csv", "r")) !== FALSE) {
			$header = fgetcsv($handle, 32000, ';','"');
			foreach($header as $key => $value){
				$header[$key] = lime_header_clean($value,$header_key);
			}
			$index=array_flip($header);
			$COUNT=0;
			$ENGAGEMENT_QUESTION_COUNT=0;
			$MANAGER_QUESTION_COUNT=0;
			$LEADER_QUESTION_COUNT=0;
			$WFH_QUESTION_COUNT=0;
			$WFO_QUESTION_COUNT=0;
			$HR_QUESTION_COUNT=0;
			$WB_QUESTION_COUNT=0;
			$MANAGER_INDEX = 0;
			$ENGAGE_INDEX = 0;
			$LEADER_INDEX = 0;
			$WFH_INDEX = 0;
			$WFO_INDEX = 0;
			$HR_INDEX = 0;
			$WB_INDEX = 0;
			$processed=array();
			foreach($questions as $question){
				if(startsWith($question["title"],"ENGAGE")){
					$processed[$question["title"]]=0;
					$ENGAGEMENT_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"LEADER")){
					$processed[$question["title"]]=0;
					$LEADER_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"MANAGER")){
					$processed[$question["title"]]=0;
					$MANAGER_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WFH")){
					$processed[$question["title"]]=0;
					$WFH_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WFO")){
					$processed[$question["title"]]=0;
					$WFO_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"HR")){
					$processed[$question["title"]]=0;
					$HR_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WB")){
					$processed[$question["title"]]=0;
					$WB_QUESTION_COUNT++;
				}
			}
			while (($data = fgetcsv($handle, 32000, ";",'"')) !== FALSE) {
				if(isset($data[$index["employee_id"]])&&in_array($data[$index["employee_id"]],$employee_list,false)){
					$USER_MANAGER = 0;
					$USER_ENGAGE = 0;
					$USER_LEADER = 0;
					$USER_WFH = 0;
					$USER_WFO = 0;
					$USER_HR = 0;
					$USER_WB = 0;
					foreach($processed as $key => $value){
						if($data[$index[$key]]>3){
							$processed[$key]=$processed[$key]+1;
						}
						if(startsWith($key,"MANAGER")){
							$MANAGER_INDEX=$MANAGER_INDEX+$data[$index[$key]];
							$USER_MANAGER=$USER_MANAGER+$data[$index[$key]];
						}else if(startsWith($key,"ENGAGE")){
							$ENGAGE_INDEX=$ENGAGE_INDEX+$data[$index[$key]];
							$USER_ENGAGE=$USER_ENGAGE+$data[$index[$key]];
						}else if(startsWith($key,"LEADER")){
							$LEADER_INDEX=$LEADER_INDEX+$data[$index[$key]];
							$USER_LEADER=$USER_LEADER+$data[$index[$key]];
						}else if(startsWith($key,"WFH")){
							$WFH_INDEX=$WFH_INDEX+$data[$index[$key]];
							$USER_WFH=$USER_WFH+$data[$index[$key]];
						}else if(startsWith($key,"WFO")){
							$WFO_INDEX=$WFO_INDEX+$data[$index[$key]];
							$USER_WFO=$USER_WFO+$data[$index[$key]];
						}else if(startsWith($key,"HR")){
							$HR_INDEX=$HR_INDEX+$data[$index[$key]];
							$USER_HR=$USER_HR+$data[$index[$key]];
						}else if(startsWith($key,"WB")){
							$WB_INDEX=$WB_INDEX+$data[$index[$key]];
							$USER_WB=$USER_WB+$data[$index[$key]];
						}
					}
					if($MANAGER_QUESTION_COUNT>0&&($USER_MANAGER/$MANAGER_QUESTION_COUNT)>3.75){
						$processed["MANAGER_TOTAL"]=$processed["MANAGER_TOTAL"]+1;
					}
					if($ENGAGEMENT_QUESTION_COUNT>0&&($USER_ENGAGE/$ENGAGEMENT_QUESTION_COUNT)>3.75){
						$processed["ENGAGE_TOTAL"]=$processed["ENGAGE_TOTAL"]+1;
					}
					if($LEADER_QUESTION_COUNT>0&&($USER_LEADER/$LEADER_QUESTION_COUNT)>3.75){
						$processed["LEADER_TOTAL"]=$processed["LEADER_TOTAL"]+1;
					}
					if($WFH_QUESTION_COUNT>0&&($USER_WFH/$WFH_QUESTION_COUNT)>3.75){
						$processed["WFH_TOTAL"]=$processed["WFH_TOTAL"]+1;
					}
					if($WFO_QUESTION_COUNT>0&&($USER_WFO/$WFO_QUESTION_COUNT)>3.75){
						$processed["WFO_TOTAL"]=$processed["WFO_TOTAL"]+1;
					}
					if($HR_QUESTION_COUNT>0&&($USER_HR/$HR_QUESTION_COUNT)>3.75){
						$processed["HR_TOTAL"]=$processed["HR_TOTAL"]+1;
					}
					if($WB_QUESTION_COUNT>0&&($USER_WB/$WB_QUESTION_COUNT)>3.75){
						$processed["WB_TOTAL"]=$processed["WB_TOTAL"]+1;
					}
					$COUNT++;
				}
			}
		}
		foreach($processed as $key => $value){
			$processed[$key]=($processed[$key]*100)/$COUNT;
		}
		if($ENGAGEMENT_QUESTION_COUNT>0)
				$processed["ENGAGEMENT_INDEX"]=$ENGAGE_INDEX/($ENGAGEMENT_QUESTION_COUNT*$COUNT);
			if($MANAGER_QUESTION_COUNT>0)
				$processed["MANAGER_INDEX"]=$MANAGER_INDEX/($MANAGER_QUESTION_COUNT*$COUNT);
			if($LEADER_QUESTION_COUNT>0)
				$processed["LEADER_INDEX"]=$LEADER_INDEX/($LEADER_QUESTION_COUNT*$COUNT);
			if($WFH_QUESTION_COUNT>0)
				$processed["WFH_INDEX"]=$WFH_INDEX/($WFH_QUESTION_COUNT*$COUNT);
			if($WFO_QUESTION_COUNT>0)
				$processed["WFO_INDEX"]=$WFO_INDEX/($WFO_QUESTION_COUNT*$COUNT);
			if($HR_QUESTION_COUNT>0)
				$processed["HR_INDEX"]=$HR_INDEX/($HR_QUESTION_COUNT*$COUNT);
			if($WB_QUESTION_COUNT>0)
				$processed["WB_INDEX"]=$WB_INDEX/($WB_QUESTION_COUNT*$COUNT);
		$processed["COUNT"]=$COUNT;
		$response["team"] = $processed;
		$response["organization"] = json_decode(file_get_contents($dir."/aggregate.json"),TRUE);
		$user = ToArray(execute_query("
		SELECT `U`.`email`,`AL`.* FROM `user` U
		LEFT JOIN `account_linking` AL ON `AL`.`user_id` = `U`.`user_id` 
		AND `AL`.`account_id` = ".mysql_prep($account_id)." 
		WHERE `U`.`email` = '".mysql_prep($email)."';"));
		foreach($user_survey AS $key => $value){
			if(startsWith($key,"attribute"))
				$user[lime_header_clean($key,$header_key)] = $value;
		}
		$response["user"] = $user;
		$response["survey"] = $survey;
		return $response;
}
function survey_process_old_depricated($survey_id){
	$dir = ROOT_DIRECTORY."/survey_data/".$survey_id;
	if (!file_exists($dir)) {
		mkdir($dir,0755,true);
	}
	$lime_session = lime_session_admin_start();
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$survey = $lime_client->get_survey_properties($lime_session,$survey_id,null);
	$survey_data = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($survey_id)));
	$manager_data = execute_query("SELECT `M`.`employee_id`,`AL`.`id` AS manager_id FROM `survey_mapping` M
	LEFT JOIN `account_linking` AL ON `M`.`user_id`= `AL`.`user_id` AND `AL`.`account_id` = ".$survey_data["account_id"]."
	WHERE `survey_id`=".mysql_prep($survey_id)." AND `type`=1 AND `M`.`account_id` = ".$survey_data["account_id"].";");
	$manager_lookup = array();
	foreach($manager_data as $item){
		$manager_lookup[$item["employee_id"]]=$item["manager_id"];
	}
	unset($manager_data);
	$MANAGER_STAT = array();
	file_put_contents($dir."/survey.json",json_encode($survey,true));
	$attributes = json_decode($survey["attributedescriptions"],true);
	$header_key = [];
	$request_att[]="id";
	$request_att[]="token";
	if(isset($attributes)){
		foreach($attributes as $key => $value){
			$request_att[]=$key;
			if(isset($value["description"])){
				$header_key[$key] = $value["description"];
			}else{
				$header_key[$key] = $key;
			}
		}
	}
	$questions = $lime_client->list_questions($lime_session,$survey_id,null,null);
	file_put_contents($dir."/questions.json",json_encode($questions,true));
	foreach($questions as $question){
		if($question["type"]==="L"){
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"];
		}else if($question["type"]==="O"){
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"];
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"]."comment";
		}
	}
	$request_att[] = "completed";
	$participants = $lime_client->list_participants($lime_session,$survey_id,0,100000,false,$request_att);
	if(isset($participants["status"])&&$participants["status"]==="Error: No survey participants table"){
		execute_query("UPDATE `survey` SET `synced_at` = ".get_sql_india_time()." WHERE `survey_id` = ".mysql_prep($survey_id));
		return 0;
	}
	$participant_final = array();
	$participant_insert = array();
	foreach($participants as $participant){
		$temp = $participant;
		$temp = array_merge($temp,$temp["participant_info"]);
		unset($temp["participant_info"]);
		foreach($temp AS $key => $value){
			$temp_new[lime_header_clean($key,$header_key)] = $value;
		}
		$participant_insert_item["survey_id"] = $survey_id;
		$participant_insert_item["token"] = $temp_new["token"];
		$participant_insert_item["employee_id"] = $temp_new["employee_id"];
		$participant_insert_item["status"] = $temp_new["completed"];
		$participant_insert[]=$participant_insert_item;
		$participant_final[]=$temp_new;
	}
	file_put_contents($dir."/participants.json",json_encode($participant_final,true));
	execute_query("DELETE FROM `participant` WHERE `survey_id` = ".mysql_prep($survey_id));
	insert_bulk("participant",$participant_insert);
	unset($participants);
	unset($participant_final);
	unset($participant_insert);
	file_put_contents($dir."/response.csv",base64_decode($lime_client->export_responses($lime_session,$survey_id,"csv",null,"complete","code","short",null,null,$request_att)));
	if (($handle = fopen($dir."/response.csv", "r")) !== FALSE) {
		$header = fgetcsv($handle, 32000, ';','"');
		foreach($header as $key => $value){
			$header[$key] = lime_header_clean($value,$header_key);
		}
		$index=array_flip($header);
		$COUNT=0;
		$ENGAGEMENT_QUESTION_COUNT=0;
		$MANAGER_QUESTION_COUNT=0;
		$LEADER_QUESTION_COUNT=0;
		$WFH_QUESTION_COUNT=0;
		$WFO_QUESTION_COUNT=0;
		$HR_QUESTION_COUNT=0;
		$WB_QUESTION_COUNT=0;
		$processed=array();
		foreach($questions as $question){
			if(startsWith($question["title"],"ENGAGE")){
				$processed[$question["title"]]=0;
				$ENGAGEMENT_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"LEADER")){
				$processed[$question["title"]]=0;
				$LEADER_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"MANAGER")){
				$processed[$question["title"]]=0;
				$MANAGER_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"WFH")){
				$processed[$question["title"]]=0;
				$WFH_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"WFO")){
				$processed[$question["title"]]=0;
				$WFO_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"HR")){
				$processed[$question["title"]]=0;
				$HR_QUESTION_COUNT++;
			}else if(startsWith($question["title"],"WB")){
				$processed[$question["title"]]=0;
				$WB_QUESTION_COUNT++;
			}
		}
		$MANAGER_INDEX = 0;
		$ENGAGE_INDEX = 0;
		$LEADER_INDEX = 0;
		$WFH_INDEX = 0;
		$WFO_INDEX = 0;
		$HR_INDEX = 0;
		$WB_INDEX = 0;
		$response = array();
		while (($data = fgetcsv($handle, 32000, ";",'"')) !== FALSE) {
			if(count($data)>5){
				unset($row);
				foreach($data as $key => $value){
					$row[trim($header[$key])] = trim($value);
				}
				if(count($row)>2)
					$response[] = $row;
				$USER_MANAGER = 0;
				$USER_ENGAGE = 0;
				$USER_LEADER = 0;
				$USER_WFH = 0;
				$USER_WFO = 0;
				$USER_HR = 0;
				$USER_WB = 0;
				foreach($processed as $key => $value){
					if($data[$index[$key]]>3){
						$processed[$key]=$processed[$key]+1;
					}
					if(startsWith($key,"MANAGER")){
						$MANAGER_INDEX=$MANAGER_INDEX+$data[$index[$key]];
						$USER_MANAGER=$USER_MANAGER+$data[$index[$key]];
					}else if(startsWith($key,"ENGAGE")){
						$ENGAGE_INDEX=$ENGAGE_INDEX+$data[$index[$key]];
						$USER_ENGAGE=$USER_ENGAGE+$data[$index[$key]];
					}else if(startsWith($key,"LEADER")){
						$LEADER_INDEX=$LEADER_INDEX+$data[$index[$key]];
						$USER_LEADER=$USER_LEADER+$data[$index[$key]];
					}else if(startsWith($key,"WFH")){
						$WFH_INDEX=$WFH_INDEX+$data[$index[$key]];
						$USER_WFH=$USER_WFH+$data[$index[$key]];
					}else if(startsWith($key,"WFO")){
						$WFO_INDEX=$WFO_INDEX+$data[$index[$key]];
						$USER_WFO=$USER_WFO+$data[$index[$key]];
					}else if(startsWith($key,"HR")){
						$HR_INDEX=$HR_INDEX+$data[$index[$key]];
						$USER_HR=$USER_HR+$data[$index[$key]];
					}else if(startsWith($key,"WB")){
						$WB_INDEX=$WB_INDEX+$data[$index[$key]];
						$USER_WB=$USER_WB+$data[$index[$key]];
					}
				}
				if($ENGAGEMENT_QUESTION_COUNT>0&&($USER_ENGAGE/$ENGAGEMENT_QUESTION_COUNT)>3.75){
					$processed["ENGAGE_TOTAL"]=$processed["ENGAGE_TOTAL"]+1;
				}
				if($MANAGER_QUESTION_COUNT>0){
					$USER_MANAGER_INDEX=$USER_MANAGER/$MANAGER_QUESTION_COUNT;
					if($USER_MANAGER_INDEX>3.75){
						$processed["MANAGER_TOTAL"]=$processed["MANAGER_TOTAL"]+1;
					}
					$manager_id = $manager_lookup[$row["employee_id"]];
					$MANAGER_STAT[$manager_id]["COUNT"]++;
					$MANAGER_STAT[$manager_id]["MANAGER_INDEX"]=$MANAGER_STAT[$manager_id]["MANAGER_INDEX"]+$USER_MANAGER_INDEX;
					if($ENGAGEMENT_QUESTION_COUNT>0&&($USER_ENGAGE/$ENGAGEMENT_QUESTION_COUNT)>3.75){
						$MANAGER_STAT[$manager_id]["ENGAGE_TOTAL"]=$MANAGER_STAT[$manager_id]["ENGAGE_TOTAL"]+1;
					}
				}			
				if($LEADER_QUESTION_COUNT>0&&($USER_LEADER/$LEADER_QUESTION_COUNT)>3.75){
					$processed["LEADER_TOTAL"]=$processed["LEADER_TOTAL"]+1;
				}
				if($WFH_QUESTION_COUNT>0&&($USER_WFH/$WFH_QUESTION_COUNT)>3.75){
					$processed["WFH_TOTAL"]=$processed["WFH_TOTAL"]+1;
				}
				if($WFO_QUESTION_COUNT>0&&($USER_WFO/$WFO_QUESTION_COUNT)>3.75){
					$processed["WFO_TOTAL"]=$processed["WFO_TOTAL"]+1;
				}
				if($HR_QUESTION_COUNT>0&&($USER_HR/$HR_QUESTION_COUNT)>3.75){
					$processed["HR_TOTAL"]=$processed["HR_TOTAL"]+1;
				}
				if($WB_QUESTION_COUNT>0&&($USER_WB/$WB_QUESTION_COUNT)>3.75){
					$processed["WB_TOTAL"]=$processed["WB_TOTAL"]+1;
				}			
				$COUNT++;
			}
		}
		foreach($processed as $key => $value){
			$processed[$key]=($processed[$key]*100)/$COUNT;
		}
		if($ENGAGEMENT_QUESTION_COUNT>0)
			$processed["ENGAGEMENT_INDEX"]=$ENGAGE_INDEX/($ENGAGEMENT_QUESTION_COUNT*$COUNT);
		if($MANAGER_QUESTION_COUNT>0)
			$processed["MANAGER_INDEX"]=$MANAGER_INDEX/($MANAGER_QUESTION_COUNT*$COUNT);
		if($LEADER_QUESTION_COUNT>0)
			$processed["LEADER_INDEX"]=$LEADER_INDEX/($LEADER_QUESTION_COUNT*$COUNT);
		if($WFH_QUESTION_COUNT>0)
			$processed["WFH_INDEX"]=$WFH_INDEX/($WFH_QUESTION_COUNT*$COUNT);
		if($WFO_QUESTION_COUNT>0)
			$processed["WFO_INDEX"]=$WFO_INDEX/($WFO_QUESTION_COUNT*$COUNT);
		if($HR_QUESTION_COUNT>0)
			$processed["HR_INDEX"]=$HR_INDEX/($HR_QUESTION_COUNT*$COUNT);
		if($WB_QUESTION_COUNT>0)
			$processed["WB_INDEX"]=$WB_INDEX/($WB_QUESTION_COUNT*$COUNT);
		$processed["COUNT"]=$COUNT;
		file_put_contents($dir."/response.json",json_encode($response,true));
		file_put_contents($dir."/aggregate.json",json_encode($processed,true));
		$MANAGER_RESPONSE = array();
		foreach($MANAGER_STAT as $manager_id => $MANAGER){
			if(trim($manager_id)!=""){
				$MANAGER["MANAGER_INDEX"]=$MANAGER["MANAGER_INDEX"]/$MANAGER["COUNT"];
				if(!isset($MANAGER["ENGAGE_TOTAL"])){
					$MANAGER["ENGAGE_TOTAL"]=0;
				}
				$MANAGER_RESPONSE[$manager_id]=$MANAGER;
			}
		}
		file_put_contents($dir."/manager.json",json_encode($MANAGER_RESPONSE,true));
		//file_put_contents($dir."/score.json",json_encode(survey_score_process($survey_id),true));
		survey_score_process($survey_id);
	}
	execute_query("UPDATE `survey` SET `synced_at` = ".get_sql_india_time()." WHERE `survey_id` = ".mysql_prep($survey_id));
	return $COUNT;
}
function survey_process($survey_id){
	$dir = ROOT_DIRECTORY."/survey_data/".$survey_id;
	if (!file_exists($dir)) {
		mkdir($dir,0755,true);
	}
	$lime_session = lime_session_admin_start();
	$lime_client = new \org\jsonrpcphp\JsonRPCClient(LS_REMOTE_BASEURL);
	$survey = $lime_client->get_survey_properties($lime_session,$survey_id,null);
	$survey_data = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($survey_id)));
	$MANAGER_STAT = array();
	file_put_contents($dir."/survey.json",json_encode($survey,true));
	$attributes = json_decode($survey["attributedescriptions"],true);
	$header_key = [];
	$request_att[]="id";
	$request_att[]="token";
	if(isset($attributes)){
		foreach($attributes as $key => $value){
			$request_att[]=$key;
			if(isset($value["description"])){
				$header_key[$key] = $value["description"];
			}else{
				$header_key[$key] = $key;
			}
		}
	}
	$questions = $lime_client->list_questions($lime_session,$survey_id,null,null);
	file_put_contents($dir."/questions.json",json_encode($questions,true));
	foreach($questions as $question){
		if($question["type"]==="L"){
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"];
		}else if($question["type"]==="O"){
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"];
			$request_att[]=$question["sid"]."X".$question["gid"]."X".$question["qid"]."comment";
		}
	}
	$request_att[] = "completed";
	$participant_final = array();
	$page =0;
	$finished=false;
	execute_query("DELETE FROM `participant` WHERE `survey_id` = ".mysql_prep($survey_id));
	while(!$finished&&$page<50){
		//echo $page." page processed<br>";
		$participant_insert = array();
		$participants = $lime_client->list_participants($lime_session,$survey_id,$page*10000,10000,false,$request_att);
		foreach($participants as $participant){
			if(isset($participant["participant_info"])){
				$temp = $participant;
				$temp = array_merge($temp,$temp["participant_info"]);
				unset($temp["participant_info"]);
				foreach($temp AS $key => $value){
					$temp_new[lime_header_clean($key,$header_key)] = $value;
				}
				$participant_insert_item["survey_id"] = $survey_id;
				$participant_insert_item["token"] = $temp_new["token"];
				$participant_insert_item["employee_id"] = $temp_new["employee_id"];
				$participant_insert_item["status"] = $temp_new["completed"];
				$participant_insert[]=$participant_insert_item;
				$participant_final[]=$temp_new;
			}
		}
		insert_bulk("participant",$participant_insert);
		if((isset($participants["status"])&&$participants["status"]==="No survey participants found")||count($participant_insert)<1){
			$finished=true;
		}else{
			$page++;
		}
		if(isset($participants["status"])&&$participants["status"]==="Error: No survey participants table"){
			execute_query("UPDATE `survey` SET `synced_at` = ".get_sql_india_time()." WHERE `survey_id` = ".mysql_prep($survey_id));
			return 0;
		}
		unset($participant_insert);
		unset($participants);		
	}
	file_put_contents($dir."/participants.json",json_encode($participant_final,true));//Required for Status Table
	unset($participant_final);
	file_put_contents($dir."/response.csv",base64_decode($lime_client->export_responses($lime_session,$survey_id,"csv",null,"complete","code","short",null,null,$request_att)));
	$count=0;
	if (($handle = fopen($dir."/response.csv", "r")) !== FALSE) {
		$count = survey_score_process($survey_id);
	}
	execute_query("UPDATE `survey` SET `synced_at` = ".get_sql_india_time()." WHERE `survey_id` = ".mysql_prep($survey_id));
	return $count;
}
function survey_score_process($survey_id){
		$survey = ToArray(execute_query("SELECT * FROM `survey` WHERE `survey_id` = ".mysql_prep($survey_id)." "));		
		$employees_temp = ToArrays(execute_query("SELECT (CASE WHEN `SM`.`type`=1 THEN 'MANAGER' WHEN `SM`.`type`=2 THEN  'LEADER' WHEN `SM`.`type`=4 THEN  'HR' ELSE 'OTHER' END) as type ,`AL`.`id`,`SM`.`employee_id` FROM `survey_mapping` SM
		LEFT JOIN `account_linking` AL ON `SM`.`account_id`=`AL`.`account_id` AND `SM`.`user_id`=`AL`.`user_id`
		WHERE `SM`.`account_id` = ".mysql_prep($survey["account_id"])." AND `SM`.`type` in (1,2,4) AND `SM`.`survey_id` = ".mysql_prep($survey_id)." AND `AL`.`id`!=`SM`.`employee_id`
		GROUP BY 1,2,3 ORDER BY 1,2,3;"));
		$employees["ORGANIZATION"]["ALL"]["employee_list"]=[];
		foreach($employees_temp as $employee){
			$employees[$employee["type"]][$employee["id"]]["employee_list"][] =trim($employee["employee_id"]);
			if(!in_array(trim($employee["employee_id"]),$employees["ORGANIZATION"]["ALL"]["employee_list"]))
				$employees["ORGANIZATION"]["ALL"]["employee_list"][] =trim($employee["employee_id"]);
		}
		$dir = ROOT_DIRECTORY."/survey_data/".$survey_id;
		$survey_details = json_decode(file_get_contents($dir."/survey.json"),true);
		$questions = json_decode(file_get_contents($dir."/questions.json"),true);
		$attributes = json_decode($survey_details["attributedescriptions"],true);
		$attribute_list = [];
		$header_key = [];
		foreach($attributes as $key => $value){
			if(isset($value["description"])){
				$header_key[$key] = $value["description"];
			}else{
				$header_key[$key] = $key;
			}
			$attribute_list[]=$key;
		}
		$user_data = [];
		if(($handle = fopen($dir."/response.csv", "r")) !== FALSE) {
			$header = fgetcsv($handle, 32000, ';','"');
			foreach($header as $key => $value){
				$header[$key] = lime_header_clean($value,$header_key);
			}
			$index=array_flip($header);
			$COUNT=0;
			$ENGAGEMENT_QUESTION_COUNT=0;
			$MANAGER_QUESTION_COUNT=0;
			$LEADER_QUESTION_COUNT=0;
			$WFH_QUESTION_COUNT=0;
			$WFO_QUESTION_COUNT=0;
			$HR_QUESTION_COUNT=0;
			$WB_QUESTION_COUNT=0;
			$MANAGER_INDEX = 0;
			$ENGAGE_INDEX = 0;
			$LEADER_INDEX = 0;
			$WFH_INDEX = 0;
			$WFO_INDEX = 0;
			$HR_INDEX = 0;
			$WB_INDEX = 0;
			$processed=array();
			foreach($questions as $question){
				if(startsWith($question["title"],"ENGAGE")){
					$processed[$question["title"]]=0;
					$ENGAGEMENT_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"LEADER")){
					$processed[$question["title"]]=0;
					$LEADER_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"MANAGER")){
					$processed[$question["title"]]=0;
					$MANAGER_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WFH")){
					$processed[$question["title"]]=0;
					$WFH_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WFO")){
					$processed[$question["title"]]=0;
					$WFO_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"HR")){
					$processed[$question["title"]]=0;
					$HR_QUESTION_COUNT++;
				}else if(startsWith($question["title"],"WB")){
					$processed[$question["title"]]=0;
					$WB_QUESTION_COUNT++;
				}
			}
			foreach($employees as $type => $user_list){
					foreach($user_list as $id => $user_array){
						$employees[$type][$id]["score"]=$processed;
					}
			}
			$count = 0;
			unlink($dir."/response.json");
			file_put_contents($dir."/response.json","[",FILE_APPEND);
			while (($data = fgetcsv($handle, 32000, ";",'"')) !== FALSE) {
				if(count($data)>5){
					unset($row);
					foreach($data as $key => $value){
						$row[trim($header[$key])] = trim($value);
					}
					if(count($row)>2){
						//$response[] = $row;
						if($count<1)
							file_put_contents($dir."/response.json",json_encode($row,true),FILE_APPEND);
						else
							file_put_contents($dir."/response.json",",".json_encode($row,true),FILE_APPEND);
					}
					foreach($employees as $type => $user_list){
						foreach($user_list as $id => $user_array){
							if(isset($data[$index["employee_id"]])&&(in_array($data[$index["employee_id"]],$employees[$type][$id]["employee_list"],false)||($type==="ORGANIZATION"&&$id==="ALL"))){
								$USER_MANAGER = 0;
								$USER_ENGAGE = 0;
								$USER_LEADER = 0;
								$USER_WFH = 0;
								$USER_WFO = 0;
								$USER_HR = 0;
								$USER_WB = 0;
								foreach($employees[$type][$id]["score"] as $key => $value){
									if($data[$index[$key]]>3){
										$employees[$type][$id]["score"][$key]=$employees[$type][$id]["score"][$key]+1;
									}
									if(startsWith($key,"MANAGER")){
										$employees[$type][$id]["index"]["MANAGER_INDEX"]=$employees[$type][$id]["index"]["MANAGER_INDEX"]+$data[$index[$key]];
										$USER_MANAGER=$USER_MANAGER+$data[$index[$key]];
									}else if(startsWith($key,"ENGAGE")){
										$employees[$type][$id]["index"]["ENGAGEMENT_INDEX"]=$employees[$type][$id]["index"]["ENGAGEMENT_INDEX"]+$data[$index[$key]];
										$USER_ENGAGE=$USER_ENGAGE+$data[$index[$key]];
									}else if(startsWith($key,"LEADER")){
										$employees[$type][$id]["index"]["LEADER_INDEX"]=$employees[$type][$id]["index"]["LEADER_INDEX"]+$data[$index[$key]];
										$USER_LEADER=$USER_LEADER+$data[$index[$key]];
									}else if(startsWith($key,"WFH")){
										$employees[$type][$id]["index"]["WFH_INDEX"]=$employees[$type][$id]["index"]["WFH_INDEX"]+$data[$index[$key]];
										$USER_WFH=$USER_WFH+$data[$index[$key]];
									}else if(startsWith($key,"WFO")){
										$employees[$type][$id]["index"]["WFO_INDEX"]=$employees[$type][$id]["index"]["WFO_INDEX"]+$data[$index[$key]];
										$USER_WFO=$USER_WFO+$data[$index[$key]];
									}else if(startsWith($key,"HR")){
										$employees[$type][$id]["index"]["HR_INDEX"]=$employees[$type][$id]["index"]["HR_INDEX"]+$data[$index[$key]];
										$USER_HR=$USER_HR+$data[$index[$key]];
									}else if(startsWith($key,"WB")){
										$employees[$type][$id]["index"]["WB_INDEX"]=$employees[$type][$id]["index"]["WB_INDEX"]+$data[$index[$key]];
										$USER_WB=$USER_WB+$data[$index[$key]];
									}
								}
								if($MANAGER_QUESTION_COUNT>0&&($USER_MANAGER/$MANAGER_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["MANAGER_TOTAL"]=$employees[$type][$id]["total"]["MANAGER_TOTAL"]+1;
								}
								if($ENGAGEMENT_QUESTION_COUNT>0&&($USER_ENGAGE/$ENGAGEMENT_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["ENGAGE_TOTAL"]=$employees[$type][$id]["total"]["ENGAGE_TOTAL"]+1;
								}
								if($LEADER_QUESTION_COUNT>0&&($USER_LEADER/$LEADER_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["LEADER_TOTAL"]=$employees[$type][$id]["total"]["LEADER_TOTAL"]+1;
								}
								if($WFH_QUESTION_COUNT>0&&($USER_WFH/$WFH_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["WFH_TOTAL"]=$employees[$type][$id]["total"]["WFH_TOTAL"]+1;
								}
								if($WFO_QUESTION_COUNT>0&&($USER_WFO/$WFO_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["WFO_TOTAL"]=$employees[$type][$id]["total"]["WFO_TOTAL"]+1;
								}
								if($HR_QUESTION_COUNT>0&&($USER_HR/$HR_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["HR_TOTAL"]=$employees[$type][$id]["total"]["HR_TOTAL"]+1;
								}
								if($WB_QUESTION_COUNT>0&&($USER_WB/$WB_QUESTION_COUNT)>3.75){
									$employees[$type][$id]["total"]["WB_TOTAL"]=$employees[$type][$id]["total"]["WB_TOTAL"]+1;
								}
								$employees[$type][$id]["count"]++;
							}
						}
					}
					$count++;
				}
			}
			file_put_contents($dir."/response.json","]",FILE_APPEND);
			foreach($employees as $type => $user_list){
				foreach($user_list as $id => $user_array){
					foreach($employees[$type][$id]["score"] as $key => $value){
						if($employees[$type][$id]["count"]>0)
							$employees[$type][$id]["score"][$key]=($employees[$type][$id]["score"][$key]*100)/$employees[$type][$id]["count"];
						else
						$employees[$type][$id]["score"][$key]=0;
					}
					
					foreach($employees[$type][$id]["total"] as $key => $value){
						if($employees[$type][$id]["count"]>0)
							$employees[$type][$id]["total"][$key]=($employees[$type][$id]["total"][$key]*100)/$employees[$type][$id]["count"];
						else
							$employees[$type][$id]["total"][$key]=0;
					}
					
					if($ENGAGEMENT_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["ENGAGEMENT_INDEX"]=$employees[$type][$id]["index"]["ENGAGEMENT_INDEX"]/($ENGAGEMENT_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["ENGAGEMENT_INDEX"]=0;
						
					if($MANAGER_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["MANAGER_INDEX"]=$employees[$type][$id]["index"]["MANAGER_INDEX"]/($MANAGER_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["MANAGER_INDEX"]=0;
						
					if($LEADER_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["LEADER_INDEX"]=$employees[$type][$id]["index"]["LEADER_INDEX"]/($LEADER_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["LEADER_INDEX"]=0;
						
					if($WFH_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["WFH_INDEX"]=$employees[$type][$id]["index"]["WFH_INDEX"]/($WFH_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["WFH_INDEX"]=0;
						
					if($WFO_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["WFO_INDEX"]=$employees[$type][$id]["index"]["WFO_INDEX"]/($WFO_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["WFO_INDEX"]=0;
						
					if($HR_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["HR_INDEX"]=$employees[$type][$id]["index"]["HR_INDEX"]/($HR_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["HR_INDEX"]=0;
						
					if($WB_QUESTION_COUNT>0&&$employees[$type][$id]["count"]>0)
						$employees[$type][$id]["index"]["WB_INDEX"]=$employees[$type][$id]["index"]["WB_INDEX"]/($WB_QUESTION_COUNT*$employees[$type][$id]["count"]);
					else
						$employees[$type][$id]["index"]["WB_INDEX"]=0;
					
				}
			}
		}
		file_put_contents($dir."/score.json",json_encode($employees,true));
		return $count;		
}
?>
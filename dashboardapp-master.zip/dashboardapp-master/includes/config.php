<?php
define("APP_NAME", "We Matter");
define("PROTOCOL", "https://");
define("WEBSITE_URL", "app.we-matter.com");
define("APP_LOGO",PROTOCOL.WEBSITE_URL."/asset/image/wematter_logo.png");
define("PUBLIC_DIRECTORY", "/home/app/public_html");
define("ROOT_DIRECTORY", "/home/app");
define("APP_EMAIL_ID", "hey@we-matter.com");
define("DB_SERVER", "localhost");
define("DB_USER", "app_db");
define("DB_PASS", "2n8m48re");
define("DB_NAME", "app_db");
define("SUPER_ADMIN_EMAIL", "prashants01@gmail.com");
define("SUPER_ADMIN_PASSWORD", "QEfab7Yivs0C");
define("SELF_REGISTRATION", false);

define("LIME_DB_SERVER", "localhost");
define("LIME_DB_USER", "survey_db");
define("LIME_DB_PASS", "2n8m48re");
define("LIME_DB_NAME", "survey_db");
define("LIME_DB_TABLE_PREFIX", "");//Not Used in Code

define( 'LS_AUTHHASH_SECRET', 'QSOR2ERrwaHcVYzdfMq86kAoCQUrO71G');
define( 'LS_BASEURL', 'https://survey.we-matter.com');
define( 'LS_REMOTE_BASEURL', 'https://survey.we-matter.com/index.php/admin/remotecontrol');
define( 'LS_ADMIN_USERNAME', 'prashants01@gmail.com' );
define( 'LS_PASSWORD', 'QEfab7Yivs0C' );
define( 'ENV', 'prod' );
//define( 'ENV', 'devel' );
$hybridauth_config = [
  'callback' => PROTOCOL.WEBSITE_URL.'/hybridauth/callback.php',
  'providers' => [
   'Google' => [
		'enabled' => false,
		'keys' => [
			'id'     => '...',
			'secret' => '...',
		],
		'scope' => 'email',
	],
	'Facebook' => [
      'enabled' => false,
      'keys' => [
        'id' => '...',
        'secret' => '...',
      ],
    ],
    'Twitter' => [
      'enabled' => false,
      'keys' => [
        'key' => '...',
        'secret' => '...',
      ],
    ],
    'LinkedIn' => [
      'enabled' => false,
      'keys' => [
        'id' => '...',
        'secret' => '...',
      ],
    ],
    
  ],
];

if(isset($_REQUEST["error"])&&$_REQUEST["error"]==="1"){
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
}
if(session_id() == '') {
	session_start();
}
if(isset($_REQUEST["devel"])){
	$_SESSION["devel"]=$_REQUEST["devel"];
}
$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
if(mysqli_connect_errno()) {
die("Database connection failed: " . 
	 mysqli_connect_error() . 
	 " (" . mysqli_connect_errno() . ")"
);
}
require_once(ROOT_DIRECTORY."/vendor/autoload.php");
include(ROOT_DIRECTORY."/includes/codebase/common.php");
include(ROOT_DIRECTORY."/includes/codebase/encryption.php");
include(ROOT_DIRECTORY."/includes/codebase/userauth.php");
include(ROOT_DIRECTORY."/includes/codebase/lime.php");
include(ROOT_DIRECTORY."/includes/codebase/survey.php");
include(ROOT_DIRECTORY."/includes/codebase/mail.php");
include(ROOT_DIRECTORY."/includes/layout/routes.php"); //Build Large Templates Here
include(ROOT_DIRECTORY."/includes/layout/menu.php");   //Build your menu Here
?>
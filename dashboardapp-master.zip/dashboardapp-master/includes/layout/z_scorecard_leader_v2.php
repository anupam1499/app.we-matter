<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo PROTOCOL.WEBSITE_URL."/asset/css/pdf.css";?>" rel="stylesheet" type="text/css" >
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <title>Leader Scorecard</title>
    <script type="text/javascript">
    //   google.charts.load('current', {'packages':['corechart']});
    //   google.charts.setOnLoadCallback(drawChart);

        function init() {
            // google.charts.load('current',
            // {packages: ['corechart']}); 
            google.load("visualization", "44", {packages:["corechart"]});
            var interval = setInterval(function() { 
                if ( google.visualization !== undefined && google.visualization.DataTable !== undefined && google.visualization.BarChart !== undefined ){
                    clearInterval(interval); 
                    window.status = 'ready'; 
                    drawChart(); 
                } 
            }, 100);
        }

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Type', 'Engagement',  {"type":"string", "role":"style"}, 'Destructive Range', 'Serious Range', 'Indifferent Range', 'High Performance Range'],
                ['Team Engagement Score',<?php echo round($scorecard["team"]["ENGAGE_TOTAL"]); ?>, 'color: #C24E00' ,30,15,20,35,],
                ['Organization Overall',<?php echo round($scorecard["organization"]["ENGAGE_TOTAL"]); ?>, 'color: #053b6d' ,30,15,20,35,]
            ]);

            var view = new google.visualization.DataView(data);
            view.setColumns([0, 1,
                            { calc: "stringify",
                                sourceColumn: 1,
                                type: "string",
                                role: "annotation" },2,3,4,5,6]
                            );
            var options = {
                legend: {position: 'none'},
                isStacked: true,
                seriesType: 'steppedArea',
                series: {
                    0:  {type:'bars', visibleInLegend: false},
                    },
                chartArea: {width: '75%'},
                hAxis: {
                    title: '',
                    textStyle: {
                        fontSize: 25,
                        fontName: 'Montserrat',
                        color: '#053b6d',
                    },
                    
                },
                vAxis: {
                    title: 'Score (in %)',
                    titleTextStyle: {
                        fontSize: 40,
                        fontName: 'Montserrat',
                        color: '#053b6d',
                    },
                    textStyle: {
                            fontSize: 25,
                            fontName: 'Montserrat',
                            color: '#053b6d',
                        },
                    minValue: 0,
                    maxValue: 100,
                },
                annotations: {
                    textStyle: {
                        fontSize: 25,
                        fontName: 'Montserrat',
                    },
                },
                bar: {groupWidth: "30%"},
                colors: ['#053b6d', 'red', '#F3C030', '#73B504', '#4582A1']
            };

            var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));

            chart.draw(view, options);

      }
    </script>
    <title>Manager Scorecard</title>
</head>
<body onload="init()">
    <!-- Page 1 -->
    <div class="page">
        <center>
			<h1 style="color:#053b6d;"><? echo $account_name;?></h1>
            <div class="heading">Leader <span style="color: #EE7D1F;">Scorecard</span></div>
            <br>
            <img src="<?echo PROTOCOL.WEBSITE_URL."/asset/image/leader-slide-1.jpg";?>" width="60%"/>
            <div class="name">Leader Name: <?php echo $scorecard["user"]["name"]; ?></div>
            <div class="code">Leader Code: <?php echo $scorecard["user"]["id"]; ?></div>
			<h2 style="color:#f44336">Note: For internal use only. External circulation is not permitted</h2>
        </center>
    </div>
    <!-- Page 2 --; -->
    <div class="page">
        <center>
			<br><br>
            <div class="heading">Team Engagement <span style="color: #EE7D1F;">Score</span></div>
            <br><br>
			<table border="0" style="border:0px;" ><tr style="width:100%" >
			<td style="width:900px;">
			<div id="chart_div" style="width:900px; height: 750px;"></div>
			</td>
			<td style="width:600px;">
				<table class="table">
					<thead>
						<tr>
							<th>Category</th>
							<th>Range</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><span style="color:red;">Destructive Range</span></td>
							<td><span style="color:red;">0 - 30%</span></td>
						</tr>
						<tr>
							<td><span style="color:#F3C030;">Serious Range</span></td>
							<td><span style="color:#F3C030;">31% - 45%</span></td>
						</tr>
						<tr>
							<td><span style="color:#73B504;">Indifferent Range</span></td>
							<td><span style="color:#73B504;">46% - 65%</span></td>
						</tr>
						<tr>
							<td><span style="color:#4582A1;">High Performance Range</span></td>
							<td><span style="color:#4582A1;">66% - 100%</span></td>
						</tr>
					</tbody>
				</table>
			</td>
			</tr>
			</table>
				
            <br><br>
            
        </center>
    </div>
    <!-- Page 3 -->
    <div class="page">
        <center>
			<br><br>
            <div class="heading">Engagement <span style="color: #EE7D1F;">Behaviors</span></div>
            <br><br>
            <table class="table-sm">
                <thead>
                    <tr>
                        <th>Outcome Behaviors</th>
                        <th>Questions</th>
                        <th>Team Score</th>
                        <th>Organization Overall</th>
                    </tr>
                </thead>
                <tbody>
                   <?/*$questions = json_decode('[{"title":"ENGAGE01","outcome":"Promoter","question":"I would highly recommend this organization to a friend seeking employment","hint":"Brand Ambassador"},{"title":"ENGAGE02","outcome":"Persistent","question":"It would take a lot to get me to leave this organization in the next 2 to 3 years","hint":"3 to 5 years Loyalty"},{"title":"ENGAGE03","outcome":"Perseverance","question":"This organization motivates me to contribute more than is normally required to complete my work","hint":"Discretionary Effort"},{"title":"ENGAGE04","outcome":"Passionate","question":"This organization inspires me to be passionate about working here","hint":"Passion for work and job"},{"title":"ENGAGE05","outcome":"Peaceful","question":"The enviornment of the organization makes me feel happy to go back to work after a long weekend","hint":"Joy of work"}]',TRUE);
				   foreach($questions as $question){
					   if(isset($scorecard["team"][$question["title"]])){
				   ?>
                    <tr>
                        <td style="vertical-align: middle;"><?php echo $question["outcome"]."<br>(".$question["hint"].")"; ?></td>
                        <td><?php echo $question["question"]; ?></td>
                        <td>
                            <?php
                                echo round($scorecard["team"][$question["title"]])."%";
                            ?>
                        </td>
                        <td>
                            <?php
                                echo round($scorecard["organization"][$question["title"]])."%";
                            ?>
                        </td>
                    </tr>
				   <?php 
					   }
				   }*/?>
				   <?
				   $question_engage_v1 = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'ENGAGE%'"));
				   foreach($question_engage_v1 as $question){
					   $question_engage_v2[$question["code"]]=$question;
				   }
				   $questions  = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey["survey_id"]."/questions.json"),true);
				   foreach($questions as $question){
					   unset($temp);
					   if(startsWith($question["title"], "ENGAGE")){
						   $temp=$question_engage_v2[$question["title"]];
						   $temp["question"]=$question["question"];
						   $temp["question_order"]=$question["question_order"];
						   $question_engage[]=$temp;
					   }
				   }
				   //$question_engage = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'ENGAGE%'"));
				   foreach($question_engage as $question){
					   if(isset($scorecard["team"][$question["code"]])){
				   ?>
                    <tr>
                        <td style="vertical-align: middle;"><?php echo $question["driver"]."<br>(".$question["hint"].")"; ?></td>
                        <td><?php echo $question["question"]; ?></td>
                        <td>
                            <?php
                                echo round($scorecard["team"][$question["code"]])."%";
                            ?>
                        </td>
                        <td>
                            <?php
                                echo round($scorecard["organization"][$question["code"]])."%";
                            ?>
                        </td>
                    </tr>
				   <?php 
					   }
				   }?>
                </tbody>
            </table>
        </center>
    </div>
	 <!-- Page 4 -->
    <div class="page">
        <br><br>
        <center>
            <div class="heading">Leader <span style="color: #EE7D1F;">Score</span></div>
            <br><br>
			<table class="table-sm">
                <thead>
                    <tr style="background-color: #053b6d;">
						<th colspan="2" style="text-align: center; color: #EE7D1F;">No. of Responses = <?php echo $scorecard["team"]["COUNT"]; ?></th>
                        <th style="color: #EE7D1F;" ><?php echo $scorecard["user"]["name"]; ?> (<?php echo $scorecard["user"]["id"]; ?>)</th>
                        <th style="color: #EE7D1F;" >Organization Overall</th>
                    </tr>
					<tr style="background-color: #EE7D1F;">
						<th colspan="2" style="text-align: center; color: #053b6d;">Leader Index</th>
                        <th style="color: #053b6d;"><?php echo round($scorecard["team"]["LEADER_INDEX"],2);?></th>
                        <th style="color: #053b6d;"><?php echo round($scorecard["organization"]["LEADER_INDEX"],2)?></th>
                    </tr>
                </thead>
                <tbody>
                   <?/*$questions = json_decode('[{"title":"LEADER01","outcome":"Business Confidence","question":"Senior Leadership inspires confidence that our business will succeed"},{"title":"LEADER02","outcome":"Direction","question":"Senior leadership in this organization provides clear direction for the future"},{"title":"LEADER03","outcome":"Communication","question":"Senior leadership communicates effectively and honestly with the employees"},{"title":"LEADER04","outcome":"Purpose","question":"The purpose of the organization inspires me to go beyond what is expected of me at work."},{"title":"LEADER05","outcome":"People Focus","question":"Senior leadership treats employees as the most valued asset of the organization"},{"title":"LEADER06","outcome":"Customer Centricity","question":"The organization supports me to exceed expectations of my internal / external customers"}]',TRUE);*/
				   /*$temp = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'LEADER%'"));
				   foreach($temp as $question){
						$question_leader[$question["code"]] = $question;
				   }*/
				   $question_leader_v1 = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'LEADER%'"));
				   foreach($question_leader_v1 as $question){
					   $question_leader_v2[$question["code"]]=$question;
				   }
				   $questions  = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey["survey_id"]."/questions.json"),true);
				   foreach($questions as $question){
					   unset($temp);
					   if(startsWith($question["title"], "LEADER")){
						   $temp=$question_leader_v2[$question["title"]];
						   $temp["question"]=$question["question"];
						   $temp["question_order"]=$question["question_order"];
						   $question_leader[$question["title"]]=$temp;
					   }
				   }
				   
				   $ordered_leader = array();
				   foreach($question_leader as $question){
					    if(isset($scorecard["team"][$question["code"]])){
							$item["code"] = $question["code"];
							$item["score"] = $scorecard["team"][$question["code"]];
							$item["diff"] = $scorecard["organization"][$question["code"]] - $scorecard["team"][$question["code"]];
							$ordered_leader[] = $item;
						}
				   }
				   $ordered_leader = array_orderby($ordered_leader,"score",SORT_ASC,"diff",SORT_DESC);
				   foreach($question_leader as $question){
					   if(isset($scorecard["team"][$question["code"]])){
				   ?>
                    <tr>
                        <td style="vertical-align: middle;"><?php echo $question["driver"]; ?></td>
                        <td><?php echo $question["question"]; ?></td>
                        <td style="background-color:<?
						//$index = array_search($question["code"],array_keys($ordered_leader));
						/*$index =  $leader_rank[$question["code"]];
						if($index<2){
							echo "#4caf50";
						}else if($index<4){
							echo "#ffc107";
						}else{
							echo "#f44336";
						}*/
						$score = round($scorecard["team"][$question["code"]]);
						if($score>=75){
							echo "#4caf50";
						}else if($score>=55){
							echo "#ffc107";
						}else{
							echo "#f44336";
						}
						?>">
                            <?php
                                echo round($scorecard["team"][$question["code"]])."%";
                            ?>
                        </td>
                        <td>
                            <?php
                                echo round($scorecard["organization"][$question["code"]])."%";
                            ?>
                        </td>
                    </tr>
				   <?php 
					   }
				   }?>
                </tbody>
            </table>
        </center>
    </div>
	<?
	$ordered_leader=array_slice($ordered_leader,0,2);
	$recommended = array();
	foreach($ordered_leader as $item){
		if($scorecard["team"][$item["code"]]<80)
			$recommended[] = $item["code"];
	}
	if(count($recommended)>0){
	?>
	<div class="page">
	 <center>
		<br><br>
		<div class="heading">Recommendation for Critical <span style="color: #EE7D1F;">Leader</span> Driver</div>
		<br><br>
				 <table class="table-xs" style="width:100%">
				
				<?
				foreach($question_leader as $question){
					if(in_array($question["code"],$recommended)&&$scorecard["team"][$question["code"]]<80){
					?>
						 <tr style="background-color: #053b6d;">
							<td style="color:#ffffff;">Driver: <?echo $question["driver"];?></td>
							<td  style="color:#ffffff;"><?echo $question["question"];?></td>
						 </tr>
						<tr>
							<td colspan="2"><?echo $question["description"];?></td>
						</tr>
						<tr  border="0">
							<td colspan="2"  border="0" style="border:0px;"> <br> </td>
						</tr>
					  
					<?
					}
				}
			?>
			</table>
	 </center>
	</div>
	<?
	}
	?>
	<div class="page">
		<br><br><br><br><br><br>
		<center>
			<div class="heading">Copyright <span style="color: #EE7D1F;">Notice</span></div>
			<br><br><br><br>
			<div class="code">Copyright &copy; <?php echo date("Y");?> TheOther 2 Thirds Consulting LLP</div>
			<br><br>
			<div style="width:900px; text-align: left; font-size: 24px;">
				All rights reserved. No part of this document, including but not limited to the employee
				well-being model, WE model, engagement and well-being parameters, may be
				reproduced, distributed, or transmitted in any form or by any means, including
				photocopying, recording, or other electronic or mechanical methods, without the prior
				written permission of the publisher, except in the case of brief quotations embodied in
				critical reviews, with due credits, permitted by copyright law. The model or the content,
				here-in may not be used for carrying out any survey or training program. For permission
				requests, write to the publisher, addressed “Attention: Permissions Coordinator,” at the
				address below.
				<ul>
					<li>TheOther 2 Thirds Consulting LLP</li>
					<li>A-12, Sangam, Juhu Versova Link Road</li>
					<li>Andheri (West), Mumbai – 400053, India.</li>
					<li>support@TheOther2Thirds.com</li>
					<li>www.TheOther2Thirds.com</li>
				<ul>
			</div>
		</center>
	</div>
	<div class="page">
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<center>
			<div class="heading">Thank <span style="color: #EE7D1F;">You</span></div>
			<!--
			<div class="name">Refer to our manual to understand scorecards and action plans.</div>-->
		</center>
	</div> 
</body>
</html>
<?php
function array_orderby()
{
    $args = func_get_args();
    $data = array_shift($args);
    foreach ($args as $n => $field) {
        if (is_string($field)) {
            $tmp = array();
            foreach ($data as $key => $row)
                $tmp[$key] = $row[$field];
            $args[$n] = $tmp;
            }
    }
    $args[] = &$data;
    call_user_func_array('array_multisort', $args);
    return array_pop($args);
}
?>
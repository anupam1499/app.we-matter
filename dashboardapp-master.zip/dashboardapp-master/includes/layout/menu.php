<?
if(isset($_SESSION["admin_logged_in"])){
	$menu = menu("Admin","fas fa-users-cog","#");
	$menu["submenu"][] = menu("Account","fas fa-building",PROTOCOL.WEBSITE_URL."/admin/account.php");
	$menu["submenu"][] = menu("User Login","fas fa-user",PROTOCOL.WEBSITE_URL."/admin/user_login.php");
	$menus[] = $menu;
}
if(isset($_SESSION["admin_logged_in"])||(isset($_SESSION["role_selected"]["role_id"])&&$_SESSION["role_selected"]["role_id"]==="1")){
	$menus[] = menu("Survey Editor","fas fa-building",PROTOCOL.WEBSITE_URL."/user/survey_tool.php");
}
if(isset($_SESSION["role_selected"])){
	if(count($_SESSION["roles_available"])>1){
		$menu = menu("Account","fas fa-building","#");
		foreach($_SESSION["roles_available"] as $role){
			$menu["submenu"][] = menu($role["account_name"]." - ".$role["role_name"],"fas fa-camera",PROTOCOL.WEBSITE_URL."/user/account_picker.php?account_linking_id=".$role["account_linking_id"]);
		}
		$menus[] = $menu;
	}
	$menus[] = menu("Survey","fas fa-list",PROTOCOL.WEBSITE_URL."/account/survey.php");
	if($_SESSION["role_selected"]["role_id"]==="1"){
		$menus[] = menu("User","fas fa-user",PROTOCOL.WEBSITE_URL."/account/user.php");
		$menus[] = menu("Embed","fas fa-tachometer-alt",PROTOCOL.WEBSITE_URL."/account/embed.php");
		$menus[] = menu("External Url","fas fa-link",PROTOCOL.WEBSITE_URL."/account/url.php");
	}
	/*if((isset($_SESSION["map"]["manager_subordinate"])&&$_SESSION["map"]["manager_subordinate"]>0)||(isset($_SESSION["map"]["leader_subordinate"])&&$_SESSION["map"]["leader_subordinate"]>0)||(isset($_SESSION["map"]["dashboard_subordinate"])&&$_SESSION["map"]["dashboard_subordinate"]>0))
	    $menus[] = menu("My Scorecard","fas fa-tachometer-alt",PROTOCOL.WEBSITE_URL."/account/my_scorecard.php");*/
}
if(isset($_SESSION["role_selected"])){
	$embeds = ToArrays(execute_query("SELECT * FROM `embed` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND ((`type` = 1 and `id` = ".mysql_prep($_SESSION["user_id"])." ) OR (`type`=3 AND (".$_SESSION["role_selected"]["role_id"]."=1 OR ".$_SESSION["role_selected"]["role_id"]."=2)) OR  `type` = 2 ) ORDER BY `modified_at` DESC"));
	foreach($embeds as $embed){
		$menus[] = menu($embed["embed_name"],"fas fa-tachometer-alt",PROTOCOL.WEBSITE_URL."/account/embed.php?method=display&embed_id=".$embed["embed_id"]);
	}
	$urls = ToArrays(execute_query("SELECT * FROM `url` WHERE `account_id` = ".mysql_prep($_SESSION["role_selected"]["account_id"])." AND ((`type` = 1 and `id` = ".mysql_prep($_SESSION["user_id"])." ) OR (`type`=3 AND (".$_SESSION["role_selected"]["role_id"]."=1 OR ".$_SESSION["role_selected"]["role_id"]."=2)) OR  `type` = 2 ) ORDER BY `modified_at` DESC"));
	foreach($urls as $url){
		$menus[] = menu($url["url_name"],"fas fa-tachometer-alt",$url["url"]);
	}
}
function menu($name,$icon,$url){
	$item["name"] = $name;
	$item["icon"] = $icon;
	$item["url"] = $url;
	return $item;
}
?>
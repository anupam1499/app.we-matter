<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Manager Scorecard</title>
	<style type="text/css">
		h1,h2 {
		  text-align: center !important;
		}
		.name,.code,.cell{
			text-align: center !important;
		}
		.table-bordered {
		  border-collapse: collapse;
		}
		.table-bordered td,
		.table-bordered th{
		  border: 1px solid #999;
		  padding: 0.5rem;
		  text-align: left;
		}
	</style>
</head>
<body onload="init()">
    <!-- Page 1 -->
    <div class="page">
		<table style="width:100%"><tr style="width:100%"><td style="width:49%" align="left"><img src="<?php echo (isset($account_logo_url)?$account_logo_url:PROTOCOL.WEBSITE_URL."/asset/image/other-logo.png");?>" style="height:50px;"/></td><td  style="width:49%" align="right">  <img src="<?php echo PROTOCOL.WEBSITE_URL."/asset/image/other-logo.png";?>"    style="height:50px;"/></td></tr></table><br><br><br>
        <center>
			<h1 style="color:#053b6d;"><? echo $account_name;?></h1>
            <h1><span style="color: #053b6d;">Manager</span> <span style="color: #EE7D1F;">Scorecard</span></h1>
            <br>
            <img src="<?echo PROTOCOL.WEBSITE_URL."/asset/image/manager-slide-1.jpg"?>"  width="60%"/>
            <div class="name">Manager Name: <?php echo $scorecard["user"]["name"] ?></div>
            <div class="code">Manager Code: <?php echo $scorecard["user"]["id"] ?></div>
			<h2 style="color:#f44336">Note: For internal use only. External circulation is not permitted</h2>
        </center>
    </div> 
    <!-- Page 3 -->
    <div class="page">
       <br><br>
        <center>
            <h1><span style="color: #053b6d;">Engagement </span><span style="color: #EE7D1F;">Behaviors</span></h1>
            <br><br>
            <table class="table-bordered" style="width:100%">
                <thead>
                    <tr style="background-color: #053b6d; color:#ffffff;">
                        <th>Outcome Behaviors</th>
                        <th>Questions</th>
                        <th style="text-align: center;">Team Score<br><?php echo round($scorecard["team"]["ENGAGE_TOTAL"])."%"; ?></th>
                        <th style="text-align: center;">Organization Overall<br><?php echo round($scorecard["organization"]["ENGAGE_TOTAL"])."%"; ?></th>
                    </tr>
                </thead>
                <tbody>
                   <?
				   $question_engage_v1 = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'ENGAGE%'"));
				   foreach($question_engage_v1 as $question){
					   $question_engage_v2[$question["code"]]=$question;
				   }
				   $questions  = json_decode(file_get_contents(ROOT_DIRECTORY."/survey_data/".$survey["survey_id"]."/questions.json"),true);
				   foreach($questions as $question){
					   unset($temp);
					   if(startsWith($question["title"], "ENGAGE")){
						   $temp=$question_engage_v2[$question["title"]];
						   $temp["question"]=$question["question"];
						   $temp["question_order"]=$question["question_order"];
						   $question_engage[]=$temp;
					   }
				   }
				   //$question_engage = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'ENGAGE%'"));
				   foreach($question_engage as $question){
					   if(isset($scorecard["team"][$question["code"]])){
				   ?>
                    <tr>
                        <td style="vertical-align: middle;"><?php echo $question["driver"]."<br>(".$question["hint"].")"; ?></td>
                        <td><?php echo $question["question"]; ?></td>
                        <td class="cell">
                            <?php
                                echo round($scorecard["team"][$question["code"]])."%";
                            ?>
                        </td>
                        <td class="cell">
                            <?php
                                echo round($scorecard["organization"][$question["code"]])."%";
                            ?>
                        </td>
                    </tr>
				   <?php 
					   }
				   }?>
                </tbody>
            </table>
        </center>
    </div>
    <div class="page">
        <br><br>
        <center>
            <h1><span style="color: #053b6d;">Manager</span> <span style="color: #EE7D1F;">Score</span></h1>
            <br><br>
			<?//print_r($scorecard);?>
            <table class="table-bordered" style="width:100%">
                <thead>
                    <tr style="background-color: #053b6d; color:#ffffff;">
                    <th colspan="3" style="text-align: center;">No. of Responses = <?php echo $scorecard["team"]["COUNT"]; ?></th>
                        <th style="text-align: center;"><?php echo $scorecard["user"]["name"]; ?> (<?php echo $scorecard["user"]["id"]; ?>)</th>
                        <th style="text-align: center;">Organization Overall</th>
                    </tr>
                    <tr style="background-color: #EE7D1F;  color:#ffffff;" class="orange-bg">
						<th style="text-align: center;">Category</th>
						<th style="text-align: center;">Driver</th>
                        <th style="text-align: right;">Manager Index</th>
                        <th style="text-align: center;">
                            <?php
                                echo round($scorecard["team"]["MANAGER_INDEX"], 2);
                            ?>
                        </th>
                        <th style="text-align: center;">
                            <?php
                                echo round($scorecard["organization"]["MANAGER_INDEX"], 2);
                            ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
				<?/*$manager_questions = json_decode('{"MANAGER01":"My manager sets clear expectations and goals with me","MANAGER02":"I understand how my work goals relate to the organization’s goals","MANAGER03":"In the last three months I received feedback that helped me to improve my performance","MANAGER04":"I have the resources and information required to deliver my work right","MANAGER05":"I receive appropriate recognition (beyond my pay and benefits) every time I do some good work","MANAGER06":"At work my opinion counts","MANAGER07":"My manager cares about me as a person","MANAGER08":"In the last one year I had the opportunity to learn and grow","MANAGER09":"My manager provides me with valuable guidance and counseling about my career","MANAGER10":"My manager develops a positive team atmosphere"}',TRUE);*/
				$manager_questions_v1 = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'MANAGER%'"));
				foreach($manager_questions_v1 as $question){
					$manager_questions_v2[$question["code"]] = $question;
				}
			   foreach($questions as $question){
				   unset($temp);
				   if(startsWith($question["title"], "MANAGER")){
					   $temp=$manager_questions_v2[$question["title"]];
					   $temp["question"]=$question["question"];
					   $temp["question_order"]=$question["question_order"];
					   $manager_questions[$question["title"]]=$temp;
				   }
			   }
				/*$question_manager = ToArrays(execute_query("SELECT * FROM `question` WHERE `code` like 'MANAGER%'"));
				foreach($question_manager as $question){
					$manager_questions[$question["code"]] = $question;
				}*/
			   $ordered_manager = array();
			   foreach($manager_questions as $question){
					if(isset($scorecard["team"][$question["code"]])){
						$item["code"] = $question["code"];
						$item["score"] = $scorecard["team"][$question["code"]];
						$item["diff"] = $scorecard["organization"][$question["code"]]-$scorecard["team"][$question["code"]];
						$ordered_manager[] = $item;
					}
			   }
			   $ordered_manager = array_orderby($ordered_manager,"score",SORT_ASC,"diff",SORT_DESC);
				?>
					<tr>
						<td rowspan="4" style="vertical-align: middle;" class="table-spanner">Performance</td>
                            <td>
								Goal Setting
							</td>
							<td><?php echo $manager_questions["MANAGER01"]["question"]; ?></td>
							<td class="cell" style="background-color:<?
								$score = round($scorecard["team"]["MANAGER01"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								/*$index = $manager_rank["MANAGER01"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER01"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER01"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td>
								Allignment of goals
							</td>
							<td><?php echo $manager_questions["MANAGER02"]["question"]; ?></td>
                            <td class="cell"  style="background-color:<?
								/*$index = $manager_rank["MANAGER02"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								$score = round($scorecard["team"]["MANAGER02"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER02"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER02"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td>
								Feedback
							</td>
							<td><?php 
								//echo $manager_questions["MANAGER03"]["question"];
									if(isset($scorecard["team"]["MANAGER03"])){
										echo $manager_questions["MANAGER03"]["question"];
									}else if(isset($scorecard["team"]["MANAGER12"])){
										echo $manager_questions["MANAGER12"]["question"];
									}
							?>
							</td>
                            <td class="cell"  style="background-color:<?
								/*if(isset($scorecard["team"]["MANAGER03"]))
									$index = $manager_rank["MANAGER03"];
								else
									$index = $manager_rank["MANAGER12"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								
								if(isset($scorecard["team"]["MANAGER03"]))
									$score = round($scorecard["team"]["MANAGER03"]);
								else
									$score = round($scorecard["team"]["MANAGER12"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    //echo round($scorecard["team"]["MANAGER03"])."%";
									if(isset($scorecard["team"]["MANAGER03"])){
										echo round($scorecard["team"]["MANAGER03"])."%";
									}else if(isset($scorecard["team"]["MANAGER12"])){
										echo round($scorecard["team"]["MANAGER12"])."%";
									}
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    //echo round($scorecard["organization"]["MANAGER03"])."%";
									if(isset($scorecard["organization"]["MANAGER03"])){
										echo round($scorecard["organization"]["MANAGER03"])."%";
									}else if(isset($scorecard["organization"]["MANAGER12"])){
										echo round($scorecard["organization"]["MANAGER12"])."%";
									}
                                ?>
                            </td>
					</tr>
					<tr>
							<td>
								Resource
							</td>
							<td><?php echo $manager_questions["MANAGER04"]["question"]; ?></td>
                            <td  class="cell" style="background-color:<?
								$score = round($scorecard["team"]["MANAGER04"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER04"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER04"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="1" style="vertical-align: middle;" class="table-spanner">Recognition</td>
                            <td>
								Appreciation &amp; Recognition
							</td>
							<td><?php echo $manager_questions["MANAGER05"]["question"]; ?></td>
                            <td  class="cell" style="background-color:<?
								$score = round($scorecard["team"]["MANAGER05"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER05"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER05"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="2" style="vertical-align: middle;" class="table-spanner">Belonging</td>
                            <td>
								Diversity of Thought
							</td>
							<td><?php 
									if(isset($scorecard["team"]["MANAGER06"])){
										echo $manager_questions["MANAGER06"]["question"];
									}else if(isset($scorecard["team"]["MANAGER11"])){
										echo $manager_questions["MANAGER11"]["question"];
									}
								?>
							</td>
                            <td class="cell"  style="background-color:<?
								/*if(isset($scorecard["team"]["MANAGER06"]))
									$index = $manager_rank["MANAGER06"];
								else
									$index = $manager_rank["MANAGER11"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								if(isset($scorecard["team"]["MANAGER06"]))
									$score = round($scorecard["team"]["MANAGER06"]);
								else
									$score = round($scorecard["team"]["MANAGER11"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
									if(isset($scorecard["team"]["MANAGER06"])){
										echo round($scorecard["team"]["MANAGER06"])."%";
									}else if(isset($scorecard["team"]["MANAGER11"])){
										echo round($scorecard["team"]["MANAGER11"])."%";
									}
                                ?>
                            </td>
                            <td class="cell" >
									<?php
									if(isset($scorecard["organization"]["MANAGER06"])){
										echo round($scorecard["organization"]["MANAGER06"])."%";
									}else if(isset($scorecard["organization"]["MANAGER11"])){
										echo round($scorecard["organization"]["MANAGER11"])."%";
									}
                                ?>
                            </td>
					</tr>
					<tr>
							<td>
								Care
							</td>
							<td><?php echo $manager_questions["MANAGER07"]["question"]; ?></td>
                            <td  class="cell" style="background-color:<?
								/*$index = $manager_rank["MANAGER07"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								$score = round($scorecard["team"]["MANAGER07"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER07"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER07"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="2" style="vertical-align: middle;" class="table-spanner">Development</td>
                            <td>
								Learn &amp; Grow
							</td>
							<td><?php 
								//echo $manager_questions["MANAGER08"]["question"];
								if(isset($scorecard["team"]["MANAGER08"])){
									echo $manager_questions["MANAGER08"]["question"];
								}else if(isset($scorecard["team"]["MANAGER13"])){
									echo $manager_questions["MANAGER13"]["question"];
								}
							?>
							</td>
                            <td class="cell"  style="background-color:<?
								/*if(isset($scorecard["team"]["MANAGER08"]))
									$index = $manager_rank["MANAGER08"];
								else
									$index = $manager_rank["MANAGER13"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								if(isset($scorecard["team"]["MANAGER08"]))
									$score = round($scorecard["team"]["MANAGER08"]);
								else
									$score = round($scorecard["team"]["MANAGER13"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    //echo round($scorecard["team"]["MANAGER08"])."%";
									if(isset($scorecard["team"]["MANAGER08"])){
										echo round($scorecard["team"]["MANAGER08"])."%";
									}else if(isset($scorecard["team"]["MANAGER13"])){
										echo round($scorecard["team"]["MANAGER13"])."%";
									}
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    //echo round($scorecard["organization"]["MANAGER08"])."%";
									if(isset($scorecard["organization"]["MANAGER08"])){
										echo round($scorecard["organization"]["MANAGER08"])."%";
									}else if(isset($scorecard["organization"]["MANAGER13"])){
										echo round($scorecard["organization"]["MANAGER13"])."%";
									}
                                ?>
                            </td>
					</tr>
					<tr>
							<td>
								Coaching
							</td>
							<td><?php echo $manager_questions["MANAGER09"]["question"]; ?></td>
                            <td class="cell"  style="background-color:<?
								/*$index = $manager_rank["MANAGER09"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								$score = round($scorecard["team"]["MANAGER09"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER09"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER09"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="1" style="vertical-align: middle;" class="table-spanner">Teamwork</td>
                            <td>
								Positive Team
							</td>
							<td><?php echo $manager_questions["MANAGER10"]["question"]; ?></td>
                            <td class="cell"  style="background-color:<?
								/*$index = $manager_rank["MANAGER10"];
								if($index<4){
									echo "#4caf50";
								}else if($index<7){
									echo "#ffc107";
								}else{
									echo "#f44336";
								}*/
								$score = round($scorecard["team"]["MANAGER10"]);
								if($score>=75)
									echo "#4caf50";
								else if($score>=55)
									echo "#ffc107";
								else
									echo "#f44336";
								?>; color:#ffffff;">
                                <?php
                                    echo round($scorecard["team"]["MANAGER10"])."%";
                                ?>
                            </td>
                            <td class="cell" >
                                <?php
                                    echo round($scorecard["organization"]["MANAGER10"])."%";
                                ?>
                            </td>
					</tr>
                </tbody>
            </table>
        </center>
    </div>
	<?
	$ordered_manager = array_slice($ordered_manager,0,3);
	//print_r($ordered_manager);
	$recommended = array();
	foreach($ordered_manager as $item){
		if($scorecard["team"][$item["code"]]<80)
			$recommended[] = $item["code"];
	}
	//print_r($recommended);
	if(count($recommended)>0){
	?>
	<div class="page">
	 <center>
	 <br><br>
		<h1><span style="color: #053b6d;">Recommendation for Critical </span><span style="color: #EE7D1F;">Manager</span> <span style="color: #053b6d;">Driver</div></h1>
		<br><br>
				 <table class="table-bordered" style="width:100%">
				<?
				foreach($manager_questions as $question){
					//if($manager_rank[$question["code"]]>=7){
					if(in_array($question["code"],$recommended)&&$scorecard["team"][$question["code"]]<80){
					?>
						 <tr style="background-color: #053b6d;">
							<td style="color:#ffffff;">Driver: <?echo $question["driver"];?></td>
							<td  style="color:#ffffff;"><?echo $question["question"];?></td>
						 </tr>
						<tr>
							<td colspan="2"><?echo $question["description"];?></td>
						</tr>
						<tr  border="0">
							<td colspan="2"  border="0" style="border:0px;"> <br> </td>
						</tr>
					  
					<?
					}
				}
			?>
			</table>
	 </center>
	</div>
	<?
	}
	?>
	<div class="page">
        <center>
		    <br><br>
            <h1><span style="color: #053b6d;">Copyright</span> <span style="color: #EE7D1F;">Notice</span></h1>
            <br><br>
            <div class="code">Copyright &copy; <?php echo date("Y");?> TheOther 2 Thirds Consulting LLP</div>
			<br><br>
			<div style="width:900px; text-align: left;">
				All rights reserved. No part of this document, including but not limited to the employee
				well-being model, WE model, engagement and well-being parameters, may be
				reproduced, distributed, or transmitted in any form or by any means, including
				photocopying, recording, or other electronic or mechanical methods, without the prior
				written permission of the publisher, except in the case of brief quotations embodied in
				critical reviews, with due credits, permitted by copyright law. The model or the content,
				here-in may not be used for carrying out any survey or training program. For permission
				requests, write to the publisher, addressed “Attention: Permissions Coordinator,” at the
				address below.
				<ul>
					<li>TheOther 2 Thirds Consulting LLP</li>
					<li>A-12, Sangam, Juhu Versova Link Road</li>
					<li>Andheri (West), Mumbai – 400053, India.</li>
					<li>support@TheOther2Thirds.com</li>
					<li>www.TheOther2Thirds.com</li>
				<ul>
			</div>
        </center>
    </div>
    <div class="page">
        <center>
            <h1><span style="color: #053b6d;">Thank</span> <span style="color: #EE7D1F;">You</span></h1>
            <!--
            <div class="name">Refer to our manual to understand scorecards and action plans.</div>-->
			<br><br><br><br>
			<p>Click the below button to login and download the scorecard</p>
        </center>
    </div> 
</body>
</html>
<?php
function array_orderby(){
    $args = func_get_args();
    $data = array_shift($args);
    foreach ($args as $n => $field) {
        if (is_string($field)) {
            $tmp = array();
            foreach ($data as $key => $row)
                $tmp[$key] = $row[$field];
            $args[$n] = $tmp;
            }
    }
    $args[] = &$data;
    call_user_func_array('array_multisort', $args);
    return array_pop($args);
}
?>
<link rel="stylesheet" href="./style.css" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css" integrity="sha512-6qkvBbDyl5TDJtNJiC8foyEVuB6gxMBkrKy67XpqnIDxyvLLPJzmTjAj1dRJfNdmXWqD10VbJoeN4pOQqDwvRA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


           
 </script>
<div class="card text-white bg-secondary" >
	<div class="card-header bg-dark font-weight-bold" data-toggle="collapse" data-target="#container_filter_group" aria-expanded="false" aria-controls="container_filter_group">
	Filter <span id="filter_text" style="font-size: 60%;"></span>
	</div>
	<div class="collapse" id="container_filter_group">
		<div class="card-body row" id="container_filter">
		</div>
		<div class="card-footer bg-dark">&nbsp;
			<button class="btn btn-success btn-sm float-right mr-2" onclick="filter_apply()" >Apply</button> &nbsp; 
			<button class="btn btn-secondary btn-sm float-right mr-2" onclick="filter_reset()" >Reset</button>
		</div>
	</div>
</div>


<div class="row" >
	<div class="col-sm-12 pt-1" id="dashboard">
		<ul class="nav nav-tabs">
		  <li id="engagement_tab" class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#engagement">Engagement</a>
		  </li>
		  <li id="driver_analysis_tab" class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#driver_analysis">All Driver Analysis</a>
		  </li>
		  <?php if($survey["dashboard_qualitative"]){ ?>
		  <li id="qualitative_tab" class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#qualitative">Qualitative</a>
		  </li>
		  <?php }?>
		  <!--<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#word_cloud">Word Cloud</a>
		  </li>-->
		  <?php if($survey["dashboard_diagnostic"]){ ?>
		  <li id="diagnostic_tab" class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#diagnostic">Diagnostic</a>
		  </li>
		   <?php }?>
		   <li id="heat_map_tab" class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#heat_map">Heat Map</a>
		  </li>
		  <?php 
		   if($survey["comparator"]){?>
		  <li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#comparator">Comparator</a>
		  </li>
		  <?php }?>
		  <? if(($_SESSION["role_selected"]["role_id"]==="1"||$_SESSION["role_selected"]["role_id"]==="2") && $survey['report'] ){?>
			  <li id="reports_tab" class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#report">Reports</a>
			  </li>
          <?}?>
		  <!--<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#thematic">Thematic</a>
		  </li>-->
		</ul>
		<!-- Tab panes -->
		
<div class="tab-content">
  <div class="tab-pane active" id="engagement">
    <div class="engagement">
  		<div class="row">
            <div class="col-lg-4 col-md-12 text-center mt-3">
              <div class="card border-secondary" >
				<div class="dropdown">
                    <i class="fa fa-download mt-2 mr-2" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="float:right;"  onclick="downloadAsImage('enagement_donut_container','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')"></i>
                </div>
                <div class="card-body pb-0" style="height:280px;" id="enagement_donut_container">
                    <canvas id="enagement_donut" style="height:280px;"></canvas>
                </div>
                <div class="card-footer bg-secondary text-white">Distribution of Engagement Level</div>
              </div>
            </div>
            <div class="col-lg-4 col-md-12 text-center mt-3">
                <div class="card border-secondary">
                    <div class="dropdown">
                    <i class="fa fa-download mt-2 mr-2" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="float:right;" onclick="downloadAsImage('prediction_donut_container','<?echo $_SESSION["role_selected"]["account_name"]?>_Prediction')"></i>
	                </div>
                    <div class="card-body pb-0" style="height:280px;" id="prediction_donut_container">
                        <canvas id="prediction_donut" style="height: 280px;"></canvas>
                    </div>
                    <div class="card-footer bg-secondary text-white">Distribution of Prediction Performance</div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 text-center mt-3">
                <div class="card border-secondary">
                  <div class="dropdown">
                    <i class="fa fa-download mt-2 mr-2" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="float:right;" onclick="downloadAsImage('attrition_donut_container','<?echo $_SESSION["role_selected"]["account_name"]?>_Attrition')"></i>
                	</div>
                    <div class="card-body pb-0" style="height:280px;" id="attrition_donut_container">
                        <canvas id="attrition_donut" style="height: 280px;"></canvas>
                    </div>
                    <div class="card-footer bg-secondary text-white">Distribution of Attrition Risk Level</div>
                </div>
            </div>
        </div>
        <!--<div class="row">
            <div class="col-lg-4 col-md-6 text-center mt-3">
            <div class="card border-secondary">
                <div class="card-body pb-0"><h2  style=" white-space:nowrap; overflow:hidden;" id="predicted_high_performance" ></h2></div>
                <div class="card-footer bg-secondary text-white" style="height:72px; overflow:hidden;">
                Predicted High Performance
                </div>
            </div>
            </div>
            <div class="col-lg-4 col-md-6 text-center mt-3">
                <div class="card border-secondary">
                    <div class="card-body pb-0"><h2  style=" white-space:nowrap; overflow:hidden;" id="predicted_performance" ></h2></div>
                    <div class="card-footer bg-secondary text-white" style="height:72px; overflow:hidden;">
                    Predicted Performance
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-center mt-3">
                <div class="card border-secondary">
                    <div class="card-body pb-0"><h2 id="predicted_attrition" style=" white-space:nowrap; overflow:hidden;" ></h2></div>
                    <div class="card-footer bg-secondary text-white" style= "height:72px; overflow:hidden;">
                    Predicted Attrition
                    </div>
                </div>
            </div>
        </div>-->
        <div class="row mt-3">
          <div class="col-lg-3 col-md-6 text-center mt-3">
              <div class="card border-secondary">
                  <div class="card-body pb-0"><h2 id="num_of_reponses_1"  style=" white-space:nowrap; overflow:hidden;" ></h2></div>
                  <div class="card-footer bg-secondary text-white" style="height:72px;"># of Responses</div>
              </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center mt-3">
              <div class="card border-secondary">
                  <div class="card-body pb-0"><h2 id="engagement_perc_1"  style=" white-space:nowrap; overflow:hidden;" ></h2></div>
                  <div class="card-footer bg-secondary text-white" style="height:72px;">Engagement</div>
              </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center mt-3">
              <div class="card border-secondary">
                  <div class="card-body pb-0"><h2 id="engagement_index"  style=" white-space:nowrap; overflow:hidden;" ></h2></div>
                  <div class="card-footer bg-secondary text-white" style="height:72px;">Engagement Index</div>
              </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center mt-3">
              <div class="card border-secondary">
                  <div class="card-body pb-0"><h2 id="positivity_index"  style=" white-space:nowrap; overflow:hidden;" ></h2></div>
                  <div class="card-footer bg-secondary text-white" style="height:72px;">Positivity Index</div>
              </div>
          </div>
        </div>
			
			
				
			
			<hr>
			<div class="row mt-3">
				<div class="col-md-7" >
					<h2 class="text-center" >5P Engaged Behavior: Benchmark with <?echo $_SESSION["role_selected"]["account_name"]?></h2>	
                  <div class="dropdown float-right btn btn-secondary">
                    <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-style:20px" onclick="downloadAsImage('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">
				   </i>
                      <!--<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" onclick="downloadAsImage('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">Image</a>
                        <a class="dropdown-item" onclick="downloadAsPDF('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">PDF</a>
                        <a class="dropdown-item" onclick="exportImageToExcel('benchmarkIndex','benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">Excel</a>
                      </div>-->
                </div>
				</div>
				<div class="col-md-5 text-center" >
					<div class="card border-secondary">
						<div class="card-body pb-0"><h2 id="benchmark_index" ></h2></div>
						<div class="card-footer bg-secondary text-white">Benchmark Index</div>
					</div>
				</div>
			</div>
      		<div class="benchmarkIndex" id="benchmarkIndex">
			<div class="row mt-3">
				<div class="col-md-2 order-md-2 text-center d-none d-md-block" ><i style="color:#e74a3b;" class="far fa-frown fa-3x"></i> <i style="color:#858796;" class="far fa-meh fa-3x"></i> <i style="color:#1cc88a;" class="far fa-grin fa-3x"></i>
				</div>
				<div class="col-md-5 order-md-1  d-none d-md-block text-center" ><?echo $_SESSION["role_selected"]["account_name"]?>
				</div>
				<div class="col-md-5 text-center  d-none d-md-block order-md-3" >
					<span class="text-center" >
						<select id="benchmark_select" class="form-control border-secondary" onchange="benchmark_change();">
							<option value="All" >All Industry</option>
							<option>BFSI</option>
							<option>Consulting and Advisory</option>
							<option>Consumer</option>
							<option>Healthcare and Pharma</option>
							<option>Industrial</option>
							<option>IT/BPO</option>
							<option>Others</option>
							<option>Services Others</option>
						</select>
					</span>
				</div>
			</div>
			<div id="ENGAGE_BENCHMARK_AREA">
				<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center" data-toggle="tooltip"  title="I would highly recommend this organization to a friend seeking employment">Promoter
						<br><small>Brand Ambassador</small>
					</div>
					<div class="col-md-5 order-md-1 text-center"  id="ENGAGE01_CHART" >
					</div>
					
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_ENGAGE01_CHART" >...
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center" data-toggle="tooltip"  title="It would take a lot to get me to leave this organization in the next 3 to 5 years">Persistent
						<br><small>Medium Term Loyalty</small>
					</div>
					<div class="col-md-5 order-md-1 text-center" id="ENGAGE02_CHART"  >...
					</div>
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_ENGAGE02_CHART" >...
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center" data-toggle="tooltip"  title="This organization motivates me to contribute more than is normally required to complete my work">Perseverance
						<br><small>Discretionary Effort</small>
					</div>
					<div class="col-md-5 order-md-1 text-center" id="ENGAGE03_CHART" >...
					</div>				
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_ENGAGE03_CHART">...
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center"  data-toggle="tooltip"  title="This organization inspires me to be passionate about working here">Passionate
						<br><small>Inspiration</small>
					</div>
					<div class="col-md-5 order-md-1 text-center" id="ENGAGE04_CHART" >...
					</div>
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_ENGAGE04_CHART">...
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-md-2 order-md-2 text-center" data-toggle="tooltip"  title="The enviornment of the organization makes me feel happy to go back to work after a long weekend">Peaceful
						<br><small>Stress Free Environment</small>
					</div>
					<div class="col-md-5 order-md-1 text-center" id="ENGAGE05_CHART" >...
					</div>
					
					<div class="col-md-5 order-md-3 text-center" id="BENCHMARK_ENGAGE05_CHART">...
					</div>
				</div>
              <div id="editor">
                
              </div>
		      </div>
			</div>
      	     </div>
			<div class="p-3 m-3"></div>
		  </div>
		  <div class="tab-pane driver_analysis" id="driver_analysis">
			<div class="row mt-3">
				<div id="num_of_reponses_2_card" class="col-md-3 col-sm-6 text-center mt-3">
					<div class="card border-secondary">
						<div class="card-body pb-0"><h2 id="num_of_reponses_2" ></h2></div>
						<div class="card-footer bg-secondary text-white"># of Responses</div>
					</div>
				</div>
				<div id="engagement_perc_2_card" class="col-md-3 col-sm-6 text-center mt-3">
					<div class="card border-secondary">
						<div class="card-body pb-0"><h2 id="engagement_perc_2" ></h2></div>
						<div class="card-footer bg-secondary text-white">Engagement %</div>
					</div>
				</div>
				<div id="engagement_index_2_card" class="col-md-3 col-sm-6 text-center mt-3">
					<div class="card border-secondary">
						<div class="card-body pb-0"><h2 id="engagement_index_2" ></h2></div>
						<div class="card-footer bg-secondary text-white">Engagement Index</div>
					</div>
				</div>
				<div id="driver_text_card" class="col-md-3 col-sm-6 text-center mt-3">
					<div class="card border-secondary">
						<div class="card-body pb-0"><h2 id="driver_index" ></h2></div>
						<div class="card-footer bg-secondary text-white" id="driver_text" >Index</div>
					</div>
				</div> 
				<!--<div class="col-md-3 col-sm-6 text-center"><h2 id="engagement_index_2" ></h2><p>Engagement Index</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="wfh_index" ></h2><p>WFH Index</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="hr_index" ></h2><p>HR Index</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="enagement_perc_2" ></h2><p>Engagement %</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="manager_index" ></h2><p>Manager Index</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="leader_index" ></h2><p>Leader Index</p></div>
				<div class="col-md-3 col-sm-6 text-center"><h2 id="well_being_index" ></h2><p>Well Being Index</p></div>-->
			</div>
			<div class="row mt-3">
				<div class="col-md-6 text-center">
					<select id="driver_selector" class="form-control border-secondary" onchange="driver_selector_change()">
						<option value="ALL" >All</option>
						<option value="HR" >HR</option>
						<option value="LEADER" >Leader</option>
						<option value="MANAGER" >Manager</option>
						<option value="WB" >Well Being</option>
						<option value="WFH" >WFH</option>
						<option value="WFO" >WFO</option>
						<option value="OTHER" >Others</option>
					</select>
				</div>
				<div class="col-md-4 mt-2 text-center">
                  Action Area: <div style="height: 12px;  width: 20px;  display: inline-block; background-color:#087f23;"></div> 
                  Strength <div style="height: 12px;  width: 20px;  display: inline-block; background-color:#ffbf00;"></div> 
                  Caution <div style="height: 12px;  width: 20px;  display: inline-block; background-color:#ba000d;"></div> 
                  Development
               </div>
               <div class="col-md-2 mt-1">
                 <div class="dropdown btn btn-secondary float-right">
                    <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				   </i>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" onclick="downloadAsImage('driver','<?echo $_SESSION["role_selected"]["account_name"]?>_driverAnalysis')">Image</a>
                        <!--<a class="dropdown-item" onclick="downloadAsPDF('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">PDF</a>-->
                        <!--<a class="dropdown-item" onclick="exportImageToExcel('benchmarkIndex','benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">Excel</a>-->
                      </div>
                   </div>
              </div>
			</div>
				<div class="row mt-3" id="driver">
				</div>
			<div class="p-3 m-3"></div>
		  </div>
		  
		  <div class="tab-pane" id="qualitative">
			<div class="row mt-3 mb-0">
				<div class="col-lg-4">
						<label class="mt-3">Open Ended Question</label>
						<select id="open_select" class="form-control" onchange="open_select_change()">
						</select>
					
					<label class="mt-3 mb-0" >Category</label>
					<select id="open_filter" class="form-control" onchange="open_filter_change()">
					</select>
 					<div class="card mt-4">
                      <div class="card-header">
                        <h4>
                          Comments
                        </h4>
                      	<div class="dropdown text-right mt-n4">
                          <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="downloadDivToExcel('open_select','open_filter')" style="font-size:20px">
                          </i>
                   		</div>
                  	</div>
					<div id="open_comment" style="height:300px; overflow:scroll" class="mt-2">
					</div>
                  </div>
				</div>
				<div class="col-lg-8" >
					<div class="card">
                      	<div class="card-header">
                          Word Cloud
                          <div class="dropdown text-right mt-n3">
                          <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:20px" onclick="downloadAsImage('open_wordcloud','<?echo $_SESSION["role_selected"]["account_name"]?>_Word_cloud')">
                          </i>
                   		</div>
                      </div>
					  	<div class="card-body table-responsive" id="open_wordcloud"></div>
					</div>
				</div>
			</div>
		  </div>
		  <!--<div class="tab-pane container" id="word_cloud">...</div>-->
		  <div class="tab-pane diagnostic" id="diagnostic">
			<div class="row mt-3">
				<div class="col-md-4 text-right mt-1">Choose Driver</div>
                <div class="col-md-6">
                    <select id="diagnostic_select" class="form-control" onchange="diagnostic_select_change();">
                    </select>
                </div>
                <div class="col-md-2">
                    <!--<input type="button" value="Download PDF" class="btn btn-primary" onclick="downloadAsPDF('diagnostic','<?echo $_SESSION["role_selected"]["account_name"] ?>_Diagnostic')">-->
                 </div>
			</div>
			<div class="row mt-3">
				<div class="col-lg-8 table-responsive" id="correlation_scatterplot" style="overflow-wrap: break-word;">
				</div>
				<div class="col-lg-4" id="correlation_index">
				</div>
			</div>
			<div class="row mt-3">
				<div class="col-md-12">
				<h4 class="text-center">Prescriptive Plan of Action for All Engagement Drivers</h4>
				</div>
				<div class="col-md-12" id="diagnostic_recommendation">
				</div>
			</div>
		  </div>
		  <div class="tab-pane" id="heat_map">
			<div class="row">
				<div class="col-md-5" >
					<div class="form-group pt-3">
					<label>Drivers</label>
					<select id="heatmap_attribute" class="form-control" onchange="heatmap_change()">
						
					</select>
					</div>
				</div>
				<div class="col-md-5" >
					<div class="form-group pt-3">
					<label>Split based on Demographics</label>
					<select id="heatmap_parameter" class="form-control" onchange="heatmap_change()">
						
					</select>
					</div>
				</div>
              	 <div class="col-md-2 mt-4 pt-3">
                   <div class="dropdown btn btn-secondary">
                     <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:20px">
                     </i>
                     <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                       <a class="dropdown-item" onclick="downloadAsImage('heatmap_table','<?echo $_SESSION["role_selected"]["account_name"]?>_HeatMap')">Image</a>
                       <!--<a class="dropdown-item" onclick="downloadAsPDF('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">PDF</a>-->
                       <a class="dropdown-item" onclick="downloadasExcel('heatmap_table','<?echo $_SESSION["role_selected"]["account_name"]?>_Heat_Map')">Excel</a>
                     </div>
               	</div>
               </div>
			</div>
			<div class="row">
			<div class="col-md-12 double-scroll" id="heatmap_table">
			</div>
			</div>
		  </div>
  
		  <div class="tab-pane" id="report">
			<div class="row mt-3" style="margin:40px">
                   <table class="table">
                    <tr>
                    <th>Report Type</th>
                    <th align="right" style="text-align: right;"></th>
                    </tr>
                    <tr>
                      <td> 
                        Overall Report
                      </td>
                       <td align="right">
                        <button name="download_report" class="btn btn-primary" style="margin:auto" onclick="respond_report('<?php echo $_SESSION['role_selected']['account_name']; 						?>','<?php echo 	$survey['survey_id']; ?>', '<? echo $_SESSION["role_selected"]["account"]["logo_url"];?>',0)">Download</button>
                      </td>
                     </tr>
                    <tr>
                       <td>
                         Unit Report ( Apply the filters before downloading)
                      </td>
                      <td align="right">
                        	<button name="download_report" class="btn btn-primary" style="margin:auto" onclick="respond_report('<?php echo $_SESSION['role_selected']['account_name']; 						?>' ,'<?php echo $survey['survey_id']; ?>','<? echo $_SESSION["role_selected"]["account"]["logo_url"];?>', 1)"> Download</button>
  
                      </td>
                     </tr>
                </table>
			</div> 
		  </div>          
		
		  <!--<div class="tab-pane" id="thematic">
            <div class="row" style="margin:auto;margin-top:30px;width:95%">
                  <div class="col-sm-6" >
                      <div id="chart-container1" class="full-width" style="width:auto;border-radius:25px;padding-bottom:10px"> 
                              <div >
                              <canvas  id="graphCanvas" style="margin:auto"> </canvas>
                              </div>
                              <div style="width: 85%;margin:auto;text-align:center;">
                                 CLICK ON A CHART SECTION TO FILTER  AND CLICK <button type="button" class="btn btn-primary">RESET</button> TO SHOW ALL
                              </div>
                      </div>
              	  </div>
             </div>
             <div class="row" style="margin:auto;margin-top:10px;width:95%">
             	<div id="my_dataviz" style="background-color:#181830;border-radius:25px">
               </div>
             </div>
             <div class="row" style="margin:auto;margin-top:10px;width:95%;background-color:#E8E8E8">
                <div class="col-sm-5"  id="chart-container2" style="background-color:#F07818;border-radius: 25px;">       
                    <div id="chart-container2">
                        <canvas id="themesCanvas"></canvas>
                    </div>
                 </div>
                 <div class="col-sm-7" id="tablediv">
                     <table>
                         <tr>
                         	<th>Comments</th>
                            <th>Detected</th>
                         </tr>
                         <tr>
                              <td>&nbsp</td>
                              <td>&nbsp</td>
                         </tr>
                      </table>
                  </div>
              </div>
		  </div> -->
          
		  <div class="tab-pane" id="comparator">
				<div class="row">
					<div class="col-md-6" >
						<div class="form-group pt-4 float-right">
							<label>Compare with</label>
						</div>
					</div>
					<div class="col-md-6" >
						<div class="form-group pt-3">
							<select id="comparator_survey" class="form-control" onchange="comparator_setup()">
							<option value="0" disabled selected="selected">Select here</option>
							<?php
								$surveys = ToArrays(execute_query("SELECT `survey_id` ,`survey_name` FROM `survey` WHERE `account_id` = ".$_SESSION["role_selected"]["account_id"]." AND `survey_id` != '".mysql_prep($survey["survey_id"])."' AND `survey_group` = 'Employee Satisfaction'"));
								foreach($surveys as $item){
									echo "<option value=\"".$item["survey_id"]."\">".$item["survey_name"]."</option>";
								}
							?>
							</select>
						</div>
					</div>
				</div>
				<div class="row">
				<div class="col-md-5" >
					<div class="form-group pt-3">
					<label>Drivers</label>
					<select id="comparator_attribute" class="form-control" onchange="comparator_change()">
					</select>
					</div>
				</div>
				<div class="col-md-5" >
					<div class="form-group pt-3">
					<label>Split based on Demographics</label>
					<select id="comparator_parameter" class="form-control" onchange="comparator_change()">
					</select>
					</div>
				</div>
                <div class="col-md-2 mt-4 pt-3">
                    <div class="dropdown btn btn-secondary">
                      <i class="fa fa-download" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size:20px">
                     </i>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" onclick="downloadAsImage('comparator_table','<?echo $_SESSION["role_selected"]["account_name"]?>_Comparator')">Image</a>
                        <!--<a class="dropdown-item" onclick="downloadAsPDF('benchmarkIndex','<?echo $_SESSION["role_selected"]["account_name"]?>_Engagement')">PDF</a>-->
                        <a class="dropdown-item" onclick="downloadasExcel('comparator_table','<?echo $_SESSION["role_selected"]["account_name"]?>_Comparator')">Excel</a>
                      </div>
                	</div>
                 </div>  
			</div>
			<div class="row">
				<div class="col-md-12 double-scroll" id="comparator_table">
				</div>
			</div>
		  </div>
          
      </div>
	</div>
</div>

<!--<div id="chatCircle" class="agent-face chat-circle" onclick="openChatbot();">
  <div class="half">
    <img class="agent circle" src="./images/kyaraLogo.jpg" alt="Kyara" />
  </div>
</div>

<div id="popup" class="popup" style="display: none">
<section class="avenue-messenger">
  <div class="menu">
    <div id="menuButton" class="menu button" onclick="closeChatbot();">&#10005;</div>
  </div>
  <div class="chat">
        <div class="agent-face">
          <div class="half">
            <img
              class="agent circle"
              src="./images/kyaraLogo.jpg"
              alt="Kyara"
            />
          </div>
        </div>
        <div class="chat-title">
          <h1><b>Kyara</b></h1>
          <h2>WE-Matter Chat</h2>
        </div>
        <div class="messages">
            <div
              class="messages-content mCSB_container"
              id="messagesContent"
            ></div>
          </div>
        <div class="message-box">
          <textarea
            type="text"
            class="message-input"
            id="messageInput"
            placeholder="Type message..."
          ></textarea>
          <button type="submit" class="message-submit" id="sendButton">
            Send
          </button>
        </div>
  </div>
</section>
</div>

<script>
      function openChatbot() {
        console.log("Open Chatbot");
        console.log(document.getElementById('open_comment').value);
        $("#chatCircle").hide();
        $("#popup").show();
      }
      function closeChatbot() {
        $("#popup").hide();
        $("#chat-circle").show();
      }
</script>-->
  
<script src="./script.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-alpha1/html2canvas.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>
<script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js" integrity="sha512-2hIlk2fL+NNHkULe9gGdma/T5vSYk80U5tvAFSy3dGEl8XD4h2i6frQvHv5B+bm/Itmi8nJ6krAcj5FWFcBGig==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

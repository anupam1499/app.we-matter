<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo PROTOCOL.WEBSITE_URL."/asset/css/pdf.css"?>" rel="stylesheet" type="text/css" >
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <title>Manager Scorecard</title>
    <script type="text/javascript">
    //   google.charts.load('current', {'packages':['corechart']});
    //   google.charts.setOnLoadCallback(drawChart);

        function init() {
            // google.charts.load('current',
            // {packages: ['corechart']}); 
            google.load("visualization", "44", {packages:["corechart"]});
            var interval = setInterval(function() { 
                if ( google.visualization !== undefined && google.visualization.DataTable !== undefined && google.visualization.BarChart !== undefined ){
                    clearInterval(interval); 
                    window.status = 'ready'; 
                    drawChart(); 
                } 
            }, 100);
        }

        function drawChart() {

            var data = google.visualization.arrayToDataTable([
                ['Type', 'Engagement',  {"type":"string", "role":"style"}, 'Destructive Range', 'Serious Range', 'Indifferent Range', 'High Performance Range'],
                ['Team Engagement Score',<?php echo round($scorecard["team"]["ENGAGE_TOTAL"]); ?>, 'color: #C24E00' ,30,15,20,35,],
                ['Organization Overall',<?php echo round($scorecard["organization"]["ENGAGE_TOTAL"]); ?>, 'color: #053b6d' ,30,15,20,35,]
            ]);

            var view = new google.visualization.DataView(data);
            view.setColumns([0, 1,
                            { calc: "stringify",
                                sourceColumn: 1,
                                type: "string",
                                role: "annotation" },2,3,4,5,6]
                            );
            var options = {
                legend: {position: 'none'},
                isStacked: true,
                seriesType: 'steppedArea',
                series: {
                    0:  {type:'bars', visibleInLegend: false},
                    },
                chartArea: {width: '75%'},
                hAxis: {
                    title: '',
                    textStyle: {
                        fontSize: 25,
                        fontName: 'Montserrat',
                        color: '#053b6d',
                    },
                    
                },
                vAxis: {
                    title: 'Score (in %)',
                    titleTextStyle: {
                        fontSize: 40,
                        fontName: 'Montserrat',
                        color: '#053b6d',
                    },
                    textStyle: {
                            fontSize: 25,
                            fontName: 'Montserrat',
                            color: '#053b6d',
                        },
                    minValue: 0,
                    maxValue: 100,
                },
                annotations: {
                    textStyle: {
                        fontSize: 25,
                        fontName: 'Montserrat',
                    },
                },
                bar: {groupWidth: "30%"},
                colors: ['#053b6d', 'red', '#F3C030', '#73B504', '#4582A1']
            };

            var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));

            chart.draw(view, options);

      }
    </script>
    <title>Manager Scorecard</title>
</head>
<body onload="init()">
    <br><br><br><br><br><br>
    <!-- Page 1 -->
    <div class="page">
        <center>
            <div class="heading">Manager <span style="color: #EE7D1F;">Scorecard</span></div>
            <br><br><br><br>
            <img src="<?echo PROTOCOL.WEBSITE_URL."/asset/image/manager-slide-1.jpg"?>"  width="1000"/>
            <div class="name">Manager Name: <?php echo $scorecard["user"]["name"] ?></div>
            <div class="code">Manager Code: <?php echo $scorecard["user"]["id"] ?></span>
        </center>
    </div> 
    <!-- Page 2 --; -->
    <div class="page">
        <br><br><br><br><br><br>
        <center>
            <div class="heading">Team Engagement <span style="color: #EE7D1F;">Score</span></div>
            <br><br>
            <div id="chart_div" style="width: 1000px; height: 500px;"></div>
            <br><br>
            <table class="table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Range</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><span style="color:red;">Destructive Range</span></td>
                        <td><span style="color:red;">0 - 30%</span></td>
                    </tr>
                    <tr>
                        <td><span style="color:#F3C030;">Serious Range</span></td>
                        <td><span style="color:#F3C030;">31% - 45%</span></td>
                    </tr>
                    <tr>
                        <td><span style="color:#73B504;">Indifferent Range</span></td>
                        <td><span style="color:#73B504;">46% - 65%</span></td>
                    </tr>
                    <tr>
                        <td><span style="color:#4582A1;">High Performance Range</span></td>
                        <td><span style="color:#4582A1;">66% - 100%</span></td>
                    </tr>
                </tbody>
            </table>
        </center>
    </div> 
    <!-- Page 3 -->
    <div class="page">
        <br><br><br><br><br><br>
        <center>
            <div class="heading">Engagement <span style="color: #EE7D1F;">Behaviors</span></div>
            <br><br><br><br>
            <table class="table-sm">
                <thead>
                    <tr>
                        <th>Outcome Behaviors</th>
                        <th>Questions</th>
                        <th>Team Score</th>
                        <th>Organization Overall</th>
                    </tr>
                </thead>
                <tbody>
                   <?$questions = json_decode('[{"title":"ENGAGE01","outcome":"Promoter","question":"I would highly recommend this organization to a friend seeking employment"},{"title":"ENGAGE02","outcome":"Persistent","question":"It would take a lot to get me to leave this organization in the next 2 to 3 years"},{"title":"ENGAGE03","outcome":"Perseverance","question":"This organization motivates me to contribute more than is normally required to complete my work"},{"title":"ENGAGE04","outcome":"Passionate","question":"This organization inspires me to be passionate about working here"},{"title":"ENGAGE05","outcome":"Peaceful","question":"The enviornment of the organization makes me feel happy to go back to work after a long weekend"}]',TRUE);
				   foreach($questions as $question){
					   if(isset($scorecard["team"][$question["title"]])){
				   ?>
                    <tr>
                        <td style="vertical-align: middle;"><?php echo $question["outcome"]; ?></td>
                        <td><?php echo $question["question"]; ?></td>
                        <td>
                            <?php
                                echo round($scorecard["team"][$question["title"]])."%";
                            ?>
                        </td>
                        <td>
                            <?php
                                echo round($scorecard["organization"][$question["title"]])."%";
                            ?>
                        </td>
                    </tr>
				   <?php 
					   }
				   }?>
                </tbody>
            </table>
        </center>
    </div>
    <div class="page">
        <br><br>
        <center>
            <div class="heading">Manager <span style="color: #EE7D1F;">Score</span></div>
            <br><br><br><br>
            <table class="table-xs">
                <thead>
                    <tr style="background-color: #053b6d;">
                    <th colspan="2" style="text-align: center;">No. of Responses = <?php echo $scorecard["team"]["COUNT"]; ?></th>
                        <th><?php echo $scorecard["user"]["name"]; ?> (<?php echo $scorecard["user"]["id"]; ?>)</th>
                        <th>Organization Overall</th>
                    </tr>
                    <tr style="background-color: #EE7D1F;" class="orange-bg">
                        <th colspan="2" style="text-align: center;">Manager Index</th>
                        <th>
                            <?php
                                echo round($scorecard["team"]["MANAGER_INDEX"], 2);
                            ?>
                        </th>
                        <th>
                            <?php
                                echo round($scorecard["organization"]["MANAGER_INDEX"], 2);
                            ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
				<?$manager_questions = json_decode('{"MANAGER01":"My manager sets clear expectations and goals with me","MANAGER02":"I understand how my work goals relate to the organization’s goals","MANAGER03":"In the last three months I received feedback that helped me to improve my performance","MANAGER04":"I have the resources and information required to deliver my work right","MANAGER05":"I receive appropriate recognition (beyond my pay and benefits) every time I do some good work","MANAGER06":"At work my opinion counts","MANAGER07":"My manager cares about me as a person","MANAGER08":"In the last one year I had the opportunity to learn and grow","MANAGER09":"My manager provides me with valuable guidance and counseling about my career","MANAGER10":"My manager develops a positive team atmosphere"}',TRUE);?>
					<tr>
						<td rowspan="4" style="vertical-align: middle;" class="table-spanner">Performance</td>
                            <td><?php echo $manager_questions["MANAGER01"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER01"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER01"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td><?php echo $manager_questions["MANAGER02"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER02"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER02"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td><?php echo $manager_questions["MANAGER03"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER03"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER03"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td><?php echo $manager_questions["MANAGER04"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER04"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER04"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="1" style="vertical-align: middle;" class="table-spanner">Recognition</td>
                            <td><?php echo $manager_questions["MANAGER05"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER05"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER05"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="2" style="vertical-align: middle;" class="table-spanner">Belonging</td>
                            <td><?php echo $manager_questions["MANAGER06"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER06"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER06"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td><?php echo $manager_questions["MANAGER07"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER07"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER07"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="2" style="vertical-align: middle;" class="table-spanner">Development</td>
                            <td><?php echo $manager_questions["MANAGER08"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER08"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER08"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
							<td><?php echo $manager_questions["MANAGER09"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER09"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER09"])."%";
                                ?>
                            </td>
					</tr>
					<tr>
						<td rowspan="1" style="vertical-align: middle;" class="table-spanner">Development</td>
                            <td><?php echo $manager_questions["MANAGER10"]; ?></td>
                            <td>
                                <?php
                                    echo round($scorecard["team"]["MANAGER10"])."%";
                                ?>
                            </td>
                            <td>
                                <?php
                                    echo round($scorecard["organization"]["MANAGER10"])."%";
                                ?>
                            </td>
					</tr>
                </tbody>
            </table>
        </center>
    </div>  
    <div class="page">
        <br><br><br><br><br><br>
        <center>
            <div class="heading">Thank <span style="color: #EE7D1F;">You</span></div>
            <br><br><br><br>
            <div class="name">Refer to our manual to understand scorecards and action plans.</div>
        </center>
    </div> 
</body>
</html>
</div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer 
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
	  -->
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->
  <div id="modal" class="modal" tabindex="-1" role="dialog">
	  <div class="modal-dialog  modal-xl" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="modal_title"></h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body" id="modal_body" >
		  </div>
		</div>
	  </div>
	</div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
   <div id="snackbar">Message</div>
	<div id="loading" style="width: 100%; height: 100%; top: 0; left: 0; position: fixed; visibility:hidden; opacity: 0.7; background-color: #000; z-index: 99; text-align: center;">
	  <img id="loading-image" style="height:128px;width:128px;position: absolute;  top: 40vh; left: 45vw; z-index: 100;" src="<?echo PROTOCOL.WEBSITE_URL; ?>/asset/image/loading.svg" alt="Loading..." />
	</div>
    <!-- REQUIRED JS SCRIPTS -->
	<script>
	function loading(status){
		if(status){
			document.getElementById("loading").style.visibility = "visible";
		}else{
			document.getElementById("loading").style.visibility = "hidden";
		}
	}
	function snackbar(text){
		var x = document.getElementById("snackbar");
		x.innerHTML = text;
		x.className = "show";
		setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
	}
	function modal(title,data){
		document.getElementById("modal_title").innerHTML = title;
		document.getElementById("modal_body").innerHTML = data;
		$("#modal").modal();
	}
	function copyToClipboard(text) {
	  var $temp = $("<input>");
	  $("body").append($temp);
	  $temp.val(text).select();
	  document.execCommand("copy");
	  $temp.remove();
	  snackbar("Link is Copied to Clipboard!");
	}
	function scrollTo(id){
		$('html, body').animate({
			scrollTop: $("#"+id).offset().top
		}, 1000);
	}
	function password_change_modal(){
		modal('Change Password',`<div class="input-group mb-3">
		  <input type="Password" name="password" id="password" class="form-control" placeholder="Password" aria-label="Password">
		  <div class="input-group-append">
			<button class="btn btn-success" type="button" onclick="password_change();" >Save</button>
		  </div>
		</div>`);
	}
	function password_change(){
		$("#modal").modal('hide');
		$.post( '/user/userauth.php', { method: "change_password", output: "json",password:document.getElementById("password").value })
		  .done(function( data ) {
			snackbar(data.message);
		}).fail(function(){
			snackbar("Saving Failed");
		});
	}
  </script>
  <!-- Bootstrap core JavaScript-->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="https://cdn.jsdelivr.net/npm/jquery.easing@1.4.1/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.0.7/js/sb-admin-2.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/datatables@1.10.18/media/js/jquery.dataTables.min.js"></script> 
  <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.39.0/build/js/tempusdominus-bootstrap-4.min.js"></script>
  <script>
	/*$(document).ready(function(){
		bytesroute.execute('isVisible', true);
	});
    function tutorial(id){
		bytesroute.execute('run',id, {once: false});
	}*/
</script>
  
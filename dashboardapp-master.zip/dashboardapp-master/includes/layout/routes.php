<?php
//Layout Location
function app_header(){
	return ROOT_DIRECTORY.'/includes/layout/app_header.php';
}
function app_script(){
	return ROOT_DIRECTORY.'/includes/layout/app_script.php';
}
function app_footer(){
	return ROOT_DIRECTORY.'/includes/layout/app_footer.php';
}
function userauth_header(){
	return ROOT_DIRECTORY.'/includes/layout/userauth_header.php';
}
function userauth_footer(){
	return ROOT_DIRECTORY.'/includes/layout/userauth_footer.php';
}
?>